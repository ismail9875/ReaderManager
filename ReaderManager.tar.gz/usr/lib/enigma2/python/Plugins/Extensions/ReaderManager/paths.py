# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os

# ─── توافق Py2/Py3 للـ open مع encoding ───
try:
    from io import open
except ImportError:
    pass


CONFIG_DIR  = "/etc/tuxbox/config"
OSCAM_FILE  = os.path.join(CONFIG_DIR, "oscam.server")
NCAM_FILE   = os.path.join(CONFIG_DIR, "ncam.server")

OSCAM_TEMPLATE = """# 
# ======================================================
# ==== oscam.server - created by ReaderManager ====
# ======================================================

[reader]
label                         = emulator
protocol                      = emu
device                        = emu
caid                          = 0500,0604,090F,0E00,1010,1801,2600,2602,2610,4AE1
detect                        = cd
ident                         = 0500:000000,007400,007800,021110,023800;0604:000000;090F:000000;0E00:000000;1010:000000;1801:000000,001101,002111,007301;2600:000000;2602:000000;2610:000000;4AE1:000011,000014,0000FE
group                         = 1
emmcache                      = 2,1,2,1
emu_auproviders               = 0604:010200;0E00:000000;1010:000000;2610:000000;4AE1:000011,000014,0000FE
"""

NCAM_TEMPLATE = """#
# ======================================================
# ==== ncam.server - created by ReaderManager ====
# ======================================================

[reader]
label                         = emulator
protocol                      = emu
device                        = emu
caid                          = 0500,0604,090F,0E00,1010,1801,2600,2602,2610,4AE1
detect                        = cd
ident                         = 0500:000000,007400,007800,021110,023800;0604:000000;090F:000000;0E00:000000;1010:000000;1801:000000,001101,002111,007301;2600:000000;2602:000000;2610:000000;4AE1:000011,000014,0000FE
group                         = 1
emmcache                      = 2,1,2,1
emu_auproviders               = 0604:010200;0E00:000000;1010:000000;2610:000000;4AE1:000011,000014,0000FE
"""


def _ensure_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
            return True
        except Exception as e:
            try:
                print("[paths] mkdir failed for %s: %s" % (path, e))
            except Exception:
                pass
            return False
    return True


def _create_file_if_missing(path, template):
    if os.path.exists(path):
        return False
    try:
        with open(path, "w") as f:
            f.write(template)
        try:
            os.chmod(path, 0o644)
        except Exception:
            pass
        return True
    except Exception as e:
        try:
            print("[paths] write failed for %s: %s" % (path, e))
        except Exception:
            pass
        return False


def bootstrap():
    dir_created   = _ensure_dir(CONFIG_DIR)
    oscam_created = _create_file_if_missing(OSCAM_FILE, OSCAM_TEMPLATE)
    ncam_created  = _create_file_if_missing(NCAM_FILE,  NCAM_TEMPLATE)
    return {
        "config_dir": CONFIG_DIR,
        "oscam_file": OSCAM_FILE,
        "ncam_file":  NCAM_FILE,
        "created": {
            "dir":   dir_created,
            "oscam": oscam_created,
            "ncam":  ncam_created,
        },
    }


def get_oscam_path():
    return OSCAM_FILE


def get_ncam_path():
    return NCAM_FILE