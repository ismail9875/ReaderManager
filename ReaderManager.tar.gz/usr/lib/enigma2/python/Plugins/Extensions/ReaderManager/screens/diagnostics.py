# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import time as _time
import threading

print("[Diagnostics] Module loading...")

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.MenuList import MenuList
from Components.config import config
from Tools.LoadPixmap import LoadPixmap

from enigma import (
    eListboxPythonMultiContent, gFont, eTimer,
    RT_HALIGN_LEFT, RT_HALIGN_CENTER, RT_HALIGN_RIGHT,
    RT_VALIGN_CENTER,
)

print("[Diagnostics] Basic imports OK")

# MultiContent
try:
    from Components.MultiContent import (
        MultiContentEntryText,
        MultiContentEntryRectangle,
        MultiContentEntryProgress,
        MultiContentEntryPixmapAlphaBlend,
    )
    HAS_MULTI = True
    print("[Diagnostics] MultiContent OK (full)")
except ImportError:
    try:
        from Components.MultiContent import (
            MultiContentEntryText,
            MultiContentEntryRectangle,
            MultiContentEntryPixmapAlphaTest as MultiContentEntryPixmapAlphaBlend,
        )
        MultiContentEntryProgress = None
        HAS_MULTI = True
        print("[Diagnostics] MultiContent OK (partial)")
    except ImportError as e:
        HAS_MULTI = False
        MultiContentEntryText = None
        MultiContentEntryRectangle = None
        MultiContentEntryProgress = None
        MultiContentEntryPixmapAlphaBlend = None
        print("[Diagnostics] MultiContent FAILED: %s" % e)

from ..utils import logger
from ..utils import oscamapi
from ..utils import ncamapi
from ..core.softcam_detect import (
    detect_active_softcam, is_oscam_active, is_ncam_active,
    get_status_for_active
)
from ..core.softcam_paths import (
    list_available_softcams, tag_for_path,
    detect_reader_file, detect_config_dir,
)
from ..utils.reader_stats import (
    collect_all_stats, extract_reader_stats,
    top_fastest, top_most_providing,
    top_best_success_rate, top_worst_failures, top_cards,
    top_by_score, get_fastest_reader, summary,
)

try:
    from ..utils.reader_bench import (
        bench_all_readers, apply_bench_to_readers,
    )
    HAS_BENCH = True
    print("[Diagnostics] reader_bench OK")
except ImportError as e:
    HAS_BENCH = False
    bench_all_readers = None
    apply_bench_to_readers = None
    print("[Diagnostics] reader_bench MISSING: %s" % e)

from ..utils.skin_loader import get_screen_skin

# ═══════════════════════════════════════════════════════════════════
#  الألوان
# ═══════════════════════════════════════════════════════════════════
COLOR_TEXT       = "#EAF2FF"
COLOR_HEADER     = "#FFC93C"
COLOR_LABEL      = "#88DDFF"
COLOR_EXCELLENT  = "#22DD66"
COLOR_GOOD       = "#A8E63C"
COLOR_AVERAGE    = "#FFC93C"
COLOR_WEAK       = "#FF8C42"
COLOR_BAD        = "#E64545"
COLOR_VALUE      = "#FFFFFF"
COLOR_BAR_BG     = "#1A2F55"
COLOR_BG_ROW1    = "#0E1E3C"
COLOR_BG_ROW2    = "#11284A"
COLOR_BG_HDR     = "#0A2440"
COLOR_BORDER     = "#1E90FF"
COLOR_ICON       = "#88DDFF"


TEXT_ICONS = {
    "online":    "●",
    "offline":   "○",
    "ok":        "✓",
    "fail":      "✗",
    "total":     "Σ",
    "fastest":   "⚡",
    "champion":  "★",
    "readers":   "▤",
    "providers": "▤",
    "cards":     "▤",
    "arrow":     "▶",
}


def _quality_color(rate):
    try:
        r = float(rate)
    except (ValueError, TypeError):
        r = 0.0
    if r >= 90:
        return COLOR_EXCELLENT
    if r >= 75:
        return COLOR_GOOD
    if r >= 50:
        return COLOR_AVERAGE
    if r >= 25:
        return COLOR_WEAK
    return COLOR_BAD


def _speed_color(ms):
    try:
        v = float(ms)
    except (ValueError, TypeError):
        v = 0.0
    if v <= 0:
        return COLOR_TEXT
    if v < 50:
        return COLOR_EXCELLENT
    if v < 150:
        return COLOR_GOOD
    if v < 400:
        return COLOR_AVERAGE
    if v < 800:
        return COLOR_WEAK
    return COLOR_BAD


# ═══════════════════════════════════════════════════════════════════
#  IconManager
# ═══════════════════════════════════════════════════════════════════
class IconManager(object):
    ICONS = {
        "online":       "status_online.png",
        "offline":      "status_offline.png",
        "ok":           "status_ok.png",
        "fail":         "status_fail.png",
        "total":        "stat_total.png",
        "fastest":      "icon_fastest.png",
        "champion":     "icon_champion.png",
        "readers":      "icon_readers.png",
        "providers":    "icon_providers.png",
        "cards":        "icon_cards.png",
        "arrow":        "icon_arrow.png",
    }

    def __init__(self, icons_dir=None):
        self._dir = icons_dir or self._resolve_dir()
        self._cache = {}
        self._preload()

    def _resolve_dir(self):
        candidates = []
        try:
            here = os.path.dirname(os.path.abspath(__file__))
            plugin_dir = os.path.dirname(here)
            candidates.append(os.path.join(plugin_dir, "icons"))
            candidates.append(os.path.join(plugin_dir, "images", "icons"))
        except Exception:
            pass
        candidates += [
            "/usr/lib/enigma2/python/Plugins/Extensions/"
            "ReaderManager/icons",
            "/usr/lib/enigma2/python/Plugins/Extensions/"
            "OscamReaderManager/icons",
        ]
        for c in candidates:
            if os.path.isdir(c):
                logger.log("Diagnostics", "Icons dir: %s" % c)
                return c
        logger.log("Diagnostics", "No icons dir — using fallback")
        return None

    def _preload(self):
        if not self._dir:
            return
        for key, fname in self.ICONS.items():
            path = os.path.join(self._dir, fname)
            if not os.path.isfile(path):
                self._cache[key] = None
                continue
            try:
                pix = LoadPixmap(path)
                self._cache[key] = pix if pix else None
            except Exception as e:
                logger.log("Diagnostics",
                           "icon load failed %s: %s" % (fname, e))
                self._cache[key] = None

    def get(self, key):
        return self._cache.get(key)

    def has(self, key):
        return self._cache.get(key) is not None

from ..utils.skin_loader import load_screen_skin

# ═══════════════════════════════════════════════════════════════════
#  DiagnosticsScreen — 1920×1080 + Mini TV + ECM Info
# ═══════════════════════════════════════════════════════════════════


class DiagnosticsScreen(Screen):
    screen_name = "Diagnostics"



    SECTIONS = [
        ("overview",  "Overview — All Readers"),
        ("fastest",   "Fastest Readers (real HTTP response)"),
        ("providing", "Most Providing (by ECM count)"),
        ("success",   "Best Success Rate (decoded / total)"),
        ("failures",  "Worst Failures (ECM no-k)"),
        ("cards",     "Most Cards (readers with cards)"),
        ("champion",  "Champion — Best Overall"),
    ]

    # ═══════════════════════════════════════════════════════════════
    #  الأبعاد
    # ═══════════════════════════════════════════════════════════════
    TABLE_W       = 760
    ROW_H         = 50
    HDR_H         = 46
    SEP_H         = 8
    SPACE_H       = 14

    COL_ICON_X   = 8
    COL_ICON_W   = 44
    COL_LABEL_X  = 60
    COL_LABEL_W  = 240
    COL_ECM_X    = 306
    COL_ECM_W    = 90
    COL_OK_X     = 400
    COL_OK_W     = 70
    COL_RATE_X   = 476
    COL_RATE_W   = 100
    COL_BAR_X    = 580
    COL_BAR_W    = 176

    ICON_SIZE    = 32

    # Bench
    BENCH_CACHE_TTL  = 30
    BENCH_SAMPLES    = 3
    BENCH_TIMEOUT    = 2.0
    BENCH_PARALLEL   = 4

    # ECM info
    ECM_FILE         = "/tmp/ecm.info"
    ECM_POLL_MS      = 500





    def __init__(self, session):
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        print("[Diagnostics] === __init__ STARTED ===")
        try:
            Screen.__init__(self, session)
            self.session = session

            self._icons = IconManager()

            self["active_cam"]   = Label("")
            self["page_info"]    = Label("")
            self["stats_title"]  = Label("Loading...")
            self["status"]       = Label("Collecting stats...")
            self["softcam_info"] = Label("Loading active softcam...")

            # ⭐ حقول ECM
            self["ecm_reader"]   = Label("Reader:    -")
            self["ecm_protocol"] = Label("Protocol:  -")
            self["ecm_time"]     = Label("ECM Time:  -")
            self["ecm_cw0"]      = Label("CW0:       -")
            self["ecm_cw1"]      = Label("CW1:       -")

            self["key_red"]    = Button("Close")
            self["key_green"]  = Button("Refresh")
            self["key_yellow"] = Button("Next")
            self["key_blue"]   = Button("Details")

            self["stats_list"] = MenuList([], content=eListboxPythonMultiContent)

            try:
                self["stats_list"].l.setItemHeight(self.ROW_H)
                print("[Diagnostics] setItemHeight(%d) OK" % self.ROW_H)
            except Exception as e:
                print("[Diagnostics] setItemHeight failed: %s" % e)

            try:
                self["stats_list"].l.setItemWidth(self.TABLE_W)
            except Exception:
                pass

            self["stats_list"].l.setFont(0, gFont("Regular", 24))
            self["stats_list"].l.setFont(1, gFont("Regular", 20))
            self["stats_list"].l.setFont(2, gFont("Regular", 18))
            self["stats_list"].l.setBuildFunc(self._build_row)

            self._active_softcam = None
            self._stats = []
            self._section_idx = 0
            self._closing = False
            self._timers = []
            self._rows = []
            self._last_error = ""

            self._bench_cache = {}
            self._bench_cache_time = 0
            self._bench_running = False

            # ⭐ ECM timer
            self._ecm_timer = None

            self["actions"] = ActionMap(
                ["OkCancelActions", "ColorActions", "DirectionActions"],
                {
                    "ok":     self.next_section,
                    "cancel": self.close,
                    "red":    self.close,
                    "green":  self.refresh,
                    "yellow": self.next_section,
                    "blue":   self.show_details,
                    "left":   self.prev_section,
                    "right":  self.next_section,
                    "up":     self.stats_up,
                    "down":   self.stats_down,
                }, -1)

            self.onLayoutFinish.append(self._on_start)

            print("[Diagnostics] === __init__ COMPLETED ===")
        except Exception as e:
            import traceback
            print("[Diagnostics] __init__ FAILED: %s" % e)
            print(traceback.format_exc())
            raise

    # ══════════════════════════════════════════════════════════════
    #  ⭐ ECM Info — Timer + Parser
    # ══════════════════════════════════════════════════════════════
    def _start_ecm_timer(self):
        """يبدأ timer لقراءة /tmp/ecm.info."""
        try:
            from enigma import eTimer
            self._ecm_timer = eTimer()
            self._ecm_timer.callback.append(self._read_ecm_info)
            self._ecm_timer.start(self.ECM_POLL_MS, False)
            # اقرأ فوراً
            self._read_ecm_info()
            print("[Diagnostics] ECM timer started (%d ms)"
                  % self.ECM_POLL_MS)
        except Exception as e:
            logger.log("Diagnostics", "_start_ecm_timer: %s" % e)

    def _read_ecm_info(self):
        """يقرأ /tmp/ecm.info ويعرضه."""
        if self._closing:
            return

        try:
            if not os.path.exists(self.ECM_FILE):
                self._set_ecm_values(
                    reader="(no ECM)",
                    protocol="-",
                    ecm_time="-",
                    cw0="-",
                    cw1="-")
                return

            with open(self.ECM_FILE, "r") as f:
                content = f.read()

            data = self._parse_ecm_info(content)
            self._set_ecm_values(
                reader=data.get("reader", "-"),
                protocol=data.get("protocol", "-"),
                ecm_time=data.get("ecm_time", "-"),
                cw0=data.get("cw0", "-"),
                cw1=data.get("cw1", "-"))

        except Exception as e:
            logger.log("Diagnostics", "_read_ecm_info: %s" % e)

    def _parse_ecm_info(self, content):
        """يحلل محتوى /tmp/ecm.info."""
        result = {
            "reader":   "-",
            "protocol": "-",
            "ecm_time": "-",
            "cw0":      "-",
            "cw1":      "-",
        }

        if not content:
            return result

        try:
            for line in content.split("\n"):
                line = line.strip()
                if not line:
                    continue

                low = line.lower()

                # reader
                if low.startswith("reader:"):
                    result["reader"] = line.split(":", 1)[1].strip()

                # protocol
                elif low.startswith("protocol:"):
                    result["protocol"] = line.split(":", 1)[1].strip()

                # ecm time
                elif low.startswith("ecm time:"):
                    val = line.split(":", 1)[1].strip()
                    try:
                        f = float(val)
                        # إذا كانت أقل من 10 → ثواني → ms
                        if f < 10:
                            f = f * 1000
                        result["ecm_time"] = "%.0f ms" % f
                    except (ValueError, TypeError):
                        result["ecm_time"] = val

                # cw0
                elif low.startswith("cw0:"):
                    result["cw0"] = line.split(":", 1)[1].strip().upper()

                # cw1
                elif low.startswith("cw1:"):
                    result["cw1"] = line.split(":", 1)[1].strip().upper()

        except Exception as e:
            logger.log("Diagnostics", "_parse_ecm_info: %s" % e)

        return result

    def _set_ecm_values(self, reader, protocol, ecm_time, cw0, cw1):
        """يُحدّث قيم ECM في الواجهة."""
        try:
            self["ecm_reader"].setText(
                "Reader:    %s" % (reader or "-"))
            self["ecm_protocol"].setText(
                "Protocol:  %s" % (protocol or "-"))
            self["ecm_time"].setText(
                "ECM Time:  %s" % (ecm_time or "-"))
            self["ecm_cw0"].setText(
                "CW0:       %s" % (cw0 or "-"))
            self["ecm_cw1"].setText(
                "CW1:       %s" % (cw1 or "-"))
        except Exception as e:
            logger.log("Diagnostics", "_set_ecm_values: %s" % e)

    # ══════════════════════════════════════════════════════════════
    #  MultiContent Build
    # ══════════════════════════════════════════════════════════════
    def _add_icon(self, res, key, x, y, size=None):
        if size is None:
            size = self.ICON_SIZE
        pix = self._icons.get(key)
        if pix:
            res.append(MultiContentEntryPixmapAlphaBlend(
                pos=(x, y), size=(size, size), png=pix))
            return True
        text = TEXT_ICONS.get(key, "?")
        res.append(MultiContentEntryText(
            pos=(x, y), size=(size, size),
            font=1,
            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            color=COLOR_ICON, color_sel=COLOR_VALUE,
            text=text))
        return False

    def _build_row(self, item):
        if isinstance(item, tuple):
            row = item[0]
        else:
            row = item

        if not isinstance(row, dict):
            return [None, MultiContentEntryText(
                pos=(0, 0), size=(self.TABLE_W, self.ROW_H),
                font=1, color=COLOR_TEXT, text=str(row))]

        rtype = row.get("type", "row")
        res = [row]

        if rtype == "header":
            res.append(MultiContentEntryRectangle(
                pos=(0, 0), size=(self.TABLE_W, self.HDR_H),
                backgroundColor=COLOR_BG_HDR, cornerRadius=6))
            res.append(MultiContentEntryText(
                pos=(18, 0), size=(self.TABLE_W - 60, self.HDR_H),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                color=COLOR_HEADER, color_sel=COLOR_HEADER,
                text=row.get("text", "")))
            hdr_icon = row.get("icon")
            if hdr_icon:
                self._add_icon(res, hdr_icon,
                               self.TABLE_W - 42,
                               (self.HDR_H - self.ICON_SIZE) // 2,
                               self.ICON_SIZE)
            return res

        if rtype == "sep":
            res.append(MultiContentEntryRectangle(
                pos=(0, self.SEP_H // 2 - 1),
                size=(self.TABLE_W, 2),
                backgroundColor=COLOR_BORDER))
            return res

        if rtype == "space":
            return res

        bg = COLOR_BG_ROW1 if row.get("even") else COLOR_BG_ROW2
        res.append(MultiContentEntryRectangle(
            pos=(0, 0), size=(self.TABLE_W, self.ROW_H),
            backgroundColor=bg,
            backgroundColorSelected=COLOR_BG_ROW2,
            cornerRadius=4))

        icon_key = row.get("icon_key")
        if icon_key:
            icon_y = (self.ROW_H - self.ICON_SIZE) // 2
            self._add_icon(res, icon_key,
                           self.COL_ICON_X, icon_y,
                           self.ICON_SIZE)
        else:
            res.append(MultiContentEntryText(
                pos=(self.COL_ICON_X, 0),
                size=(self.COL_ICON_W, self.ROW_H),
                font=1,
                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                color=row.get("icon_color", COLOR_ICON),
                color_sel=row.get("icon_color", COLOR_ICON),
                text=row.get("icon_text", "")))

        res.append(MultiContentEntryText(
            pos=(self.COL_LABEL_X, 0),
            size=(self.COL_LABEL_W, self.ROW_H),
            font=1,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=COLOR_LABEL, color_sel=COLOR_VALUE,
            text=row.get("label", "?")))

        val_color = row.get("ecm_color", COLOR_VALUE)
        res.append(MultiContentEntryText(
            pos=(self.COL_ECM_X, 0),
            size=(self.COL_ECM_W, self.ROW_H),
            font=1,
            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
            color=val_color, color_sel=val_color,
            text=str(row.get("ecm", "0"))))

        res.append(MultiContentEntryText(
            pos=(self.COL_OK_X, 0),
            size=(self.COL_OK_W, self.ROW_H),
            font=1,
            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
            color=COLOR_EXCELLENT, color_sel=COLOR_EXCELLENT,
            text=str(row.get("ok", ""))))

        rate = row.get("rate", 0.0)
        rate_color = _quality_color(rate)
        rate_text = "%.1f%%" % rate if rate > 0 else "—"
        res.append(MultiContentEntryText(
            pos=(self.COL_RATE_X, 0),
            size=(self.COL_RATE_W, self.ROW_H),
            font=1,
            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
            color=rate_color, color_sel=rate_color,
            text=rate_text))

        if MultiContentEntryProgress and row.get("show_bar", True):
            percent_int = int(round(rate))
            percent_int = max(0, min(100, percent_int))
            bar_y = (self.ROW_H - 22) // 2
            res.append(MultiContentEntryProgress(
                pos=(self.COL_BAR_X, bar_y),
                size=(self.COL_BAR_W, 22),
                percent=percent_int,
                borderWidth=1,
                borderColor=COLOR_BAR_BG,
                foreColor=rate_color,
                backColor=COLOR_BAR_BG,
                cornerRadius=5))
        elif row.get("show_bar", True):
            bar_filled = int(round(rate / 100.0 * self.COL_BAR_W))
            bar_filled = max(0, min(self.COL_BAR_W, bar_filled))
            bar_y = (self.ROW_H - 22) // 2
            res.append(MultiContentEntryRectangle(
                pos=(self.COL_BAR_X, bar_y),
                size=(self.COL_BAR_W, 22),
                backgroundColor=COLOR_BAR_BG, cornerRadius=5))
            if bar_filled > 0:
                res.append(MultiContentEntryRectangle(
                    pos=(self.COL_BAR_X, bar_y),
                    size=(bar_filled, 22),
                    backgroundColor=rate_color, cornerRadius=5))

        return res

    # ══════════════════════════════════════════════════════════════
    #  Lifecycle
    # ══════════════════════════════════════════════════════════════
    def _on_start(self):
        print("[Diagnostics] === _on_start CALLED ===")
        logger.log("Diagnostics", "=== _on_start CALLED ===")

        # ⭐ ابدأ ECM timer
        self._start_ecm_timer()

        # البيانات
        self._refresh_all()

    def refresh(self):
        print("[Diagnostics] === refresh CALLED ===")
        self._bench_cache = {}
        self._bench_cache_time = 0
        self._refresh_all()

    def _refresh_all(self):
        try:
            self["status"].setText("Refreshing...")
            self._load_active_softcam()
            self._load_stats_async()
        except Exception as e:
            logger.log("Diagnostics", "_refresh_all: %s" % e)

    # ══════════════════════════════════════════════════════════════
    #  Active SoftCam
    # ══════════════════════════════════════════════════════════════
    def _load_active_softcam(self):
        try:
            self._active_softcam = detect_active_softcam()
        except Exception as e:
            print("[Diagnostics] detect_active_softcam failed: %s" % e)
            self._active_softcam = None

        if not self._active_softcam:
            self["softcam_info"].setText(
                "No active softcam\n"
                "detected on system.")
            self["active_cam"].setText("Active: (none)")
            self["page_info"].setText("0 readers")
            return

        sc = self._active_softcam
        name = sc.get("name", "?")
        version = sc.get("version", "?")
        path = sc.get("path", "?")
        pid = sc.get("pid", "?")
        status = get_status_for_active()

        config_dir = sc.get("config_dir", "?")
        reader_file = sc.get("reader_file", "?")

        if not config_dir or config_dir == "?":
            try:
                config_dir = detect_config_dir(name) or "?"
            except Exception:
                config_dir = "?"
        if not reader_file or reader_file == "?":
            try:
                reader_file = detect_reader_file(name) or "?"
            except Exception:
                reader_file = "?"

        lines = []
        lines.append("Name:")
        lines.append("  %s" % name[:26])
        lines.append("")
        lines.append("Version:")
        lines.append("  %s" % (version[:26] if version else "-"))
        lines.append("")
        lines.append("PID:")
        lines.append("  %s" % pid)
        lines.append("")
        lines.append("Binary:")
        lines.append("  %s" % self._short_path(path, 26))
        lines.append("")
        lines.append("Config dir:")
        lines.append("  %s" % self._short_path(config_dir, 26))
        lines.append("")
        lines.append("Reader file:")
        lines.append("  %s" % self._short_path(reader_file, 26))
        lines.append("")
        lines.append("Readers loaded:")
        lines.append("  %d" % len(self._stats))
        lines.append("")
        lines.append("Status:")
        lines.append("  %s" % status[:26])

        self["softcam_info"].setText("\n".join(lines))
        self["active_cam"].setText(
            "Active: %s  |  PID %s" % (name[:30], pid))
        self["page_info"].setText(
            "%d reader(s)" % len(self._stats))

    def _short_path(self, path, max_len=30):
        if not path or path == "?":
            return "-"
        if len(path) <= max_len:
            return path
        return "…" + path[-(max_len - 1):]

    # ══════════════════════════════════════════════════════════════
    #  Stats Loading
    # ══════════════════════════════════════════════════════════════
    def _load_stats_async(self):
        try:
            self["stats_title"].setText("Loading...")
            self._set_rows([{"type": "header",
                             "text": "  Loading stats..."}])
            self["status"].setText("Collecting stats...")

            t = threading.Thread(target=self._stats_worker)
            t.setDaemon(True)
            t.start()
        except Exception as e:
            print("[Diagnostics] _load_stats_async ERROR: %s" % e)

    def _stats_worker(self):
        print("[Diagnostics] === _stats_worker STARTED ===")

        stats_list = []
        readers_status = []
        client = None
        self._last_error = ""

        try:
            client = self._make_client()
            if not client:
                self._last_error = "Client creation failed"
                self._schedule_ui(self._apply_stats, [])
                return

            try:
                readers_status = client.get_reader_status()
            except Exception as e:
                self._last_error = "get_reader_status: %s" % e
                self._schedule_ui(self._apply_stats, [])
                return

            if not readers_status:
                self._last_error = "No readers returned"
                self._schedule_ui(self._apply_stats, [])
                return

            labels = [getattr(r, "label", None)
                      for r in readers_status]
            labels = [l for l in labels if l]

            if HAS_BENCH and bench_all_readers and apply_bench_to_readers and labels:
                try:
                    bench = self._get_bench(client, labels)
                    if bench:
                        apply_bench_to_readers(readers_status, bench)
                except Exception as e:
                    print("[Diagnostics] bench error: %s" % e)

            stats_list = [extract_reader_stats(r)
                          for r in readers_status]

        except Exception as e:
            import traceback
            self._last_error = str(e)
            print("[Diagnostics] EXCEPTION: %s" % e)
            print(traceback.format_exc())

        self._schedule_ui(self._apply_stats, stats_list)

    def _get_bench(self, client, labels):
        now = _time.time()
        age = now - self._bench_cache_time

        if self._bench_cache and age < self.BENCH_CACHE_TTL:
            return self._bench_cache

        if self._bench_running:
            return self._bench_cache

        self._bench_running = True
        try:
            base_url = getattr(client, "base_url", "")
            username = getattr(client, "username", "")
            password = getattr(client, "password", "")

            def _progress(done, total):
                if self._closing:
                    return
                self._schedule_ui(
                    self._update_progress, done, total)

            bench = bench_all_readers(
                labels, base_url,
                username=username,
                password=password,
                samples=self.BENCH_SAMPLES,
                timeout=self.BENCH_TIMEOUT,
                max_parallel=self.BENCH_PARALLEL,
                cancel_check=lambda: self._closing,
                progress_callback=_progress)

            if bench:
                self._bench_cache = bench
                self._bench_cache_time = _time.time()

            return bench
        finally:
            self._bench_running = False

    def _update_progress(self, done, total):
        if self._closing:
            return
        try:
            self["status"].setText(
                "Benchmarking... %d / %d readers"
                % (done, total))
        except Exception:
            pass

    def _make_client(self):
        sc = self._active_softcam
        if not sc:
            return None
        name = (sc.get("name") or "").lower()
        if "ncam" in name:
            return self._make_ncam_client()
        return self._make_oscam_client()

    def _make_oscam_client(self):
        try:
            if hasattr(oscamapi, "configure_auto"):
                client = oscamapi.configure_auto()
                if client and getattr(client, "base_url", ""):
                    try:
                        test = client.get_reader_status()
                        if test:
                            return client
                    except Exception:
                        pass
        except Exception:
            pass

        try:
            url = config.plugins.OscamReaderManager.oscam_url.value
            if url:
                user = config.plugins.OscamReaderManager.oscam_user.value
                pwd = config.plugins.OscamReaderManager.oscam_pass.value
                try:
                    timeout = float(
                        config.plugins.OscamReaderManager.oscam_timeout.value)
                except (TypeError, ValueError):
                    timeout = 5.0
                client = oscamapi.OSCamAPI(url, user, pwd, timeout=timeout)
                test = client.get_reader_status()
                if test:
                    return client
        except Exception:
            pass

        return None

    def _make_ncam_client(self):
        try:
            url = config.plugins.OscamReaderManager.ncam_url.value
            user = config.plugins.OscamReaderManager.ncam_user.value
            pwd = config.plugins.OscamReaderManager.ncam_pass.value
            try:
                timeout = float(
                    config.plugins.OscamReaderManager.ncam_timeout.value)
            except (TypeError, ValueError):
                timeout = 5.0
            return ncamapi.NCamAPI(url, user, pwd, timeout=timeout)
        except Exception:
            return None

    def _apply_stats(self, stats_list):
        try:
            self._stats = stats_list or []
            self._render_section()
            self._load_active_softcam()
            if self._stats:
                self["status"].setText(
                    "Loaded %d reader(s)" % len(self._stats))
            else:
                self["status"].setText("No readers loaded")
        except Exception as e:
            logger.log("Diagnostics", "_apply_stats: %s" % e)

    # ══════════════════════════════════════════════════════════════
    #  Navigation
    # ══════════════════════════════════════════════════════════════
    def stats_up(self):
        try:
            idx = self["stats_list"].getSelectedIndex()
            if idx is not None and idx > 0:
                self["stats_list"].moveToIndex(idx - 1)
        except Exception:
            pass

    def stats_down(self):
        try:
            idx = self["stats_list"].getSelectedIndex()
            total = len(self._rows)
            if idx is not None and idx < total - 1:
                self["stats_list"].moveToIndex(idx + 1)
        except Exception:
            pass

    def next_section(self):
        if not self.SECTIONS:
            return
        self._section_idx = (self._section_idx + 1) % len(self.SECTIONS)
        self._render_section()

    def prev_section(self):
        if not self.SECTIONS:
            return
        self._section_idx = (self._section_idx - 1) % len(self.SECTIONS)
        self._render_section()

    def _set_rows(self, rows):
        self._rows = rows
        tuples = [(r,) for r in rows]
        self["stats_list"].setList(tuples)

    def _render_section(self):
        if not self.SECTIONS:
            return
        key, title = self.SECTIONS[self._section_idx]
        self["stats_title"].setText(
            "[%d/%d]  %s"
            % (self._section_idx + 1, len(self.SECTIONS), title))

        try:
            if key == "overview":
                self._render_overview()
            elif key == "fastest":
                self._render_fastest()
            elif key == "providing":
                self._render_providing()
            elif key == "success":
                self._render_success()
            elif key == "failures":
                self._render_failures()
            elif key == "cards":
                self._render_cards()
            elif key == "champion":
                self._render_champion()
        except Exception as e:
            logger.log("Diagnostics", "_render_section: %s" % e)

    # ══════════════════════════════════════════════════════════════
    #  Renderers
    # ══════════════════════════════════════════════════════════════
    def _render_overview(self):
        rows = []

        if not self._stats:
            rows.append({"type": "header",
                         "text": "  No readers loaded"})
            self._set_rows(rows)
            return

        totals = {}
        try:
            client = self._make_client()
            if client and hasattr(client, "get_totals"):
                totals = client.get_totals() or {}
        except Exception:
            pass

        if totals:
            readers_total = totals.get("total_readers", 0)
            readers_conn = totals.get("total_connected_readers", 0)
            cwok = totals.get("total_cwok_readers", 0)
            cwnok = totals.get("total_cwnok_readers", 0)
            ecm = totals.get("total_sum_all_readers_ecm", 0)
            rate = totals.get("rel_cwok_readers", 0.0)
        else:
            s = summary(self._stats)
            readers_total = s["readers_total"]
            readers_conn = s["readers_connected"]
            cwok = s["total_ok"]
            cwnok = s["total_nok"]
            ecm = s["total_ecm"]
            rate = s["overall_success"]

        rows.append({
            "type": "header",
            "text": "  OVERALL SUMMARY",
            "icon": "readers",
        })

        rows.append({
            "type": "row",
            "icon_key": "online",
            "label": "Readers Online",
            "ecm": "%d / %d" % (readers_conn, readers_total),
            "ok": "", "rate": rate, "even": True,
        })
        rows.append({
            "type": "row",
            "icon_key": "ok",
            "label": "Total CWs OK",
            "ecm": str(cwok),
            "ok": "", "rate": rate, "even": False,
        })
        rows.append({
            "type": "row",
            "icon_key": "fail",
            "label": "Total CWs NOK",
            "ecm": str(cwnok),
            "ok": "", "rate": 0, "even": True,
        })
        rows.append({
            "type": "row",
            "icon_key": "total",
            "label": "Total ECMs",
            "ecm": str(ecm),
            "ok": "", "rate": rate, "even": False,
        })

        rows.append({"type": "sep"})
        rows.append({"type": "space"})

        rows.append({
            "type": "header",
            "text": "  READERS (sorted by ECMs)",
            "icon": "readers",
        })

        sorted_stats = sorted(self._stats,
                              key=lambda x: x.get("ecm_count", 0),
                              reverse=True)
        for i, r in enumerate(sorted_stats[:20]):
            is_conn = r.get("is_connected")
            rows.append({
                "type": "row",
                "icon_key": "online" if is_conn else "offline",
                "label": (r.get("label") or "?")[:22],
                "ecm": str(r.get("ecm_count", 0)),
                "ok": str(r.get("ecm_ok", 0)),
                "rate": r.get("success_rate", 0.0),
                "even": bool(i % 2 == 0),
            })

        self._set_rows(rows)

    def _render_fastest(self):
        rows = []
        rows.append({
            "type": "header",
            "text": "  FASTEST READERS",
            "icon": "fastest",
        })

        if not self._stats:
            rows.append({"type": "header", "text": "    No readers loaded"})
            self._set_rows(rows)
            return

        candidates = [
            r for r in self._stats
            if r.get("is_connected") and r.get("avg_time_ms", 0) > 0
        ]
        candidates.sort(key=lambda r: r["avg_time_ms"])

        if not candidates:
            rows.append({"type": "header",
                         "text": "    Waiting for benchmark data..."})
            self._set_rows(rows)
            return

        for i, r in enumerate(candidates[:20]):
            avg = r.get("avg_time_ms", 0)
            rows.append({
                "type": "row",
                "icon_text": str(i + 1),
                "icon_color": COLOR_HEADER,
                "label": (r["label"] or "?")[:22],
                "ecm": "%5.0f ms" % avg,
                "ecm_color": _speed_color(avg),
                "ok": "",
                "rate": 0,
                "show_bar": False,
                "even": bool(i % 2 == 0),
            })

        self._set_rows(rows)

    def _render_providing(self):
        rows = []
        rows.append({
            "type": "header",
            "text": "  MOST PROVIDING",
            "icon": "providers",
        })
        top = top_most_providing(self._stats, n=20)
        if not top:
            rows.append({"type": "header", "text": "    No data yet"})
            self._set_rows(rows)
            return
        for i, r in enumerate(top):
            rows.append({
                "type": "row",
                "icon_text": str(i + 1),
                "icon_color": COLOR_HEADER,
                "label": (r["label"] or "?")[:22],
                "ecm": str(r["ecm_count"]),
                "ok": str(r["ecm_ok"]),
                "rate": r["success_rate"],
                "even": bool(i % 2 == 0),
            })
        self._set_rows(rows)

    def _render_success(self):
        rows = []
        rows.append({
            "type": "header",
            "text": "  BEST SUCCESS RATE",
            "icon": "ok",
        })
        top = top_best_success_rate(self._stats, n=20, min_ecm=1)
        if not top:
            rows.append({"type": "header", "text": "    No data yet"})
            self._set_rows(rows)
            return
        for i, r in enumerate(top):
            rows.append({
                "type": "row",
                "icon_text": str(i + 1),
                "icon_color": COLOR_HEADER,
                "label": (r["label"] or "?")[:22],
                "ecm": "%d/%d" % (r["ecm_ok"], r["ecm_count"]),
                "ok": "",
                "rate": r["success_rate"],
                "even": bool(i % 2 == 0),
            })
        self._set_rows(rows)

    def _render_failures(self):
        rows = []
        rows.append({
            "type": "header",
            "text": "  WORST FAILURES",
            "icon": "fail",
        })
        top = top_worst_failures(self._stats, n=20)
        if not top:
            rows.append({"type": "header",
                         "text": "    ✓ No failures recorded"})
            self._set_rows(rows)
            return
        for i, r in enumerate(top):
            rows.append({
                "type": "row",
                "icon_text": str(i + 1),
                "icon_color": COLOR_BAD,
                "label": (r["label"] or "?")[:22],
                "ecm": "NOK %d" % r["ecm_nok"],
                "ok": "",
                "rate": r["success_rate"],
                "even": bool(i % 2 == 0),
            })
        self._set_rows(rows)

    def _render_cards(self):
        rows = []
        rows.append({
            "type": "header",
            "text": "  READERS WITH CARDS",
            "icon": "cards",
        })
        top = top_cards(self._stats, n=20)
        if not top:
            rows.append({"type": "header",
                         "text": "    No cards detected"})
            self._set_rows(rows)
            return
        for i, r in enumerate(top):
            rows.append({
                "type": "row",
                "icon_text": str(i + 1),
                "icon_color": COLOR_HEADER,
                "label": (r["label"] or "?")[:22],
                "ecm": "Cards %d" % r["cards"],
                "ok": "",
                "rate": r["success_rate"],
                "even": bool(i % 2 == 0),
            })
        self._set_rows(rows)

    def _render_champion(self):
        rows = []
        rows.append({
            "type": "header",
            "text": "  CHAMPION — BEST OVERALL",
            "icon": "champion",
        })
        rows.append({"type": "sep"})

        candidates = [
            r for r in self._stats
            if r.get("is_connected") and r.get("avg_time_ms", 0) > 0
        ]
        if candidates:
            candidates.sort(key=lambda r: r["avg_time_ms"])
            fastest = candidates[0]
            rows.append({
                "type": "header",
                "text": "  FASTEST: %s  (%.0f ms)"
                        % (fastest["label"], fastest["avg_time_ms"]),
                "icon": "fastest",
            })
        else:
            rows.append({"type": "header",
                         "text": "  FASTEST: (no data)"})

        rows.append({"type": "space"})

        by_score = top_by_score(self._stats, n=5)
        rows.append({
            "type": "header",
            "text": "  TOP BY SCORE",
            "icon": "champion",
        })
        for i, r in enumerate(by_score):
            rows.append({
                "type": "row",
                "icon_text": str(i + 1),
                "icon_color": COLOR_HEADER,
                "label": (r["label"] or "?")[:22],
                "ecm": "score %.1f" % r["score"],
                "ok": str(r["ecm_count"]),
                "rate": r["success_rate"],
                "even": bool(i % 2 == 0),
            })

        rows.append({"type": "space"})

        by_ecm = top_most_providing(self._stats, n=5)
        rows.append({
            "type": "header",
            "text": "  TOP PROVIDERS",
            "icon": "providers",
        })
        for i, r in enumerate(by_ecm):
            rows.append({
                "type": "row",
                "icon_text": str(i + 1),
                "icon_color": COLOR_EXCELLENT,
                "label": (r["label"] or "?")[:22],
                "ecm": str(r["ecm_count"]),
                "ok": str(r["ecm_ok"]),
                "rate": r["success_rate"],
                "even": bool(i % 2 == 0),
            })

        self._set_rows(rows)

    # ============================================================
    def show_details(self):
        try:
            sc = self._active_softcam
            if not sc:
                return

            lines = [
                "Active SoftCam",
                "",
                "Name:      %s" % sc.get("name", "?"),
                "Version:   %s" % (sc.get("version") or "-"),
                "Status:    %s" % get_status_for_active(),
                "Binary:    %s" % sc.get("path", "?"),
                "Config:    %s" % sc.get("config_dir", "?"),
                "PID:       %s" % sc.get("pid", "?"),
                "",
                "Readers:   %d" % len(self._stats),
                "HAS_BENCH: %s" % HAS_BENCH,
                "HAS_MULTI: %s" % HAS_MULTI,
                "ROW_H:     %d" % self.ROW_H,
                "ICON_SIZE: %d" % self.ICON_SIZE,
                "",
                "ECM File:  %s" % self.ECM_FILE,
                "ECM Poll:  %d ms" % self.ECM_POLL_MS,
            ]

            if self._last_error:
                lines += ["", "Last Error:", "  %s" % self._last_error]

            self.session.open(MessageBox, "\n".join(lines),
                              MessageBox.TYPE_INFO, timeout=20)
        except Exception as e:
            logger.log("Diagnostics", "show_details error: %s" % e)

    # ============================================================
    def _schedule_ui(self, func, *args):
        if self._closing:
            return
        try:
            t = eTimer()
            t.callback.append(lambda: func(*args))
            t.start(10, True)
            self._timers.append(t)
        except Exception:
            try:
                func(*args)
            except Exception:
                pass

    def close(self):
        print("[Diagnostics] === close ===")
        self._closing = True

        # ⭐ أوقف ECM timer
        try:
            if self._ecm_timer:
                self._ecm_timer.stop()
                self._ecm_timer = None
        except Exception:
            pass

        for t in self._timers:
            try:
                t.stop()
            except Exception:
                pass
        self._timers = []
        Screen.close(self)


print("[Diagnostics] Module loaded successfully")