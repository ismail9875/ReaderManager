# -*- coding: utf-8 -*-
"""
utils/emu_manager.py — إدارة المحاكيات (SoftCams).

v10 (نهائي — تبديل بدون إيقاف القناة):
    ① الرابط الرمزي
    ② settings
    ③ الذاكرة (default=link_value)
    ④ SystemInfo + updateSysSoftCam
    ⑤ eDVBResourceManager (كل الطرق المتاحة)
    ⑥ ServiceAction.switchSoftcam
    ⑦ InfoBar replay (بدون stop) + fallback
    ⑧ updateSysSoftCam (final)
    ⑨ FINAL VERIFY
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import glob
import time as _time
import subprocess
import threading

try:
    from io import open
except ImportError:
    pass

try:
    _TimeoutExpired = subprocess.TimeoutExpired
except AttributeError:
    class _TimeoutExpired(Exception):
        pass

from . import logger


# ═══════════════════════════════════════════════════════════════════
#  الإعدادات
# ═══════════════════════════════════════════════════════════════════
BIN_DIR = "/usr/bin"
INIT_DIR = "/etc/init.d"

BINARY_PATTERNS = [
    r"^oscam(?:[._-].+)?$",
    r"^OSCam(?:[._-].+)?$",
    r"^ncam(?:[._-].+)?$",
    r"^NCam(?:[._-].+)?$",
]

FAMILY_OSCAM = "oscam"
FAMILY_NCAM  = "ncam"

INIT_SCRIPT_PATTERNS = [
    "/etc/init.d/softcam.oscam-*",
    "/etc/init.d/softcam.OSCam-*",
    "/etc/init.d/softcam.oscam",
    "/etc/init.d/softcam.OSCam",
    "/etc/init.d/softcam_oscam*",
    "/etc/init.d/oscam",
    "/etc/init.d/softcam.ncam-*",
    "/etc/init.d/softcam.NCam-*",
    "/etc/init.d/softcam.ncam",
    "/etc/init.d/softcam.NCam",
    "/etc/init.d/softcam_ncam*",
    "/etc/init.d/ncam",
    "/etc/init.d/softcam",
]

CMD_TIMEOUT = 20

SOFTCAM_LINK       = "/etc/init.d/softcam"
SOFTCAM_NONE       = "/etc/init.d/softcam.None"
ENIGMA_SETTINGS    = "/etc/enigma2/settings"

STOP_WAIT_TIMEOUT  = 3.0
STOP_POLL_INTERVAL = 0.1


# ═══════════════════════════════════════════════════════════════════
#  EmulatorInfo
# ═══════════════════════════════════════════════════════════════════
class EmulatorInfo(object):
    """نموذج بيانات محاكي واحد."""

    __slots__ = (
        "key", "name", "family", "version", "binary_path",
        "init_script", "enabled", "running",
        "description", "extra",
    )

    def __init__(self, name, family, binary_path):
        self.key = "emu:%s:%s" % (family, os.path.basename(binary_path))
        self.name = name
        self.family = family
        self.version = ""
        self.binary_path = binary_path
        self.init_script = ""
        self.enabled = False
        self.running = False
        self.description = ""
        self.extra = {}

    def to_dict(self):
        return {
            "key": self.key,
            "name": self.name,
            "family": self.family,
            "version": self.version,
            "binary_path": self.binary_path,
            "init_script": self.init_script,
            "enabled": self.enabled,
            "running": self.running,
        }

    def __repr__(self):
        return "<Emulator %s v%s running=%s>" % (
            self.name, self.version or "?", self.running)


# ═══════════════════════════════════════════════════════════════════
#  Helpers — subprocess
# ═══════════════════════════════════════════════════════════════════
def _run(cmd, timeout=CMD_TIMEOUT):
    """ينفّذ أمر shell وينتظر النتيجة."""
    p = None
    try:
        p = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = p.communicate(timeout=timeout)
        except TypeError:
            result = [b"", b""]

            def _target():
                try:
                    result[0], result[1] = p.communicate()
                except Exception:
                    pass

            t = threading.Thread(target=_target)
            t.setDaemon(True)
            t.start()
            t.join(timeout)
            if t.isAlive():
                try:
                    p.kill()
                except Exception:
                    pass
                return -1, "", "timeout"
            out, err = result

        if isinstance(out, bytes):
            out = out.decode("utf-8", "ignore")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "ignore")
        return p.returncode, out, err
    except _TimeoutExpired:
        if p:
            try:
                p.kill()
            except Exception:
                pass
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)


def _run_async(cmd):
    """ينفّذ أمر shell في الخلفية بدون انتظار."""
    try:
        subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            close_fds=True)
        return True
    except Exception as e:
        logger.log("EmuManager", "_run_async error: %s" % e)
        return False


# ═══════════════════════════════════════════════════════════════════
#  Helpers — File IO
# ═══════════════════════════════════════════════════════════════════
def _safe_read(path):
    try:
        if not os.path.isfile(path):
            return ""
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def _safe_write(path, content):
    try:
        d = os.path.dirname(path)
        if d and not os.path.isdir(d):
            try:
                os.makedirs(d)
            except Exception:
                pass
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except Exception as e:
        logger.log("EmuManager", "Cannot write %s: %s" % (path, e))
        return False


def _get_enigma_config():
    try:
        from Components.config import config
        return config
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════
#  استخراج اسم CAM من السكربت
# ═══════════════════════════════════════════════════════════════════
def _get_cam_name_from_script(script_path):
    """يستخرج اسم CAM من مسار السكربت."""
    if not script_path:
        return ""
    try:
        basename = os.path.basename(script_path)
        prefix = "softcam."
        if basename.startswith(prefix):
            return basename[len(prefix):]
    except Exception:
        pass
    return ""


def _read_active_cam_link():
    """يقرأ اسم المحاكي النشط من الرابط الرمزي."""
    try:
        if not os.path.islink(SOFTCAM_LINK):
            return None, None
        target = os.readlink(SOFTCAM_LINK)
        prefix = "softcam."
        if prefix in target:
            name = target.split(prefix, 1)[1]
            if name.lower() == "none" or not name:
                return None, target
            return name, target
    except Exception:
        pass
    return None, None


def _get_available_softcams():
    """يُعيد قائمة كاملة بأسماء Softcams المتاحة (مع None)."""
    result = ["None"]
    try:
        for f in sorted(os.listdir("/etc/init.d")):
            if f.startswith("softcam.") and f != "softcam.None":
                name = f[len("softcam."):]
                if name:
                    result.append(name)
    except Exception:
        pass
    return result


# ═══════════════════════════════════════════════════════════════════
#  كتابة/verify settings
# ═══════════════════════════════════════════════════════════════════
def _write_settings_key(key, value):
    """يكتب مفتاحاً في /etc/enigma2/settings مباشرة."""
    try:
        if not os.path.isfile(ENIGMA_SETTINGS):
            logger.log("EmuManager",
                       "settings file not found: %s" % ENIGMA_SETTINGS)
            return False

        if value is None:
            value = "None"
        value = str(value).strip()

        lines = _safe_read(ENIGMA_SETTINGS).splitlines()
        new_lines = []
        found = False
        prefix = key + "="

        for line in lines:
            if line.startswith(prefix):
                new_lines.append("%s=%s" % (key, value))
                found = True
            else:
                new_lines.append(line)

        if not found:
            new_lines.append("%s=%s" % (key, value))

        _safe_write(ENIGMA_SETTINGS, "\n".join(new_lines) + "\n")
        logger.log("EmuManager",
                   "Wrote %s=%s in settings" % (key, value))
        return True
    except Exception as e:
        logger.log("EmuManager", "_write_settings_key error: %s" % e)
        return False


def _verify_settings_key(key, expected_value):
    """يتحقق أن المفتاح مكتوب بالقيمة المتوقعة."""
    try:
        if not os.path.isfile(ENIGMA_SETTINGS):
            return False
        prefix = key + "="
        with open(ENIGMA_SETTINGS, "r") as f:
            for line in f:
                if line.startswith(prefix):
                    actual = line.strip().split("=", 1)[1]
                    return actual == str(expected_value).strip()
    except Exception:
        pass
    return False


# ═══════════════════════════════════════════════════════════════════
#  Hints
# ═══════════════════════════════════════════════════════════════════
def _set_hints_for(emu):
    """يعيّن hints في restart_oscam / restart_ncam إذا كانت متوفرة."""
    try:
        if emu.family == FAMILY_OSCAM:
            from . import restart_oscam
            if hasattr(restart_oscam, "set_cam_name") and emu.name:
                restart_oscam.set_cam_name(emu.name)
            if hasattr(restart_oscam, "set_script_hint") and emu.init_script:
                restart_oscam.set_script_hint(emu.init_script)
            if hasattr(restart_oscam, "set_binary_hint") and emu.binary_path:
                restart_oscam.set_binary_hint(emu.binary_path)
            logger.log("EmuManager",
                       "Hints set for oscam: cam=%s script=%s binary=%s"
                       % (emu.name,
                          emu.init_script or "-",
                          emu.binary_path or "-"))
            return True

        if emu.family == FAMILY_NCAM:
            from . import restart_ncam
            if hasattr(restart_ncam, "set_cam_name") and emu.name:
                restart_ncam.set_cam_name(emu.name)
            if hasattr(restart_ncam, "set_script_hint") and emu.init_script:
                restart_ncam.set_script_hint(emu.init_script)
            if hasattr(restart_ncam, "set_binary_hint") and emu.binary_path:
                restart_ncam.set_binary_hint(emu.binary_path)
            logger.log("EmuManager",
                       "Hints set for ncam: cam=%s script=%s binary=%s"
                       % (emu.name,
                          emu.init_script or "-",
                          emu.binary_path or "-"))
            return True
    except Exception as e:
        logger.log("EmuManager", "_set_hints_for error: %s" % e)

    return False


# ═══════════════════════════════════════════════════════════════════
#  EmulatorManager
# ═══════════════════════════════════════════════════════════════════
class EmulatorManager(object):
    """
    يكتشف المحاكيات ويتحكم بها بسرعة عالية.

    - الواجهة تستجيب في < 50ms.
    - العملية الفعلية في Thread منفصل.
    - انتظار ذكي لتوقف المحاكي القديم.
    - تعيين Active Cam بدون إيقاف القناة (playService مباشرة).
    """

    def __init__(self, bin_dir=BIN_DIR, init_dir=INIT_DIR):
        self.bin_dir = bin_dir
        self.init_dir = init_dir
        self._cache = None
        self._lock = threading.Lock()

    # ==================================================================
    #  Discovery
    # ==================================================================
    def discover(self, force=False):
        """يكتشف كل المحاكيات في /usr/bin."""
        with self._lock:
            if self._cache is not None and not force:
                return self._cache

            emus = []
            seen_paths = set()

            try:
                entries = sorted(os.listdir(self.bin_dir))
            except Exception as e:
                logger.log("EmuManager",
                           "Cannot list %s: %s" % (self.bin_dir, e))
                self._cache = []
                return []

            for fname in entries:
                full_path = os.path.join(self.bin_dir, fname)

                if not os.path.isfile(full_path):
                    continue
                if not os.access(full_path, os.X_OK):
                    continue
                if full_path in seen_paths:
                    continue

                family = self._detect_family(fname)
                if not family:
                    continue

                seen_paths.add(full_path)

                emu = EmulatorInfo(fname, family, full_path)
                emu.version = self._extract_version(emu)
                emu.init_script = self._find_init_script(emu)
                emu.running = self._check_running(emu)
                emu.enabled = emu.running
                emu.description = "%s binary (%s)" % (
                    family.upper(), emu.version or "unknown version")

                emus.append(emu)

            emus.sort(key=lambda e: (
                0 if e.family == FAMILY_OSCAM else 1,
                e.name.lower()))

            self._cache = emus
            logger.log("EmuManager",
                       "Discovered %d emulator(s) in %s"
                       % (len(emus), self.bin_dir))
            return emus

    def refresh(self):
        """إعادة كشف قسري."""
        return self.discover(force=True)

    # ==================================================================
    #  Family / Version / Script search
    # ==================================================================
    @staticmethod
    def _detect_family(fname):
        low = fname.lower()
        for pattern in BINARY_PATTERNS:
            try:
                if re.match(pattern, fname, re.IGNORECASE):
                    if low.startswith("oscam"):
                        return FAMILY_OSCAM
                    if low.startswith("ncam"):
                        return FAMILY_NCAM
            except Exception:
                continue
        return None

    def _extract_version(self, emu):
        v = self._version_from_name(emu.name)
        if v:
            return v
        v = self._version_from_binary(emu.binary_path)
        if v:
            return v
        v = self._version_from_tmp(emu.family)
        if v:
            return v
        return ""

    @staticmethod
    def _version_from_name(name):
        m = re.search(r"[._-]v?(\d+(?:[._-]\d+)*)", name)
        if m:
            return m.group(1).replace("_", ".")
        return ""

    def _version_from_binary(self, path):
        for args in (["-V"], ["--build-info"], ["-h"]):
            try:
                rc, out, err = _run(
                    "%s %s 2>&1" % (path, " ".join(args)),
                    timeout=5)
                if rc != 0 and not out and not err:
                    continue

                text = (out or "") + "\n" + (err or "")

                patterns = [
                    r"Version:\s*([^\s@]+)",
                    r"version[:\s]+([0-9][0-9A-Za-z._-]+)",
                    r"v(\d+\.\d+[0-9A-Za-z._-]*)",
                    r"(\d+\.\d+\.\d+)",
                    r"svn[:\s]+r?(\d+)",
                ]
                for pat in patterns:
                    m = re.search(pat, text, re.IGNORECASE)
                    if m:
                        return m.group(1).strip()
            except Exception:
                continue
        return ""

    @staticmethod
    def _version_from_tmp(family):
        paths = [
            "/tmp/.%s/%s.version" % (family, family),
            "/tmp/%s.version" % family,
            "/var/tmp/%s.version" % family,
        ]
        for path in paths:
            if not os.path.isfile(path):
                continue
            try:
                with open(path, "r", encoding="utf-8",
                          errors="ignore") as f:
                    for line in f:
                        if line.startswith("Version:"):
                            v = line.replace("Version:", "").strip()
                            v = v.split("@")[0].strip()
                            m = re.match(r"(\d+(?:\.\d+)*)", v)
                            if m:
                                return m.group(1)
                            return v
            except Exception:
                continue
        return ""

    def _find_init_script(self, emu):
        family = emu.family
        version = emu.version
        candidates = []
        base = emu.name

        if version:
            for sep in ("-", "_", "."):
                candidates.append(
                    os.path.join(self.init_dir,
                                 "softcam.%s%s%s" % (base, sep, version)))
                candidates.append(
                    os.path.join(self.init_dir,
                                 "softcam.%s%s%s" % (family, sep, version)))

        candidates.append(
            os.path.join(self.init_dir, "softcam.%s-*" % base))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s-*" % family))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s" % base))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s" % family))
        candidates.append(os.path.join(self.init_dir, family))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s.sh" % base))

        for pat in INIT_SCRIPT_PATTERNS:
            candidates.append(pat)

        seen = set()
        for cand in candidates:
            if cand in seen:
                continue
            seen.add(cand)

            if "*" in cand or "?" in cand:
                try:
                    matches = sorted(glob.glob(cand), reverse=True)
                except Exception:
                    matches = []
                for m in matches:
                    if self._is_valid_script(m):
                        logger.log("EmuManager",
                                   "init script for %s: %s"
                                   % (emu.name, m))
                        return m
            else:
                if self._is_valid_script(cand):
                    logger.log("EmuManager",
                               "init script for %s: %s"
                               % (emu.name, cand))
                    return cand

        return ""

    @staticmethod
    def _is_valid_script(path):
        try:
            return (os.path.isfile(path)
                    and os.access(path, os.X_OK))
        except Exception:
            return False

    def _check_running(self, emu):
        base = emu.name

        rc, out, _ = _run("pidof %s 2>/dev/null" % base, timeout=3)
        if rc == 0 and out.strip():
            return True

        try:
            for pid_dir in os.listdir("/proc"):
                if not pid_dir.isdigit():
                    continue
                try:
                    comm_path = "/proc/%s/comm" % pid_dir
                    if os.path.isfile(comm_path):
                        with open(comm_path, "r") as f:
                            comm = f.read().strip()
                        if comm == base:
                            return True
                    cmdline_path = "/proc/%s/cmdline" % pid_dir
                    if os.path.isfile(cmdline_path):
                        with open(cmdline_path, "rb") as f:
                            cmdline = f.read().decode(
                                "utf-8", "ignore"
                            ).replace("\0", " ")
                        if base in cmdline:
                            return True
                except (IOError, OSError):
                    continue
        except Exception:
            pass

        return False

    # ==================================================================
    #  ⭐ Active Cam — بدون إيقاف القناة
    # ==================================================================
    def _set_active_cam_state(self, emu):
        """
        يعيّن محاكياً كـ Active Cam بدون إيقاف القناة (إن أمكن):
        ① الرابط الرمزي
        ② settings
        ③ الذاكرة (default=link_value)
        ④ SystemInfo + updateSysSoftCam
        ⑤ eDVBResourceManager (كل الطرق)
        ⑥ ServiceAction.switchSoftcam
        ⑦ InfoBar replay (بدون stop)
        ⑧ updateSysSoftCam (final)
        ⑨ FINAL VERIFY
        """
        if emu is None:
            logger.log("EmuManager",
                       "_set_active_cam_state: emu is None")
            return False

        script = emu.init_script
        if not script or not os.path.isfile(script):
            logger.log("EmuManager",
                       "Cannot set active cam: no script for %s"
                       % emu.name)
            return False

        cam_name = _get_cam_name_from_script(script)
        if not cam_name:
            logger.log("EmuManager",
                       "Cannot extract cam name from %s" % script)
            return False

        logger.log("EmuManager", "=" * 60)
        logger.log("EmuManager",
                   "MANUAL Setting Active Cam: %s" % cam_name)
        logger.log("EmuManager", "=" * 60)

        # ═══════════════════════════════════════════════════════════
        #  ① الرابط الرمزي
        # ═══════════════════════════════════════════════════════════
        try:
            if os.path.islink(SOFTCAM_LINK) or os.path.exists(SOFTCAM_LINK):
                try:
                    os.unlink(SOFTCAM_LINK)
                    logger.log("EmuManager", "[1] Removed old link")
                except Exception as e:
                    logger.log("EmuManager",
                               "[1] unlink failed: %s" % e)

            rc, out, err = _run(
                "ln -sf %s %s" % (script, SOFTCAM_LINK),
                timeout=3)

            if rc != 0:
                logger.log("EmuManager",
                           "[1] ln -sf failed: rc=%d err=%s" % (rc, err))
                return False

            if os.path.islink(SOFTCAM_LINK):
                target = os.readlink(SOFTCAM_LINK)
                logger.log("EmuManager",
                           "[1] Link created: %s -> %s"
                           % (SOFTCAM_LINK, target))
            else:
                logger.log("EmuManager",
                           "[1] ERROR: link not created!")
                return False
        except Exception as e:
            logger.log("EmuManager", "[1] link error: %s" % e)
            return False

        # ═══════════════════════════════════════════════════════════
        #  ② settings
        # ═══════════════════════════════════════════════════════════
        try:
            _write_settings_key("config.misc.softcams", cam_name)
            logger.log("EmuManager",
                       "[2] settings written: config.misc.softcams=%s"
                       % cam_name)
        except Exception as e:
            logger.log("EmuManager",
                       "[2] settings write failed: %s" % e)

        # ═══════════════════════════════════════════════════════════
        #  ③ الذاكرة — إعادة إنشاء مع default=link_value
        # ═══════════════════════════════════════════════════════════
        try:
            from Components.config import ConfigSelection
            from Components.config import config as global_config

            # احذف القديم
            if hasattr(global_config.misc, "softcams"):
                try:
                    delattr(global_config.misc, "softcams")
                except Exception:
                    pass

            # اجلب القيمة من الرابط
            link_value = None
            try:
                if os.path.islink(SOFTCAM_LINK):
                    target = os.readlink(SOFTCAM_LINK)
                    prefix = "softcam."
                    if prefix in target:
                        link_value = target.split(prefix, 1)[1]
            except Exception:
                pass

            default_value = link_value or cam_name

            logger.log("EmuManager",
                       "[3] link_value=%s default_value=%s"
                       % (link_value or "(none)", default_value))

            softcams_list = _get_available_softcams()
            if not softcams_list:
                softcams_list = [default_value]

            global_config.misc.softcams = ConfigSelection(
                default=default_value,
                choices=softcams_list)

            global_config.misc.softcams.value = default_value

            # احفظ 3 مرات
            try:
                global_config.misc.softcams.save()
                logger.log("EmuManager", "[3] softcams.save() OK")
            except Exception as e:
                logger.log("EmuManager",
                           "[3] softcams.save() failed: %s" % e)

            try:
                global_config.misc.save()
                logger.log("EmuManager", "[3] misc.save() OK")
            except Exception as e:
                logger.log("EmuManager",
                           "[3] misc.save() failed: %s" % e)

            try:
                global_config.save()
                logger.log("EmuManager", "[3] config.save() OK")
            except Exception as e:
                logger.log("EmuManager",
                           "[3] config.save() failed: %s" % e)

            logger.log("EmuManager",
                       "[3] memory config.misc.softcams=%s saved"
                       % default_value)
        except Exception as e:
            logger.log("EmuManager",
                       "[3] memory update failed: %s" % e)

        # ═══════════════════════════════════════════════════════════
        #  ④ SystemInfo + updateSysSoftCam
        # ═══════════════════════════════════════════════════════════
        try:
            from Components.SystemInfo import updateSysSoftCam
            updateSysSoftCam()
            logger.log("EmuManager", "[4] updateSysSoftCam() called")
        except Exception as e:
            logger.log("EmuManager",
                       "[4] updateSysSoftCam failed: %s" % e)

        try:
            from Components.SystemInfo import SystemInfo
            if isinstance(SystemInfo, dict):
                SystemInfo["Softcam"] = cam_name
                logger.log("EmuManager",
                           "[4] SystemInfo['Softcam']=%s" % cam_name)
        except Exception as e:
            logger.log("EmuManager",
                       "[4] SystemInfo update failed: %s" % e)

        # ═══════════════════════════════════════════════════════════
        #  ⑤ eDVBResourceManager (كل الطرق المتاحة)
        # ═══════════════════════════════════════════════════════════
        try:
            from enigma import eDVBResourceManager
            rm = eDVBResourceManager.getInstance()
            if rm is not None:
                done = False
                for method in ("setCamName", "setSoftCam",
                               "setCamdName", "setCAMD",
                               "reloadSoftCam", "reloadSoftcam",
                               "switchSoftcam"):
                    if hasattr(rm, method):
                        try:
                            getattr(rm, method)(cam_name)
                            logger.log("EmuManager",
                                       "[5] eDVB.%s(%s) OK"
                                       % (method, cam_name))
                            done = True
                            break
                        except Exception as e:
                            logger.log("EmuManager",
                                       "[5] eDVB.%s failed: %s"
                                       % (method, e))

                if not done:
                    logger.log("EmuManager",
                               "[5] eDVB has no set* method — skipping")
            else:
                logger.log("EmuManager",
                           "[5] eDVBResourceManager instance is None")
        except Exception as e:
            logger.log("EmuManager", "[5] eDVB access failed: %s" % e)

        # ═══════════════════════════════════════════════════════════
        #  ⑥ ServiceAction.switchSoftcam
        # ═══════════════════════════════════════════════════════════
        try:
            from Tools.ServiceAction import ServiceAction
            logger.log("EmuManager",
                       "[6] Calling ServiceAction.switchSoftcam(%s)"
                       % cam_name)
            ServiceAction.switchSoftcam(cam_name, None)
            logger.log("EmuManager",
                       "[6] ServiceAction returned")
        except Exception as e:
            logger.log("EmuManager",
                       "[6] ServiceAction failed: %s" % e)

        # ═══════════════════════════════════════════════════════════
        #  ⑦ ⭐ InfoBar replay (بدون stop) + fallback
        #  playService(current) مباشرة → إعادة تشغيل سريعة بدون توقف
        # ═══════════════════════════════════════════════════════════
        try:
            from Screens.InfoBar import InfoBar
            inst = InfoBar.instance
            if inst is not None and hasattr(inst, "session"):
                nav = inst.session.nav
                if nav is not None:
                    current = None
                    try:
                        current = nav.getCurrentlyPlayingServiceReference()
                    except Exception:
                        pass

                    if current:
                        logger.log("EmuManager",
                                   "[7] Replaying service (no stop)...")
                        try:
                            # ⭐ إعادة تشغيل مباشرة — بدون stop
                            nav.playService(current, adjust=False)
                            logger.log("EmuManager",
                                       "[7] Service replayed OK")
                        except Exception as e:
                            logger.log("EmuManager",
                                       "[7] Replay failed: %s — "
                                       "trying stop+play" % e)
                            # fallback: stop + play
                            try:
                                nav.stopService()
                                _time.sleep(0.3)
                                nav.playService(current)
                                logger.log("EmuManager",
                                           "[7] Stop+play OK")
                            except Exception as e2:
                                logger.log("EmuManager",
                                           "[7] Stop+play failed: %s" % e2)
                    else:
                        logger.log("EmuManager",
                                   "[7] No current service")
            else:
                logger.log("EmuManager",
                           "[7] InfoBar instance unavailable")
        except Exception as e:
            logger.log("EmuManager",
                       "[7] InfoBar access failed: %s" % e)

        # ═══════════════════════════════════════════════════════════
        #  ⑧ updateSysSoftCam (final)
        # ═══════════════════════════════════════════════════════════
        try:
            from Components.SystemInfo import updateSysSoftCam
            updateSysSoftCam()
            logger.log("EmuManager", "[8] updateSysSoftCam() (final)")
        except Exception:
            pass

        # ═══════════════════════════════════════════════════════════
        #  ⑨ FINAL VERIFY
        # ═══════════════════════════════════════════════════════════
        _time.sleep(0.3)

        try:
            new_current, new_target = _read_active_cam_link()
            logger.log("EmuManager",
                       "[9] FINAL link: %s -> %s"
                       % (new_current or "(none)",
                          new_target or "(none)"))

            ok = _verify_settings_key("config.misc.softcams", cam_name)
            logger.log("EmuManager",
                       "[9] FINAL settings verify: %s" % ok)

            try:
                cfg = _get_enigma_config()
                if cfg and hasattr(cfg, "misc") and \
                        hasattr(cfg.misc, "softcams"):
                    mem_value = cfg.misc.softcams.value
                    mem_default = getattr(cfg.misc.softcams, "default", None)
                    logger.log("EmuManager",
                               "[9] FINAL memory: value=%s default=%s"
                               % (mem_value, mem_default))
            except Exception:
                pass
        except Exception as e:
            logger.log("EmuManager",
                       "[9] FINAL verify error: %s" % e)

        logger.log("EmuManager", "=" * 60)
        logger.log("EmuManager",
                   "Active Cam SET: %s" % cam_name)
        logger.log("EmuManager", "=" * 60)

        return True

    # ------------------------------------------------------------------
    def _clear_active_cam_state(self, previous_emu=None):
        """يمسح Active Cam يدوياً."""
        logger.log("EmuManager", "=" * 60)
        logger.log("EmuManager", "CLEARING Active Cam")
        logger.log("EmuManager", "=" * 60)

        # ① الرابط → None
        try:
            if os.path.isfile(SOFTCAM_NONE):
                _run("ln -sf %s %s" % (SOFTCAM_NONE, SOFTCAM_LINK),
                     timeout=3)
            elif os.path.islink(SOFTCAM_LINK):
                os.unlink(SOFTCAM_LINK)
            logger.log("EmuManager", "[1] Link set to None")
        except Exception as e:
            logger.log("EmuManager", "[1] link None failed: %s" % e)

        # ② settings
        try:
            _write_settings_key("config.misc.softcams", "None")
            logger.log("EmuManager", "[2] settings set to None")
        except Exception:
            pass

        # ③ الذاكرة
        try:
            from Components.config import ConfigSelection            
            from Components.config import config as global_config

            if hasattr(global_config.misc, "softcams"):
                try:
                    delattr(global_config.misc, "softcams")
                except Exception:
                    pass

            softcams_list = _get_available_softcams()
            global_config.misc.softcams = ConfigSelection(
                default="None",
                choices=softcams_list)

            global_config.misc.softcams.value = "None"

            try:
                global_config.misc.softcams.save()
            except Exception:
                pass
            try:
                global_config.misc.save()
            except Exception:
                pass

            logger.log("EmuManager", "[3] memory set to None")
        except Exception as e:
            logger.log("EmuManager",
                       "[3] memory clear failed: %s" % e)

        # ④ SystemInfo
        try:
            from Components.SystemInfo import updateSysSoftCam
            updateSysSoftCam()
        except Exception:
            pass

        try:
            from Components.SystemInfo import SystemInfo
            if isinstance(SystemInfo, dict):
                SystemInfo["Softcam"] = "None"
        except Exception:
            pass

        logger.log("EmuManager", "Active cam cleared")

    def clear_active_cam(self):
        """واجهة عامة لمسح Active Cam."""
        self._clear_active_cam_state()
        return True

    # ==================================================================
    #  Control — Start/Stop/Restart
    # ==================================================================
    def start(self, emu):
        return self._control(emu, "start")

    def stop(self, emu):
        return self._control(emu, "stop")

    def restart(self, emu):
        return self._control(emu, "restart")

    def toggle(self, emu):
        if emu is None:
            return False, "No emulator"
        if emu.running:
            return self.stop(emu)
        return self.start(emu)

    def _control(self, emu, action):
        """تنفيذ سريع + العملية الفعلية في Thread منفصل."""
        if emu is None:
            return False, "No emulator"

        script = emu.init_script
        if not script or not self._is_valid_script(script):
            logger.log("EmuManager",
                       "_control FAILED: no init_script for %s (script=%r)"
                       % (emu.name, script))
            return False, "No init script for %s" % emu.name

        logger.log("EmuManager",
                   "_control: %s %s script=%s"
                   % (emu.name, action, script))

        # ⭐ عيّن hints
        _set_hints_for(emu)

        # ① Active Cam فوراً
        try:
            if action in ("start", "restart"):
                ok = self._set_active_cam_state(emu)
                logger.log("EmuManager",
                           "_control: _set_active_cam_state → %s" % ok)
            elif action == "stop":
                current, _ = _read_active_cam_link()
                logger.log("EmuManager",
                           "_control stop: current=%r emu=%r"
                           % (current, emu.name))
                if current and current.lower() == emu.name.lower():
                    self._clear_active_cam_state(emu)
        except Exception as e:
            logger.log("EmuManager",
                       "_control active cam update failed: %s" % e)

        # ② العملية الفعلية في Thread منفصل
        try:
            t = threading.Thread(
                target=self._do_control_bg,
                args=(emu, action, script))
            t.setDaemon(True)
            t.start()
        except Exception as e:
            logger.log("EmuManager",
                       "_control thread spawn failed: %s" % e)

        if action == "start":
            msg = "%s: activating..." % emu.name
        elif action == "stop":
            msg = "%s: deactivating..." % emu.name
        elif action == "restart":
            msg = "%s: restarting..." % emu.name
        else:
            msg = "%s: %s OK" % (emu.name, action)
        return True, msg

    def _do_control_bg(self, emu, action, script):
        """العملية الكاملة في الخلفية."""
        try:
            stopped_others = []

            if action in ("start", "restart"):
                stopped_others = self._stop_others_sync(emu)

            cmd = "%s %s" % (script, action)
            logger.log("EmuManager",
                       "Background exec: %s" % cmd)
            rc, out, err = _run(cmd, timeout=CMD_TIMEOUT)

            emu.running = self._check_running(emu)
            emu.enabled = emu.running

            msg = "%s: %s %s (rc=%d)" % (
                emu.name, action,
                "OK" if rc == 0 else "failed", rc)
            if stopped_others:
                msg += " (stopped: %s)" % ", ".join(stopped_others)
            logger.log("EmuManager", msg)
        except Exception as e:
            logger.log("EmuManager",
                       "_do_control_bg error: %s" % e)

    def _stop_others_sync(self, keep_emu):
        """يوقف المحاكيات الأخرى وينتظر انتهاءها فعلاً."""
        stopped = []
        try:
            emus = self.discover()
        except Exception as e:
            logger.log("EmuManager",
                       "_stop_others_sync: discover failed: %s" % e)
            return stopped

        for other in emus:
            if other.key == keep_emu.key:
                continue

            is_running = self._check_running(other)
            if not is_running:
                continue

            script = other.init_script
            if not script or not self._is_valid_script(script):
                continue

            logger.log("EmuManager",
                       "_stop_others_sync: stopping %s ..."
                       % other.name)

            _run_async("%s stop" % script)

            start = _time.time()
            while _time.time() - start < STOP_WAIT_TIMEOUT:
                rc, out, _ = _run(
                    "pidof %s 2>/dev/null" % other.name,
                    timeout=1)
                if rc != 0 or not out.strip():
                    break
                _time.sleep(STOP_POLL_INTERVAL)

            elapsed = _time.time() - start
            if elapsed >= STOP_WAIT_TIMEOUT:
                logger.log("EmuManager",
                           "_stop_others_sync: %s timeout - killall"
                           % other.name)
                # SIGTERM ثم SIGKILL
                _run_async("killall -TERM %s 2>/dev/null" % other.name)
                _time.sleep(0.5)
                _run_async("killall -9 %s 2>/dev/null" % other.name)
                _time.sleep(0.3)
            else:
                logger.log("EmuManager",
                           "_stop_others_sync: %s stopped in %.2fs"
                           % (other.name, elapsed))

            other.running = False
            other.enabled = False
            stopped.append(other.name)

        return stopped

    # ==================================================================
    #  Status
    # ==================================================================
    def get_running_count(self):
        """يُعيد (عدد العامل، الإجمالي)."""
        emus = self.discover()
        return (sum(1 for e in emus if e.running), len(emus))

    def get_status(self, emu):
        if emu is None:
            return "unknown"
        emu.running = self._check_running(emu)
        emu.enabled = emu.running
        return "running" if emu.running else "stopped"

    # ==================================================================
    #  Active Cam getter
    # ==================================================================
    def get_active_cam_name(self):
        """يقرأ اسم المحاكي النشط."""
        name, target = _read_active_cam_link()
        if name:
            return name

        try:
            cfg = _get_enigma_config()
            if cfg is not None:
                if hasattr(cfg, "misc") and \
                        hasattr(cfg.misc, "softcams"):
                    v = (cfg.misc.softcams.value or "").strip()
                    if v and v.lower() != "none":
                        return v
        except Exception:
            pass

        return "No CAM active"

    # ==================================================================
    #  واجهة عامة
    # ==================================================================
    def force_active_cam(self, emu):
        """واجهة عامة لإجبار Active Cam."""
        logger.log("EmuManager",
                   "force_active_cam() called for %s"
                   % (emu.name if emu else "None"))
        return self._set_active_cam_state(emu)