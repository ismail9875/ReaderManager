# -*- coding: utf-8 -*-
"""
utils/reader_stats.py — تجميع إحصائيات الريدرات من WebIF.

v4 (نهائي):
    - قراءة مباشرة من ReaderStatus (oscamapi/ncamapi v6)
    - دعم الحقول الفعلية: ecmok, ecmnok, ecm_timeout, success_rate_val
    - ترتيب متعدد المعايير (أسرع، أكثر تزويداً، إلخ)
"""
from __future__ import absolute_import, print_function, unicode_literals

from ..utils import logger


# ═══════════════════════════════════════════════════════════════════
#  استخراج إحصائيات قارئ واحد
# ═══════════════════════════════════════════════════════════════════
def extract_reader_stats(reader_info):
    """
    يستخرج من ReaderStatus (oscamapi/ncamapi v6).

    ReaderStatus يحتوي على:
        - ecmok         (ECMs الناجحة)
        - ecmnok        (ECMs الفاشلة)
        - ecm_timeout   (Timeouts)
        - ecm_count     (الإجمالي، محسوب)
        - cw_count      (الشفرات المُزودة)
        - avg_time_ms   (متوسط وقت الاستجابة)
        - success_rate_val (نسبة النجاح من OSCam مباشرة)
    """
    stats = {
        "label":         "?",
        "protocol":      "",
        "is_connected":  False,
        "cards":         0,
        "ecm_count":     0,
        "ecm_ok":        0,
        "ecm_nok":       0,
        "ecm_timeout":   0,
        "avg_time_ms":   0.0,
        "min_time_ms":   0.0,
        "max_time_ms":   0.0,
        "cw_count":      0,
        "success_rate":  0.0,
        "score":         0.0,
    }

    if reader_info is None:
        return stats

    # ─── قراءة مباشرة من ReaderStatus ───
    stats["label"] = str(getattr(reader_info, "label", "?") or "?")
    stats["protocol"] = str(getattr(reader_info, "protocol", "") or "")
    stats["is_connected"] = bool(getattr(reader_info, "is_connected", False))
    stats["cards"] = int(getattr(reader_info, "card_count", 0) or 0)

    stats["ecm_count"] = int(getattr(reader_info, "ecm_count", 0) or 0)
    stats["ecm_ok"] = int(getattr(reader_info, "ecmok", 0) or 0)
    stats["ecm_nok"] = int(getattr(reader_info, "ecmnok", 0) or 0)
    stats["ecm_timeout"] = int(getattr(reader_info, "ecm_timeout", 0) or 0)
    stats["cw_count"] = int(getattr(reader_info, "cw_count", 0) or 0)

    stats["avg_time_ms"] = float(
        getattr(reader_info, "avg_time_ms", 0.0) or 0.0)
    stats["min_time_ms"] = float(
        getattr(reader_info, "min_time_ms", 0.0) or 0.0)
    stats["max_time_ms"] = float(
        getattr(reader_info, "max_time_ms", 0.0) or 0.0)

    # ─── نسبة النجاح ───
    sr = getattr(reader_info, "success_rate_val", None)
    if sr is not None:
        try:
            stats["success_rate"] = float(sr)
        except (ValueError, TypeError):
            sr = None

    if sr is None:
        if stats["ecm_count"] > 0:
            stats["success_rate"] = (
                (stats["ecm_ok"] * 100.0) / stats["ecm_count"])
        elif stats["ecm_ok"] > 0:
            stats["success_rate"] = 100.0

    # ─── احتياطيات ───
    if stats["ecm_count"] == 0 and (
            stats["ecm_ok"] > 0 or stats["ecm_nok"] > 0):
        stats["ecm_count"] = stats["ecm_ok"] + stats["ecm_nok"]

    if stats["cw_count"] == 0 and stats["ecm_ok"] > 0:
        stats["cw_count"] = stats["ecm_ok"]

    # ─── درجة مركبة ───
    # score = success_rate * 0.6 + speed_score * 0.4
    if stats["is_connected"] and stats["ecm_count"] > 0:
        speed_score = 0.0
        if stats["avg_time_ms"] > 0:
            # 100ms → 100 نقطة، 1000ms → 10 نقاط
            speed_score = max(0.0, min(100.0,
                10000.0 / stats["avg_time_ms"]))
        stats["score"] = (stats["success_rate"] * 0.6
                          + speed_score * 0.4)

    return stats


# ═══════════════════════════════════════════════════════════════════
#  تجميع من API
# ═══════════════════════════════════════════════════════════════════
def collect_all_stats(api_client):
    if not api_client:
        return []
    try:
        readers = api_client.get_reader_status()
    except Exception as e:
        logger.log("ReaderStats", "get_reader_status error: %s" % e)
        return []

    result = []
    for r in readers:
        try:
            result.append(extract_reader_stats(r))
        except Exception as e:
            logger.log("ReaderStats",
                       "extract error for %r: %s" % (r, e))
    return result


# ═══════════════════════════════════════════════════════════════════
#  ⭐ الترتيب
# ═══════════════════════════════════════════════════════════════════
def top_fastest(stats_list, n=5, min_ecm=1):
    """أسرع الريدرات (أقل avg_time_ms)."""
    candidates = [
        s for s in stats_list
        if s["is_connected"]
        and s["ecm_count"] >= min_ecm
        and s["avg_time_ms"] > 0
    ]
    candidates.sort(key=lambda s: s["avg_time_ms"])
    return candidates[:n]


def get_fastest_reader(stats_list, min_ecm=1):
    """يُرجع أسرع ريدر واحد أو None."""
    top = top_fastest(stats_list, n=1, min_ecm=min_ecm)
    return top[0] if top else None


def top_most_providing(stats_list, n=5):
    """أكثر الريدرات تزويداً للشفرات (أعلى ecm_count)."""
    c = [s for s in stats_list if s["ecm_count"] > 0]
    c.sort(key=lambda s: s["ecm_count"], reverse=True)
    return c[:n]


def top_best_success_rate(stats_list, n=5, min_ecm=1):
    """أعلى نسبة نجاح."""
    c = [s for s in stats_list
         if s["ecm_count"] >= min_ecm and s["success_rate"] > 0]
    c.sort(key=lambda s: s["success_rate"], reverse=True)
    return c[:n]


def top_worst_failures(stats_list, n=5):
    """أكثر الريدرات فشلاً."""
    c = [s for s in stats_list if s["ecm_nok"] > 0]
    c.sort(key=lambda s: s["ecm_nok"], reverse=True)
    return c[:n]


def top_cards(stats_list, n=5):
    """أكثر الريدرات احتواءً على كروت."""
    c = [s for s in stats_list if s["cards"] > 0]
    c.sort(key=lambda s: s["cards"], reverse=True)
    return c[:n]


def top_by_score(stats_list, n=5):
    """ترتيب حسب الدرجة المركبة (نجاح + سرعة)."""
    c = [s for s in stats_list if s["score"] > 0]
    c.sort(key=lambda s: s["score"], reverse=True)
    return c[:n]


# ═══════════════════════════════════════════════════════════════════
#  ملخّص
# ═══════════════════════════════════════════════════════════════════
def summary(stats_list):
    total_ecm = sum(s["ecm_count"] for s in stats_list)
    total_ok = sum(s["ecm_ok"] for s in stats_list)
    total_nok = sum(s["ecm_nok"] for s in stats_list)
    total_timeout = sum(s["ecm_timeout"] for s in stats_list)
    total_cards = sum(s["cards"] for s in stats_list)
    connected = sum(1 for s in stats_list if s["is_connected"])

    # متوسط عام مرجّح بعدد ECMs
    weighted_sum = 0.0
    weight_total = 0
    for s in stats_list:
        if s["avg_time_ms"] > 0 and s["ecm_count"] > 0:
            weighted_sum += s["avg_time_ms"] * s["ecm_count"]
            weight_total += s["ecm_count"]
    overall_avg = (weighted_sum / weight_total) if weight_total > 0 else 0.0

    success = (total_ok * 100.0 / total_ecm) if total_ecm > 0 else 0.0

    return {
        "readers_total":     len(stats_list),
        "readers_connected": connected,
        "total_cards":       total_cards,
        "total_ecm":         total_ecm,
        "total_ok":          total_ok,
        "total_nok":         total_nok,
        "total_timeout":     total_timeout,
        "overall_avg_ms":    overall_avg,
        "overall_success":   success,
    }