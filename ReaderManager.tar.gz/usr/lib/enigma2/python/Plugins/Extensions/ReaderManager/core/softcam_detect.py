# -*- coding: utf-8 -*-
"""
core/softcam_detect.py — كشف المحاكي النشط.

v7 (نهائي):
    - قراءة ConfigDir من oscam.version (مصدر الحقيقة)
    - قراءة Version من oscam.version
    - كشف Reader file تلقائياً
    - بحث نشط عن PID في /proc
    - استخراج Binary من cmdline
    - fallback متعدد المستويات
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import time

from ..utils import logger


# ═══════════════════════════════════════════════════════════════════
#  المسارات الثابتة
# ═══════════════════════════════════════════════════════════════════
_INIT_LINK      = "/etc/init.d/softcam"
_OSCAM_VERSION  = "/tmp/.oscam/oscam.version"
_NCAM_VERSION   = "/tmp/.ncam/ncam.version"

# ملفات readers المحتملة (بالترتيب)
_READER_FILES = [
    "oscam.server",
    "oscam.reader",
    "ncam.server",
    "ncam.reader",
    "reader.conf",
    "reader.cfg",
    "gcam.reader",
]


# ═══════════════════════════════════════════════════════════════════
#  قراءة ملف oscam.version / ncam.version
# ═══════════════════════════════════════════════════════════════════
def _read_version_file(path):
    """
    يقرأ oscam.version أو ncam.version.

    البنية الفعلية:
        Version:        2.26.07-11966-803@590510
        ...
        WebifPort:      8888
        ...
        ConfigDir:      /etc/tuxbox/config/
        ...

    Returns:
        dict: version, config_dir, webif_port
    """
    result = {
        "version":    None,
        "config_dir": None,
        "webif_port": None,
    }

    if not path or not os.path.exists(path):
        return result

    try:
        with open(path, "r") as f:
            content = f.read()

        # ─── ConfigDir ───
        # ConfigDir:      /etc/tuxbox/config/
        # ConfigDir=/etc/tuxbox/config
        m = re.search(r'ConfigDir\s*[=:]\s*([^\r\n]+)',
                       content, re.IGNORECASE)
        if m:
            value = m.group(1).strip()
            # أزل الشرطة المائلة الزائدة
            value = value.rstrip("/") or value
            result["config_dir"] = value

        # ─── Version ───
        m = re.search(r'^Version\s*[=:]\s*([^\r\n]+)',
                       content, re.IGNORECASE | re.MULTILINE)
        if m:
            result["version"] = m.group(1).strip()

        # ─── WebifPort ───
        m = re.search(r'WebifPort\s*[=:]\s*(\d+)',
                       content, re.IGNORECASE)
        if m:
            result["webif_port"] = m.group(1).strip()

        logger.log("SoftcamDetect",
                   "_read_version_file(%s): version=%r config=%r port=%r"
                   % (os.path.basename(path),
                      result["version"],
                      result["config_dir"],
                      result["webif_port"]))

    except Exception as e:
        logger.log("SoftcamDetect",
                   "_read_version_file(%s): %s" % (path, e))

    return result


# ═══════════════════════════════════════════════════════════════════
#  قراءة cmdline من /proc/<pid>/
# ═══════════════════════════════════════════════════════════════════
def _parse_cmdline(pid):
    """
    يقرأ /proc/<pid>/cmdline ويستخرج:
        binary, config_dir, pidfile

    يدعم:
        --config-dir PATH
        --config-dir=PATH
        --configdir=PATH
        -c PATH
        -cPATH
    """
    result = {
        "binary":     None,
        "config_dir": None,
        "pidfile":    None,
        "raw_args":   [],
    }

    if not pid:
        return result

    try:
        with open("/proc/%d/cmdline" % pid, "rb") as f:
            data = f.read().decode("utf-8", "replace")

        parts = [p for p in data.split("\x00") if p]
        result["raw_args"] = parts

        if not parts:
            return result

        result["binary"] = parts[0]

        for i, part in enumerate(parts):
            low = part.lower()

            # ─── config-dir ───
            if low.startswith("--config-dir="):
                result["config_dir"] = part.split("=", 1)[1].strip()
                continue
            if low.startswith("--configdir="):
                result["config_dir"] = part.split("=", 1)[1].strip()
                continue
            if low in ("--config-dir", "--configdir"):
                if i + 1 < len(parts):
                    result["config_dir"] = parts[i + 1].strip()
                continue

            # -c PATH (شكل مختصر)
            if low == "-c":
                if i + 1 < len(parts):
                    nxt = parts[i + 1]
                    if not nxt.startswith("-"):
                        result["config_dir"] = nxt.strip()
                continue

            # -cPATH (متصل)
            if low.startswith("-c") and len(part) > 2:
                candidate = part[2:].strip()
                if candidate.startswith("/") or candidate.startswith("./"):
                    result["config_dir"] = candidate
                    continue

            # ─── pidfile ───
            if low.startswith("--pidfile="):
                result["pidfile"] = part.split("=", 1)[1].strip()
                continue
            if low == "--pidfile":
                if i + 1 < len(parts):
                    result["pidfile"] = parts[i + 1].strip()
                continue

        logger.log("SoftcamDetect",
                   "_parse_cmdline(%d): args=%d config=%r pidfile=%r"
                   % (pid, len(parts),
                      result["config_dir"], result["pidfile"]))

    except Exception as e:
        logger.log("SoftcamDetect",
                   "_parse_cmdline(%s): %s" % (pid, e))

    return result


# ═══════════════════════════════════════════════════════════════════
#  البحث النشط عن PID المحاكي
# ═══════════════════════════════════════════════════════════════════
def _find_real_oscam_pid(cam_name=None):
    """
    يبحث عن PID المحاكي الحقيقي في /proc.

    Args:
        cam_name: اسم المحاكي (مثل "OSCam_11966-803") أو None

    Returns:
        (pid, cmdline_readable) أو (None, None)
    """
    candidates = []

    try:
        proc_dirs = os.listdir("/proc")
    except Exception as e:
        logger.log("SoftcamDetect",
                   "_find_real_oscam_pid: listdir error: %s" % e)
        return None, None

    cam_base = os.path.basename(cam_name) if cam_name else None

    for entry in proc_dirs:
        if not entry.isdigit():
            continue

        pid = int(entry)
        if pid <= 1:
            continue

        cmdline_path = "/proc/%s/cmdline" % entry
        if not os.path.exists(cmdline_path):
            continue

        try:
            with open(cmdline_path, "rb") as f:
                data = f.read().decode("utf-8", "replace")
        except Exception:
            continue

        if not data:
            continue

        readable = data.replace("\x00", " ").strip()
        low = readable.lower()

        parts = data.split("\x00")
        exe = parts[0] if parts else ""
        exe_base = os.path.basename(exe)

        # تجاهل shells و Enigma
        if exe_base in ("sh", "bash", "enigma2", "python", "python2",
                        "python3", "ps", "grep"):
            continue

        # يجب أن يحتوي على كلمة دالة
        if not any(k in low for k in ("oscam", "ncam", "gcam")):
            continue

        # ─── حساب النقاط ───
        score = 0

        # 1) الاسم يطابق
        if cam_base and cam_base in readable:
            score += 100

        # 2) exe_base يطابق cam_base
        if cam_base and cam_base in exe_base:
            score += 80

        # 3) --config-dir
        if "--config-dir" in readable or "--configdir" in readable:
            score += 40

        # 4) من /usr/bin/
        if exe.startswith("/usr/bin/"):
            score += 20

        # 5) من /usr/sbin/
        if exe.startswith("/usr/sbin/"):
            score += 15

        # 6) PPid = 1 (daemon)
        try:
            with open("/proc/%s/status" % entry, "r") as f:
                for line in f:
                    if line.startswith("PPid:"):
                        ppid = int(line.split()[1])
                        if ppid == 1:
                            score += 30
                        break
        except Exception:
            pass

        # 7) Uid = 0
        try:
            with open("/proc/%s/status" % entry, "r") as f:
                for line in f:
                    if line.startswith("Uid:"):
                        uid = int(line.split()[1])
                        if uid == 0:
                            score += 10
                        break
        except Exception:
            pass

        if score > 0:
            candidates.append((score, pid, readable, exe))

    if not candidates:
        logger.log("SoftcamDetect",
                   "_find_real_oscam_pid: no candidates")
        return None, None

    candidates.sort(key=lambda x: -x[0])
    best_score, best_pid, best_cmd, best_exe = candidates[0]

    logger.log("SoftcamDetect",
               "_find_real_oscam_pid: PID=%d (score=%d) exe=%s"
               % (best_pid, best_score, best_exe))

    return best_pid, best_cmd


# ═══════════════════════════════════════════════════════════════════
#  ⭐ الكشف الرئيسي — detect_active_softcam
# ═══════════════════════════════════════════════════════════════════
def detect_active_softcam():
    """
    v7: كشف دقيق للمحاكي النشط.

    ترتيب الأولويات:
        1) init.d link → الاسم
        2) /proc scan → PID + Binary
        3) oscam.version → Version + ConfigDir (المصدر الأهم)
        4) cmdline → fallback لـ config
        5) reader file → تلقائياً من config_dir

    Returns:
        {
            "name":        str,
            "version":     str,
            "path":        str,   # binary path
            "pid":         int,
            "config_dir":  str,
            "reader_file": str,
            "status":      str,
            "type":        str,   # "oscam" / "ncam"
        }
    """
    result = {
        "name":        None,
        "version":     None,
        "path":        None,
        "pid":         None,
        "config_dir":  None,
        "reader_file": None,
        "status":      None,
        "type":        None,
    }

    # ═══ 1) الاسم من init.d link ═══
    try:
        if os.path.islink(_INIT_LINK):
            target = os.readlink(_INIT_LINK)
            base = os.path.basename(target)
            if base.startswith("softcam."):
                base = base[len("softcam."):]
            result["name"] = base
    except Exception as e:
        logger.log("SoftcamDetect", "init link: %s" % e)

    # ═══ 2) PID + Binary من /proc ═══
    pid, cmdline = _find_real_oscam_pid(result["name"])
    if pid:
        result["pid"] = pid

        info = _parse_cmdline(pid)
        if info.get("binary"):
            result["path"] = info["binary"]

        # إذا لم نعرف الاسم، استخرجه من binary
        if not result["name"] and info.get("binary"):
            result["name"] = os.path.basename(info["binary"])

    # ═══ 3) oscam.version (المصدر الأهم لـ ConfigDir) ═══
    for vf in (_OSCAM_VERSION, _NCAM_VERSION):
        if os.path.exists(vf):
            vinfo = _read_version_file(vf)

            if vinfo.get("version"):
                result["version"] = vinfo["version"]

            if vinfo.get("config_dir"):
                result["config_dir"] = vinfo["config_dir"]

            # النوع
            if "ncam" in vf.lower():
                result["type"] = "ncam"
            else:
                result["type"] = "oscam"

            break

    # ═══ 4) fallback: config من cmdline ═══
    if not result["config_dir"] and pid:
        info = _parse_cmdline(pid)
        if info.get("config_dir"):
            result["config_dir"] = info["config_dir"]
            result["config_dir"] = result["config_dir"].rstrip("/")

    # ═══ 5) اكتشف reader file ═══
    if result["config_dir"]:
        for fname in _READER_FILES:
            full = os.path.join(result["config_dir"], fname)
            if os.path.isfile(full):
                result["reader_file"] = full
                break

    # ═══ 6) نوع افتراضي من الاسم ═══
    if not result["type"] and result["name"]:
        low = result["name"].lower()
        result["type"] = "ncam" if "ncam" in low else "oscam"

    # ═══ 7) الحالة ═══
    if result["pid"]:
        result["status"] = "Running (PID %d)" % result["pid"]
    else:
        result["status"] = "Not running"

    logger.log("SoftcamDetect",
               "Active: name=%s pid=%s version=%s config=%s readers=%s"
               % (result["name"], result["pid"],
                  result["version"], result["config_dir"],
                  result["reader_file"]))

    return result


# ═══════════════════════════════════════════════════════════════════
#  التحقق من النوع
# ═══════════════════════════════════════════════════════════════════
def is_oscam_active(active_info=None):
    """هل OSCam هو النشط؟"""
    if active_info is None:
        active_info = detect_active_softcam()
    if not active_info:
        return False

    t = (active_info.get("type") or "").lower()
    name = (active_info.get("name") or "").lower()

    if t == "oscam":
        return True
    if t == "ncam":
        return False

    if "ncam" in name:
        return False
    if "oscam" in name:
        return True

    return True


def is_ncam_active(active_info=None):
    """هل NCam هو النشط؟"""
    if active_info is None:
        active_info = detect_active_softcam()
    if not active_info:
        return False

    t = (active_info.get("type") or "").lower()
    name = (active_info.get("name") or "").lower()

    if t == "ncam":
        return True
    if t == "oscam":
        return False

    return "ncam" in name


# ═══════════════════════════════════════════════════════════════════
#  نص الحالة
# ═══════════════════════════════════════════════════════════════════
def get_status_for_active(active_info=None):
    """يُرجع نص الحالة المختصر."""
    if active_info is None:
        active_info = detect_active_softcam()
    if not active_info:
        return "No softcam"

    name = active_info.get("name") or "?"
    status = active_info.get("status") or "?"
    return "%s: %s" % (name, status)


# ═══════════════════════════════════════════════════════════════════
#  ⭐ قتل عمليات المحاكيات الأخرى
# ═══════════════════════════════════════════════════════════════════
def kill_other_softcams(active_name=None, force=False):
    """
    يقتل كل عمليات OSCam/NCam ما عدا المحاكي النشط.

    Args:
        active_name: اسم المحاكي النشط (يُبقى)
        force: إذا True، استخدم SIGKILL مباشرة

    Returns:
        قائمة PIDs التي تم قتلها
    """
    killed = []
    sig = 9 if force else 15

    try:
        for entry in os.listdir("/proc"):
            if not entry.isdigit():
                continue

            pid = int(entry)
            if pid <= 1:
                continue

            cmdline_path = "/proc/%s/cmdline" % entry
            if not os.path.exists(cmdline_path):
                continue

            try:
                with open(cmdline_path, "rb") as f:
                    data = f.read().decode("utf-8", "replace")
            except Exception:
                continue

            if not data:
                continue

            readable = data.replace("\x00", " ").strip()
            low = readable.lower()

            if not any(k in low for k in ("oscam", "ncam", "gcam")):
                continue

            # تجاهل النشط
            if active_name and active_name in readable:
                continue

            parts = data.split("\x00")
            exe = parts[0] if parts else ""
            if os.path.basename(exe) in ("sh", "bash", "enigma2"):
                continue

            try:
                os.kill(pid, sig)
                killed.append(pid)
                logger.log("SoftcamDetect",
                           "kill_others: SIG%d PID %d" % (sig, pid))
            except Exception as e:
                logger.log("SoftcamDetect",
                           "kill_others SIG%d %d: %s" % (sig, pid, e))
    except Exception as e:
        logger.log("SoftcamDetect", "kill_others error: %s" % e)

    return killed


# ═══════════════════════════════════════════════════════════════════
#  إعادة تشغيل المحاكي النشط
# ═══════════════════════════════════════════════════════════════════
def restart_active_softcam():
    """
    يعيد تشغيل المحاكي النشط عبر init.d.

    Returns:
        (ok, message)
    """
    active = detect_active_softcam()
    if not active:
        return False, "No active softcam"

    name = active.get("name")
    if not name:
        return False, "Cannot determine softcam name"

    script = "/etc/init.d/softcam.%s" % name
    if not os.path.exists(script):
        return False, "Init script not found: %s" % script

    try:
        import subprocess
        logger.log("SoftcamDetect",
                   "restart: %s restart" % script)
        p = subprocess.Popen([script, "restart"],
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        p.wait()
        return True, "Restarted %s" % name
    except Exception as e:
        logger.log("SoftcamDetect", "restart error: %s" % e)
        return False, str(e)