# -*- coding: utf-8 -*-
"""
utils/field_help.py — نصوص المساعدة ثنائية اللغة لحقول القارئ.

يُوفّر:
    - get_help(field_name)     : نص المساعدة لحقل
    - get_help_dict()          : نسخة من قاعدة البيانات
    - has_help(field_name)     : هل يوجد نص مساعدة؟
    - add_help(field_name, text): إضافة/تحديث
    - reload_help()            : إعادة تحميل (للتوسّع المستقبلي)
"""
from __future__ import absolute_import, print_function, unicode_literals


# ═══════════════════════════════════════════════════════════════════
#  Bilingual help database
#  المفتاح = اسم الحقل الظاهر في القائمة
# ═══════════════════════════════════════════════════════════════════
HELP_DATA = {

    # ─────────────────────────────────────────────────────────────
    #  General Settings
    # ─────────────────────────────────────────────────────────────
    "Label": (
        "Reader Label\n"
        "-------------------------------------------\n"
        "Unique identifier for this reader.\n"
        "\n"
        "Recommendation:\n"
        "  * Use descriptive names (e.g. server1, local_card)\n"
        "  * Allowed: letters, digits, dot (.), dash (-), underscore (_)\n"
        "  * Must be unique within the same file\n"
        "  * Minimum 2 characters\n"
        "\n"
        "Reference: wiki.streamboard.tv - oscam.server"
    ),

    "Status": (
        "Reader Status\n"
        "-------------------------------------------\n"
        "Enabled  : reader is active and will be loaded\n"
        "Disabled : reader is skipped (kept in file)\n"
        "\n"
        "Recommendation:\n"
        "  * Use Disabled for temporary testing without deleting\n"
        "  * Use the Blue button to quickly toggle state"
    ),

    "Protocol": (
        "Protocol Type\n"
        "-------------------------------------------\n"
        "Common protocols:\n"
        "  * cccam    : CCcam line (C: host port user pass)\n"
        "  * newcamd  : Newcamd line with DES key\n"
        "  * mgcamd   : Mgcamd protocol (NCam only)\n"
        "  * cs378x   : Cache-Exchange TCP\n"
        "  * camd35   : Camd 3.5 protocol\n"
        "  * gbox     : GBox protocol\n"
        "  * radegast : Radegast protocol\n"
        "  * mouse    : Smartcard reader (serial/USB)\n"
        "  * smartreader : Smargo / SmartReader\n"
        "  * pcsc     : PC/SC reader\n"
        "  * internal : Internal card reader (DreamBox)\n"
        "  * constcw  : Constant CW file\n"
        "  * cacheex  : Cache-Exchange mode\n"
        "  * emu      : Emulator (SoftCam.Key)\n"
        "\n"
        "Simple Mode  : cccam, newcamd, mgcamd, emu\n"
        "Advanced Mode: all protocols\n"
        "\n"
        "Reference: wiki.streamboard.tv - oscam.server"
    ),

    "Host ": (
        "Host / Device\n"
        "-------------------------------------------\n"
        "For network protocols (TCP):\n"
        "  IP address or DNS name\n"
        "  Example: 192.168.1.100  or  server.example.com\n"
        "\n"
        "For local readers:\n"
        "  Device path\n"
        "  Example: /dev/sci0  /dev/sci1  /dev/ttyUSB0\n"
        "\n"
        "For emulator:\n"
        "  0  or  emu\n"
        "\n"
        "Recommendation:\n"
        "  * Use static IP for network reliability\n"
        "  * Ensure DNS resolution works if using hostnames"
    ),

    "Port": (
        "Port Number\n"
        "-------------------------------------------\n"
        "TCP port for network protocols.\n"
        "\n"
        "Common defaults:\n"
        "  * CCcam    : 12000\n"
        "  * Newcamd  : 34000 (or 10000-50000)\n"
        "  * CS378x   : 13001\n"
        "  * Camd35   : 12345\n"
        "  * GBox     : 8000\n"
        "  * Radegast : 23889\n"
        "\n"
        "Range: 1 - 65535\n"
        "Local protocols (internal, mouse) -> 0"
    ),

    "Username": (
        "Username\n"
        "-------------------------------------------\n"
        "Login name for authentication.\n"
        "\n"
        "Required for:\n"
        "  cccam, newcamd, mgcamd, cs378x, camd35,\n"
        "  gbox, radegast, cacheex\n"
        "\n"
        "Not required for:\n"
        "  internal, mouse, smartreader, pcsc, emu\n"
        "\n"
        "Recommendation:\n"
        "  * Keep unique per reader\n"
        "  * No spaces"
    ),

    "Password": (
        "Password\n"
        "-------------------------------------------\n"
        "Password for authentication (case-sensitive).\n"
        "\n"
        "Recommendation:\n"
        "  * Unique per reader\n"
        "  * Avoid characters that break config parser\n"
        "  * Length: 1 - 64 characters\n"
        "  * Use different passwords per server for security"
    ),

    "Group": (
        "Group Number\n"
        "-------------------------------------------\n"
        "Reader group(s) for load-balancing.\n"
        "\n"
        "Format:\n"
        "  * Single   : 1\n"
        "  * Multiple : 1,2,3\n"
        "\n"
        "Recommendation:\n"
        "  * Group 1: local cards (highest priority)\n"
        "  * Group 2: main server\n"
        "  * Group 3+: backup servers\n"
        "  * Range: 1 - 64\n"
        "  * Use commas without spaces"
    ),

    "Keepalive": (
        "Keepalive\n"
        "-------------------------------------------\n"
        "Keep TCP connection alive during idle periods.\n"
        "\n"
        "Enabled  : send periodic keepalive packets\n"
        "Disabled : connection may close when idle\n"
        "\n"
        "Recommendation:\n"
        "  * Enabled for internet servers\n"
        "  * Disabled for local LAN (rarely needed)"
    ),

    "CCcam Version": (
        "CCcam Version\n"
        "-------------------------------------------\n"
        "Version reported to CCcam server.\n"
        "\n"
        "Options:\n"
        "  * 2.0.11 : older, some servers require\n"
        "  * 2.1.x  : widespread compatibility\n"
        "  * 2.2.x  : most common\n"
        "  * 2.3.2  : latest (recommended)\n"
        "\n"
        "Recommendation:\n"
        "  * Use 2.3.2 unless server rejects\n"
        "  * If rejected, downgrade to 2.1.1"
    ),

    "Key": (
        "DES Key\n"
        "-------------------------------------------\n"
        "Encryption key for Newcamd / Mgcamd protocols.\n"
        "\n"
        "Format: hexadecimal string (8-64 chars)\n"
        "Default: 0102030405060708091011121314\n"
        "\n"
        "Recommendation:\n"
        "  * Must match the server's key EXACTLY\n"
        "  * Typically 14 bytes (28 hex chars)\n"
        "  * Case insensitive"
    ),

    "Detect": (
        "Card Detect Mode\n"
        "-------------------------------------------\n"
        "How the reader detects an inserted smartcard.\n"
        "\n"
        "Options:\n"
        "  * cd   : Carrier Detect (pin) - recommended\n"
        "  * dsr  : Data Set Ready\n"
        "  * cts  : Clear To Send\n"
        "  * ring : Ring Indicator\n"
        "  * none : Always inserted (unresponsive readers)\n"
        "\n"
        "Recommendation:\n"
        "  * Use 'cd' for standard readers\n"
        "  * Use 'none' if detection fails repeatedly"
    ),

    # ─────────────────────────────────────────────────────────────
    #  Identifiers
    # ─────────────────────────────────────────────────────────────
    "CAID": (
        "CAID List\n"
        "-------------------------------------------\n"
        "Conditional Access IDs the reader can decode.\n"
        "\n"
        "Format: comma-separated hexadecimal\n"
        "  Example: 0500,0604,0B00,1810\n"
        "\n"
        "Common CAIDs:\n"
        "  * 0500 : Viaccess\n"
        "  * 0604 : Irdeto\n"
        "  * 0B00 : Conax\n"
        "  * 1810 : Nagravision\n"
        "  * 098C : NDS/Videoguard\n"
        "  * 0E00 : PowerVu\n"
        "  * 2600 : Biss\n"
        "\n"
        "Recommendation:\n"
        "  * Leave empty to accept all CAIDs\n"
        "  * Specify only if server requires filtering"
    ),

    "Ident": (
        "Ident List\n"
        "-------------------------------------------\n"
        "Provider identifiers for filtering.\n"
        "\n"
        "Format: CAID:PROVID pairs, comma-separated\n"
        "  Example: 0500:032830,0500:032920\n"
        "\n"
        "Recommendation:\n"
        "  * Leave empty for auto-detection\n"
        "  * Use to prevent ECM flooding\n"
        "  * Ask provider for correct Ident values"
    ),

    "CHID": (
        "CHID List\n"
        "-------------------------------------------\n"
        "Channel IDs for Cache-Exchange.\n"
        "\n"
        "Format: comma-separated hexadecimal\n"
        "  Example: 0001,0002,0003\n"
        "\n"
        "Recommendation:\n"
        "  * Usually required for cacheex protocol\n"
        "  * Leave empty for non-cacheex readers"
    ),

    # ─────────────────────────────────────────────────────────────
    #  EMM Management
    # ─────────────────────────────────────────────────────────────
    "Block Unique EMM": (
        "Block Unique EMM\n"
        "-------------------------------------------\n"
        "Block writing Unique EMMs to the card.\n"
        "\n"
        "Enabled  : reject unique EMMs\n"
        "Disabled : allow (default)\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for shared/remote cards\n"
        "  * Disable for personal cards (allows updates)"
    ),

    "Block Shared EMM": (
        "Block Shared EMM\n"
        "-------------------------------------------\n"
        "Block writing Shared EMMs.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for remote/shared readers\n"
        "  * Disable if card needs provider updates"
    ),

    "Block Global EMM": (
        "Block Global EMM\n"
        "-------------------------------------------\n"
        "Block writing Global EMMs.\n"
        "\n"
        "Recommendation:\n"
        "  * Usually enabled to protect the card\n"
        "  * Disable only if provider requires"
    ),

    "Block Unknown EMM": (
        "Block Unknown EMM\n"
        "-------------------------------------------\n"
        "Block writing unknown EMM types.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for security"
    ),

    "Block EMM by Length": (
        "Block EMM by Length\n"
        "-------------------------------------------\n"
        "Block EMMs of specific lengths.\n"
        "\n"
        "Format: comma-separated length values or ranges\n"
        "  Example: 50-60,100-110\n"
        "\n"
        "Recommendation:\n"
        "  * Use only when provider sends malicious EMM\n"
        "  * Leave empty normally"
    ),

    "Save Unique EMM": (
        "Save Unique EMM\n"
        "-------------------------------------------\n"
        "Save received Unique EMMs to file.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for debugging\n"
        "  * Disable for production (saves disk space)"
    ),

    "Save Shared EMM": (
        "Save Shared EMM\n"
        "-------------------------------------------\n"
        "Save received Shared EMMs.\n"
        "\n"
        "Recommendation:\n"
        "  * Usually disabled"
    ),

    "Save Global EMM": (
        "Save Global EMM\n"
        "-------------------------------------------\n"
        "Save received Global EMMs.\n"
        "\n"
        "Recommendation:\n"
        "  * Usually disabled"
    ),

    "EMM Cache": (
        "EMM Cache\n"
        "-------------------------------------------\n"
        "EMM caching configuration.\n"
        "\n"
        "Format: usecache,rewrite,logging\n"
        "  * usecache : enable EMM cache\n"
        "  * rewrite  : rewrite EMMs\n"
        "  * logging  : log EMM activity\n"
        "\n"
        "Example: 1,3,2\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for cards receiving many EMMs\n"
        "  * Disable if EMM write issues occur"
    ),

    # ─────────────────────────────────────────────────────────────
    #  Frequency (Local readers)
    # ─────────────────────────────────────────────────────────────
    "Card MHz": (
        "Card MHz\n"
        "-------------------------------------------\n"
        "Card clock frequency in 10 kHz units.\n"
        "\n"
        "Range: 100 - 2000 (i.e. 1 - 20 MHz)\n"
        "Default: 357 (3.57 MHz)\n"
        "\n"
        "Recommendation:\n"
        "  * 357 for most smartcards\n"
        "  * 500 for high-speed cards\n"
        "  * Leave empty for auto-detect"
    ),

    "Reader MHz": (
        "Reader MHz\n"
        "-------------------------------------------\n"
        "Reader clock frequency (same units as Card MHz).\n"
        "\n"
        "Default: 357\n"
        "\n"
        "Recommendation:\n"
        "  * Match Card MHz for stability\n"
        "  * Higher values for high-speed cards"
    ),

    "Auto Speed": (
        "Auto Speed\n"
        "-------------------------------------------\n"
        "Automatically detect card speed.\n"
        "\n"
        "Recommendation:\n"
        "  * Enabled by default\n"
        "  * Disable if reader has detection issues"
    ),

    "Deprecated Mode": (
        "Deprecated Mode\n"
        "-------------------------------------------\n"
        "Use deprecated communication mode.\n"
        "\n"
        "Recommendation:\n"
        "  * Keep disabled unless legacy reader requires"
    ),

    "Smargo Patch": (
        "Smargo Patch\n"
        "-------------------------------------------\n"
        "Enable Smargo-specific patching.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable only for genuine Smargo readers\n"
        "  * Disable for other hardware"
    ),

    # ─────────────────────────────────────────────────────────────
    #  Rate Limiting
    # ─────────────────────────────────────────────────────────────
    "Rate Limit ECM": (
        "Rate Limit ECM\n"
        "-------------------------------------------\n"
        "Maximum number of concurrent ECM requests.\n"
        "\n"
        "Range: 0 - 20\n"
        "  * 0  : disabled\n"
        "  * 1  : very strict (single ECM)\n"
        "  * 4  : typical for shared cards\n"
        "\n"
        "Recommendation:\n"
        "  * Use 2-4 for remote/shared readers\n"
        "  * Disable for local personal cards\n"
        "\n"
        "Reference: wiki.streamboard.tv - ratelimitecm"
    ),

    "Rate Limit Time": (
        "Rate Limit Time\n"
        "-------------------------------------------\n"
        "Minimum interval to release a slot.\n"
        "\n"
        "Unit: milliseconds\n"
        "Range: 3000 - 11000 ms\n"
        "  * 3000 : aggressive (may cause bad CWs)\n"
        "  * 8000 : minimum safe value\n"
        "  * 9000 : recommended\n"
        "  * 11000: very conservative\n"
        "\n"
        "Recommendation:\n"
        "  * 9000 ms for most setups\n"
        "  * 10000 ms for SECA/M7 cards\n"
        "  * Must be paired with srvidholdtime\n"
        "\n"
        "Reference: wiki.streamboard.tv - ratelimittime"
    ),

    "SRVID Hold Time": (
        "SRVID Hold Time\n"
        "-------------------------------------------\n"
        "Extra time that a service ID stays in its slot after\n"
        "ratelimittime expires, before being replaced.\n"
        "\n"
        "Unit: milliseconds\n"
        "Range: 0 - 5000 ms\n"
        "  * 0    : no hold (instant release)\n"
        "  * 2000 : default\n"
        "  * 5000 : maximum (aggressive caching)\n"
        "\n"
        "Recommendation:\n"
        "  * 2000 ms for most setups\n"
        "  * Increase if channels open slowly\n"
        "\n"
        "Reference: wiki.streamboard.tv - srvidholdtime"
    ),

    "Cooldown": (
        "Cooldown\n"
        "-------------------------------------------\n"
        "Delay before a channel retry after failed ECM.\n"
        "\n"
        "Format: delay,duration (in seconds)\n"
        "  * delay    : initial wait\n"
        "  * duration : max wait window\n"
        "\n"
        "Example: 10,60\n"
        "  = wait 10s, up to 60s max\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for unstable servers\n"
        "  * Disable (empty) for stable servers"
    ),

    "ECM Unique": (
        "ECM Unique\n"
        "-------------------------------------------\n"
        "Allow only one ECM request per unique SRVID+CAID.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable to reduce server load\n"
        "  * Disable if compatibility issues arise"
    ),

    # ─────────────────────────────────────────────────────────────
    #  Timeouts
    # ─────────────────────────────────────────────────────────────
    "Inactivity Timeout": (
        "Inactivity Timeout\n"
        "-------------------------------------------\n"
        "Close idle TCP connection to save resources.\n"
        "\n"
        "Unit: seconds\n"
        "Range: -1 to 120 s\n"
        "  * -1  : reconnect on failure (Newcamd only)\n"
        "  * 0   : disabled (keep connection open)\n"
        "  * 30  : for unstable internet\n"
        "  * 60  : for stable internet\n"
        "  * 120 : maximum (very aggressive)\n"
        "\n"
        "Recommendation:\n"
        "  * 0 for local LAN\n"
        "  * 60 for stable internet\n"
        "  * 30 for unstable internet\n"
        "  * 0 (or -1) for mobile/satellite\n"
        "\n"
        "Reference: wiki.streamboard.tv - inactivitytimeout"
    ),

    "Reconnect Timeout": (
        "Reconnect Timeout\n"
        "-------------------------------------------\n"
        "Delay before reconnecting after a TCP disconnection.\n"
        "\n"
        "Unit: seconds\n"
        "Range: 1 - 60 s\n"
        "  * 1  : aggressive reconnect\n"
        "  * 5  : default\n"
        "  * 10 : balanced\n"
        "  * 60 : very conservative\n"
        "\n"
        "Recommendation:\n"
        "  * 5 seconds for most setups\n"
        "  * Increase if server rate-limits reconnects\n"
        "  * Decrease if failover speed is critical\n"
        "\n"
        "Reference: wiki.streamboard.tv - reconnecttimeout"
    ),

    # ─────────────────────────────────────────────────────────────
    #  Additional
    # ─────────────────────────────────────────────────────────────
    "Class Filter": (
        "Class Filter\n"
        "-------------------------------------------\n"
        "Filter ECMs by class byte.\n"
        "\n"
        "Format: comma-separated hexadecimal\n"
        "  * 01     : allow class 01\n"
        "  * !1b    : exclude class 1b\n"
        "\n"
        "Example: 01,02,!1b\n"
        "\n"
        "Recommendation:\n"
        "  * Leave empty for most cases\n"
        "  * Advanced filtering only"
    ),

    "Fallback": (
        "Fallback Reader\n"
        "-------------------------------------------\n"
        "Mark this reader as fallback (last-resort).\n"
        "\n"
        "Enabled  : used only if primary readers fail\n"
        "Disabled : normal priority\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for slow backup servers\n"
        "  * Keeps fast servers as primary"
    ),

    "Drop Bad CWs": (
        "Drop Bad CWs\n"
        "-------------------------------------------\n"
        "Discard incorrect control words.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for unstable readers\n"
        "  * Disable if CW check is too strict"
    ),

    "Disable CRC CWS": (
        "Disable CRC CWS\n"
        "-------------------------------------------\n"
        "Disable CRC check on control words.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable only if provider has CRC issues\n"
        "  * Disable normally (safer)"
    ),

    "AU Disabled": (
        "AU Disabled\n"
        "-------------------------------------------\n"
        "Disable Auto-Update for this reader.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for shared cards (avoid updates)\n"
        "  * Disable if you want to allow updates"
    ),

    "Disable CRC For": (
        "Disable CRC For\n"
        "-------------------------------------------\n"
        "Disable CRC check for specific CAID:PROVID pairs.\n"
        "\n"
        "Format: comma-separated CAID:PROVID\n"
        "  Example: 0500:050000,0604:000000\n"
        "\n"
        "Recommendation:\n"
        "  * Use for providers with known CRC bug\n"
        "  * Leave empty normally"
    ),

    # ─────────────────────────────────────────────────────────────
    #  AES
    # ─────────────────────────────────────────────────────────────
    "AES Key": (
        "AES Key\n"
        "-------------------------------------------\n"
        "AES key for encrypted card communication.\n"
        "\n"
        "Format: hexadecimal (32, 48, or 64 chars)\n"
        "\n"
        "Recommendation:\n"
        "  * Required for some internal readers\n"
        "  * Leave empty if card doesn't use AES"
    ),

    "AES Keys": (
        "AES Keys\n"
        "-------------------------------------------\n"
        "Multiple AES keys separated by semicolons.\n"
        "\n"
        "Format: key1;key2;key3\n"
        "\n"
        "Recommendation:\n"
        "  * For multi-provider cards\n"
        "  * Leave empty if single key"
    ),

    # ─────────────────────────────────────────────────────────────
    #  Internal Advanced
    # ─────────────────────────────────────────────────────────────
    "PIN Code": (
        "PIN Code\n"
        "-------------------------------------------\n"
        "Card PIN for parental control unlock.\n"
        "\n"
        "Format: 4 digits (typically 0000 or 1234)\n"
        "\n"
        "Recommendation:\n"
        "  * Fill only if card is PIN-protected\n"
        "  * Leave empty if not used"
    ),

    "BoxID": (
        "BoxID\n"
        "-------------------------------------------\n"
        "Box identifier for certain providers.\n"
        "\n"
        "Format: hexadecimal (typically 8 chars)\n"
        "\n"
        "Recommendation:\n"
        "  * Provider-specific\n"
        "  * Leave empty unless required"
    ),

    "Mhrz": (
        "Mhrz\n"
        "-------------------------------------------\n"
        "Maximum hop rate zone (advanced).\n"
        "\n"
        "Range: 0 - 9000\n"
        "Default: 200\n"
        "\n"
        "Recommendation:\n"
        "  * Leave default unless documented"
    ),

    "Card Mhrz": (
        "Card Mhrz\n"
        "-------------------------------------------\n"
        "Card-level Mhrz value.\n"
        "\n"
        "Range: 0 - 9000\n"
        "Default: 450\n"
        "\n"
        "Recommendation:\n"
        "  * Leave default unless documented"
    ),

    # ─────────────────────────────────────────────────────────────
    #  CCcam Advanced
    # ─────────────────────────────────────────────────────────────
    "Reconnect Time < 9000": (
        "CCcam Reconnect Time\n"
        "-------------------------------------------\n"
        "Reconnect delay for CCcam protocol.\n"
        "\n"
        "Range: 0 - 9000 ms\n"
        "  0 : immediate\n"
        "\n"
        "Recommendation:\n"
        "  * 0 for fast servers\n"
        "  * 300-1000 for rate-limited servers"
    ),

    "CCC Max Hops < 10": (
        "CCcam Max Hops\n"
        "-------------------------------------------\n"
        "Maximum hops allowed for CCcam sharing.\n"
        "\n"
        "Range: 0 - 10\n"
        "  * 0 : no restriction\n"
        "  * 2 : typical for shared content\n"
        "  * 5+: for extended sharing\n"
        "\n"
        "Recommendation:\n"
        "  * Use 2 for public servers\n"
        "  * Use 0 for direct connections"
    ),

    "Enable CacheEx": (
        "Enable CacheEx\n"
        "-------------------------------------------\n"
        "Enable Cache-Exchange mode.\n"
        "\n"
        "Recommendation:\n"
        "  * Enable for cache-sharing networks\n"
        "  * Disable for private single-server setups"
    ),

    "CacheEx Mode": (
        "CacheEx Mode\n"
        "-------------------------------------------\n"
        "Cache-Exchange operating mode.\n"
        "\n"
        "Options:\n"
        "  * 1 : Cache Pull\n"
        "  * 2 : Cache Push\n"
        "  * 3 : Reverse Cache Push\n"
        "\n"
        "Recommendation:\n"
        "  * Mode 1 for client-side\n"
        "  * Mode 2 for server-side"
    ),

    "CacheEx MaxHop": (
        "CacheEx MaxHop\n"
        "-------------------------------------------\n"
        "Maximum hops in cache exchange.\n"
        "\n"
        "Range: 0 - 10\n"
        "\n"
        "Recommendation:\n"
        "  * 0-1 for private setups\n"
        "  * 2-3 for public cache networks"
    ),

    "CacheEx Wait": (
        "CacheEx Wait\n"
        "-------------------------------------------\n"
        "Wait time for cacheex response.\n"
        "\n"
        "Unit: milliseconds\n"
        "\n"
        "Recommendation:\n"
        "  * Leave default unless tuning"
    ),
}


# ═══════════════════════════════════════════════════════════════════
#  Aliases — إذا كان للحقل عدة تسميات في الواجهة
# ═══════════════════════════════════════════════════════════════════
HELP_ALIASES = {
    "Host":              "Host ",
    "Reader Label":      "Label",
    "Reader Status":     "Status",
    "Reader Group":      "Group",
    "Keepalive Enabled": "Keepalive",
    "CCCam Version":     "CCcam Version",
    "DES Key":           "Key",
    "Card Detect":       "Detect",
    "CAID List":         "CAID",
    "Ident List":        "Ident",
    "CHID List":         "CHID",
    "Block Unique":      "Block Unique EMM",
    "Block Shared":      "Block Shared EMM",
    "Block Global":      "Block Global EMM",
    "Save Unique":       "Save Unique EMM",
    "Save Shared":       "Save Shared EMM",
    "Save Global":       "Save Global EMM",
    "EMM by Length":     "Block EMM by Length",
    "EMMCache":          "EMM Cache",
    "RateLimit ECM":     "Rate Limit ECM",
    "RateLimit Time":    "Rate Limit Time",
    "SRVID Hold":        "SRVID Hold Time",
    "ECM Cooldown":      "Cooldown",
    "ECM Unique":        "ECM Unique",
    "Inactivity":        "Inactivity Timeout",
    "Reconnect Timeout": "Reconnect Timeout",
    "Class Filter":      "Class Filter",
    "Fallback Reader":   "Fallback",
    "Drop Bad CW":       "Drop Bad CWs",
    "Disable CRC":       "Disable CRC CWS",
    "AU Disabled":       "AU Disabled",
    "Disable CRC For":   "Disable CRC For",
    "AES Key":           "AES Key",
    "AES Keys":          "AES Keys",
    "PIN":               "PIN Code",
    "Pin Code":          "PIN Code",
    "Box ID":            "BoxID",
    "Mhrz":              "Mhrz",
    "Card Mhrz":         "Card Mhrz",
    "CCcam Reconnect":   "Reconnect Time < 9000",
    "Max Hops":          "CCC Max Hops < 10",
    "CacheEx Enable":    "Enable CacheEx",
    "CacheEx Mode":      "CacheEx Mode",
    "CacheEx MaxHop":    "CacheEx MaxHop",
    "CacheEx Wait":      "CacheEx Wait",
}


# ═══════════════════════════════════════════════════════════════════
#  Public API
# ═══════════════════════════════════════════════════════════════════
def get_help(field_name, default=""):
    """
    يُرجع نص المساعدة للحقل المطلوب.

    البحث:
        1. الاسم الدقيق
        2. الاسم عبر aliases
        3. بعد إزالة المسافات
    """
    if not field_name:
        return default

    # ① الاسم المباشر
    if field_name in HELP_DATA:
        return HELP_DATA[field_name]

    # ② alias
    alias = HELP_ALIASES.get(field_name)
    if alias and alias in HELP_DATA:
        return HELP_DATA[alias]

    # ③ إزالة المسافات
    stripped = field_name.strip()
    if stripped in HELP_DATA:
        return HELP_DATA[stripped]

    alias = HELP_ALIASES.get(stripped)
    if alias and alias in HELP_DATA:
        return HELP_DATA[alias]

    return default


def get_help_dict():
    """يُرجع نسخة من قاعدة البيانات كاملة."""
    return dict(HELP_DATA)


def has_help(field_name):
    """يتحقق إن كان للحقل نص مساعدة."""
    if not field_name:
        return False
    if field_name in HELP_DATA:
        return True
    stripped = field_name.strip()
    if stripped in HELP_DATA:
        return True
    return HELP_ALIASES.get(stripped, "") in HELP_DATA


def add_help(field_name, text):
    """يُضيف/يُحدّث نص مساعدة لحقل (للتخصيص)."""
    if field_name and text:
        HELP_DATA[field_name] = text


def reload_help():
    """
    نقطة إعادة تحميل (للاستخدام لاحقاً إذا رغبت بتحميل
    نصوص من ملف خارجي مثل JSON).
    """
    pass