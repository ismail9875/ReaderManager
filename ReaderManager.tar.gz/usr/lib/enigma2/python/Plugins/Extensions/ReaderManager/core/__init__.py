# -*- coding: utf-8 -*-
"""
core — منطق البلوجين الأساسي.

يحتوي على:
    - config_setup.py    : إعدادات config.plugins.OscamReaderManager
    - helpers.py         : دوال مساعدة + ثوابت + Maps/Regex
    - webif_updater.py   : تحديث قسم [webif] في oscam.conf/ncam.conf
    - softcam_detect.py  : اكتشاف Active SoftCam وإعادة تشغيله
"""
from __future__ import absolute_import, print_function, unicode_literals


__all__ = [
    "config_setup",
    "helpers",
    "webif_updater",
    "softcam_detect",
]