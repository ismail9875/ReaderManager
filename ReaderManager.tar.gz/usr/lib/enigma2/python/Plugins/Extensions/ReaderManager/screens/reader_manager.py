# -*- coding: utf-8 -*-
"""
screens/reader_manager.py — الشاشة الرئيسية ReaderManager.
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import threading

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.config import config
from Tools.LoadPixmap import LoadPixmap

from ..utils import logger
from ..utils import oscamapi
from ..utils import ncamapi
from ..utils.reader_parser import ReaderParser
from ..utils.test_queue import get_queue
from ..utils.paths import bootstrap as _paths_bootstrap
from ..utils.skin_loader import get_screen_skin
from ..core.helpers import display_host
from ..core.softcam_detect import (
    detect_active_softcam, is_oscam_active, is_ncam_active,
    restart_active_softcam, get_status_for_active
)
from ..core.softcam_paths import (
    detect_reader_file, detect_config_dir,
    list_available_softcams, tag_for_path,
)
from .settings import SettingsMenu
from .log_viewer import LogViewer


# ═══════════════════════════════════════════════════════════════════
#  مسارات الملفات (افتراضية + ديناميكية)
# ═══════════════════════════════════════════════════════════════════
_bootstrap = _paths_bootstrap()
_DEFAULT_OSCAM_FILE = _bootstrap["oscam_file"]
_DEFAULT_NCAM_FILE  = _bootstrap["ncam_file"]

OSCAM_FILE = _DEFAULT_OSCAM_FILE
NCAM_FILE  = _DEFAULT_NCAM_FILE


def _resolve_paths_for_active():
    global OSCAM_FILE, NCAM_FILE

    active = detect_active_softcam()
    name = (active or {}).get("name", "") if active else ""

    if name:
        path = detect_reader_file(name)
        if path:
            key = name.lower()
            if "ncam" in key:
                NCAM_FILE = path
            else:
                OSCAM_FILE = path
            logger.log("ReaderManager",
                       "Resolved paths for %s: OSCAM=%s NCAM=%s"
                       % (name, OSCAM_FILE, NCAM_FILE))
    return OSCAM_FILE, NCAM_FILE


# ═══════════════════════════════════════════════════════════════════
#  ReaderManager
# ═══════════════════════════════════════════════════════════════════
class ReaderManager(Screen):

    # ⭐ اسم الشاشة
    screen_name = "ReaderManager"

    def __init__(self, session):
        # ⭐ اسنِ السكين قبل Screen.__init__
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session

        # ═══════════════════════════════════════════════════════════
        #  الحماية أولاً — قبل أي شيء آخر
        # ═══════════════════════════════════════════════════════════
        self._closing = False
        self._restart_in_progress = False

        self["status"]      = Label("Ready")
        self["active_file"] = Label("")
        self["file_badge"]  = Pixmap()
        self["key_red"]     = Button("Exit")
        self["key_green"]   = Button("Add")
        self["key_yellow"]  = Button("Delete")
        self["key_blue"]    = Button("Edit")

        self["list_label"]  = MenuList([])
        self["list_host"]   = MenuList([])
        self["list_port"]   = MenuList([])
        self["list_state"]  = MenuList([])
        self["list_file"]   = MenuList([])
        self["list_cards"]  = MenuList([])
        self["list_status"] = MenuList([])

        self.readers = []
        self.current_index = 0
        self.current_file = OSCAM_FILE
        self._syncing = False

        self.oscam_details = {}
        self.ncam_details = {}
        self.status_cache = {}

        try:
            from threading import Lock as _Lock
            self._data_lock = _Lock()
        except Exception:
            self._data_lock = None

        self._refresh_timer = None
        self._oscam_poll_timer = None
        self._ncam_poll_timer = None
        self._refresh_scheduled_timer = None
        self._editor_timer = None
        self._restart_timer = None

        self._active_softcam = detect_active_softcam()

        self._queue = get_queue(test_timeout=5)
        self._queue.add_listener(self._on_queue_result)

        self._oscam_client = None
        self._ncam_client = None

        self._setup_clients()

        for name in ("list_label", "list_host", "list_port", "list_state",
                     "list_file", "list_cards", "list_status"):
            self[name].onSelectionChanged.append(self.sync_lists)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions",
             "MenuActions", "InfobarActions", "EPGSelectActions"],
            {
                "ok":            self.toggleState,
                "cancel":        self.close,
                "red":           self.close,
                "green":         self.addReader,
                "yellow":        self.deleteReader,
                "blue":          self.editReader,
                "menu":          self.openSettingsMenu,
                "info":          self.viewReader,
                "infobar":       self.viewReader,
                "epg":           self.openLog,
                "showEventInfo": self.openLog,
                "text":          self.openLog,
                "up":            self.moveUp,
                "down":          self.moveDown,
                "left":          self.switchPrev,
                "right":         self.switchNext,
            }, -1)

        self.onLayoutFinish.append(self._on_start)

    # ------------------------------------------------------------------
    #  (بقية الدوال كما هي تماماً من الملف الأصلي)
    # ------------------------------------------------------------------
    def _update_file_badge(self):
        try:
            plugin_dir = os.path.dirname(
                os.path.dirname(os.path.abspath(__file__)))
            images_dir = os.path.join(plugin_dir, "images")

            tag = tag_for_path(self.current_file)
            if tag == "NCAM":
                img_name = "ncam.png"
            elif tag == "OSCAM-ICAM":
                img_name = "oscamicam.png"
            else:
                img_name = "oscam.png"

            img_path = os.path.join(images_dir, img_name)

            if os.path.isfile(img_path):
                pix = LoadPixmap(img_path)
                if pix:
                    self["file_badge"].instance.setPixmap(pix)
                    return

            try:
                self["file_badge"].instance.setPixmap(None)
            except Exception:
                pass
        except Exception as e:
            logger.log("ReaderManager",
                       "_update_file_badge error: %s" % e)

    def _setup_clients(self):
        self._oscam_client = None
        self._ncam_client = None

        active = self._active_softcam
        if active:
            name = active.get("name") or "?"
            ver = active.get("version") or "?"
            logger.log("ReaderManager",
                       "Active SoftCam: %s (version=%s)" % (name, ver))
        else:
            logger.log("ReaderManager", "No active SoftCam detected")

        if config.plugins.OscamReaderManager.oscam_enabled.value:
            if is_oscam_active(active) or active is None:
                self._setup_oscam_client()
            else:
                logger.log("OSCamAPI", "Not active - skip setup")

        if config.plugins.OscamReaderManager.ncam_enabled.value:
            if is_ncam_active(active):
                self._setup_ncam_client()
            else:
                logger.log("NCamAPI", "Not active - skip setup")

    def _setup_oscam_client(self):
        try:
            if config.plugins.OscamReaderManager.oscam_autoconf.value:
                try:
                    if hasattr(oscamapi, "configure_auto"):
                        self._oscam_client = oscamapi.configure_auto()
                        return
                except Exception as e:
                    logger.log("OSCamAPI", "Auto failed: %s" % e)

            url = config.plugins.OscamReaderManager.oscam_url.value
            user = config.plugins.OscamReaderManager.oscam_user.value
            pwd = config.plugins.OscamReaderManager.oscam_pass.value
            try:
                timeout = float(
                    config.plugins.OscamReaderManager.oscam_timeout.value)
            except (TypeError, ValueError):
                timeout = 5.0
            self._oscam_client = oscamapi.OSCamAPI(url, user, pwd,
                                                    timeout=timeout)
        except Exception as e:
            logger.log("OSCamAPI", "Setup failed: %s" % e)
            self._oscam_client = None

    def _setup_ncam_client(self):
        try:
            if config.plugins.OscamReaderManager.ncam_autoconf.value:
                try:
                    if hasattr(ncamapi, "configure_auto"):
                        self._ncam_client = ncamapi.configure_auto()
                        return
                except Exception as e:
                    logger.log("NCamAPI", "Auto failed: %s" % e)

            url = config.plugins.OscamReaderManager.ncam_url.value
            user = config.plugins.OscamReaderManager.ncam_user.value
            pwd = config.plugins.OscamReaderManager.ncam_pass.value
            try:
                timeout = float(
                    config.plugins.OscamReaderManager.ncam_timeout.value)
            except (TypeError, ValueError):
                timeout = 5.0
            self._ncam_client = ncamapi.NCamAPI(url, user, pwd,
                                                 timeout=timeout)
        except Exception as e:
            logger.log("NCamAPI", "Setup failed: %s" % e)
            self._ncam_client = None

    def _get_active_client(self):
        if tag_for_path(self.current_file) == "NCAM":
            return self._ncam_client, "NCamAPI"
        return self._oscam_client, "OSCamAPI"

    def _get_active_details(self):
        if tag_for_path(self.current_file) == "NCAM":
            return self.ncam_details
        return self.oscam_details

    def _get_cards_count(self, reader):
        try:
            details = self._get_active_details()
            info = details.get(reader.label)
            if info is None:
                return 0
            return int(getattr(info, "card_count", 0) or 0)
        except Exception:
            return 0

    def _sort_readers(self, readers):
        try:
            mode = config.plugins.OscamReaderManager.sort_mode.value
        except Exception:
            mode = "alpha"

        readers = list(readers)

        if mode == "file":
            return readers

        if mode == "alpha":
            def key_alpha(r):
                label = (getattr(r, "label", "") or "").strip().lower()
                return (label == "", label)
            try:
                return sorted(readers, key=key_alpha)
            except Exception:
                return readers

        if mode == "proto":
            def key_proto(r):
                proto = (getattr(r, "protocol", "") or "").strip().lower()
                label = (getattr(r, "label", "") or "").strip().lower()
                return (proto, label)
            try:
                return sorted(readers, key=key_proto)
            except Exception:
                return readers

        if mode in ("cards_asc", "cards_desc"):
            reverse = (mode == "cards_desc")
            try:
                return sorted(
                    readers,
                    key=self._get_cards_count,
                    reverse=reverse)
            except Exception:
                return readers

        return readers

    def _current_label(self):
        if not self.readers:
            return None
        try:
            r = self.readers[self.current_index]
            return getattr(r, "label", None)
        except Exception:
            return None

    def _find_index_by_label(self, label):
        if not label:
            return -1
        for i, r in enumerate(self.readers):
            if (getattr(r, "label", "") or "") == label:
                return i
        return -1

    def _restore_selection(self, label):
        if not label:
            return
        idx = self._find_index_by_label(label)
        if idx >= 0:
            self.current_index = idx

    def _on_start(self):
        _resolve_paths_for_active()

        active = detect_active_softcam()
        if active:
            name = (active.get("name") or "").lower()
            if "ncam" in name:
                self.current_file = NCAM_FILE
            else:
                self.current_file = OSCAM_FILE
        else:
            self.current_file = OSCAM_FILE

        self.loadReaders()
        self._start_polling()

    def _start_polling(self):
        try:
            from enigma import eTimer
            try:
                interval = int(
                    config.plugins.OscamReaderManager.poll_interval.value
                ) * 1000
            except (TypeError, ValueError):
                interval = 10000

            for attr in ("_oscam_poll_timer", "_ncam_poll_timer"):
                timer = getattr(self, attr, None)
                if timer:
                    try:
                        timer.stop()
                    except Exception:
                        pass
                setattr(self, attr, None)

            self._active_softcam = detect_active_softcam()
            active = self._active_softcam

            if not active:
                logger.log("ReaderManager",
                           "No active SoftCam - polling skipped")
                return

            logger.log("ReaderManager",
                       "Polling for %s (every %d ms)"
                       % (active.get("name", "?"), interval))

            if is_ncam_active(active):
                if self._ncam_client:
                    self._ncam_poll_timer = eTimer()
                    self._ncam_poll_timer.callback.append(self._poll_ncam)
                    self._ncam_poll_timer.start(interval, False)
                    self._poll_ncam()
                else:
                    logger.log("NCamAPI",
                               "NCam active but client missing")
            elif is_oscam_active(active):
                if self._oscam_client:
                    self._oscam_poll_timer = eTimer()
                    self._oscam_poll_timer.callback.append(self._poll_oscam)
                    self._oscam_poll_timer.start(interval, False)
                    self._poll_oscam()
                else:
                    logger.log("OSCamAPI",
                               "OSCam active but client missing")
            else:
                if tag_for_path(self.current_file) == "NCAM" \
                        and self._ncam_client:
                    self._ncam_poll_timer = eTimer()
                    self._ncam_poll_timer.callback.append(self._poll_ncam)
                    self._ncam_poll_timer.start(interval, False)
                    self._poll_ncam()
                elif self._oscam_client:
                    self._oscam_poll_timer = eTimer()
                    self._oscam_poll_timer.callback.append(
                        self._poll_oscam)
                    self._oscam_poll_timer.start(interval, False)
                    self._poll_oscam()
        except Exception as e:
            logger.log("ReaderManager", "Timer failed: %s" % e)

    def _poll_oscam(self):
        if getattr(self, "_closing", True) or not self._oscam_client:
            return
        try:
            t = threading.Thread(target=self._oscam_worker)
            t.setDaemon(True)
            t.start()
        except Exception as e:
            logger.log("OSCamAPI", "Thread spawn failed: %s" % e)

    def _oscam_worker(self):
        if getattr(self, "_closing", True):
            return
        try:
            readers = self._oscam_client.get_reader_status()

            if getattr(self, "_closing", True):
                return
            if not hasattr(self, "_data_lock") or self._data_lock is None:
                return

            details = {r.label: r for r in readers}
            with self._data_lock:
                self.oscam_details = details

            connected = sum(1 for r in readers if r.is_connected)
            method = self._oscam_client.get_last_method() or "?"
            logger.log("OSCamAPI", "Poll OK: %d/%d (via %s)"
                       % (connected, len(readers), method))
            self._schedule_ui_refresh()
        except Exception as e:
            logger.log("OSCamAPI", "Poll error: %s" % e)

    def _poll_ncam(self):
        if getattr(self, "_closing", True) or not self._ncam_client:
            return
        try:
            t = threading.Thread(target=self._ncam_worker)
            t.setDaemon(True)
            t.start()
        except Exception as e:
            logger.log("NCamAPI", "Thread spawn failed: %s" % e)

    def _ncam_worker(self):
        if getattr(self, "_closing", True):
            return
        try:
            readers = self._ncam_client.get_reader_status(
                fetch_cards=True)

            if getattr(self, "_closing", True):
                return
            if not hasattr(self, "_data_lock") or self._data_lock is None:
                return

            details = {r.label: r for r in readers}
            with self._data_lock:
                self.ncam_details = details

            connected = sum(1 for r in readers if r.is_connected)
            method = self._ncam_client.get_last_method() or "?"
            logger.log("NCamAPI", "Poll OK: %d/%d (via %s)"
                       % (connected, len(readers), method))
            self._schedule_ui_refresh()
        except Exception as e:
            logger.log("NCamAPI", "Poll error: %s" % e)

    def _schedule_ui_refresh(self):
        if getattr(self, "_closing", True):
            return
        try:
            from enigma import eTimer
            t = eTimer()
            t.callback.append(self._apply_api_update)
            t.start(10, True)
            self._refresh_timer = t
        except Exception:
            pass

    def _apply_api_update(self):
        if getattr(self, "_closing", True):
            return
        try:
            try:
                mode = config.plugins.OscamReaderManager.sort_mode.value
                if mode in ("cards_asc", "cards_desc"):
                    current = self._current_label()
                    self.readers = self._sort_readers(self.readers)
                    self._restore_selection(current)
            except Exception:
                pass

            self.refreshLists()
            self._update_status_bar()
        except Exception as e:
            logger.log("ReaderManager", "Apply update error: %s" % e)

    def _update_status_bar(self):
        try:
            if tag_for_path(self.current_file) == "NCAM":
                with self._data_lock:
                    details = dict(self.ncam_details)
                api_name = "NCam"
                client = self._ncam_client
            else:
                with self._data_lock:
                    details = dict(self.oscam_details)
                api_name = "OSCam"
                client = self._oscam_client

            n = len(details)
            method = (client.get_last_method() if client else "?") or "?"
            err = client.get_last_error() if client else ""

            active_name = ""
            if self._active_softcam:
                active_name = self._active_softcam.get("name") or ""

            status = get_status_for_active()

            if err and n == 0:
                self["status"].setText(
                    "%s: error | %s" % (api_name, err))
            else:
                self["status"].setText(
                    "%s WebIF: %d reader(s) via %s | %s | Active: %s"
                    % (api_name, n, method, status, active_name or "-"))
        except Exception:
            pass

    def _schedule_oscam_refresh(self, delay_ms=1500,
                                 immediate_first=False):
        if getattr(self, "_closing", True):
            return
        try:
            from enigma import eTimer
            if self._refresh_scheduled_timer is not None:
                try:
                    self._refresh_scheduled_timer.stop()
                except Exception:
                    pass
                self._refresh_scheduled_timer = None

            poller = (self._poll_ncam
                      if tag_for_path(self.current_file) == "NCAM"
                      else self._poll_oscam)

            if immediate_first:
                poller()

            t = eTimer()
            t.callback.append(poller)
            t.start(delay_ms, True)
            self._refresh_scheduled_timer = t
        except Exception as e:
            logger.log("ReaderManager", "Schedule error: %s" % e)

    def _on_queue_result(self, reader, result):
        if getattr(self, "_closing", True):
            return
        try:
            label = getattr(reader, "label", "") or "?"
            active = self._get_active_details()
            if label in active:
                return

            if not getattr(reader, "enabled", True):
                new_val = "-"
            else:
                ok = bool(result and result.get("ok"))
                new_val = "Connected" if ok else "Disconnected"

            with self._data_lock:
                self.status_cache[label] = new_val
            self._schedule_ui_refresh()
        except Exception as e:
            logger.log("ReaderManager", "Queue result error: %s" % e)

    def _file_tag(self, path):
        return tag_for_path(path)

    def _file_exists(self, path):
        return path and os.path.exists(path)

    def _get_available_switches(self):
        switches = []
        seen_paths = set()

        for sc in list_available_softcams():
            path = sc["reader_file"]
            if path in seen_paths:
                continue
            seen_paths.add(path)
            switches.append((tag_for_path(path), path))

        for tag, path in (("OSCAM", OSCAM_FILE),
                          ("NCAM", NCAM_FILE)):
            if path and path not in seen_paths and os.path.exists(path):
                seen_paths.add(path)
                switches.append((tag, path))

        if not switches:
            switches = [("OSCAM", OSCAM_FILE),
                        ("NCAM", NCAM_FILE)]

        return switches

    def _reload_active(self, new_file, label):
        if not self._file_exists(new_file):
            self.session.open(MessageBox,
                "%s file not found:\n%s" % (label, new_file),
                MessageBox.TYPE_ERROR, timeout=4)
            return
        if new_file == self.current_file:
            self["status"].setText("Already on %s" % label)
            return

        self.current_file = new_file
        self.current_index = 0
        self["status"].setText("Loading %s readers..." % label)

        self._update_file_badge()

        self.loadReaders()
        self["status"].setText("Showing %d reader(s) from %s"
                               % (len(self.readers), label))

        self._start_polling()
        self._schedule_oscam_refresh(delay_ms=1000,
                                      immediate_first=True)

    def switchNext(self):
        switches = self._get_available_switches()
        if not switches:
            return
        paths = [p for _, p in switches]
        try:
            idx = paths.index(self.current_file)
        except ValueError:
            idx = -1
        next_idx = (idx + 1) % len(paths)
        tag, path = switches[next_idx]
        self._reload_active(path, tag)

    def switchPrev(self):
        switches = self._get_available_switches()
        if not switches:
            return
        paths = [p for _, p in switches]
        try:
            idx = paths.index(self.current_file)
        except ValueError:
            idx = 0
        prev_idx = (idx - 1) % len(paths)
        tag, path = switches[prev_idx]
        self._reload_active(path, tag)

    def switchToOscam(self):
        self._reload_active(OSCAM_FILE, "OSCAM")

    def switchToNcam(self):
        self._reload_active(NCAM_FILE, "NCAM")

    def _restart_via_script(self, action_text=""):
        if getattr(self, "_closing", True):
            return

        if self._restart_in_progress:
            logger.log("ReaderManager",
                       "_restart_via_script: already in progress")
            return

        self._restart_in_progress = True
        self["status"].setText("%s - restarting..." % action_text)

        try:
            t = threading.Thread(
                target=self._do_restart_worker,
                args=(action_text,))
            t.setDaemon(True)
            t.start()
        except Exception as e:
            logger.log("ReaderManager",
                       "Thread spawn failed: %s" % e)
            self._restart_in_progress = False

    def _do_restart_worker(self, action_text):
        try:
            logger.log("ReaderManager",
                       "_do_restart_worker: calling restart_active_softcam")
            ok, msg = restart_active_softcam()
            logger.log("ReaderManager",
                       "_do_restart_worker: ok=%s msg=%r" % (ok, msg))

            self._schedule_status_update(
                "%s | %s - refreshing..." % (action_text, msg))
            self._schedule_poll_after(3000)

        except Exception as e:
            logger.log("ReaderManager",
                       "_do_restart_worker error: %s" % e)
            self._schedule_status_update(
                "Restart error: %s" % str(e))
            self._schedule_poll_after(2000)
        finally:
            self._restart_in_progress = False

    def _schedule_status_update(self, text):
        if getattr(self, "_closing", True):
            return
        try:
            from enigma import eTimer
            t = eTimer()
            t.callback.append(lambda: self._apply_status_text(text))
            t.start(10, True)
        except Exception:
            pass

    def _apply_status_text(self, text):
        if getattr(self, "_closing", True):
            return
        try:
            self["status"].setText(text)
        except Exception:
            pass

    def _schedule_poll_after(self, delay_ms):
        if getattr(self, "_closing", True):
            return
        try:
            from enigma import eTimer
            poller = (self._poll_ncam
                      if tag_for_path(self.current_file) == "NCAM"
                      else self._poll_oscam)
            t = eTimer()
            t.callback.append(poller)
            t.start(delay_ms, True)
            self._refresh_scheduled_timer = t
        except Exception:
            pass

    def auto_restart_cam(self, action_text=""):
        if not config.plugins.OscamReaderManager.auto_restart.value:
            self._schedule_oscam_refresh(delay_ms=2000,
                                          immediate_first=True)
            return

        try:
            delay = int(
                config.plugins.OscamReaderManager.restart_delay.value)
        except (TypeError, ValueError):
            delay = 3

        if config.plugins.OscamReaderManager.confirm_restart.value:
            self.session.openWithCallback(
                lambda ans: self._do_restart_delayed(
                    ans, delay, action_text),
                MessageBox,
                "%s. Restart softcam now?" % action_text,
                MessageBox.TYPE_YESNO)
        else:
            self._do_restart_delayed(True, delay, action_text)

    def _do_restart_delayed(self, answer, delay, action_text):
        if not answer:
            self._schedule_oscam_refresh(delay_ms=1500,
                                          immediate_first=True)
            return
        if delay > 0:
            self["status"].setText("Waiting %d seconds..." % delay)
            try:
                from enigma import eTimer
                self._restart_timer = eTimer()
                self._restart_timer.callback.append(
                    lambda: self._restart_via_script(action_text))
                self._restart_timer.start(delay * 1000, True)
            except Exception as e:
                logger.log("ReaderManager",
                           "Restart timer error: %s" % e)
                self._restart_via_script(action_text)
        else:
            self._restart_via_script(action_text)

    def loadReaders(self):
        raw_readers = []
        tag = self._file_tag(self.current_file)
        self["active_file"].setText("Active file: %s" % tag)

        self._update_file_badge()

        if not self._file_exists(self.current_file):
            self.readers = []
            self.refreshLists()
            self["status"].setText("%s file not found | %s"
                                   % (tag, get_status_for_active()))
            return

        parser = ReaderParser()
        try:
            for r in parser.parse_file(self.current_file):
                r.source_file = self.current_file
                r.source_tag  = tag
                raw_readers.append(r)
        except Exception as e:
            logger.log("ReaderManager",
                       "parse error %s: %s" % (self.current_file, e))

        self.readers = self._sort_readers(raw_readers)

        self.refreshLists()
        self["status"].setText("%d reader(s) from %s | %s"
                               % (len(self.readers), tag,
                                  get_status_for_active()))

        active_client = (self._ncam_client
                         if tag_for_path(self.current_file) == "NCAM"
                         else self._oscam_client)
        readers_on = [r for r in self.readers
                      if getattr(r, "enabled", True)]
        if readers_on and not active_client:
            self._queue.enqueue_many(readers_on, priority=5,
                                      reason="startup")

    def refreshLists(self):
        labels, hosts, ports, states, files, cards, statuses = (
            [], [], [], [], [], [], [])

        active = self._get_active_details()
        with self._data_lock:
            active_copy = dict(active)
            cache_copy = dict(self.status_cache)

        for r in self.readers:
            labels.append(r.label or "-")
            dev = r.device or ""
            if "," in dev:
                h, p = dev.split(",", 1)
            else:
                h, p = dev, "-"
            hosts.append(display_host(h) if h else "-")
            ports.append(p or "-")
            states.append("ON" if r.enabled else "OFF")
            files.append(r.protocol or "-")

            if not r.enabled:
                cards.append("-")
                statuses.append("-")
                continue

            info = active_copy.get(r.label)
            if info is not None:
                cards.append(info.display_cards)
                statuses.append(info.display_status)
            else:
                cards.append("?")
                statuses.append(cache_copy.get(r.label, "?"))

        self._syncing = True
        try:
            self["list_label"].setList(labels)
            self["list_host"].setList(hosts)
            self["list_port"].setList(ports)
            self["list_state"].setList(states)
            self["list_file"].setList(files)
            self["list_cards"].setList(cards)
            self["list_status"].setList(statuses)
        finally:
            self._syncing = False

        if self.readers:
            idx = min(self.current_index, len(self.readers) - 1)
            if idx < 0:
                idx = 0
            self.current_index = idx
            self.setIndex(idx, force=True)

    def setIndex(self, idx, force=False):
        if self._syncing or not self.readers:
            return
        idx = max(0, min(idx, len(self.readers) - 1))
        if not force and idx == self.current_index:
            return
        self._syncing = True
        try:
            self.current_index = idx
            for name in ("list_label", "list_host", "list_port",
                         "list_state", "list_file", "list_cards",
                         "list_status"):
                widget = self[name]
                try:
                    if hasattr(widget, "setCurrentIndex"):
                        widget.setCurrentIndex(idx)
                    elif hasattr(widget, "moveToIndex"):
                        widget.moveToIndex(idx)
                    elif (hasattr(widget, "instance")
                          and widget.instance is not None):
                        widget.instance.moveToIndex(idx)
                except Exception:
                    pass
        finally:
            self._syncing = False

    def sync_lists(self):
        if self._syncing:
            return
        for name in ("list_label", "list_host", "list_port",
                     "list_state", "list_file", "list_cards",
                     "list_status"):
            try:
                widget = self[name]
                idx = None
                if hasattr(widget, "getSelectedIndex"):
                    idx = widget.getSelectedIndex()
                elif hasattr(widget, "getCurrentIndex"):
                    idx = widget.getCurrentIndex()
                elif (hasattr(widget, "instance")
                      and widget.instance is not None):
                    idx = widget.instance.getCurrentIndex()
            except Exception:
                continue
            if idx is not None and idx >= 0 and idx != self.current_index:
                self.setIndex(idx)
                break

    def moveUp(self):
        if self.readers and not self._syncing:
            if self.current_index <= 0:
                self.setIndex(len(self.readers) - 1)
            else:
                self.setIndex(self.current_index - 1)

    def moveDown(self):
        if self.readers and not self._syncing:
            if self.current_index >= len(self.readers) - 1:
                self.setIndex(0)
            else:
                self.setIndex(self.current_index + 1)

    def openSettingsMenu(self):
        self.session.openWithCallback(
            self._after_settings_menu,
            SettingsMenu,
            self._on_emulator_changed)

    def _after_settings_menu(self, *args):
        if getattr(self, "_closing", True):
            return
        try:
            keep_label = self._current_label()

            _resolve_paths_for_active()

            self._active_softcam = detect_active_softcam()
            self._setup_clients()
            self._start_polling()

            self.loadReaders()
            self._restore_selection(keep_label)

            self.refreshLists()
            self._schedule_oscam_refresh(delay_ms=500,
                                          immediate_first=True)
        except Exception as e:
            logger.log("ReaderManager", "Reconfigure error: %s" % e)

    def _on_emulator_changed(self):
        if getattr(self, "_closing", True):
            return
        try:
            logger.log("ReaderManager",
                       "Emulator state changed - reloading readers")
            _resolve_paths_for_active()
            self._active_softcam = detect_active_softcam()
            self._setup_clients()
            self._start_polling()
            self.loadReaders()
        except Exception as e:
            logger.log("ReaderManager",
                       "emu change reload error: %s" % e)

    def openLog(self):
        try:
            self.session.open(LogViewer)
        except Exception as e:
            logger.log("ReaderManager", "openLog failed: %s" % e)

    def viewReader(self):
        if not self.readers:
            self["status"].setText("No reader to display")
            return

        try:
            from ..utils.reader_view import ReaderView
        except Exception as e:
            self.session.open(MessageBox,
                "Failed to load reader view: %s" % str(e),
                MessageBox.TYPE_ERROR, timeout=5)
            return

        r = self.readers[self.current_index]
        label = getattr(r, "label", "") or ""

        api_status = None
        try:
            active = self._get_active_details()
            with self._data_lock:
                api_status = active.get(label)
        except Exception as e:
            logger.log("ReaderManager",
                       "viewReader api lookup failed: %s" % e)

        try:
            self.session.openWithCallback(
                self._after_view,
                ReaderView,
                r,
                self._on_reader_changed,
                api_status)
        except Exception as e:
            self.session.open(MessageBox,
                "ReaderView error: %s" % str(e),
                MessageBox.TYPE_ERROR, timeout=5)

    def _after_view(self, *args, **kwargs):
        self.loadReaders()
        self._schedule_oscam_refresh(delay_ms=2000,
                                      immediate_first=True)

    def _on_status_update(self, label, status, auth=None):
        if label and status:
            active = self._get_active_details()
            if label not in active:
                with self._data_lock:
                    self.status_cache[label] = status
            self.refreshLists()

    def _on_reader_changed(self, reader):
        if reader is None:
            try:
                del self.readers[self.current_index]
            except Exception:
                pass
            self.readers = self._sort_readers(self.readers)
            if self.current_index >= len(self.readers):
                self.current_index = max(0, len(self.readers) - 1)
            self.refreshLists()
            self._restart_via_script("Reader deleted")
        else:
            old_label = None
            try:
                old_label = self.readers[self.current_index].label
            except Exception:
                pass
            try:
                self.readers[self.current_index] = reader
            except Exception:
                pass
            self.readers = self._sort_readers(self.readers)
            new_label = getattr(reader, "label", None) or old_label
            self._restore_selection(new_label)
            self.refreshLists()

            active_client = (self._ncam_client
                             if tag_for_path(self.current_file) == "NCAM"
                             else self._oscam_client)
            if getattr(reader, "enabled", True):
                if not active_client:
                    self._queue.enqueue(reader, priority=2,
                                        reason="edit")
            else:
                with self._data_lock:
                    self.status_cache.pop(reader.label, None)
                self._queue.remove(reader.label)

            self._restart_via_script(
                "Reader %s updated" % reader.label)

    def _verify_reader_in_file(self, reader):
        try:
            if not self._file_exists(reader.source_file):
                logger.log("ReaderManager",
                    "verify: file missing %s" % reader.source_file)
                return False
            labels = {r.label for r in
                      ReaderParser().parse_file(reader.source_file)}
            if (reader.label or "") not in labels:
                logger.log("ReaderManager",
                    "verify: label '%s' not found in %s"
                    % (reader.label, reader.source_file))
                return False
            return True
        except Exception as e:
            logger.log("ReaderManager", "verify error: %s" % e)
            return False

    def _handle_editor_result(self, reader, is_edit):
        if not reader:
            return

        if not self._verify_reader_in_file(reader):
            self.session.open(
                MessageBox,
                "Save verification failed:\n"
                "Reader '%s' was not found in:\n%s"
                % (getattr(reader, "label", "?"), reader.source_file),
                MessageBox.TYPE_ERROR, timeout=6)
            return

        try:
            on_disk = ReaderParser().parse_file(reader.source_file)
            for r in on_disk:
                if r.label == reader.label:
                    r.source_file = reader.source_file
                    r.source_tag = self._file_tag(reader.source_file)
                    reader = r
                    break
        except Exception as e:
            logger.log("ReaderManager", "re-read failed: %s" % e)

        if not reader.source_file:
            reader.source_file = self.current_file
            reader.source_tag = self._file_tag(self.current_file)

        if is_edit:
            try:
                self.readers[self.current_index] = reader
            except Exception:
                self.readers.append(reader)
        else:
            self.readers.append(reader)

        self.readers = self._sort_readers(self.readers)
        idx = self._find_index_by_label(getattr(reader, "label", ""))
        if idx >= 0:
            self.current_index = idx
        self.refreshLists()

        active_client = (self._ncam_client
                         if tag_for_path(self.current_file) == "NCAM"
                         else self._oscam_client)
        action_word = "Updated" if is_edit else "Added"

        if getattr(reader, "enabled", True):
            if not active_client:
                self._queue.enqueue(
                    reader, priority=2,
                    reason="edit" if is_edit else "add")
        else:
            with self._data_lock:
                self.status_cache.pop(reader.label, None)
            self._queue.remove(reader.label)

        self._restart_via_script(
            "Reader %s %s" % (reader.label, action_word.lower()))

    def addReader(self):
        if not self._file_exists(self.current_file):
            self.session.open(
                MessageBox,
                "Cannot add: file not found:\n%s" % self.current_file,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        try:
            from ..utils.reader_dialog import ReaderEditor
        except Exception as e:
            self.session.open(MessageBox,
                "Cannot load editor: %s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        api_module = None
        if tag_for_path(self.current_file) == "NCAM":
            api_module = ncamapi
        else:
            api_module = oscamapi

        self.session.openWithCallback(
            self._on_editor_done_add,
            ReaderEditor, None, self.current_file, api_module)

    def editReader(self):
        if not self.readers:
            self["status"].setText("No reader to edit")
            return

        try:
            r = self.readers[self.current_index]
        except Exception:
            self["status"].setText("Invalid selection")
            return

        if not self._file_exists(r.source_file):
            self.session.open(
                MessageBox,
                "Cannot edit: file not found:\n%s" % r.source_file,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        try:
            from ..utils.reader_dialog import ReaderEditor
        except Exception as e:
            self.session.open(MessageBox,
                "Cannot load editor: %s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        api_module = None
        if "ncam" in (r.source_file or "").lower():
            api_module = ncamapi
        else:
            api_module = oscamapi

        self.session.openWithCallback(
            self._on_editor_done_edit,
            ReaderEditor, r, r.source_file, api_module)

    def _on_editor_done_add(self, reader):
        self._handle_editor_result(reader, is_edit=False)

    def _on_editor_done_edit(self, reader):
        self._handle_editor_result(reader, is_edit=True)

    def deleteReader(self):
        if not self.readers:
            return
        r = self.readers[self.current_index]
        label = r.label
        self.session.openWithCallback(
            lambda ans: self._on_delete_confirm(ans, label),
            MessageBox,
            "Delete reader: %s ?" % label, MessageBox.TYPE_YESNO)

    def _on_delete_confirm(self, answer, label):
        if not answer:
            return
        target = None
        for i, r in enumerate(self.readers):
            if (r.label or "") == (label or ""):
                target = i
                break
        if target is None:
            self["status"].setText(
                "Reader not found (already removed?)")
            return

        r = self.readers[target]
        try:
            ReaderParser().remove_from_file(r)
        except Exception as e:
            logger.log("ReaderManager", "remove error: %s" % e)
            self.session.open(MessageBox,
                "Delete failed: %s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        with self._data_lock:
            self.status_cache.pop(label, None)
        self.oscam_details.pop(label, None)
        self.ncam_details.pop(label, None)
        self._queue.remove(label)

        try:
            del self.readers[target]
        except Exception:
            pass

        self.readers = self._sort_readers(self.readers)
        if self.current_index >= len(self.readers):
            self.current_index = max(0, len(self.readers) - 1)
        self.refreshLists()

        self._restart_via_script("Reader %s deleted" % label)

    def toggleState(self):
        if not self.readers:
            logger.log("ReaderManager", "toggle: no readers")
            return

        r = self.readers[self.current_index]
        old_enabled = r.enabled
        new_enabled = not old_enabled

        logger.log("ReaderManager",
                   "toggle: label=%r old=%s new=%s file=%s"
                   % (r.label, old_enabled, new_enabled, r.source_file))

        r.enabled = new_enabled

        try:
            ReaderParser().write_single(r, r.source_file)
            logger.log("ReaderManager",
                       "toggle: write_single OK for %r" % r.label)
        except Exception as e:
            r.enabled = old_enabled
            self.refreshLists()
            logger.log("ReaderManager", "toggle: write error: %s" % e)
            self.session.open(MessageBox,
                "Failed to change state:\n%s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        if not r.enabled:
            with self._data_lock:
                self.status_cache.pop(r.label, None)
            self._queue.remove(r.label)

        self.refreshLists()
        state = "ON" if r.enabled else "OFF"

        active_client = (self._ncam_client
                         if tag_for_path(self.current_file) == "NCAM"
                         else self._oscam_client)
        if r.enabled and not active_client:
            self._queue.enqueue(r, priority=2, reason="edit")

        self._restart_via_script(
            "Reader %s set to %s" % (r.label, state))

    def close(self):
        self._closing = True

        try:
            for attr in ("_oscam_poll_timer", "_ncam_poll_timer",
                         "_refresh_scheduled_timer", "_refresh_timer",
                         "_editor_timer", "_restart_timer"):
                timer = getattr(self, attr, None)
                if timer:
                    try:
                        timer.stop()
                    except Exception:
                        pass
                    setattr(self, attr, None)
        except Exception as e:
            logger.log("ReaderManager", "close timer error: %s" % e)

        try:
            self._queue.remove_listener(self._on_queue_result)
        except Exception:
            pass

        for name in ("list_label", "list_host", "list_port",
                     "list_state", "list_file", "list_cards",
                     "list_status"):
            try:
                self[name].onSelectionChanged.remove(self.sync_lists)
            except Exception:
                pass

        logger.log("ReaderManager", "Screen closed")
        Screen.close(self)