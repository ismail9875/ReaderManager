# -*- coding: utf-8 -*-
"""
core/softcam_paths.py — بحث ديناميكي ذكي عن مسارات ملفات readers.

لا يعتمد على خريطة ثابتة، بل يمسح النظام بحثاً عن:
    1) المسارات الأساسية المحتملة (config, config1, config2, ...)
    2) ملفات readers مباشرة داخل هذه المسارات
    3) مجلدات فرعية تحمل اسم المحاكي داخل كل مسار

مثال:
    /etc/tuxbox/config/oscam.reader          → OSCAM
    /etc/tuxbox/config/oscamicam/oscam.reader → OSCAM-ICAM
    /etc/tuxbox/config1/ncam/ncam.reader     → NCAM
    /etc/tuxbox/config2/oscam-emu/oscam.server → OSCAM-EMU
    /usr/keys/oscam.reader                   → OSCAM
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import glob

from ..utils import logger


# ═══════════════════════════════════════════════════════════════════
#  أسماء ملفات readers المحتملة (بالترتيب)
# ═══════════════════════════════════════════════════════════════════
READER_FILENAMES = [
    "oscam.reader",
    "oscam.server",
    "ncam.reader",
    "ncam.server",
    "gcam.reader",
    "gcam.server",
    "reader.conf",
    "reader.cfg",
]


# ═══════════════════════════════════════════════════════════════════
#  المسارات الأساسية المحتملة (يُولَّد منها config1, config2, ...)
# ═══════════════════════════════════════════════════════════════════
BASE_CONFIG_DIRS = [
    "/etc/tuxbox",
    "/etc",
    "/usr/keys",
    "/usr/local/etc",
    "/var/etc",
    "/var/tuxbox/config",
    "/home/root",
    "/etc/enigma2",
]


# ═══════════════════════════════════════════════════════════════════
#  أنماط glob للبحث عن مجلدات config المحتملة
# ═══════════════════════════════════════════════════════════════════
CONFIG_DIR_GLOBS = [
    "config",           # /etc/tuxbox/config
    "config[0-9]",      # /etc/tuxbox/config1, config2
    "config[0-9][0-9]", # /etc/tuxbox/config10
    "config-*",         # /etc/tuxbox/config-oscam
    "config_*",         # /etc/tuxbox/config_oscam
    "*config*",         # /etc/tuxbox/myconfig
    "oscam*",           # /etc/tuxbox/oscamicam
    "ncam*",            # /etc/tuxbox/ncam
    "gcam*",
]


# ═══════════════════════════════════════════════════════════════════
#  كلمات دالة على نوع المحاكي (لتصنيف tag)
# ═══════════════════════════════════════════════════════════════════
SOFTCAM_KEYWORDS = [
    # (keyword, tag) — الأطول أولاً لتفادي التعارض
    ("oscamicam", "OSCAM-ICAM"),
    ("oscam-icam", "OSCAM-ICAM"),
    ("oscam_icam", "OSCAM-ICAM"),
    ("oscam-emu", "OSCAM-EMU"),
    ("oscam_emu", "OSCAM-EMU"),
    ("oscam-smod", "OSCAM-SMOD"),
    ("oscam_smod", "OSCAM-SMOD"),
    ("oscam-mag", "OSCAM-MAG"),
    ("oscam-mca", "OSCAM-MCA"),
    ("ncam", "NCAM"),
    ("oscam", "OSCAM"),
    ("gcam", "GCAM"),
    ("cccam", "CCCAM"),
]


# ═══════════════════════════════════════════════════════════════════
#  تحديد tag من مسار
# ═══════════════════════════════════════════════════════════════════
def tag_for_path(path):
    """
    يستنتج نوع المحاكي من المسار (مجلد أو ملف).
    مثال:
        /etc/tuxbox/config/oscamicam/oscam.reader → OSCAM-ICAM
        /etc/tuxbox/config/ncam.reader            → NCAM
    """
    if not path:
        return "UNKNOWN"

    lower = path.lower()

    for keyword, tag in SOFTCAM_KEYWORDS:
        if keyword in lower:
            return tag

    # fallback: اسم المجلد الأب
    parent = os.path.basename(os.path.dirname(path)) or ""
    if parent and parent.lower() not in ("config", "etc", "tuxbox",
                                          "keys", "root"):
        return parent.upper()

    base = os.path.basename(path)
    return (base or "UNKNOWN").upper()


# ═══════════════════════════════════════════════════════════════════
#  توليد قائمة المسارات الأساسية المحتملة
# ═══════════════════════════════════════════════════════════════════
def _iter_config_dirs():
    """
    يُولّد كل مجلدات config المحتملة على الجهاز.
    مثال: /etc/tuxbox/config, /etc/tuxbox/config1, /etc/tuxbox/config2, ...
    """
    seen = set()

    for base in BASE_CONFIG_DIRS:
        if not os.path.isdir(base):
            continue

        # 1) المجلد الأساسي نفسه (قد يكون config مباشرة)
        if base not in seen:
            seen.add(base)
            yield base

        # 2) البحث داخل base عن config / config1 / config2 ...
        for pattern in CONFIG_DIR_GLOBS:
            full_pattern = os.path.join(base, pattern)
            try:
                matches = glob.glob(full_pattern)
            except Exception:
                continue

            for m in matches:
                if not os.path.isdir(m):
                    continue
                if m in seen:
                    continue
                seen.add(m)
                yield m


# ═══════════════════════════════════════════════════════════════════
#  البحث عن ملف readers داخل مجلد
# ═══════════════════════════════════════════════════════════════════
def _find_reader_in_dir(directory):
    """يُرجع أول ملف readers موجود داخل المجلد."""
    if not directory or not os.path.isdir(directory):
        return None
    for fname in READER_FILENAMES:
        full = os.path.join(directory, fname)
        if os.path.isfile(full):
            return full
    return None


# ═══════════════════════════════════════════════════════════════════
#  البحث الشامل عن كل ملفات readers على الجهاز
# ═══════════════════════════════════════════════════════════════════
def find_all_reader_files():
    """
    يبحث في كل المسارات المحتملة عن ملفات readers.
    يُرجع قائمة عناصر:
        {
            "name": str,        # اسم المحاكي المُستنتج
            "tag": str,         # tag قصير
            "config_dir": str,  # مجلد الإعدادات
            "reader_file": str, # ملف readers
            "is_subdir": bool,  # هل الملف داخل مجلد فرعي؟
        }
    """
    results = []
    seen_files = set()

    for config_dir in _iter_config_dirs():
        # (أ) هل يوجد ملف readers مباشرة في هذا المجلد؟
        direct = _find_reader_in_dir(config_dir)
        if direct and direct not in seen_files:
            seen_files.add(direct)
            tag = tag_for_path(direct) or tag_for_path(config_dir)
            results.append({
                "name": tag.lower(),
                "tag": tag,
                "config_dir": config_dir,
                "reader_file": direct,
                "is_subdir": False,
            })

        # (ب) البحث داخل المجلدات الفرعية (مثل oscamicam/, ncam/)
        try:
            subdirs = sorted(os.listdir(config_dir))
        except Exception:
            continue

        for sub in subdirs:
            sub_path = os.path.join(config_dir, sub)
            if not os.path.isdir(sub_path):
                continue

            reader_file = _find_reader_in_dir(sub_path)
            if not reader_file:
                continue
            if reader_file in seen_files:
                continue

            seen_files.add(reader_file)
            tag = tag_for_path(sub_path) or tag_for_path(reader_file)
            results.append({
                "name": sub.lower(),
                "tag": tag,
                "config_dir": sub_path,
                "reader_file": reader_file,
                "is_subdir": True,
            })

    return results


# ═══════════════════════════════════════════════════════════════════
#  APIs متوافقة مع الإصدار السابق
# ═══════════════════════════════════════════════════════════════════
def detect_config_dir(softcam_name):
    """يُرجع مجلد config المناسب لاسم محاكي معيّن."""
    if not softcam_name:
        return None
    key = softcam_name.lower().replace(" ", "").replace("_", "-")

    best = None
    for sc in find_all_reader_files():
        name_norm = sc["name"].replace("_", "-")
        tag_norm = sc["tag"].lower().replace("_", "-")
        if key == name_norm or key == tag_norm:
            return sc["config_dir"]
        if key in name_norm or key in tag_norm:
            if best is None:
                best = sc["config_dir"]
    return best


def detect_reader_file(softcam_name):
    """يُرجع ملف readers لاسم محاكي معيّن."""
    if not softcam_name:
        return None
    key = softcam_name.lower().replace(" ", "").replace("_", "-")

    best = None
    for sc in find_all_reader_files():
        name_norm = sc["name"].replace("_", "-")
        tag_norm = sc["tag"].lower().replace("_", "-")
        if key == name_norm or key == tag_norm:
            return sc["reader_file"]
        if key in name_norm or key in tag_norm:
            if best is None:
                best = sc["reader_file"]
    return best


def list_available_softcams():
    """يُرجع كل المحاكيات المتوفرة على الجهاز."""
    return find_all_reader_files()