# -*- coding: utf-8 -*-
"""
utils — وحدات مساعدة مستقلة للبلوجين.

يحتوي على:
    - logger.py         : تسجيل الأحداث
    - paths.py          : مسارات الملفات والإعدادات
    - field_help.py     : نصوص المساعدة ثنائية اللغة
    - reader_parser.py  : قراءة/كتابة ملفات القُرّاء
    - oscamapi.py       : عميل OSCam WebIF
    - ncamapi.py        : عميل NCam WebIF
    - restart_oscam.py  : إعادة تشغيل OSCam
    - restart_ncam.py   : إعادة تشغيل NCam
    - emu_manager.py    : إدارة المحاكيات (SoftCams)
    - test_queue.py     : طابور اختبارات القُرّاء
    - reader_view.py    : شاشة عرض تفاصيل القارئ
    - reader_dialog.py  : شاشة تحرير القارئ
"""

from __future__ import absolute_import, print_function, unicode_literals

# utils/paths.py أو utils/__init__.py
def skin_path(filename):
    here = os.path.dirname(os.path.abspath(__file__))
    plugin_dir = os.path.dirname(here)
    return os.path.join(plugin_dir, "skin", filename)

__all__ = [
    "logger",
    "paths",
    "field_help",
    "reader_parser",
    "oscamapi",
    "ncamapi",
    "restart_oscam",
    "restart_ncam",
    "emu_manager",
    "test_queue",
    "reader_view",
    "reader_dialog",
    "upgrader",
    "emulator_installer",
]