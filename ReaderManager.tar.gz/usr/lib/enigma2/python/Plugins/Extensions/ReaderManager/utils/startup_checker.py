# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import time
import threading

from . import logger


# ═══════════════════════════════════════════════════════════════════
#  إعدادات
# ═══════════════════════════════════════════════════════════════════
# فترة الانتظار قبل بدء الفحص (لترك النظام يستقر)
DEFAULT_DELAY = 45  # ثانية

# ملف علامة لمنع تكرار الإشعار في نفس الجلسة
LAST_NOTIFY_FILE = "/tmp/.ReaderManager_last_notify"

# حالة الفحص الحالية
_state = {
    "checking":       False,
    "last_result":    None,
    "update_found":   False,
    "remote_version": None,
    "session":        None,
}


# ═══════════════════════════════════════════════════════════════════
#  ملف العلامة (لمنع التكرار في نفس اليوم)
# ═══════════════════════════════════════════════════════════════════
def _read_last_notify():
    """يقرأ تاريخ آخر إشعار."""
    try:
        if not os.path.isfile(LAST_NOTIFY_FILE):
            return 0
        with open(LAST_NOTIFY_FILE, "r") as f:
            return int(f.read().strip() or 0)
    except Exception:
        return 0


def _write_last_notify(ts=None):
    """يحفظ تاريخ آخر إشعار."""
    try:
        with open(LAST_NOTIFY_FILE, "w") as f:
            f.write(str(int(ts or time.time())))
    except Exception as e:
        logger.log("StartupCheck", "_write_last_notify error: %s" % e)


def _should_show_notification():
    """لا نعرض الإشعار أكثر من مرة كل 24 ساعة."""
    last = _read_last_notify()
    now = int(time.time())
    return (now - last) >= 86400


# ═══════════════════════════════════════════════════════════════════
#  قراءة الإعدادات
# ═══════════════════════════════════════════════════════════════════
def _get_config():
    """يقرأ إعدادات التحديث بأمان."""
    try:
        from Components.config import config
        m = config.plugins.OscamReaderManager
        return {
            "auto_check":   bool(m.update_auto_check.value),
            "interval":     m.update_check_interval.value,
            "show_banner":  bool(m.update_show_banner.value)
                            if hasattr(m, "update_show_banner") else True,
            "last_check":   int(m.update_last_check.value or 0),
        }
    except Exception as e:
        logger.log("StartupCheck", "config error: %s" % e)
        return None


def _save_last_check(ts=None):
    """يحفظ تاريخ آخر فحص."""
    try:
        from Components.config import config
        config.plugins.OscamReaderManager.update_last_check.value = \
            int(ts or time.time())
        config.plugins.OscamReaderManager.save()
    except Exception as e:
        logger.log("StartupCheck", "_save_last_check error: %s" % e)


def _interval_to_seconds(interval):
    """يحوّل الفاصل الزمني إلى ثواني."""
    if interval == "daily":
        return 86400
    if interval == "weekly":
        return 7 * 86400
    if interval == "monthly":
        return 30 * 86400
    return 86400  # افتراضي: يومي


def _should_check_now():
    """هل حان وقت الفحص؟"""
    cfg = _get_config()
    if not cfg:
        return False
    if not cfg["auto_check"]:
        logger.log("StartupCheck", "auto-check disabled — skip")
        return False

    last = cfg["last_check"]
    if last <= 0:
        return True

    elapsed = int(time.time()) - last
    interval_sec = _interval_to_seconds(cfg["interval"])
    if elapsed >= interval_sec:
        return True

    logger.log("StartupCheck",
               "interval not elapsed (%ds < %ds) — skip"
               % (elapsed, interval_sec))
    return False


# ═══════════════════════════════════════════════════════════════════
#  جدولة الفحص
# ═══════════════════════════════════════════════════════════════════
def schedule_check(delay=DEFAULT_DELAY, session=None):
    """
    يجدول فحصاً تلقائياً بعد `delay` ثانية من بدء Enigma2.

    Args:
        delay   : عدد الثواني قبل الفحص
        session : session الحالية (لعرض MessageBox)

    الاستخدام:
        from .utils import startup_check
        startup_check.schedule_check(delay=45, session=session)
    """
    _state["session"] = session

    if not _should_check_now():
        logger.log("StartupCheck", "scheduling skipped")
        return False

    logger.log("StartupCheck",
               "scheduling check in %d seconds" % delay)

    # ① جرّب Twisted reactor أولاً
    try:
        from twisted.internet import reactor
        reactor.callLater(delay, _run_check_in_thread)
        logger.log("StartupCheck", "scheduled via reactor")
        return True
    except Exception as e:
        logger.log("StartupCheck",
                   "reactor unavailable: %s — using thread" % e)

    # ② fallback: thread مع sleep
    def _delayed():
        time.sleep(delay)
        _run_check_in_thread()

    t = threading.Thread(target=_delayed)
    t.setDaemon(True)
    t.start()
    logger.log("StartupCheck", "scheduled via thread")
    return True


def _run_check_in_thread():
    """يشغّل الفحص في thread منفصل."""
    if _state["checking"]:
        logger.log("StartupCheck", "already checking — skip")
        return

    _state["checking"] = True
    logger.log("StartupCheck", "starting background check")

    def worker():
        try:
            from . import upgrader
            result = upgrader.check_for_updates()
            _state["last_result"] = result
            _state["update_found"] = bool(result.get("has_update"))
            _state["remote_version"] = result.get("remote_version")
            _save_last_check()

            logger.log("StartupCheck",
                       "check done: has_update=%s remote=%s"
                       % (result.get("has_update"),
                          result.get("remote_version")))

            # عرض إشعار إذا وُجد تحديث
            if result.get("has_update") and _should_show_notification():
                cfg = _get_config()
                if cfg and cfg.get("show_banner", True):
                    _schedule_notification(result)
                    _write_last_notify()

        except Exception as e:
            logger.log("StartupCheck", "worker error: %s" % e)
        finally:
            _state["checking"] = False

    t = threading.Thread(target=worker)
    t.setDaemon(True)
    t.start()


# ═══════════════════════════════════════════════════════════════════
#  عرض الإشعار
# ═══════════════════════════════════════════════════════════════════
def _schedule_notification(result):
    """يعرض الإشعار في الخيط الرئيسي."""
    try:
        from enigma import eTimer
        timer = eTimer()
        timer.callback.append(lambda: _show_notification(result))
        timer.start(10, True)

        # احتفظ بالمرجع لمنع garbage collection
        if not hasattr(_schedule_notification, "_timers"):
            _schedule_notification._timers = []
        _schedule_notification._timers.append(timer)
    except Exception as e:
        logger.log("StartupCheck",
                   "_schedule_notification error: %s" % e)
        try:
            _show_notification(result)
        except Exception:
            pass


def _show_notification(result):
    """يعرض MessageBox بالتحديث المتوفر."""
    remote = result.get("remote_version", "?")
    local = result.get("local_version", "?")

    msg = (
        "Plugin Update Available\n"
        "\n"
        "Local version:   %s\n"
        "Remote version:  %s\n"
        "\n"
        "Open the plugin and press GREEN to update."
        % (local, remote)
    )

    logger.log("StartupCheck", "showing notification: %s" % msg)

    try:
        from Screens.MessageBox import MessageBox
        from Screens.InfoBar import InfoBar

        session = _state.get("session")

        # حاول الحصول على session من InfoBar
        if session is None:
            try:
                infobar = InfoBar.instance
                if infobar and hasattr(infobar, "session"):
                    session = infobar.session
            except Exception:
                pass

        if session is not None:
            session.open(MessageBox, msg,
                         MessageBox.TYPE_INFO, timeout=20)
            logger.log("StartupCheck", "notification shown")
        else:
            logger.log("StartupCheck",
                       "no session available — notification skipped")

    except Exception as e:
        logger.log("StartupCheck",
                   "_show_notification error: %s" % e)


# ═══════════════════════════════════════════════════════════════════
#  API عام
# ═══════════════════════════════════════════════════════════════════
def get_state():
    """يُعيد حالة الفحص الحالية."""
    return dict(_state)


def check_now():
    """يُشغّل الفحص فوراً (للاستخدام اليدوي)."""
    _run_check_in_thread()