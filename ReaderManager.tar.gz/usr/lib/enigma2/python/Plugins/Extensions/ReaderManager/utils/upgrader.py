# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import sys
import time
import shutil
import tarfile
import tempfile
import traceback

try:
    from io import open
except ImportError:
    pass

# ─── توافق Py2/Py3 للـ urllib ───
try:
    from urllib2 import (build_opener, Request, HTTPHandler,
                         HTTPSHandler, URLError, HTTPError)
except ImportError:
    from urllib.request import (build_opener, Request, HTTPHandler,
                                 HTTPSHandler)
    from urllib.error import URLError, HTTPError

try:
    from ssl import create_default_context, _create_unverified_context
except ImportError:
    create_default_context = None
    _create_unverified_context = None

from . import logger


# ═══════════════════════════════════════════════════════════════════
#  إعدادات المستودع
# ═══════════════════════════════════════════════════════════════════
GITHUB_USER   = "ismail9875"
GITHUB_REPO   = "ReaderManager"
GITHUB_BRANCH = "main"

# ملف النسخة على GitHub (raw)
REMOTE_VERSION_URL = (
    "https://raw.githubusercontent.com/%s/%s/%s/version"
    % (GITHUB_USER, GITHUB_REPO, GITHUB_BRANCH)
)

# ✅ رابط ملف tar.gz المرفوع يدوياً في الريبو
# (وليس /archive/refs/heads/... الذي يُولّده GitHub تلقائياً)
REMOTE_TARBALL_URL = (
    "https://github.com/%s/%s/raw/refs/heads/%s/ReaderManager.tar.gz"
    % (GITHUB_USER, GITHUB_REPO, GITHUB_BRANCH)
)

HTTP_TIMEOUT = 15.0
VERSION_FILE = "version"

# المسار داخل الأرشيف (يحافظ على هرمية Enigma2)
PLUGIN_REL_PATH = (
    "usr/lib/enigma2/python/Plugins/Extensions/ReaderManager"
)

# مسارات العمل المؤقتة
TMP_ROOT        = "/tmp/ReaderManager_update"
TMP_DOWNLOAD    = os.path.join(TMP_ROOT, "download")
TMP_EXTRACT     = os.path.join(TMP_ROOT, "extracted")
TMP_BACKUP_ROOT = "/tmp/ReaderManager_backups"


# ═══════════════════════════════════════════════════════════════════
#  مسارات البلوجين
# ═══════════════════════════════════════════════════════════════════
def get_plugin_dir():
    """يُعيد المسار الجذري للبلوجين."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_version_file_path():
    """يُعيد مسار ملف النسخة المحلي."""
    return os.path.join(get_plugin_dir(), VERSION_FILE)


# ═══════════════════════════════════════════════════════════════════
#  قراءة النسخ
# ═══════════════════════════════════════════════════════════════════
def get_local_version():
    path = get_version_file_path()
    if not os.path.isfile(path):
        logger.log("Upgrader", "Local version file not found: %s" % path)
        return ""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read().strip()
        first_line = content.splitlines()[0].strip() if content else ""
        if not first_line:
            logger.log("Upgrader", "Local version file is empty")
            return ""
        if not re.match(r"^\d+(\.\d+)*$", first_line):
            logger.log("Upgrader",
                       "Invalid local version format: %r" % first_line)
            return ""
        return first_line
    except Exception as e:
        logger.log("Upgrader", "Cannot read local version: %s" % e)
        return ""


def get_remote_version(timeout=HTTP_TIMEOUT):
    try:
        url = REMOTE_VERSION_URL + "?_t=%d" % int(time.time())
        logger.log("Upgrader", "Fetching remote version: %s" % url)

        req = Request(url, headers={
            "User-Agent": "Enigma2-ReaderManager-Upgrader/1.0",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        })

        opener = _make_opener()
        resp = opener.open(req, timeout=timeout)
        data = resp.read()

        if isinstance(data, bytes):
            data = data.decode("utf-8", "ignore")

        first_line = data.strip().splitlines()[0].strip() if data else ""
        if not first_line:
            return False, "Empty remote version"
        if not re.match(r"^\d+(\.\d+)*$", first_line):
            return False, "Invalid remote version format: %r" % first_line

        logger.log("Upgrader", "Remote version: %s" % first_line)
        return True, first_line

    except HTTPError as e:
        msg = "HTTP %d: %s" % (e.code, e.reason)
        logger.log("Upgrader", "Remote fetch failed: %s" % msg)
        return False, msg
    except URLError as e:
        msg = "URL error: %s" % e.reason
        logger.log("Upgrader", "Remote fetch failed: %s" % msg)
        return False, msg
    except Exception as e:
        msg = "Fetch error: %s" % e
        logger.log("Upgrader", "Remote fetch failed: %s" % msg)
        return False, msg


# ═══════════════════════════════════════════════════════════════════
#  مقارنة الإصدارات
# ═══════════════════════════════════════════════════════════════════
def _parse_version(v):
    if not v:
        return None
    v = v.strip()
    if not re.match(r"^\d+(\.\d+)*$", v):
        return None
    try:
        return tuple(int(x) for x in v.split("."))
    except Exception:
        return None


def compare_versions(v1, v2):
    t1 = _parse_version(v1)
    t2 = _parse_version(v2)
    if t1 is None or t2 is None:
        return None
    max_len = max(len(t1), len(t2))
    t1 = t1 + (0,) * (max_len - len(t1))
    t2 = t2 + (0,) * (max_len - len(t2))
    if t1 < t2:
        return -1
    if t1 > t2:
        return 1
    return 0


def is_newer(remote, local):
    return compare_versions(remote, local) == 1


# ═══════════════════════════════════════════════════════════════════
#  فحص التحديثات
# ═══════════════════════════════════════════════════════════════════
def check_for_updates(timeout=HTTP_TIMEOUT):
    result = {
        "ok": False, "error": "",
        "local_version": "", "remote_version": "",
        "has_update": False, "message": "",
    }

    local = get_local_version()
    result["local_version"] = local

    if not local:
        result["error"] = "Cannot read local version"
        result["message"] = "Cannot read local version file."
        return result

    ok, remote_or_err = get_remote_version(timeout=timeout)
    if not ok:
        result["error"] = remote_or_err
        result["message"] = (
            "Cannot check for updates:\n%s\n\n"
            "Local version: %s" % (remote_or_err, local))
        return result

    remote = remote_or_err
    result["remote_version"] = remote
    result["ok"] = True

    cmp = compare_versions(remote, local)
    if cmp is None:
        result["error"] = "Version format error"
        result["message"] = (
            "Invalid version format:\nLocal: %s\nRemote: %s"
            % (local, remote))
        return result

    if cmp == 1:
        result["has_update"] = True
        result["message"] = (
            "Update available!\n\n"
            "Local:  %s\nRemote: %s\n\n"
            "Do you want to download and install it?" % (local, remote))
    elif cmp == 0:
        result["has_update"] = False
        result["message"] = "You are up to date.\n\nVersion: %s" % local
    else:
        result["has_update"] = False
        result["message"] = (
            "Your local version is newer than remote.\n\n"
            "Local:  %s\nRemote: %s" % (local, remote))

    return result


# ═══════════════════════════════════════════════════════════════════
#  HTTP opener
# ═══════════════════════════════════════════════════════════════════
def _make_opener():
    handlers = []
    try:
        if _create_unverified_context:
            ctx = _create_unverified_context()
            handlers.append(HTTPSHandler(context=ctx))
        else:
            handlers.append(HTTPSHandler())
    except Exception:
        handlers.append(HTTPSHandler())
    handlers.append(HTTPHandler)
    return build_opener(*handlers)


# ═══════════════════════════════════════════════════════════════════
#  helpers عامة
# ═══════════════════════════════════════════════════════════════════
def _safe_rmtree(path):
    try:
        if path and os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
    except Exception as e:
        logger.log("Upgrader", "_safe_rmtree(%s): %s" % (path, e))


def _safe_makedirs(path):
    try:
        if path and not os.path.isdir(path):
            os.makedirs(path)
    except Exception as e:
        logger.log("Upgrader", "_safe_makedirs(%s): %s" % (path, e))


def _log_tree(root, max_depth=6, max_files=15):
    """يُسجّل شجرة المجلد في الـ log (للتشخيص)."""
    try:
        logger.log("Upgrader", "=== TREE: %s ===" % root)
        base_depth = root.rstrip("/").count("/")
        for r, dirs, files in os.walk(root):
            depth = r.count("/") - base_depth
            if depth > max_depth:
                continue
            indent = "  " * depth
            logger.log("Upgrader",
                       "%s%s/" % (indent, os.path.basename(r) or r))
            for f in files[:max_files]:
                logger.log("Upgrader", "%s  %s" % (indent, f))
    except Exception as e:
        logger.log("Upgrader", "_log_tree error: %s" % e)


# ═══════════════════════════════════════════════════════════════════
#  تحميل tar.gz
# ═══════════════════════════════════════════════════════════════════
def download_update(dest_dir=TMP_DOWNLOAD, timeout=60.0, progress=None):
    _safe_makedirs(dest_dir)
    tar_path = os.path.join(dest_dir, "ReaderManager.tar.gz")

    try:
        url = REMOTE_TARBALL_URL + "?_t=%d" % int(time.time())
        logger.log("Upgrader", "Downloading: %s" % url)

        req = Request(url, headers={
            "User-Agent": "Enigma2-ReaderManager-Upgrader/1.0",
        })

        opener = _make_opener()
        resp = opener.open(req, timeout=timeout)

        total = 0
        try:
            total = int(resp.headers.get("Content-Length", 0))
        except Exception:
            total = 0

        chunk_size = 64 * 1024
        downloaded = 0

        with open(tar_path, "wb") as f:
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if progress:
                    try:
                        progress(downloaded, total)
                    except Exception:
                        pass

        if not os.path.isfile(tar_path) or os.path.getsize(tar_path) == 0:
            return False, "Downloaded file is empty"

        # تحقق أن الملف gzip فعلاً (magic bytes: 1f 8b)
        try:
            with open(tar_path, "rb") as f:
                magic = f.read(2)
            if magic != b"\x1f\x8b":
                return False, ("Downloaded file is not gzip "
                               "(magic=%r)" % magic)
        except Exception:
            pass

        logger.log("Upgrader",
                   "Downloaded %d bytes to %s"
                   % (os.path.getsize(tar_path), tar_path))

        return True, tar_path

    except HTTPError as e:
        return False, "HTTP %d: %s" % (e.code, e.reason)
    except URLError as e:
        return False, "URL error: %s" % e.reason
    except Exception as e:
        return False, "Download error: %s" % e


# ═══════════════════════════════════════════════════════════════════
#  استخراج tar.gz
# ═══════════════════════════════════════════════════════════════════
def _find_plugin_root(dest_dir):
    """
    يبحث عن جذر البلوجين بعدة استراتيجيات.
    Returns:
        (path, strategy_name) أو (None, "not_found")
    """
    # ① المسار الكامل المتوقع
    full_path = os.path.join(dest_dir, PLUGIN_REL_PATH)
    if os.path.isdir(full_path) and \
            os.path.isfile(os.path.join(full_path, "plugin.py")):
        return full_path, "full_path"

    # ② المسار الكامل في أي عمق (لو الأرشيف يحتوي مجلد جذري إضافي)
    for root, dirs, files in os.walk(dest_dir):
        candidate = os.path.join(root, PLUGIN_REL_PATH)
        if os.path.isdir(candidate) and \
                os.path.isfile(os.path.join(candidate, "plugin.py")):
            return candidate, "nested_full_path"

    # ③ أي مجلد اسمه ReaderManager يحتوي plugin.py
    for root, dirs, files in os.walk(dest_dir):
        if os.path.basename(root) == "ReaderManager" and \
                "plugin.py" in files:
            return root, "by_dirname"

    # ④ أي مجلد يحتوي plugin.py + __init__.py
    for root, dirs, files in os.walk(dest_dir):
        if "plugin.py" in files and "__init__.py" in files:
            return root, "by_plugin_init"

    # ⑤ أي plugin.py
    for root, dirs, files in os.walk(dest_dir):
        if "plugin.py" in files:
            return root, "by_plugin"

    # ⑥ plugin.py في الجذر
    if os.path.isfile(os.path.join(dest_dir, "plugin.py")):
        return dest_dir, "at_root"

    return None, "not_found"


def extract_tarball(tar_path, dest_dir=TMP_EXTRACT):
    """
    يستخرج tar.gz إلى dest_dir ثم يبحث عن جذر البلوجين.

    Returns:
        (ok: bool, extracted_plugin_root_or_error: str)
    """
    logger.log("Upgrader",
               "extract_tarball called: tar=%s, dest=%s"
               % (tar_path, dest_dir))

    try:
        if not os.path.isfile(tar_path):
            msg = "tar.gz not found: %s" % tar_path
            logger.log("Upgrader", msg)
            return False, msg

        size = os.path.getsize(tar_path)
        logger.log("Upgrader", "tar size: %d bytes" % size)
        if size < 512:
            msg = "tar.gz too small (%d bytes)" % size
            logger.log("Upgrader", msg)
            return False, msg

        _safe_makedirs(dest_dir)

        # فتح الأرشيف
        try:
            tf = tarfile.open(tar_path, "r:gz")
            logger.log("Upgrader", "Opened with r:gz")
        except Exception as e1:
            logger.log("Upgrader", "r:gz failed: %s — trying r:*" % e1)
            try:
                tf = tarfile.open(tar_path, "r:*")
                logger.log("Upgrader", "Opened with r:*")
            except Exception as e2:
                msg = "Cannot open tar.gz: %s" % e2
                logger.log("Upgrader", msg)
                return False, msg

        try:
            members = []
            for m in tf.getmembers():
                if ".." in m.name.split("/"):
                    continue
                if m.name.startswith("/"):
                    continue
                members.append(m)

            logger.log("Upgrader",
                       "Extracting %d members..." % len(members))
            tf.extractall(dest_dir, members=members)
            logger.log("Upgrader", "Extraction done")
        finally:
            try:
                tf.close()
            except Exception:
                pass

        # ابحث عن الجذر
        root, strategy = _find_plugin_root(dest_dir)
        if root:
            logger.log("Upgrader",
                       "Plugin root found (strategy=%s): %s"
                       % (strategy, root))
            return True, root

        # فشل — سجّل الشجرة للتشخيص
        logger.log("Upgrader", "Plugin root NOT found — dumping tree")
        _log_tree(dest_dir, max_depth=8, max_files=20)
        return False, "Plugin root not found in archive"

    except Exception as e:
        tb = traceback.format_exc()
        msg = "Extract error: %s\n%s" % (e, tb)
        logger.log("Upgrader", msg)
        return False, msg


# ═══════════════════════════════════════════════════════════════════
#  نسخة احتياطية
# ═══════════════════════════════════════════════════════════════════
def _backup_current(plugin_dir):
    try:
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(TMP_BACKUP_ROOT,
                                   "backup_%s" % timestamp)
        _safe_makedirs(TMP_BACKUP_ROOT)

        # نسخة كاملة بدون أي استثناء
        shutil.copytree(plugin_dir, backup_path)
        logger.log("Upgrader", "Backup created: %s" % backup_path)
        return True, backup_path

    except Exception as e:
        tb = traceback.format_exc()
        msg = "Backup error: %s\n%s" % (e, tb)
        logger.log("Upgrader", msg)
        return False, msg


# ═══════════════════════════════════════════════════════════════════
#  force-overwrite helpers
# ═══════════════════════════════════════════════════════════════════
def _force_clear_dir(plugin_dir):
    """
    يحذف كل محتوى المجلد — بدون أي استثناء.
    لا يحذف المجلد نفسه.
    """
    try:
        entries = os.listdir(plugin_dir)
        logger.log("Upgrader",
                   "_force_clear_dir: %d entries to remove" % len(entries))

        for name in entries:
            path = os.path.join(plugin_dir, name)
            try:
                if os.path.isdir(path) and not os.path.islink(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except Exception as e:
                logger.log("Upgrader",
                           "Cannot remove %s: %s" % (path, e))
        return True, ""
    except Exception as e:
        tb = traceback.format_exc()
        return False, "Clear dir error: %s\n%s" % (e, tb)


def _force_copy_tree(src, dst):
    """
    ينسخ محتوى src إلى dst بشكل recursive.
    force-overwrite: لا استثناءات.
    """
    copied = 0
    try:
        for root, dirs, files in os.walk(src):
            rel = os.path.relpath(root, src)
            target_dir = dst if rel == "." else os.path.join(dst, rel)

            _safe_makedirs(target_dir)

            for fname in files:
                src_file = os.path.join(root, fname)
                dst_file = os.path.join(target_dir, fname)

                try:
                    if os.path.exists(dst_file):
                        os.remove(dst_file)
                    shutil.copy2(src_file, dst_file)
                    copied += 1
                except Exception as e:
                    logger.log("Upgrader",
                               "Cannot copy %s: %s" % (src_file, e))

        return True, copied, ""

    except Exception as e:
        tb = traceback.format_exc()
        return False, copied, "Copy error: %s\n%s" % (e, tb)


# ═══════════════════════════════════════════════════════════════════
#  تطبيق التحديث
# ═══════════════════════════════════════════════════════════════════
def apply_update(source_dir):
    """
    force-overwrite: البلوجين النهائي = محتوى الأرشيف بالضبط.

    Returns:
        dict: {ok, error, backup_path, files_copied}
    """
    result = {
        "ok": False, "error": "",
        "backup_path": "", "files_copied": 0,
    }

    if not source_dir or not os.path.isdir(source_dir):
        result["error"] = "Invalid source dir: %s" % source_dir
        logger.log("Upgrader", result["error"])
        return result

    plugin_dir = get_plugin_dir()
    if not os.path.isdir(plugin_dir):
        result["error"] = "Plugin dir not found: %s" % plugin_dir
        logger.log("Upgrader", result["error"])
        return result

    logger.log("Upgrader",
               "apply_update: source=%s → plugin=%s"
               % (source_dir, plugin_dir))

    # ① نسخة احتياطية
    logger.log("Upgrader", "Step: backup")
    ok, backup_or_err = _backup_current(plugin_dir)
    if not ok:
        result["error"] = backup_or_err
        return result
    result["backup_path"] = backup_or_err

    # ② حذف كل محتوى البلوجين
    logger.log("Upgrader", "Step: clear plugin dir")
    ok, err = _force_clear_dir(plugin_dir)
    if not ok:
        result["error"] = err
        return result

    # ③ نسخ محتوى الأرشيف
    logger.log("Upgrader", "Step: copy tree")
    ok, copied, err = _force_copy_tree(source_dir, plugin_dir)
    if not ok:
        result["error"] = err
        return result

    result["files_copied"] = copied
    result["ok"] = True
    logger.log("Upgrader",
               "Update applied: %d files copied" % copied)
    return result


# ═══════════════════════════════════════════════════════════════════
#  API موحّد
# ═══════════════════════════════════════════════════════════════════
def perform_update(progress=None):
    result = {
        "ok": False, "error": "",
        "backup_path": "", "files_copied": 0,
        "new_version": "",
    }

    def _report(stage, info=""):
        logger.log("Upgrader", "REPORT [%s] %s" % (stage, info))
        if progress:
            try:
                progress(stage, info)
            except Exception as e:
                logger.log("Upgrader", "progress cb error: %s" % e)

    logger.log("Upgrader", "=== perform_update START ===")

    _safe_rmtree(TMP_ROOT)
    _safe_makedirs(TMP_ROOT)

    try:
        # ① تحقق من النسخ
        _report("download", "Verifying versions...")
        check = check_for_updates()
        if not check.get("ok"):
            result["error"] = check.get("error", "check failed")
            _report("error", result["error"])
            return result
        if not check.get("has_update"):
            result["error"] = "No update available"
            _report("error", "No update available")
            return result

        local_ver = check.get("local_version", "?")
        remote_ver = check.get("remote_version", "?")
        _report("download",
                "Update available: %s → %s" % (local_ver, remote_ver))

        # ② تحميل
        def _dl_progress(current, total):
            if total > 0:
                pct = int((current * 100) / total)
                _report("download",
                        "Downloading... %d%% (%d/%d KB)"
                        % (pct, current // 1024, total // 1024))
            else:
                _report("download",
                        "Downloading... %d KB" % (current // 1024))

        logger.log("Upgrader", "Step: download")
        ok, tar_or_err = download_update(
            dest_dir=TMP_DOWNLOAD, progress=_dl_progress)

        if not ok:
            result["error"] = tar_or_err
            _report("error", tar_or_err)
            return result

        tar_path = tar_or_err

        # ③ استخراج
        logger.log("Upgrader", "Step: extract")
        _report("extract", "Extracting archive...")
        _safe_rmtree(TMP_EXTRACT)
        _safe_makedirs(TMP_EXTRACT)

        ok, root_or_err = extract_tarball(tar_path, TMP_EXTRACT)
        if not ok:
            result["error"] = root_or_err
            _report("error", root_or_err)
            return result

        source_dir = root_or_err
        logger.log("Upgrader",
                   "Source dir for apply: %s" % source_dir)

        # ④ قراءة النسخة الجديدة
        new_version = ""
        try:
            new_ver_file = os.path.join(source_dir, VERSION_FILE)
            if os.path.isfile(new_ver_file):
                with open(new_ver_file, "r",
                          encoding="utf-8", errors="ignore") as f:
                    new_version = f.read().strip().splitlines()[0].strip()
        except Exception as e:
            logger.log("Upgrader", "read new version error: %s" % e)
        result["new_version"] = new_version
        logger.log("Upgrader",
                   "New version from archive: %r" % new_version)

        # ⑤ تطبيق
        logger.log("Upgrader", "Step: apply")
        _report("apply", "Applying update...")
        apply_res = apply_update(source_dir)

        if not apply_res["ok"]:
            result["error"] = apply_res["error"]
            _report("error", apply_res["error"])
            return result

        result["ok"] = True
        result["backup_path"] = apply_res["backup_path"]
        result["files_copied"] = apply_res["files_copied"]

        _report("done",
                "Update complete! (%d files)"
                % apply_res["files_copied"])

        logger.log("Upgrader", "=== perform_update SUCCESS ===")
        return result

    except Exception as e:
        tb = traceback.format_exc()
        result["error"] = "Unexpected error: %s\n%s" % (e, tb)
        logger.log("Upgrader", result["error"])
        _report("error", result["error"])
        return result

    finally:
        _safe_rmtree(TMP_ROOT)
        logger.log("Upgrader", "Cleaned tmp root: %s" % TMP_ROOT)
        logger.log("Upgrader", "=== perform_update END ===")


# ═══════════════════════════════════════════════════════════════════
#  Restart helper
# ═══════════════════════════════════════════════════════════════════
def restart_enigma():
    try:
        from enigma import quitMainloop
        quitMainloop(3)
        logger.log("Upgrader", "Enigma2 restart requested")
        return True
    except Exception as e:
        logger.log("Upgrader", "restart error: %s" % e)
        return False