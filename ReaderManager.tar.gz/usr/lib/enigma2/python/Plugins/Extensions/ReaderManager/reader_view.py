# -*- coding: utf-8 -*-
"""
reader_view.py — شاشة عرض تفاصيل reader.
متوافق مع Python 2.7 و Python 3.x — DreamOS / OpenSource
"""
from __future__ import absolute_import, print_function, unicode_literals

import os

# ─── توافق Py2/Py3 ───
try:
    from io import open
except ImportError:
    pass

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button

from .reader_parser import ReaderParser
from . import logger


MASK = "*****"

INVALID_CAIDS = {"0000", "000000", "00000000", ""}


# ======================================================================
#  جدول أنظمة التشفير الشامل (من MetrixHDaccess)
# ======================================================================
CAINFO_TABLE = (
    ("0002", "0002", "18Crypt"),
    ("0100", "01FF", "Seca"),
    ("0200", "02FF", "CCETT"),
    ("0300", "03FF", "Kabel Deutschland"),
    ("0400", "04FF", "Eurodec"),
    ("0500", "05FF", "Viaccess"),
    ("0600", "06FF", "Irdeto"),
    ("0700", "07FF", "DigiChiper"),
    ("0800", "08FF", "Matra"),
    ("0900", "09FF", "NDS/Videoguard"),
    ("0A00", "0AFF", "Nokia"),
    ("0B00", "0BFF", "Conax"),
    ("0C00", "0CFF", "NTL"),
    ("0D00", "0DFF", "Cryptoworks"),
    ("0E00", "0EFF", "PowerVu"),
    ("0F00", "0FFF", "Sony"),
    ("1000", "10FF", "Tandberg"),
    ("1100", "11FF", "Thomson"),
    ("1200", "12FF", "TV/Com"),
    ("1300", "14FF", "HRT"),
    ("1500", "15FF", "IBM"),
    ("1600", "16FF", "Nera"),
    ("1702", "1702", "Betacrypt"),
    ("1722", "1722", "Betacrypt"),
    ("1762", "1762", "Betacrypt"),
    ("1700", "1701", "Verimatrix"),
    ("1703", "1721", "Verimatrix"),
    ("1723", "1761", "Verimatrix"),
    ("1763", "17FF", "Verimatrix"),
    ("1800", "18FF", "Nagravision"),
    ("1900", "19FF", "Titan"),
    ("1E00", "1E07", "Alticast"),
    ("1EA0", "1EA0", "Monacrypt"),
    ("1EB0", "1EB0", "TeleCast"),
    ("1EC0", "1EC2", "Cryptoguard"),
    ("1ED0", "1ED1", "Monacrypt"),
    ("2000", "20FF", "Telefonica"),
    ("2100", "21FF", "Stendor"),
    ("2200", "22FF", "Codicrypt"),
    ("2300", "23FF", "Barco"),
    ("2400", "24FF", "StarGuide"),
    ("2500", "25FF", "Mentor"),
    ("2600", "2601", "Biss"),
    ("2602", "26FF", "Biss2"),
    ("2700", "2711", "ExSet"),
    ("2712", "2712", "Derincrypt"),
    ("2713", "2714", "Wuhan"),
    ("2715", "2715", "Network Broadcast"),
    ("2716", "2716", "Bromteck"),
    ("2717", "2718", "LogiWays"),
    ("2719", "2719", "S-Curious"),
    ("27A0", "27A4", "ByDesign India"),
    ("2800", "2809", "LCS LLC"),
    ("2810", "2810", "DeltaSat"),
    ("4347", "4347", "Crypton"),
    ("4348", "4348", "Secure TV"),
    ("44A0", "44A0", "Russkiy Mir"),
    ("4700", "47FF", "General Instrument"),
    ("4800", "48FF", "AccessGate/Telemann"),
    ("4825", "4825", "ChinaEPG"),
    ("4855", "4856", "Intertrust"),
    ("4900", "49FF", "Cryptoworks China"),
    ("4A10", "4A1F", "EasyCas"),
    ("4A20", "4A2F", "AlphaCrypt"),
    ("4A30", "4A3F", "DVN Holdings"),
    ("4A40", "4A4F", "ADT"),
    ("4A50", "4A5F", "Shenzhen Kingsky"),
    ("4A60", "4A6F", "@Sky"),
    ("4A70", "4A7F", "DreamCrypt"),
    ("4A80", "4A8F", "THALESCrypt"),
    ("4A90", "4A9F", "Runcom"),
    ("4AA0", "4AAF", "SIDSA"),
    ("4AB0", "4ABF", "Beijing Compunicate"),
    ("4AC0", "4ACF", "Latens"),
    ("4AD0", "4AD1", "XCrypt"),
    ("4AD2", "4AD3", "Beijing Digital"),
    ("4AD4", "4AD5", "Widevine"),
    ("4AD6", "4AD7", "SK Telecom"),
    ("4AD8", "4AD9", "Enigma"),
    ("4ADA", "4ADA", "Wyplay"),
    ("4ADB", "4ADB", "Jinan Taixin"),
    ("4ADC", "4ADC", "LogiWays"),
    ("4ADD", "4ADD", "ATSC SRM"),
    ("4ADE", "4ADE", "CerberCrypt"),
    ("4ADF", "4ADF", "Caston"),
    ("4AE0", "4AE1", "DreCrypt"),
    ("4AE2", "4AE3", "Microsoft"),
    ("4AE4", "4AE4", "Coretrust"),
    ("4AE5", "4AE5", "IK SATPROF"),
    ("4AE6", "4AE6", "SypherMedia"),
    ("4AE7", "4AE7", "Guangzhou Ewider"),
    ("4AE8", "4AE8", "FG Digital"),
    ("4AE9", "4AE9", "Dreamer-i"),
    ("4AEA", "4AEA", "Cryptoguard"),
    ("4AEB", "4AEB", "Abel"),
    ("4AEC", "4AEC", "FTS DVL SRL"),
    ("4AED", "4AED", "Unitend"),
    ("4AEE", "4AEE", "Bulcrypt"),
    ("4AEF", "4AEF", "NetUP"),
    ("4AF0", "4AF0", "ABV"),
    ("4AF1", "4AF2", "China DTV"),
    ("4AF3", "4AF3", "Baustem"),
    ("4AF4", "4AF4", "Marlin"),
    ("4AF5", "4AF5", "SecureMedia"),
    ("4AF6", "4AF6", "Tongfang"),
    ("4AF7", "4AF7", "MSA"),
    ("4AF8", "4AF8", "Griffin"),
    ("4AF9", "4AFA", "Beijing Topreal"),
    ("4AFB", "4AFB", "NST"),
    ("4AFC", "4AFC", "PanAccess"),
    ("4AFD", "4AFD", "Comteza"),
    ("4B00", "4B02", "Tongfang"),
    ("4B03", "4B03", "DuoCrypt"),
    ("4B04", "4B04", "Great Wall"),
    ("4B05", "4B06", "Digicap"),
    ("4B07", "4B07", "Wuhan"),
    ("4B08", "4B08", "Philips"),
    ("4B09", "4B09", "Ambernetas"),
    ("4B0A", "4B0B", "Beijing Sumavision"),
    ("4B0C", "4B0F", "Sichuan"),
    ("4B10", "4B10", "Exterity"),
    ("4B11", "4B12", "Merlin/Advanced Digital"),
    ("4B13", "4B14", "Microsoft"),
    ("4B19", "4B19", "RidSys"),
    ("4B20", "4B22", "DeltaSat"),
    ("4B23", "4B23", "SkyNLand"),
    ("4B24", "4B24", "Prowill"),
    ("4B25", "4B25", "SureSoft"),
    ("4B26", "4B26", "Unitend"),
    ("4B30", "4B31", "VTC"),
    ("4B3A", "4B3A", "ipanel"),
    ("4B3B", "4B3B", "Jinggangshan"),
    ("4B40", "4B41", "ExCaf"),
    ("4B42", "4B43", "CI Plus"),
    ("4B4A", "4B4A", "Topwell"),
    ("4B4B", "4B4D", "ABV"),
    ("4B50", "4B53", "Safeview India"),
    ("4B54", "4B54", "Telelynx"),
    ("4B60", "4B60", "KiwiSat"),
    ("4B61", "4B61", "O2 Czech"),
    ("4B62", "4B62", "GMA"),
    ("4B63", "4B63", "redCrypter"),
    ("4B64", "4B64", "Samsung/TV Key"),
    ("5347", "5347", "GkWare/StreamGuru"),
    ("5448", "5449", "Gospell VisionCrypt"),
    ("5501", "5580", "Griffin"),
    ("5581", "55FF", "Bulcrypt"),
    ("5601", "5604", "Verimatrix"),
    ("5605", "5606", "Sichuan"),
    ("5607", "5608", "Viewscenes"),
    ("5609", "5609", "Power On"),
    ("56A0", "56A0", "Laxmi"),
    ("56A1", "56A1", "C-Dot"),
    ("56B0", "56B0", "Laxmi"),
    ("56D0", "56D1", "redCrypter"),
    ("6448", "6449", "Gospell VisionCrypt"),
    ("7AC8", "7AC8", "Gospell VisionCrypt"),
    ("7BE0", "7BE1", "DreCrypt"),
    ("AA00", "AA01", "Best CAS"),
    ("A100", "A1FF", "RusCrypt"),
    ("0001", "0001", "IPDC SPP"),
    ("0004", "0006", "OMA"),
    ("0007", "0007", "Open IPTV"),
    ("0008", "0008", "Open Mobile Alliance"),
    ("0000", "0000", "no or unknown"),
)


# ======================================================================
#  خريطة توحيد أسماء الأنظمة
# ======================================================================
SYSTEM_ALIASES = {
    "nds/videoguard":             "videoguard",
    "nagravision":                "nagra",
    "dre_crypt":                  "drecrypt",
    "power_vu":                   "powervu",
    "general instrument":         "gi",
    "accessgate/telemann":        "accessgate",
    "cryptoworks china":          "cryptoworks_cn",
    "merlin/advanced digital":    "merlin",
    "biss2":                      "biss",
    "18crypt":                    "crypt18",
    "no or unknown":              "other",

    "betacrypt":                  "betacrypt",
    "verimatrix":                 "verimatrix",
    "monacrypt":                  "monacrypt",
    "wuhan":                      "wuhan",
    "logiways":                   "logiways",
    "cryptoguard":                "cryptoguard",
    "deltasat":                   "deltasat",
    "tongfang":                   "tongfang",
    "unitend":                    "unitend",
    "abv":                        "abv",
    "bulcrypt":                   "bulcrypt",
    "sichuan":                    "sichuan",
    "drecrypt":                   "drecrypt",
    "gospell visioncrypt":        "gospell",
    "redcrypter":                 "redcrypter",
    "laxmi":                      "laxmi",
    "microsoft":                  "microsoft",
    "griffin":                    "griffin",
    "beijing digital":            "beijing_digital",
    "beijing compunicate":        "beijing_compunicate",
    "beijing sumavision":         "beijing_sumavision",
    "beijing topreal":            "beijing_topreal",
    "biss":                       "biss",
    "viaccess":                   "viaccess",
    "irdeto":                     "irdeto",
    "conax":                      "conax",
    "cryptoworks":                "cryptoworks",
    "powervu":                    "powervu",
    "nagra":                      "nagra",
    "seca":                       "seca",
    "videoguard":                 "videoguard",
}


def _canonical_system(system_name):
    """يُعيد مفتاحاً موحّداً للـ system."""
    if not system_name:
        return "other"
    key = system_name.lower().strip()
    if key in SYSTEM_ALIASES:
        return SYSTEM_ALIASES[key]
    return (key.replace("/", "_")
                .replace(" ", "_")
                .replace("-", "_"))


def _guess_system_by_caid(caid):
    """يخمّن system من CAID باستخدام الجدول الشامل."""
    caid = (caid or "").upper().strip()
    if not caid or len(caid) < 4:
        return ""

    for start, end, name in CAINFO_TABLE:
        if start <= caid <= end:
            return _canonical_system(name)

    return ""


# ======================================================================
#  جدول الألوان الشامل
# ======================================================================
SYSTEM_COLORS = {
    "viaccess":             "#FF6B6B",
    "irdeto":               "#4ECDC4",
    "conax":                "#FFD93D",
    "videoguard":           "#6BCB77",
    "nagra":                "#C77DFF",
    "cryptoworks":          "#FF9F1C",
    "seca":                 "#FF4757",
    "powervu":              "#FFA502",
    "betacrypt":            "#70A1FF",
    "verimatrix":           "#5F27CD",
    "biss":                 "#2ED573",
    "crypt18":              "#FF6348",

    "ccett":                "#576574",
    "kabel_deutschland":    "#54A0FF",
    "eurodec":              "#48DBFB",
    "digichiper":           "#F368E0",
    "matra":                "#EE5A24",
    "nokia":                "#0ABDE3",
    "ntl":                  "#C8D6E5",
    "sony":                 "#FECA57",
    "tandberg":             "#1DD1A1",
    "thomson":              "#FF9FF3",
    "tv_com":               "#00D2D3",
    "hrt":                  "#FECA57",
    "ibm":                  "#1E90FF",
    "nera":                 "#A29BFE",
    "titan":                "#FD79A8",
    "alticast":             "#FF7675",
    "monacrypt":            "#74B9FF",
    "telecast":             "#0984E3",
    "cryptoguard":          "#00B894",
    "telefonica":           "#FDCB6E",
    "stendor":              "#E17055",
    "codicrypt":            "#81ECEC",
    "barco":                "#FFEAA7",
    "starguide":            "#B2BEC3",
    "mentor":               "#636E72",
    "exset":                "#E84393",
    "derincrypt":           "#00CEC9",
    "wuhan":                "#55EFC4",
    "network_broadcast":    "#FFEAA7",
    "bromteck":             "#DFE6E9",
    "logiways":             "#FD79A8",
    "s_curious":            "#A29BFE",
    "bydesign_india":       "#FF7675",
    "lcs_llc":              "#74B9FF",
    "deltasat":             "#00B894",
    "crypton":              "#E17055",
    "secure_tv":            "#FAB1A0",
    "russkiy_mir":          "#FDCB6E",
    "gi":                   "#0984E3",
    "accessgate":           "#6C5CE7",
    "chinaepg":             "#FF6B6B",
    "intertrust":           "#55A3FF",
    "cryptoworks_cn":       "#FF9F1C",
    "easycas":              "#74B9FF",
    "alphacrypt":           "#A29BFE",
    "dvn_holdings":         "#DFE6E9",
    "adt":                  "#FAB1A0",
    "shenzhen_kingsky":     "#FFEAA7",
    "at_sky":               "#F368E0",
    "dreamcrypt":           "#5F27CD",
    "thalescrypt":          "#00CEC9",
    "runcom":               "#FD79A8",
    "sidsa":                "#E84393",
    "beijing_compunicate":  "#FDCB6E",
    "latens":               "#00B894",
    "xcrypt":               "#81ECEC",
    "beijing_digital":      "#FF7675",
    "widevine":             "#6C5CE7",
    "sk_telecom":           "#FF4757",
    "enigma":               "#2ED573",
    "wyplay":               "#FFA502",
    "jinan_taixin":         "#576574",
    "atsc_srm":             "#54A0FF",
    "cerbercrypt":          "#EE5A24",
    "caston":               "#0ABDE3",
    "drecrypt":             "#F368E0",
    "microsoft":            "#00D2D3",
    "coretrust":            "#1DD1A1",
    "ik_satprof":           "#FF9FF3",
    "syphermedia":          "#FECA57",
    "guangzhou_ewider":     "#FF6348",
    "fg_digital":           "#48DBFB",
    "dreamer_i":            "#C8D6E5",
    "abel":                 "#A29BFE",
    "fts_dvl_srl":          "#FD79A8",
    "unitend":              "#55EFC4",
    "bulcrypt":             "#FAB1A0",
    "netup":                "#0984E3",
    "abv":                  "#E17055",
    "china_dtv":            "#74B9FF",
    "baustem":              "#00CEC9",
    "marlin":               "#6C5CE7",
    "securemedia":          "#FF7675",
    "tongfang":             "#FDCB6E",
    "msa":                  "#E84393",
    "griffin":              "#2ED573",
    "beijing_topreal":      "#FFA502",
    "nst":                  "#576574",
    "panaccess":            "#54A0FF",
    "comteza":              "#EE5A24",
    "duocrypt":             "#0ABDE3",
    "great_wall":           "#F368E0",
    "digicap":              "#00D2D3",
    "philips":              "#1DD1A1",
    "ambernetas":           "#FF9FF3",
    "beijing_sumavision":   "#FECA57",
    "sichuan":              "#FF6348",
    "exterity":             "#48DBFB",
    "merlin":               "#C8D6E5",
    "ridsys":               "#A29BFE",
    "skynland":             "#FD79A8",
    "prowill":              "#55EFC4",
    "suresoft":             "#FAB1A0",
    "vtc":                  "#0984E3",
    "ipanel":               "#E17055",
    "jinggangshan":         "#74B9FF",
    "excaf":                "#00CEC9",
    "ci_plus":              "#6C5CE7",
    "topwell":              "#FF7675",
    "safeview_india":       "#FDCB6E",
    "telelynx":             "#E84393",
    "kiwisat":              "#2ED573",
    "o2_czech":             "#FFA502",
    "gma":                  "#576574",
    "redcrypter":           "#54A0FF",
    "samsung_tv_key":       "#EE5A24",
    "gkwaresg":             "#0ABDE3",
    "gospell":              "#F368E0",
    "viewscenes":           "#00D2D3",
    "power_on":             "#1DD1A1",
    "laxmi":                "#FF9FF3",
    "c_dot":                "#FECA57",
    "best_cas":             "#FF6348",
    "ruscrypt":             "#48DBFB",
    "ipdc_spp":             "#C8D6E5",
    "oma":                  "#A29BFE",
    "open_iptv":            "#FD79A8",
    "open_mobile_alliance": "#55EFC4",

    "other":                "#FF6FB5",
}

OTHER_COLOR = "#FF6FB5"


# ======================================================================
#  CaidEntry
# ======================================================================
class CaidEntry(object):
    __slots__ = ("caid", "system", "cards_count", "provids")

    def __init__(self, caid, system="", cards_count=0):
        self.caid = (caid or "").strip().upper()
        self.system = (system or "").strip().lower()
        self.cards_count = cards_count
        self.provids = set()

    def add_provid(self, provid):
        """يُضيف provid فريداً ويزيد العدّاد."""
        provid = (provid or "").strip().upper()
        if not provid or provid in INVALID_CAIDS:
            return
        if provid not in self.provids:
            self.provids.add(provid)
            self.cards_count += 1

    def __repr__(self):
        return "<Caid %s sys=%s cards=%d>" % (
            self.caid, self.system, self.cards_count)


# ======================================================================
#  ReaderView
# ======================================================================
class ReaderView(Screen):
    skin = """
    <screen name="ReaderView" position="center,center" size="1280,720" title="Reader Details" flags="wfNoBorder" backgroundColor="#0A1428">

        <eLabel position="0,0" size="1280,4" backgroundColor="#1E90FF"/>
        <eLabel position="0,4" size="1280,2" backgroundColor="#22D3EE"/>
        <eLabel position="0,6" size="1280,1" backgroundColor="#A855F7"/>

        <eLabel position="30,14" size="1220,60" backgroundColor="#0E1E3C" cornerRadius="18" zPosition="-1"/>
        <eLabel position="30,14" size="1220,3"  backgroundColor="#1E90FF" cornerRadius="18"/>
        <eLabel position="center,20" size="700,48" text="Reader Details" font="Regular;32" foregroundColor="#EAF2FF" backgroundColor="#0E1E3C" halign="center" valign="center"/>

        <eLabel position="30,86" size="1220,70" backgroundColor="#0E1E3C" cornerRadius="12" zPosition="-1"/>
        <widget name="val_label" valign="center" halign="center" position="center,96" size="1220,50" font="Regular;50" foregroundColor="#EAF2FF" transparent="1"/>

        <eLabel position="30,190" size="1220,450" backgroundColor="#0E1E3C" cornerRadius="12" zPosition="-1"/>

        <widget name="col_title_0" position="50,160"   size="185,28" font="Regular;26" foregroundColor="#FF6B6B" halign="center" valign="center" transparent="1"/>
        <widget name="col_title_1" position="240,160"  size="185,28" font="Regular;26" foregroundColor="#4ECDC4" halign="center" valign="center" transparent="1"/>
        <widget name="col_title_2" position="430,160"  size="185,28" font="Regular;26" foregroundColor="#FFD93D" halign="center" valign="center" transparent="1"/>
        <widget name="col_title_3" position="620,160"  size="185,28" font="Regular;26" foregroundColor="#6BCB77" halign="center" valign="center" transparent="1"/>
        <widget name="col_title_4" position="810,160"  size="185,28" font="Regular;26" foregroundColor="#C77DFF" halign="center" valign="center" transparent="1"/>
        <widget name="col_title_5" position="1000,160" size="185,28" font="Regular;26" foregroundColor="#FF9F1C" halign="center" valign="center" transparent="1"/>

        <widget name="col_0" position="50,195"   size="185,430" font="Regular;32" foregroundColor="#FF6B6B" halign="center" valign="top" transparent="1"/>
        <widget name="col_1" position="240,195"  size="185,430" font="Regular;32" foregroundColor="#4ECDC4" halign="center" valign="top" transparent="1"/>
        <widget name="col_2" position="430,195"  size="185,430" font="Regular;32" foregroundColor="#FFD93D" halign="center" valign="top" transparent="1"/>
        <widget name="col_3" position="620,195"  size="185,430" font="Regular;32" foregroundColor="#6BCB77" halign="center" valign="top" transparent="1"/>
        <widget name="col_4" position="810,195"  size="185,430" font="Regular;32" foregroundColor="#C77DFF" halign="center" valign="top" transparent="1"/>
        <widget name="col_5" position="1000,195" size="185,430" font="Regular;32" foregroundColor="#FF9F1C" halign="center" valign="top" transparent="1"/>

        <eLabel position="30,628" size="1220,34" backgroundColor="#0E1E3C" cornerRadius="10" zPosition="-1"/>
        <eLabel position="30,628" size="4,34" backgroundColor="#1E90FF" cornerRadius="10"/>
        <widget name="state" position="50,628" size="1180,34" font="Regular;18" foregroundColor="#7EC8FF" halign="left" valign="center" transparent="1"/>

        <widget name="key_red"    position="130,676" size="240,36" font="Regular;22" backgroundColor="#3A0A18" foregroundColor="#FFB3C1" halign="center" valign="center" transparent="0" cornerRadius="18"/>
        <widget name="key_green"  position="380,676" size="240,36" font="Regular;22" backgroundColor="#0A3A18" foregroundColor="#B3FFC9" halign="center" valign="center" transparent="0" cornerRadius="18"/>
        <widget name="key_yellow" position="640,676" size="240,36" font="Regular;22" backgroundColor="#3A2E0A" foregroundColor="#FFE9A3" halign="center" valign="center" transparent="0" cornerRadius="18"/>
        <widget name="key_blue"   position="900,676" size="240,36" font="Regular;22" backgroundColor="#0A1F3A" foregroundColor="#A3D4FF" halign="center" valign="center" transparent="0" cornerRadius="18"/>
    </screen>
    """

    VISIBLE_COLS = 6
    VISIBLE_ROWS = 10

    def __init__(self, session, reader, on_toggle_callback=None,
                 api_status=None):
        Screen.__init__(self, session)
        self.session = session

        self.reader = reader
        self.api_status = api_status
        self.on_toggle_callback = on_toggle_callback

        self._visible_cols = self.VISIBLE_COLS
        self._col_offset = 0

        self._visible_rows = self.VISIBLE_ROWS
        self._row_offset = 0

        self._groups = []

        self["info_title"] = Label("Reader: %s" % (reader.label or "-"))
        self["state"]      = Label("")

        self["val_label"] = Label("-")
        self["val_host"]  = Label("-")
        self["val_port"]  = Label("-")
        self["val_user"]  = Label("-")
        self["val_pass"]  = Label("-")

        self["caids_count"] = Label("")

        for i in range(self._visible_cols):
            self["col_title_%d" % i] = Label("")
            self["col_%d" % i] = Label("")

        self["key_red"]    = Button("Close")
        self["key_green"]  = Button("ON/OFF")
        self["key_yellow"] = Button("Edit")
        self["key_blue"]   = Button("Delete")

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok":     self.close,
                "cancel": self.close,
                "red":    self.close,
                "green":  self.toggle_state,
                "yellow": self.edit_reader,
                "blue":   self.delete_reader,

                # تنقل عمودي — بين صفحات الأسطر (متزامن)
                "up":     self.scroll_up,
                "down":   self.scroll_down,

                # تنقل أفقي RTL — بين صفحات الأعمدة (قفزة 6)
                "right":  self.shift_right,
                "left":   self.shift_left,
            }, -1)

        self.onLayoutFinish.append(self.render)

    # ------------------------------------------------------------------
    def render(self):
        self._col_offset = 0
        self._row_offset = 0
        self._render_info()
        self._render_caids()
        self._render_state()

    # ------------------------------------------------------------------
    def _render_info(self):
        r = self.reader

        device = (r.device or "").strip()
        port = "-"
        if "," in device:
            parts = device.split(",", 1)
            port = parts[1].strip() or "-"

        self["val_label"].setText(r.label or "-")
        self["val_port"].setText(str(port))
        self["val_host"].setText(MASK)
        self["val_user"].setText(MASK if r.user else "-")
        self["val_pass"].setText(MASK if r.password else "-")

    # ------------------------------------------------------------------
    def get_caids(self):
        """
        يبني قاموس CAID → CaidEntry.
        يجمع الـ provids الفريدة من كل المصادر المتاحة.
        """
        caid_map = {}

        if self.api_status is not None:
            # ① من cards_details
            try:
                cards = getattr(self.api_status, "cards_details", []) or []
                for card in cards:
                    if not isinstance(card, dict):
                        continue
                    caid = (card.get("caid") or "").strip().upper()
                    if not caid or caid in INVALID_CAIDS:
                        continue

                    entry = caid_map.get(caid)
                    if entry is None:
                        entry = CaidEntry(caid)
                        caid_map[caid] = entry

                    provid = (card.get("provid")
                              or card.get("provider")
                              or card.get("provider_id")
                              or card.get("prov")
                              or "").strip().upper()

                    if provid:
                        entry.add_provid(provid)
                    else:
                        card_id = (card.get("id")
                                   or card.get("card_id")
                                   or "").strip()
                        if card_id:
                            entry.add_provid("_id_%s" % card_id)
                        else:
                            entry.cards_count += 1

                    if not entry.system:
                        sys_raw = (card.get("system") or "").strip()
                        if sys_raw:
                            entry.system = _canonical_system(sys_raw)
            except Exception as e:
                logger.log("ReaderView", "cards_details parse: %s" % e)

            # ② من entitlements
            try:
                raw = getattr(self.api_status, "raw", {}) or {}
                sources = [
                    raw.get("entitlements"),
                    (raw.get("connection") or {}).get("entitlements"),
                ]
                for src in sources:
                    if not isinstance(src, list):
                        continue
                    for ent in src:
                        if not isinstance(ent, dict):
                            continue
                        caid = (ent.get("caid") or "").strip().upper()
                        if not caid or caid in INVALID_CAIDS:
                            continue

                        entry = caid_map.get(caid)
                        if entry is None:
                            entry = CaidEntry(caid)
                            caid_map[caid] = entry

                        provid = (ent.get("provid")
                                  or ent.get("provider")
                                  or ent.get("id")
                                  or ent.get("prov")
                                  or "").strip().upper()
                        if provid:
                            entry.add_provid(provid)

                        if not entry.system:
                            sys_raw = (ent.get("system") or "").strip()
                            if sys_raw:
                                entry.system = _canonical_system(sys_raw)
            except Exception:
                pass

            # ③ من api_status.caid
            try:
                direct = (getattr(self.api_status, "caid", "") or "").upper()
                for part in direct.replace(",", " ") \
                        .replace(";", " ").split():
                    part = part.strip().upper()
                    if part and part not in INVALID_CAIDS \
                            and part not in caid_map:
                        caid_map[part] = CaidEntry(part)
            except Exception:
                pass

        # ④ من reader.caid
        r = self.reader
        direct = getattr(r, "caid", "") or ""
        for part in direct.replace(",", " ").replace(";", " ").split():
            part = part.strip().upper()
            if part and part not in INVALID_CAIDS and part not in caid_map:
                e = CaidEntry(part)
                e.cards_count = 1
                caid_map[part] = e

        # ⑤ من reader.extra
        try:
            extra = getattr(r, "extra", {}) or {}
            for key in ("caid", "caid_list"):
                v = extra.get(key)
                if v:
                    for part in str(v).replace(",", " ").split():
                        part = part.strip().upper()
                        if (part and part not in INVALID_CAIDS
                                and part not in caid_map):
                            e = CaidEntry(part)
                            e.cards_count = 1
                            caid_map[part] = e
        except Exception:
            pass

        # ⑥ fallback: املأ system من الجدول
        for caid, entry in caid_map.items():
            if not entry.system or entry.system == "other":
                guessed = _guess_system_by_caid(caid)
                if guessed:
                    entry.system = guessed

        return sorted(caid_map.values(), key=lambda e: e.caid)

    # ------------------------------------------------------------------
    def _group_by_system(self, caids):
        """
        يُجمّع حسب النظام. كل عنصر في groups هو:
            (sys_key, display, color, [(caid, count), ...])
        """
        groups = {}

        for entry in caids:
            sys_key = entry.system or "other"
            if sys_key not in groups:
                groups[sys_key] = []
            groups[sys_key].append((entry.caid, entry.cards_count))

        result = []
        used = set()

        PREFERRED = ["viaccess", "irdeto", "conax", "videoguard",
                     "nagra", "cryptoworks", "seca", "powervu",
                     "betacrypt", "verimatrix", "biss"]

        for sys_key in PREFERRED:
            if sys_key in groups:
                result.append(self._make_group(sys_key, groups[sys_key]))
                used.add(sys_key)

        remaining = sorted(k for k in groups.keys() if k not in used)
        for sys_key in remaining:
            result.append(self._make_group(sys_key, groups[sys_key]))

        return result

    def _make_group(self, sys_key, caid_pairs):
        display = sys_key.upper().replace("_", " ")[:10]
        color = SYSTEM_COLORS.get(sys_key, OTHER_COLOR)
        caid_pairs = sorted(caid_pairs, key=lambda x: x[0])
        return (sys_key, display, color, caid_pairs)

    # ------------------------------------------------------------------
    def _render_caids(self):
        caids = self.get_caids()

        for i in range(self._visible_cols):
            self["col_title_%d" % i].setText("")
            self["col_%d" % i].setText("")

        if not caids:
            self["col_0"].setText("(no CAIDs reported)")
            self["caids_count"].setText("")
            self._groups = []
            return

        groups = self._group_by_system(caids)
        self._groups = groups

        max_col = self._max_col_offset()
        if self._col_offset > max_col:
            self._col_offset = max_col
        if self._col_offset < 0:
            self._col_offset = 0

        visible_groups = groups[
            self._col_offset:self._col_offset + self._visible_cols]

        max_rows = max((len(c[3]) for c in visible_groups), default=0)
        max_row_offset = max(0, max_rows - self._visible_rows)

        if self._row_offset > max_row_offset:
            self._row_offset = max_row_offset
        if self._row_offset < 0:
            self._row_offset = 0

        for i, (sys_key, display, color, caid_pairs) in enumerate(visible_groups):
            start = self._row_offset
            end = start + self._visible_rows
            visible_pairs = caid_pairs[start:end]

            lines = []
            for caid, count in visible_pairs:
                if count and count > 1:
                    lines.append("%s [%d]" % (caid, count))
                elif count == 1:
                    lines.append("%s [1]" % caid)
                else:
                    lines.append(caid)

            prefix = u"\u25B2\n" if self._row_offset > 0 else ""
            suffix = u"\n\u25BC" if end < len(caid_pairs) else ""
            body = "\n".join(lines)

            try:
                title_widget = self["col_title_%d" % i]
                title_widget.setText("%s (%d)" % (display, len(caid_pairs)))
                title_widget.setForegroundColor(color)
            except Exception:
                pass

            try:
                col_widget = self["col_%d" % i]
                col_widget.setText(prefix + body + suffix)
                col_widget.setForegroundColor(color)
            except Exception:
                pass

        total_caids = sum(len(c[3]) for c in groups)
        total_cards = sum(
            sum(cnt for _, cnt in c[3]) for c in groups
        )
        sys_summary = " ".join(
            "%s x %d" % (display[:3], len(caid_pairs))
            for _, display, _, caid_pairs in groups
        )
        self["caids_count"].setText(
            "%d CAIDs / %d cards — %s"
            % (total_caids, total_cards, sys_summary))

    # ------------------------------------------------------------------
    def _render_state(self):
        caids = self.get_caids()
        n_caids = len(caids)

        total_cards = 0
        if self.api_status is not None:
            try:
                total_cards = int(
                    getattr(self.api_status, "card_count", 0) or 0)
            except Exception:
                total_cards = 0

        state = "ON" if self.reader.enabled else "OFF"

        h_scroll = ""
        total_pages = self._total_col_pages()
        if total_pages > 1:
            current_page = (self._col_offset // self._visible_cols) + 1
            h_scroll = "  [cols %d/%d]" % (current_page, total_pages)

        v_scroll = ""
        if self._has_vertical_scroll():
            max_off = self._max_row_offset()
            page = (self._row_offset // self._visible_rows) + 1
            total = (max_off // self._visible_rows) + 2
            v_scroll = "  [rows %d/%d]" % (page, total)

        if total_cards and total_cards != n_caids:
            text = ("State: %s | File: %s | CAIDs: %d unique / %d cards%s%s"
                    % (state, self.reader.source_tag or "-",
                       n_caids, total_cards, h_scroll, v_scroll))
        else:
            text = ("State: %s | File: %s | CAIDs: %d%s%s"
                    % (state, self.reader.source_tag or "-",
                       n_caids, h_scroll, v_scroll))

        self["state"].setText(text)

    # ------------------------------------------------------------------
    def _total_col_pages(self):
        if not self._groups:
            return 1
        return ((len(self._groups) + self._visible_cols - 1)
                // self._visible_cols)

    def _max_col_offset(self):
        if not self._groups:
            return 0
        pages = self._total_col_pages()
        return (pages - 1) * self._visible_cols

    def _has_horizontal_scroll(self):
        return self._total_col_pages() > 1

    def _max_row_offset(self):
        if not self._groups:
            return 0
        visible_groups = self._groups[
            self._col_offset:self._col_offset + self._visible_cols]
        max_rows = max((len(c[3]) for c in visible_groups), default=0)
        return max(0, max_rows - self._visible_rows)

    def _has_vertical_scroll(self):
        return self._max_row_offset() > 0

    # ------------------------------------------------------------------
    def scroll_up(self):
        if not self._has_vertical_scroll():
            return
        if self._row_offset > 0:
            self._row_offset -= self._visible_rows
            if self._row_offset < 0:
                self._row_offset = 0
            self._render_caids()
            self._render_state()

    def scroll_down(self):
        if not self._has_vertical_scroll():
            return
        max_off = self._max_row_offset()
        if self._row_offset < max_off:
            self._row_offset += self._visible_rows
            if self._row_offset > max_off:
                self._row_offset = max_off
            self._render_caids()
            self._render_state()

    # ------------------------------------------------------------------
    def shift_left(self):
        if not self._has_horizontal_scroll():
            return
        if self._col_offset > 0:
            self._col_offset -= self._visible_cols
            if self._col_offset < 0:
                self._col_offset = 0
            self._row_offset = 0
            self._render_caids()
            self._render_state()

    def shift_right(self):
        if not self._has_horizontal_scroll():
            return
        max_off = self._max_col_offset()
        if self._col_offset < max_off:
            self._col_offset += self._visible_cols
            if self._col_offset > max_off:
                self._col_offset = max_off
            self._row_offset = 0
            self._render_caids()
            self._render_state()

    # ------------------------------------------------------------------
    def toggle_state(self):
        old_enabled = self.reader.enabled
        self.reader.enabled = not old_enabled

        try:
            ReaderParser().write_single(
                self.reader, self.reader.source_file)
        except Exception as e:
            self.reader.enabled = old_enabled
            logger.log("ReaderView", "toggle write error: %s" % e)
            self.session.open(MessageBox,
                "Failed to change state:\n%s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        self.render()

        if self.on_toggle_callback:
            try:
                self.on_toggle_callback(self.reader)
            except Exception as e:
                logger.log("ReaderView", "callback error: %s" % e)

    # ------------------------------------------------------------------
    def edit_reader(self):
        try:
            from .reader_dialog import ReaderEditor
        except Exception as e:
            self.session.open(MessageBox,
                "Failed to load editor: %s" % str(e),
                MessageBox.TYPE_ERROR, timeout=5)
            return

        api_module = None
        try:
            if "ncam" in (self.reader.source_file or "").lower():
                from . import ncamapi as api_module
            else:
                from . import oscamapi as api_module
        except Exception:
            api_module = None

        self.session.openWithCallback(
            self._after_edit,
            ReaderEditor,
            self.reader,
            self.reader.source_file,
            api_module)

    def _after_edit(self, new_reader):
        if not new_reader:
            return

        self.reader = new_reader
        self["info_title"].setText(
            "Reader: %s" % (new_reader.label or "-"))
        self.render()

        if self.on_toggle_callback:
            try:
                self.on_toggle_callback(new_reader)
            except Exception as e:
                logger.log("ReaderView", "callback error: %s" % e)

    # ------------------------------------------------------------------
    def delete_reader(self):
        self.session.openWithCallback(
            self._after_delete,
            MessageBox,
            "Delete reader: %s ?" % (self.reader.label or "?"),
            MessageBox.TYPE_YESNO)

    def _after_delete(self, answer):
        if not answer:
            return

        try:
            ReaderParser().remove_from_file(self.reader)
        except Exception as e:
            logger.log("ReaderView", "remove error: %s" % e)
            self.session.open(MessageBox,
                "Delete failed:\n%s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        if self.on_toggle_callback:
            try:
                self.on_toggle_callback(None)
            except Exception as e:
                logger.log("ReaderView", "callback error: %s" % e)

        self.close()