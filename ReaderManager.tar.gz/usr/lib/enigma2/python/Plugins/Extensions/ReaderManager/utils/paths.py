# -*- coding: utf-8 -*-
"""
utils/paths.py — مسارات الملفات والإعدادات.

يُوفّر:
    - bootstrap()       : يُنشئ المجلدات والملفات إذا لزم
    - get_oscam_path()  : مسار oscam.server
    - get_ncam_path()   : مسار ncam.server

الاستخدام:
    from utils.paths import bootstrap
    info = bootstrap()
    oscam_file = info["oscam_file"]
"""
from __future__ import absolute_import, print_function, unicode_literals

import os

# ─── توافق Py2/Py3 للـ open مع encoding ───
try:
    from io import open
except ImportError:
    pass


# ═══════════════════════════════════════════════════════════════════
#  ثوابت المسارات
# ═══════════════════════════════════════════════════════════════════
CONFIG_DIR  = "/etc/tuxbox/config"
OSCAM_FILE  = os.path.join(CONFIG_DIR, "oscam.server")
NCAM_FILE   = os.path.join(CONFIG_DIR, "ncam.server")


# ═══════════════════════════════════════════════════════════════════
#  قوالب الملفات
# ═══════════════════════════════════════════════════════════════════
OSCAM_TEMPLATE = """# 
# ======================================================
# ==== oscam.server - created by ReaderManager ====
# ======================================================

[reader]
label                         = emulator
protocol                      = emu
device                        = emu
caid                          = 0500,0604,090F,0E00,1010,1801,2600,2602,2610,4AE1
detect                        = cd
ident                         = 0500:000000,007400,007800,021110,023800;0604:000000;090F:000000;0E00:000000;1010:000000;1801:000000,001101,002111,007301;2600:000000;2602:000000;2610:000000;4AE1:000011,000014,0000FE
group                         = 1
emmcache                      = 2,1,2,1
emu_auproviders               = 0604:010200;0E00:000000;1010:000000;2610:000000;4AE1:000011,000014,0000FE
"""

NCAM_TEMPLATE = """#
# ======================================================
# ==== ncam.server - created by ReaderManager ====
# ======================================================

[reader]
label                         = emulator
protocol                      = emu
device                        = emu
caid                          = 0500,0604,090F,0E00,1010,1801,2600,2602,2610,4AE1
detect                        = cd
ident                         = 0500:000000,007400,007800,021110,023800;0604:000000;090F:000000;0E00:000000;1010:000000;1801:000000,001101,002111,007301;2600:000000;2602:000000;2610:000000;4AE1:000011,000014,0000FE
group                         = 1
emmcache                      = 2,1,2,1
emu_auproviders               = 0604:010200;0E00:000000;1010:000000;2610:000000;4AE1:000011,000014,0000FE
"""


# ═══════════════════════════════════════════════════════════════════
#  Helpers داخلية
# ═══════════════════════════════════════════════════════════════════
def _ensure_dir(path):
    """يُنشئ المجلد إذا لم يوجد."""
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
            return True
        except Exception as e:
            try:
                print("[paths] mkdir failed for %s: %s" % (path, e))
            except Exception:
                pass
            return False
    return True


def _create_file_if_missing(path, template):
    """يُنشئ الملف من القالب إذا لم يوجد."""
    if os.path.exists(path):
        return False
    try:
        with open(path, "w") as f:
            f.write(template)
        try:
            os.chmod(path, 0o644)
        except Exception:
            pass
        return True
    except Exception as e:
        try:
            print("[paths] write failed for %s: %s" % (path, e))
        except Exception:
            pass
        return False


# ═══════════════════════════════════════════════════════════════════
#  Public API
# ═══════════════════════════════════════════════════════════════════
def bootstrap():
    """
    يُنشئ المجلدات والملفات المطلوبة إذا لم تكن موجودة.

    Returns:
        dict: {
            "config_dir": str,
            "oscam_file": str,
            "ncam_file":  str,
            "created": {
                "dir":   bool,
                "oscam": bool,
                "ncam":  bool,
            },
        }
    """
    dir_created   = _ensure_dir(CONFIG_DIR)
    oscam_created = _create_file_if_missing(OSCAM_FILE, OSCAM_TEMPLATE)
    ncam_created  = _create_file_if_missing(NCAM_FILE,  NCAM_TEMPLATE)

    return {
        "config_dir": CONFIG_DIR,
        "oscam_file": OSCAM_FILE,
        "ncam_file":  NCAM_FILE,
        "created": {
            "dir":   dir_created,
            "oscam": oscam_created,
            "ncam":  ncam_created,
        },
    }


def get_oscam_path():
    """يُعيد مسار oscam.server."""
    return OSCAM_FILE


def get_ncam_path():
    """يُعيد مسار ncam.server."""
    return NCAM_FILE
    
# utils/paths.py أو utils/__init__.py
def skin_path(filename):
    here = os.path.dirname(os.path.abspath(__file__))
    plugin_dir = os.path.dirname(here)
    return os.path.join(plugin_dir, "Skin", filename)