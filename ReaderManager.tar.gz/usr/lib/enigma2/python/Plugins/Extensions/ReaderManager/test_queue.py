# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import time

# ─── توافق Py2/Py3 للـ queue ───
try:
    import queue
except ImportError:
    import Queue as queue

from threading import Thread, Lock, Event

from . import logger


# =====================================================================
#  حالات
# =====================================================================
STATUS_GOOD        = "good"
STATUS_AUTH_OK     = "auth_ok"
STATUS_IN_USE      = "in_use"
STATUS_WRONG_CREDS = "wrong_creds"
STATUS_DEAD        = "dead"
STATUS_PENDING     = "pending"
STATUS_ERROR       = "error"
STATUS_DISABLED    = "disabled"


# =====================================================================
#  AuthOKEntry — سطر في قائمة Auth OK
# =====================================================================
class AuthOKEntry(object):
    __slots__ = ("label", "protocol", "device", "user", "password",
                 "host", "port", "cards", "cccversion", "latency_ms",
                 "verified_at", "status")

    def __init__(self, label, protocol, device, user, password,
                 host="", port=0, cards=0, cccversion="",
                 latency_ms=0, status=STATUS_AUTH_OK):
        self.label = label
        self.protocol = protocol
        self.device = device
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.cards = cards
        self.cccversion = cccversion
        self.latency_ms = latency_ms
        self.verified_at = time.time()
        self.status = status

    def to_dict(self):
        return {
            "label": self.label,
            "protocol": self.protocol,
            "device": self.device,
            "user": self.user,
            "host": self.host,
            "port": self.port,
            "cards": self.cards,
            "cccversion": self.cccversion,
            "latency_ms": self.latency_ms,
            "verified_at": self.verified_at,
            "verified_ago_s": int(time.time() - self.verified_at),
            "status": self.status,
        }

    def __repr__(self):
        return "<AuthOK %s@%s:%s cards=%d>" % (
            self.user, self.host, self.port, self.cards)


# =====================================================================
#  TestTask
# =====================================================================
class TestTask(object):
    __slots__ = ("reader", "priority", "seq", "reason",
                 "callback", "queued_at")

    def __init__(self, reader, priority=5, seq=0, reason="manual",
                 callback=None):
        self.reader = reader
        self.priority = priority
        self.seq = seq
        self.reason = reason
        self.callback = callback
        self.queued_at = time.time()

    def __lt__(self, other):
        return (self.priority, self.seq) < (other.priority, other.seq)


# =====================================================================
#  ReaderTestQueue
# =====================================================================
class ReaderTestQueue(object):
    """
    طابور اختبارات في الخلفية.

    الاستخدام:
        q = ReaderTestQueue(test_timeout=5)
        q.add_listener(my_callback)
        q.start()

        q.enqueue(reader, reason="add")
        q.enqueue(reader, reason="edit")

        auth_ok_list = q.get_auth_ok()

        q.stop()
    """

    def __init__(self, test_timeout=10, max_workers=1):
        self._queue = queue.PriorityQueue()
        self._lock = Lock()
        self._auth_ok = {}
        self._last_results = {}
        self._listeners = []
        self._stop_event = Event()
        self._seq = 0
        self._max_workers = max_workers
        self._test_timeout = test_timeout
        self._workers = []
        self._started = False
        self._stats = {
            "queued": 0, "completed": 0, "auth_ok": 0,
            "failed": 0, "skipped": 0,
        }

    # ------------------------------------------------------------------
    #  دورة الحياة
    # ------------------------------------------------------------------
    def start(self):
        if self._started:
            return
        self._started = True
        self._stop_event.clear()
        for i in range(self._max_workers):
            t = Thread(target=self._worker_loop,
                       name="RTQ-worker-%d" % i)
            # setDaemon بدلاً من daemon=True (Py2 compatible)
            t.setDaemon(True)
            t.start()
            self._workers.append(t)
        logger.log("Queue", "Started %d worker(s)" % self._max_workers)

    def stop(self, wait=True, timeout=5.0):
        if not self._started:
            return
        self._stop_event.set()
        with self._lock:
            for _ in self._workers:
                try:
                    self._queue.put(TestTask(None, priority=999,
                                             seq=self._next_seq(),
                                             reason="stop"))
                except Exception:
                    pass
        if wait:
            deadline = time.time() + timeout
            for t in self._workers:
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                t.join(remaining)
        self._workers = []
        self._started = False
        logger.log("Queue", "Stopped")

    # ------------------------------------------------------------------
    #  API عام
    # ------------------------------------------------------------------
    def enqueue(self, reader, priority=5, reason="manual", callback=None):
        """
        أضف قارئًا للطابور.

        يتخطى القراء OFF (enabled=False).
        """
        if reader is None:
            return False

        # تخطّي القراء غير المُفعَّلة (state = OFF)
        if not getattr(reader, "enabled", True):
            label = getattr(reader, "label", "") or "?"
            logger.log("Queue", "Skipping %s (state=OFF)" % label)
            with self._lock:
                self._stats["skipped"] += 1
            self.remove(label)
            return False

        with self._lock:
            self._seq += 1
            seq = self._seq
            self._stats["queued"] += 1
        task = TestTask(reader, priority=priority, seq=seq,
                        reason=reason, callback=callback)
        self._queue.put(task)
        logger.log("Queue", "Enqueued %s (reason=%s, prio=%d)"
                   % (getattr(reader, "label", "?"), reason, priority))
        return True

    def enqueue_many(self, readers, priority=5, reason="batch"):
        """أضف عدة قراء دفعة واحدة (يتخطى OFF تلقائيًا)."""
        count = 0
        for r in readers:
            if self.enqueue(r, priority=priority, reason=reason):
                count += 1
        logger.log("Queue", "Enqueued %d/%d readers (reason=%s)"
                   % (count, len(readers), reason))
        return count

    def remove(self, label):
        """احذف قارئًا من قائمة Auth OK والنتائج."""
        with self._lock:
            self._auth_ok.pop(label, None)
            self._last_results.pop(label, None)

    def get_auth_ok(self):
        """أعِد قائمة Auth OK مرتبة حسب المدة منذ التحقق."""
        with self._lock:
            entries = list(self._auth_ok.values())
        entries.sort(key=lambda e: e.verified_at, reverse=True)
        return entries

    def get_auth_ok_labels(self):
        with self._lock:
            return set(self._auth_ok.keys())

    def get_last_result(self, label):
        with self._lock:
            return self._last_results.get(label)

    def get_stats(self):
        with self._lock:
            return dict(self._stats)

    def add_listener(self, callback):
        if callback not in self._listeners:
            self._listeners.append(callback)

    def remove_listener(self, callback):
        try:
            self._listeners.remove(callback)
        except ValueError:
            pass

    def clear(self):
        with self._lock:
            self._auth_ok.clear()
            self._last_results.clear()
            self._stats = {
                "queued": 0, "completed": 0, "auth_ok": 0,
                "failed": 0, "skipped": 0,
            }

    # ------------------------------------------------------------------
    #  Worker loop
    # ------------------------------------------------------------------
    def _next_seq(self):
        with self._lock:
            self._seq += 1
            return self._seq

    def _worker_loop(self):
        while not self._stop_event.is_set():
            try:
                # Py2/Py3: PriorityQueue.get يدعم timeout
                task = self._queue.get(timeout=0.5)
            except Exception:
                continue

            if task is None:
                continue
            if task.reason == "stop":
                break
            if task.reader is None:
                continue

            # تحقق مجددًا من حالة القارئ
            if not getattr(task.reader, "enabled", True):
                label = getattr(task.reader, "label", "") or "?"
                logger.log("Queue",
                           "Skipping %s at execution (state=OFF)" % label)
                with self._lock:
                    self._stats["skipped"] += 1
                self.remove(label)
                continue

            try:
                self._run_test(task)
            except Exception:
                logger.log_exc("Queue", "worker error")
                try:
                    self._handle_result(
                        task.reader,
                        {"ok": False, "status": "Disconnected",
                         "message": "Worker error"})
                except Exception:
                    pass

    def _run_test(self, task):
        reader = task.reader
        try:
            from .reader_parser import test_reader
        except ImportError:
            from . import reader_parser as rp
            test_reader = getattr(rp, "test_reader", None)

        logger.log("Queue", "Testing %s (reason=%s) ..."
                   % (reader.label, task.reason))

        result = None
        if test_reader:
            try:
                result = test_reader(reader, timeout=self._test_timeout)
            except Exception as e:
                result = {
                    "ok": False, "status": "Disconnected",
                    "message": "Exception: %s" % str(e),
                    "host": "", "port": 0, "ip": "",
                    "latency_ms": None,
                    "protocol": reader.protocol or "",
                    "authenticated": False, "auth_used": False,
                    "details": {}
                }
        if result is None:
            result = {
                "ok": False, "status": "Unknown",
                "message": "No test_reader available",
                "protocol": reader.protocol or "",
                "details": {}
            }

        self._handle_result(reader, result, task=task)

    def _handle_result(self, reader, result, task=None):
        label = getattr(reader, "label", "") or "?"

        # لا نُسجّل نتائج القراء OFF
        if not getattr(reader, "enabled", True):
            with self._lock:
                self._auth_ok.pop(label, None)
                self._last_results.pop(label, None)
            return

        with self._lock:
            self._last_results[label] = result
            self._stats["completed"] += 1

            if self._is_success(result):
                entry = self._make_entry(reader, result)
                self._auth_ok[label] = entry
                self._stats["auth_ok"] += 1
                logger.log("Queue", "[OK] %s -> %s (%d cards)"
                           % (label, result.get("message", ""),
                              entry.cards))
            else:
                self._auth_ok.pop(label, None)
                self._stats["failed"] += 1
                logger.log("Queue", "[FAIL] %s -> %s"
                           % (label, result.get("message", "")))

        for cb in list(self._listeners):
            try:
                cb(reader, result)
            except Exception:
                pass

        if task is not None and task.callback:
            try:
                task.callback(reader, result)
            except Exception:
                pass

    # ------------------------------------------------------------------
    #  مساعدات
    # ------------------------------------------------------------------
    def _is_success(self, result):
        if not result:
            return False
        if not result.get("ok"):
            return False
        proto = (result.get("protocol") or "").lower()
        if proto in ("emu", "internal", "constcw", "serial"):
            return True
        msg = (result.get("message") or "").lower()
        if "wrong credentials" in msg or "auth rejected" in msg:
            return False
        if "dead" in msg or "timeout" in msg:
            return False
        return True

    def _make_entry(self, reader, result):
        host, port = self._split_device(reader.device or "")
        details = result.get("details") or {}
        return AuthOKEntry(
            label=getattr(reader, "label", "") or "?",
            protocol=getattr(reader, "protocol", "") or "",
            device=getattr(reader, "device", "") or "",
            user=getattr(reader, "user", "") or "",
            password=getattr(reader, "password", "") or "",
            host=host,
            port=port,
            cards=int(details.get("cards", 0) or 0),
            cccversion=details.get("cccversion", ""),
            latency_ms=result.get("latency_ms") or 0,
            status=STATUS_AUTH_OK,
        )

    @staticmethod
    def _split_device(device):
        if "," in device:
            h, p = device.rsplit(",", 1)
            try:
                return h.strip(), int(p.strip())
            except Exception:
                return h.strip(), p.strip()
        return device.strip(), 0


# =====================================================================
#  Singleton
# =====================================================================
_global_queue = None


def get_queue(test_timeout=10):
    """أعِد الطابور العالمي (ينشئه إن لم يوجد)."""
    global _global_queue
    if _global_queue is None:
        _global_queue = ReaderTestQueue(test_timeout=test_timeout)
        _global_queue.start()
    return _global_queue


def shutdown_queue():
    global _global_queue
    if _global_queue is not None:
        _global_queue.stop()
        _global_queue = None