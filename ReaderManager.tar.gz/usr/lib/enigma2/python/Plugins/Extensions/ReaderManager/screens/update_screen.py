# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import re
import threading
import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Processing import Processing
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.ProgressBar import ProgressBar
from Components.config import config

from ..utils import logger
from ..utils import upgrader
from ..utils.skin_loader import get_screen_skin


class UpdateScreen(Screen):
    screen_name = "UpdateScreen"

    def __init__(self, session, auto_check=True):
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session
        self._auto_check = auto_check

        # ─── widgets ───
        self["title_ver"]     = Label("")
        self["status"]        = Label("Ready")
        self["local_ver"]     = Label("-")
        self["remote_ver"]    = Label("-")
        self["message"]       = Label("")
        self["progress"]      = ProgressBar()
        self["progress_text"] = Label("")
        self["progress_info"] = Label("")
        self["footer_info"]   = Label("")

        self["key_red"]       = Button("Close")
        self["key_green"]     = Button("Check")
        self["key_yellow"]    = Button("Auto-Check")
        self["key_blue"]      = Button("Details")

        # ─── حالة ───
        self._updating = False
        self._checking = False
        self._has_update = False
        self._check_result = None
        self._timers = []
        self._progress_bar_works = True
        self._processing_visible = False

        # ─── actions ───
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "cancel": self.close,
                "red":    self.close,
                "green":  self.check_or_update,
                "ok":     self.check_or_update,
                "yellow": self.toggle_auto_check,
                "blue":   self.show_details,
            }, -1)

        self.onLayoutFinish.append(self._on_start)

    # ------------------------------------------------------------------
    def _on_start(self):
        local = upgrader.get_local_version()
        self["local_ver"].setText(local or "unknown")

        self._test_progress_bar()
        self._set_progress_bar(0, "idle")
        self._update_footer_auto_state()

        if self._auto_check and self._get_auto_check_setting():
            self._start_check()
        else:
            self["status"].setText("Ready to check for updates.")

    # ------------------------------------------------------------------
    def _test_progress_bar(self):
        try:
            self["progress"].setValue(50)
            self["progress"].setValue(0)
            self._progress_bar_works = True
            logger.log("UpdateScreen", "ProgressBar works")
        except Exception as e:
            logger.log("UpdateScreen",
                       "ProgressBar failed: %s" % e)
            self._progress_bar_works = False

    # ------------------------------------------------------------------
    #  Processing helpers — تُستدعى فقط في مرحلة apply
    # ------------------------------------------------------------------
    def _processing_show(self, description="Updating..."):
        """يعرض Processing — يُستدعى مرة واحدة عند بداية التحديث."""
        if self._processing_visible:
            return
        try:
            Processing.instance.setDescription(description)
            Processing.instance.showProgress(endless=True)
            self._processing_visible = True
            logger.log("UpdateScreen", "Processing shown: %s" % description)
        except Exception as e:
            logger.log("UpdateScreen", "_processing_show error: %s" % e)

    def _processing_update(self, description):
        """يُحدّث نص Processing فقط — بدون إعادة عرضه."""
        if not self._processing_visible:
            return
        try:
            Processing.instance.setDescription(description)
        except Exception as e:
            logger.log("UpdateScreen", "_processing_update error: %s" % e)

    def _processing_hide(self):
        """يُخفي Processing — يُستدعى عند الانتهاء (نجاح أو فشل)."""
        if not self._processing_visible:
            return
        try:
            Processing.instance.hideProgress()
            self._processing_visible = False
            logger.log("UpdateScreen", "Processing hidden")
        except Exception as e:
            logger.log("UpdateScreen", "_processing_hide error: %s" % e)

    # ------------------------------------------------------------------
    #  شريط التقدم
    # ------------------------------------------------------------------
    def _set_progress_bar(self, percent, stage="download"):
        try:
            percent = max(0, min(100, int(percent)))
        except Exception:
            percent = 0

        # ① ProgressBar
        if self._progress_bar_works:
            try:
                self["progress"].setValue(percent)
            except Exception as e:
                logger.log("UpdateScreen", "setValue error: %s" % e)
                self._progress_bar_works = False

        # ② النص
        if self._progress_bar_works:
            try:
                self["progress_text"].setText("%d%%" % percent)
            except Exception:
                pass
        else:
            BAR_WIDTH = 40
            filled = int(BAR_WIDTH * percent / 100)
            bar = "━" * filled + "─" * (BAR_WIDTH - filled)
            try:
                self["progress_text"].setText(
                    "%s  %d%%" % (bar, percent))
            except Exception:
                pass

        # ③ النص التفصيلي
        stage_text = {
            "idle":     "Idle",
            "download": "Downloading...",
            "extract":  "Extracting...",
            "apply":    "Applying...",
            "done":     "Complete",
            "error":    "Failed",
        }
        try:
            self["progress_info"].setText(
                stage_text.get(stage, stage))
        except Exception:
            pass

    def _extract_percent(self, info):
        if not info:
            return 0
        try:
            m = re.search(r"(\d+)\s*%", info)
            if m:
                return int(m.group(1))
        except Exception:
            pass
        return 0

    # ------------------------------------------------------------------
    #  Auto-check helpers
    # ------------------------------------------------------------------
    def _get_auto_check_setting(self):
        try:
            return bool(config.plugins.OscamReaderManager
                        .update_auto_check.value)
        except Exception:
            return False

    def _update_footer_auto_state(self):
        try:
            enabled = self._get_auto_check_setting()
            interval = config.plugins.OscamReaderManager \
                .update_check_interval.value
            last = config.plugins.OscamReaderManager \
                .update_last_check.value

            last_str = "never"
            if last and last > 0:
                try:
                    elapsed = int(time.time()) - int(last)
                    if elapsed < 60:
                        last_str = "%ds ago" % elapsed
                    elif elapsed < 3600:
                        last_str = "%dm ago" % (elapsed // 60)
                    elif elapsed < 86400:
                        last_str = "%dh ago" % (elapsed // 3600)
                    else:
                        last_str = "%dd ago" % (elapsed // 86400)
                except Exception:
                    last_str = "unknown"

            state = "ON" if enabled else "OFF"
            self["footer_info"].setText(
                "Auto-check: %s  |  Interval: %s  |  Last check: %s"
                % (state, interval, last_str))
        except Exception as e:
            logger.log("UpdateScreen",
                       "_update_footer_auto_state error: %s" % e)
            self["footer_info"].setText("Auto-check: (?)")

    def toggle_auto_check(self):
        try:
            old = bool(config.plugins.OscamReaderManager
                       .update_auto_check.value)
            new = not old
            config.plugins.OscamReaderManager.update_auto_check.value = new
            config.plugins.OscamReaderManager.save()

            state = "ENABLED" if new else "DISABLED"
            self["status"].setText("Auto-check %s" % state)
            self._update_footer_auto_state()

            logger.log("UpdateScreen",
                       "auto-check set to %s" % state)
        except Exception as e:
            logger.log("UpdateScreen",
                       "toggle_auto_check error: %s" % e)

    # ------------------------------------------------------------------
    #  Check / Update
    # ------------------------------------------------------------------
    def check_or_update(self):
        if self._updating or self._checking:
            return

        if self._has_update:
            self._confirm_apply()
        else:
            self._start_check()

    # ------------------------------------------------------------------
    #  Check — بدون Processing
    # ------------------------------------------------------------------
    def _start_check(self):
        self._checking = True
        self["key_green"].setText("Checking...")
        self["status"].setText("Checking for updates...")
        self["message"].setText("Contacting GitHub...")
        self._set_progress_bar(0, "idle")

        # ← لا نستدعي _processing_show هنا

        try:
            config.plugins.OscamReaderManager.update_last_check.value = \
                int(time.time())
            config.plugins.OscamReaderManager.save()
        except Exception:
            pass

        t = threading.Thread(target=self._check_worker)
        t.setDaemon(True)
        t.start()

    def _check_worker(self):
        try:
            result = upgrader.check_for_updates()
            self._schedule_ui(self._after_check, result)
        except Exception as e:
            self._schedule_ui(
                self._after_check,
                {"ok": False, "error": str(e),
                 "message": "Check failed: %s" % e})

    def _after_check(self, result):
        self._checking = False
        self._check_result = result

        # ← لا نستدعي _processing_hide هنا (لم يُعرض أصلاً)

        local = result.get("local_version") or "unknown"
        remote = result.get("remote_version") or "-"

        self["local_ver"].setText(local)
        self["remote_ver"].setText(remote)
        self["message"].setText(result.get("message", ""))
        self["title_ver"].setText("v%s" % local)

        self._update_footer_auto_state()

        if not result.get("ok"):
            self["status"].setText("Check failed")
            self["key_green"].setText("Retry")
            self._set_progress_bar(100, "error")
            return

        if result.get("has_update"):
            self["status"].setText(
                "Update available: %s → %s" % (local, remote))
            self["key_green"].setText("Update")
            self._has_update = True
            self._set_progress_bar(100, "extract")
        else:
            self["status"].setText("Up to date (v%s)" % local)
            self["key_green"].setText("Re-check")
            self._has_update = False
            self._set_progress_bar(100, "done")

    # ------------------------------------------------------------------
    def _confirm_apply(self):
        self.session.openWithCallback(
            self._on_confirm,
            MessageBox,
            "Download and install the update?\n\n"
            "• Local:  %s\n"
            "• Remote: %s\n\n"
            "Enigma2 will restart after installation."
            % (self._check_result.get("local_version", "?"),
               self._check_result.get("remote_version", "?")),
            MessageBox.TYPE_YESNO)

    def _on_confirm(self, answer):
        if not answer:
            return
        self._start_apply()

    # ------------------------------------------------------------------
    #  Apply — مع Processing
    # ------------------------------------------------------------------
    def _start_apply(self):
        if self._updating:
            return

        self._updating = True
        self["key_green"].setText("Updating...")
        self["status"].setText("Updating...")
        self["message"].setText("Starting update...")
        self._set_progress_bar(0, "download")

        # ← Processing يُعرض هنا فقط
        self._processing_show("Starting update...")

        t = threading.Thread(target=self._apply_worker)
        t.setDaemon(True)
        t.start()

    def _apply_worker(self):
        def progress(stage, info):
            self._schedule_ui(self._after_progress, stage, info)

        try:
            result = upgrader.perform_update(progress=progress)
            self._schedule_ui(self._after_apply, result)
        except Exception as e:
            self._schedule_ui(
                self._after_apply,
                {"ok": False, "error": str(e),
                 "message": "Update error: %s" % e})

    def _after_progress(self, stage, info):
        percent = self._extract_percent(info)

        # ─── تحديث نص Processing ───
        processing_text = {
            "download": "Downloading... %d%%" % percent,
            "extract":  "Extracting...",
            "apply":    "Applying update...",
            "done":     "Complete",
            "error":    "Failed",
        }.get(stage, info or stage)

        self._processing_update(processing_text)

        # ─── تحديث الشاشة ───
        if stage == "download":
            self["status"].setText("Downloading...")
            self["message"].setText(info)
            self._set_progress_bar(percent, "download")

        elif stage == "extract":
            self["status"].setText("Extracting...")
            self["message"].setText(info)
            self._set_progress_bar(percent or 50, "extract")

        elif stage == "apply":
            self["status"].setText("Applying...")
            self["message"].setText(info)
            self._set_progress_bar(percent or 80, "apply")

        elif stage == "done":
            self["status"].setText("Done")
            self["message"].setText(info)
            self._set_progress_bar(100, "done")

        elif stage == "error":
            self["status"].setText("Error")
            self["message"].setText(info)
            self._set_progress_bar(percent or 0, "error")

    def _after_apply(self, result):
        self._updating = False

        # ← إخفاء Processing عند الانتهاء (نجاح أو فشل)
        self._processing_hide()

        if not result.get("ok"):
            self["status"].setText("Update failed")
            self["message"].setText(
                "Update failed:\n%s\n\n"
                "Backup preserved at:\n%s"
                % (result.get("error", "unknown"),
                   result.get("backup_path", "-")))
            self["key_green"].setText("Retry")
            self._set_progress_bar(100, "error")
            return

        new_ver = result.get("new_version") or "?"
        copied = result.get("files_copied", 0)

        self["status"].setText("Update complete!")
        self["local_ver"].setText(new_ver)
        self["message"].setText(
            "Update applied successfully.\n\n"
            "• New version: %s\n"
            "• Files copied: %d\n"
            "• Backup: %s\n\n"
            "Enigma2 will restart in 3 seconds..."
            % (new_ver, copied, result.get("backup_path", "-")))

        self["key_green"].setText("Restart now")
        self._set_progress_bar(100, "done")
        self._schedule_ui(self._restart_enigma, 3)

    def _restart_enigma(self, delay_seconds=0):
        if delay_seconds > 0:
            import time as _t
            _t.sleep(delay_seconds)
        upgrader.restart_enigma()

    # ------------------------------------------------------------------
    #  Details
    # ------------------------------------------------------------------
    def show_details(self):
        if not self._check_result:
            self.session.open(
                MessageBox,
                "No check performed yet.\n"
                "Press GREEN to check for updates.",
                MessageBox.TYPE_INFO, timeout=5)
            return

        r = self._check_result
        lines = [
            "=== Update Check Details ===",
            "",
            "Local version :  %s" % r.get("local_version", "?"),
            "Remote version:  %s" % r.get("remote_version", "?"),
            "Status        :  %s" % (
                "Update available" if r.get("has_update")
                else "Up to date"),
            "",
            "Auto-check    :  %s" % (
                "ON" if self._get_auto_check_setting() else "OFF"),
            "Interval      :  %s" % (
                config.plugins.OscamReaderManager
                .update_check_interval.value
                if hasattr(config.plugins.OscamReaderManager,
                           "update_check_interval") else "-"),
            "",
            "Message:",
            r.get("message", "-"),
        ]

        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=20)

    # ------------------------------------------------------------------
    def _schedule_ui(self, func, *args):
        try:
            from enigma import eTimer
            t = eTimer()
            t.callback.append(lambda: func(*args))
            t.start(10, True)
            self._timers.append(t)
        except Exception as e:
            logger.log("UpdateScreen", "_schedule_ui error: %s" % e)
            try:
                func(*args)
            except Exception:
                pass

    def close(self):
        # إخفاء Processing عند إغلاق الشاشة (احتياط)
        self._processing_hide()

        for t in self._timers:
            try:
                t.stop()
            except Exception:
                pass
        self._timers = []
        Screen.close(self)