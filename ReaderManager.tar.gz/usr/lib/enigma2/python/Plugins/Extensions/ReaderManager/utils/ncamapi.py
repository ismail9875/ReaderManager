# -*- coding: utf-8 -*-
"""
utils/ncamapi.py — عميل NCam WebIF API مستقل.

v4:
    - قراءة قسم totals من ncamapi.json
    - استخراج إحصائيات تفصيلية لكل قارئ من readers.html
    - توزيع totals على القراء النشطين عند غياب التفاصيل
    - دعم كامل لـ restart/stop/start/is_running
"""
from __future__ import absolute_import, print_function, unicode_literals

import json
import re
import time
from os.path import exists

try:
    from urllib2 import (build_opener, Request, HTTPHandler,
                         HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                         HTTPDigestAuthHandler, URLError, HTTPError)
    from urllib import unquote, quote
except ImportError:
    from urllib.request import (build_opener, Request, HTTPHandler,
                                 HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                                 HTTPDigestAuthHandler)
    from urllib.error import URLError, HTTPError
    from urllib.parse import unquote, quote

try:
    import xml.dom.minidom as minidom
except ImportError:
    minidom = None

try:
    from ssl import create_default_context, _create_unverified_context
except ImportError:
    create_default_context = None
    _create_unverified_context = None

from . import logger

try:
    from . import restart_ncam
    _HAS_RESTART = True
except Exception:
    restart_ncam = None
    _HAS_RESTART = False


# ═══════════════════════════════════════════════════════════════════
#  ثوابت NCam
# ═══════════════════════════════════════════════════════════════════
NCAM_API_PREFIX   = "ncamapi"
NCAM_JSON_TAG     = "ncam"
NCAM_BINARY       = "ncam"
NCAM_DISPLAY      = "NCam"
NCAM_VERSION_FILE = "ncam.version"
NCAM_CONF_FILE    = "ncam.conf"

NCAM_VERSION_PATHS = [
    "/tmp/.ncam/ncam.version",
    "/tmp/ncam.version",
    "/var/tmp/ncam.version",
]

NCAM_CONF_PATHS = [
    "/etc/tuxbox/config/ncam/ncam.conf",
    "/etc/tuxbox/config/ncam.conf",
    "/etc/tuxbox/config/ncam-server/ncam.conf",
    "/etc/ncam/ncam.conf",
    "/var/etc/ncam.conf",
    "/usr/local/etc/ncam.conf",
]

STATUS_CONNECTED  = "CONNECTED"
STATUS_CARDOK     = "CARDOK"
STATUS_OFF        = "OFF"
STATUS_ERROR      = "ERROR"
STATUS_NEEDINIT   = "NEEDINIT"
STATUS_DISABLED   = "DISABLED"
STATUS_UNKNOWN    = "UNKNOWN"

INVALID_CAIDS = {"0000", "000000", "00000000", ""}


# ═══════════════════════════════════════════════════════════════════
#  ReaderStatus
# ═══════════════════════════════════════════════════════════════════
class ReaderStatus(object):
    """حالة قارئ واحد من NCam WebIF."""

    __slots__ = (
        "label", "enabled", "status", "protocol", "device",
        "port", "cards", "card_count", "localcards",
        "ecmok", "ecmnok", "online", "idle",
        "cccversion", "last_ecm_time", "last_channel",
        "caid", "provid", "au",
        "entitlements_count", "cards_details", "raw",
        # ─── إحصائيات الأداء ───
        "ecm_count", "cw_count", "ecm_timeout", "emm_count",
        "avg_time_ms", "min_time_ms", "max_time_ms",
    )

    def __init__(self, data=None):
        self.label = ""
        self.enabled = False
        self.status = STATUS_UNKNOWN
        self.protocol = ""
        self.device = ""
        self.port = 0
        self.cards = 0
        self.card_count = 0
        self.localcards = 0
        self.ecmok = 0
        self.ecmnok = 0
        self.online = 0
        self.idle = 0
        self.cccversion = ""
        self.last_ecm_time = ""
        self.last_channel = ""
        self.caid = ""
        self.provid = ""
        self.au = ""
        self.entitlements_count = 0
        self.cards_details = []
        self.raw = {}
        self.ecm_count = 0
        self.cw_count = 0
        self.ecm_timeout = 0
        self.emm_count = 0
        self.avg_time_ms = 0.0
        self.min_time_ms = 0.0
        self.max_time_ms = 0.0

        if data:
            self._parse(data)

    def _parse(self, data):
        self.raw = data
        self.label      = data.get("label", "") or ""
        self.enabled    = bool(data.get("enabled", True))
        self.status     = ((data.get("status") or STATUS_UNKNOWN)
                           .upper().strip())
        self.protocol   = data.get("protocol", "") or ""
        self.device     = data.get("device", "") or ""
        self.port       = self._to_int(data.get("port", 0))
        self.cards      = self._to_int(data.get("cards", 0))
        self.card_count = self._to_int(
            data.get("card_count", self.cards))
        self.localcards = self._to_int(data.get("localcards", 0))
        self.ecmok      = self._to_int(data.get("ecmok", 0))
        self.ecmnok     = self._to_int(data.get("ecmnok", 0))
        self.online     = self._to_int(data.get("online", 0))
        self.idle       = self._to_int(data.get("idle", 0))
        self.cccversion = data.get("cccversion", "") or ""
        self.last_ecm_time = data.get("last_ecm_time", "") or ""
        self.last_channel  = data.get("last_channel", "") or ""
        self.caid       = data.get("caid", "") or ""
        self.provid     = data.get("provid", "") or ""
        self.au         = data.get("au", "") or ""
        self.entitlements_count = self._to_int(
            data.get("entitlements_count", 0))
        self.cards_details = data.get("cards_details", []) or []

        # ─── إحصائيات الأداء ───
        self.ecm_count = self._to_int(
            data.get("ecm_count") or data.get("ecm")
            or data.get("total_ecm") or 0)
        self.cw_count = self._to_int(
            data.get("cw_count") or data.get("cw")
            or data.get("cws") or 0)
        self.ecm_timeout = self._to_int(
            data.get("ecm_timeout") or data.get("timeouts") or 0)
        self.emm_count = self._to_int(
            data.get("emm_count") or data.get("emm") or 0)
        self.avg_time_ms = self._to_float(
            data.get("avg_time_ms") or data.get("avg_time")
            or data.get("ecm_time") or 0.0)
        self.min_time_ms = self._to_float(
            data.get("min_time_ms") or data.get("min_time") or 0.0)
        self.max_time_ms = self._to_float(
            data.get("max_time_ms") or data.get("max_time") or 0.0)

        # ─── احتياطيات ───
        if self.ecm_count == 0 and (self.ecmok > 0 or self.ecmnok > 0):
            self.ecm_count = self.ecmok + self.ecmnok
        if self.cw_count == 0 and self.ecmok > 0:
            self.cw_count = self.ecmok

    @staticmethod
    def _to_int(v):
        if v is None:
            return 0
        if isinstance(v, bool):
            return 1 if v else 0
        try:
            if isinstance(v, str):
                m = re.search(r"-?\d+", v.replace(",", "").replace(".", ""))
                if m:
                    return int(m.group())
            return int(v)
        except (ValueError, TypeError):
            return 0

    @staticmethod
    def _to_float(v):
        if v is None:
            return 0.0
        try:
            if isinstance(v, str):
                v = v.replace(",", ".").strip()
                m = re.search(r"[-+]?\d*\.?\d+", v)
                if m:
                    return float(m.group())
            return float(v)
        except (ValueError, TypeError):
            return 0.0

    @property
    def is_connected(self):
        return self.status in (STATUS_CONNECTED, STATUS_CARDOK)

    @property
    def is_off(self):
        return self.status in (STATUS_OFF, STATUS_DISABLED)

    @property
    def is_error(self):
        return self.status in (STATUS_ERROR,)

    @property
    def is_working(self):
        return self.is_connected and self.ecmok > 0

    @property
    def display_status(self):
        return self.status

    @property
    def display_cards(self):
        if not self.is_connected:
            return "-"
        if self.card_count > 0:
            return str(self.card_count)
        return "0"

    @property
    def success_rate(self):
        if self.ecm_count > 0:
            return (self.ecmok * 100.0) / self.ecm_count
        if self.ecmok > 0:
            return 100.0
        return 0.0

    def get_caids(self):
        caids = set()
        raw = self.raw or {}

        ents = raw.get("entitlements", [])
        if isinstance(ents, list):
            for ent in ents:
                if isinstance(ent, dict):
                    c = (ent.get("caid") or "").strip().upper()
                    if c and c not in INVALID_CAIDS:
                        caids.add(c)

        for card in (self.cards_details or []):
            if isinstance(card, dict):
                c = (card.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    caids.add(c)

        for card in (raw.get("cards_details") or []):
            if isinstance(card, dict):
                c = (card.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    caids.add(c)

        if self.caid:
            for part in str(self.caid).replace(",", " ") \
                    .replace(";", " ").split():
                part = part.strip().upper()
                if part and part not in INVALID_CAIDS:
                    caids.add(part)

        return sorted(caids)

    def get_caids_dict(self):
        result = {}
        raw = self.raw or {}

        for ent in (raw.get("entitlements") or []):
            if isinstance(ent, dict):
                c = (ent.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    if c not in result:
                        result[c] = {
                            "caid": c,
                            "system": (ent.get("system") or "").strip().lower(),
                        }
                    elif not result[c]["system"]:
                        s = (ent.get("system") or "").strip().lower()
                        if s:
                            result[c]["system"] = s

        for card in (self.cards_details or []):
            if isinstance(card, dict):
                c = (card.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    if c not in result:
                        result[c] = {
                            "caid": c,
                            "system": (card.get("system") or "").strip().lower(),
                        }
                    elif not result[c]["system"]:
                        s = (card.get("system") or "").strip().lower()
                        if s:
                            result[c]["system"] = s

        for card in (raw.get("cards_details") or []):
            if isinstance(card, dict):
                c = (card.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    if c not in result:
                        result[c] = {
                            "caid": c,
                            "system": (card.get("system") or "").strip().lower(),
                        }
                    elif not result[c]["system"]:
                        s = (card.get("system") or "").strip().lower()
                        if s:
                            result[c]["system"] = s

        if self.caid:
            for part in str(self.caid).replace(",", " ") \
                    .replace(";", " ").split():
                part = part.strip().upper()
                if part and part not in INVALID_CAIDS and part not in result:
                    result[part] = {"caid": part, "system": ""}

        return sorted(result.values(), key=lambda x: x["caid"])

    def to_dict(self):
        return {
            "label": self.label,
            "enabled": self.enabled,
            "status": self.status,
            "protocol": self.protocol,
            "device": self.device,
            "port": self.port,
            "cards": self.cards,
            "card_count": self.card_count,
            "localcards": self.localcards,
            "ecmok": self.ecmok,
            "ecmnok": self.ecmnok,
            "ecm_count": self.ecm_count,
            "cw_count": self.cw_count,
            "ecm_timeout": self.ecm_timeout,
            "emm_count": self.emm_count,
            "avg_time_ms": self.avg_time_ms,
            "min_time_ms": self.min_time_ms,
            "max_time_ms": self.max_time_ms,
            "success_rate": self.success_rate,
            "online": self.online,
            "idle": self.idle,
            "cccversion": self.cccversion,
            "last_channel": self.last_channel,
            "caid": self.caid,
            "provid": self.provid,
            "au": self.au,
            "entitlements_count": self.entitlements_count,
            "is_connected": self.is_connected,
            "is_working": self.is_working,
        }

    def __repr__(self):
        return "<ReaderStatus %s: %s cards=%d ecm=%d avg=%.0fms>" % (
            self.label, self.status, self.card_count,
            self.ecm_count, self.avg_time_ms)


# ═══════════════════════════════════════════════════════════════════
#  NCamAPIError
# ═══════════════════════════════════════════════════════════════════
class NCamAPIError(Exception):
    pass


# ═══════════════════════════════════════════════════════════════════
#  NCamAPI
# ═══════════════════════════════════════════════════════════════════
class NCamAPI(object):
    def __init__(self, base_url=None, username="", password="",
                 timeout=5.0, use_ssl=False, verify_cert=False):
        self.base_url = (base_url or "").rstrip("/")
        self.username = username or ""
        self.password = password or ""
        self.timeout = timeout
        self.use_ssl = use_ssl
        self.verify_cert = verify_cert
        self._last_request = 0
        self._last_result = []
        self._last_error = ""
        self._last_method = ""
        self._last_url = ""
        self._last_totals = {}     # ⭐ جديد
        self._config_dir = None
        self._signstatus = None
        self._entitlement_cache = {}

    def _make_opener(self):
        if self.use_ssl:
            if self.verify_cert and create_default_context:
                ctx = create_default_context()
            elif _create_unverified_context:
                ctx = _create_unverified_context()
            else:
                ctx = None
            webhandler = HTTPSHandler(context=ctx) if ctx else HTTPSHandler()
        else:
            webhandler = HTTPHandler

        if self.username and self.password:
            pwman = HTTPPasswordMgrWithDefaultRealm()
            pwman.add_password(None, self.base_url,
                               self.username, self.password)
            authhandler = HTTPDigestAuthHandler(pwman)
            return build_opener(webhandler, authhandler)

        return build_opener(webhandler)

    def _http_get(self, path, timeout=None, cache_buster=True):
        if not self.base_url:
            raise NCamAPIError("Base URL not configured")

        url = "%s%s" % (self.base_url, path)

        if cache_buster:
            sep = "&" if "?" in url else "?"
            url += "%s_t=%d" % (sep, int(time.time() * 1000))

        self._last_url = url

        headers = {
            "User-Agent": "Enigma2-NCamAPI/1.0",
            "Accept": "application/json, text/xml, */*",
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
        }

        try:
            req = Request(url, headers=headers)
            opener = self._make_opener()
            resp = opener.open(req, timeout=timeout or self.timeout)
            data = resp.read()
            if isinstance(data, bytes):
                data = data.decode("utf-8", "replace")
            return data
        except HTTPError as e:
            msg = "HTTP %d: %s" % (e.code, e.reason)
            self._last_error = msg
            raise NCamAPIError(msg)
        except URLError as e:
            msg = "URL error: %s" % e.reason
            self._last_error = msg
            raise NCamAPIError(msg)
        except Exception as e:
            msg = "Request failed: %s" % e
            self._last_error = msg
            raise NCamAPIError(msg)

    # ------------------------------------------------------------------
    #  Control API
    # ------------------------------------------------------------------
    def restart(self, force=True, script_hint=None, binary_hint=None):
        if not _HAS_RESTART:
            return False, "restart_ncam module not available"
        try:
            if script_hint:
                restart_ncam.set_script_hint(script_hint)
            if binary_hint:
                restart_ncam.set_binary_hint(binary_hint)
            logger.log("NCamAPI",
                       "restart() called (force=%s, script=%s)"
                       % (force, script_hint or "-"))
            return restart_ncam.restart(force=force)
        except Exception as e:
            logger.log("NCamAPI", "restart exception: %s" % e)
            return False, "restart exception: %s" % e

    def stop(self, script_hint=None):
        if not _HAS_RESTART:
            return False, "restart_ncam module not available"
        try:
            if script_hint:
                restart_ncam.set_script_hint(script_hint)
            logger.log("NCamAPI",
                       "stop() called (script=%s)" % (script_hint or "-"))
            if hasattr(restart_ncam, "stop_only"):
                return restart_ncam.stop_only()
            return False, "stop_only not implemented"
        except Exception as e:
            logger.log("NCamAPI", "stop exception: %s" % e)
            return False, "stop exception: %s" % e

    def start(self, script_hint=None, binary_hint=None):
        if not _HAS_RESTART:
            return False, "restart_ncam module not available"
        try:
            if script_hint:
                restart_ncam.set_script_hint(script_hint)
            if binary_hint:
                restart_ncam.set_binary_hint(binary_hint)
            logger.log("NCamAPI",
                       "start() called (script=%s, binary=%s)"
                       % (script_hint or "-", binary_hint or "-"))
            if hasattr(restart_ncam, "start_only"):
                return restart_ncam.start_only()
            return False, "start_only not implemented"
        except Exception as e:
            logger.log("NCamAPI", "start exception: %s" % e)
            return False, "start exception: %s" % e

    def is_running(self):
        if not _HAS_RESTART:
            return False
        try:
            if hasattr(restart_ncam, "is_running"):
                running, _ = restart_ncam.is_running()
                return bool(running)
            return False
        except Exception:
            return False

    # ------------------------------------------------------------------
    #  ⭐ NEW: قراءة totals
    # ------------------------------------------------------------------
    def _parse_totals(self, obj):
        """يقرأ قسم 'totals' من ncamapi.json."""
        result = {
            "total_readers": 0,
            "total_connected_readers": 0,
            "total_active_readers": 0,
            "total_cwok_readers": 0,
            "total_cwnok_readers": 0,
            "total_cwtout_readers": 0,
            "rel_cwok_readers": 0.0,
            "rel_cwnok_readers": 0.0,
            "total_sum_all_readers_ecm": 0,
            "total_sum_all_readers_emm": 0,
            "total_cw": 0,
            "total_cwok": 0,
        }

        if not isinstance(obj, dict):
            return result
        root = obj.get(NCAM_JSON_TAG) or obj.get("oscam") or obj
        if not isinstance(root, dict):
            return result
        totals = root.get("totals", {})
        if not isinstance(totals, dict):
            return result

        def _i(v):
            try:
                return int(v)
            except (ValueError, TypeError):
                return 0

        def _f(v):
            try:
                return float(v)
            except (ValueError, TypeError):
                return 0.0

        result["total_readers"] = _i(totals.get("total_readers", 0))
        result["total_connected_readers"] = _i(
            totals.get("total_connected_readers", 0))
        result["total_active_readers"] = _i(
            totals.get("total_active_readers", 0))
        result["total_cwok_readers"] = _i(
            totals.get("total_cwok_readers", 0))
        result["total_cwnok_readers"] = _i(
            totals.get("total_cwnok_readers", 0))
        result["total_cwtout_readers"] = _i(
            totals.get("total_cwtout_readers", 0))
        result["rel_cwok_readers"] = _f(
            totals.get("rel_cwok_readers", 0.0))
        result["rel_cwnok_readers"] = _f(
            totals.get("rel_cwnok_readers", 0.0))
        result["total_sum_all_readers_ecm"] = _i(
            totals.get("total_sum_all_readers_ecm", 0))
        result["total_sum_all_readers_emm"] = _i(
            totals.get("total_sum_all_readers_emm", 0))
        result["total_cw"] = _i(totals.get("total_cw", 0))
        result["total_cwok"] = _i(totals.get("total_cwok", 0))

        return result

    def get_totals(self):
        return self._last_totals or {}

    # ------------------------------------------------------------------
    #  ⭐ NEW: readers.html parser
    # ------------------------------------------------------------------
    def _fetch_reader_stats_from_html(self):
        try:
            data = self._http_get("/readers.html")
        except NCamAPIError as e:
            logger.log("NCamAPI", "readers.html failed: %s" % e)
            return {}

        if not data or "<table" not in data:
            return {}

        result = {}
        row_pattern = re.compile(
            r'<tr\s+id="id_(0x[0-9a-fA-F]+)"\s+class="([rp])"[^>]*>(.*?)</tr>',
            re.DOTALL | re.IGNORECASE)

        for row_match in row_pattern.finditer(data):
            row = row_match.group(3)

            label = None
            m = re.search(
                r'<td[^>]*class="[^"]*statuscol4[^"]*"[^>]*>'
                r'(?:<a[^>]*>)?\s*([^<\s]+)',
                row, re.IGNORECASE)
            if m:
                label = m.group(1).strip()
            if not label:
                continue

            col_map = {}
            for cm in re.finditer(
                    r'<td[^>]*class="[^"]*statuscol(\d+)[^"]*"[^>]*>'
                    r'\s*([^<]*)',
                    row, re.IGNORECASE):
                col_num = int(cm.group(1))
                val = cm.group(2).strip()
                if not val or val in ("&nbsp;", "-", ""):
                    continue
                try:
                    col_map[col_num] = int(val)
                except ValueError:
                    try:
                        col_map[col_num] = float(val)
                    except ValueError:
                        col_map[col_num] = val

            stats = {"_columns": col_map}

            if 11 in col_map:
                stats["ecm_count"] = self._to_int(col_map[11])
            if 12 in col_map:
                stats["emm_count"] = self._to_int(col_map[12])
            if 13 in col_map:
                stats["cw_count"] = self._to_int(col_map[13])
                stats["ecm_ok"] = self._to_int(col_map[13])
            if 14 in col_map:
                stats["avg_time_ms"] = self._to_float(col_map[14])

            if "ecm_count" not in stats:
                for col in (10, 11):
                    v = col_map.get(col)
                    if isinstance(v, (int, float)) and v > 0:
                        stats["ecm_count"] = int(v)
                        break
            if "cw_count" not in stats:
                for col in (13, 12):
                    v = col_map.get(col)
                    if isinstance(v, (int, float)) and v > 0:
                        stats["cw_count"] = int(v)
                        stats["ecm_ok"] = int(v)
                        break
            if "avg_time_ms" not in stats:
                for col in (14, 15):
                    v = col_map.get(col)
                    if isinstance(v, (int, float)) and v > 0:
                        stats["avg_time_ms"] = float(v)
                        break

            result[label] = stats

        logger.log("NCamAPI",
                   "HTML stats: extracted %d reader(s)" % len(result))
        return result

    # ------------------------------------------------------------------
    #  WebIF — Status
    # ------------------------------------------------------------------
    @staticmethod
    def find_version_file():
        for p in NCAM_VERSION_PATHS:
            if exists(p):
                return p
        return None

    def read_version_file(self, path):
        info = {"config_dir": None, "webif": None, "port": None}
        try:
            with open(path, "r") as f:
                content = f.read()
        except Exception as e:
            raise NCamAPIError("Cannot read %s: %s" % (path, e))

        m = re.search(r'ConfigDir:\s*(.+)', content)
        if m:
            info["config_dir"] = m.group(1).strip()

        for line in content.splitlines():
            low = line.lower()
            if "web interface support:" in low:
                val = line.split(":", 1)[1].strip().lower()
                info["webif"] = (val == "yes")
            elif "webifport:" in low:
                try:
                    port = line.split(":", 1)[1].strip()
                    if port and port != "0":
                        info["port"] = port
                except Exception:
                    pass

        return info

    def read_conf_file(self, path):
        info = {
            "user": "root", "pwd": "", "port": None,
            "proto": "http", "use_ssl": False,
            "allowed_localhost": False,
        }
        if not exists(path):
            return info

        try:
            with open(path, "r") as f:
                in_webif = False
                for line in f:
                    stripped = line.strip()
                    low = stripped.lower()

                    if stripped.startswith("[") and stripped.endswith("]"):
                        in_webif = (stripped.lower() == "[webif]")
                        continue
                    if not in_webif:
                        continue

                    m = re.match(r'httpport\s*=\s*([+]?\d+)', stripped)
                    if m:
                        v = m.group(1)
                        if v.startswith("+"):
                            info["use_ssl"] = True
                            info["proto"] = "https"
                            v = v[1:]
                        info["port"] = v

                    m = re.match(r'httpuser\s*=\s*(.*)', stripped)
                    if m:
                        info["user"] = m.group(1).strip()

                    m = re.match(r'httppwd\s*=\s*(.*)', stripped)
                    if m:
                        info["pwd"] = m.group(1).strip()

                    if "httpallowed" in low:
                        allowed = stripped.split("=", 1)[1].strip() \
                            if "=" in stripped else ""
                        if ("127.0.0.1" in allowed
                                or "0.0.0.0-255.255.255.255" in allowed):
                            info["allowed_localhost"] = True

        except Exception as e:
            logger.log("NCamAPI", "Conf read error: %s" % e)

        return info

    def auto_configure(self):
        ver_file = self.find_version_file()
        if not ver_file:
            raise NCamAPIError("ncam.version not found")

        logger.log("NCamAPI", "Found version file: %s" % ver_file)

        ver_info = self.read_version_file(ver_file)
        config_dir = ver_info["config_dir"]

        if not config_dir:
            raise NCamAPIError("ConfigDir not found in ncam.version")

        self._config_dir = config_dir

        conf_file = None
        candidate = config_dir.rstrip("/") + "/" + NCAM_CONF_FILE
        if exists(candidate):
            conf_file = candidate
        else:
            for p in NCAM_CONF_PATHS:
                if exists(p):
                    conf_file = p
                    break

        if conf_file:
            logger.log("NCamAPI", "Found conf: %s" % conf_file)
            conf_info = self.read_conf_file(conf_file)
        else:
            conf_info = {"user": "root", "pwd": "", "port": None,
                         "proto": "http", "use_ssl": False,
                         "allowed_localhost": True}

        port = conf_info["port"] or ver_info["port"]
        if not port:
            raise NCamAPIError(
                "No port found in ncam.conf or ncam.version")

        proto = conf_info["proto"]
        user = conf_info["user"]
        pwd = conf_info["pwd"]

        self.base_url = "%s://127.0.0.1:%s" % (proto, port)
        self.username = user
        self.password = pwd
        self.use_ssl = conf_info["use_ssl"]

        logger.log("NCamAPI",
                   "Auto-configured: %s user=%s" % (self.base_url, user))

        return {
            "base_url": self.base_url,
            "user": user,
            "pwd": pwd,
            "proto": proto,
            "port": port,
            "config_dir": config_dir,
        }

    def get_reader_status(self, fetch_cards=True):
        """
        v4: يجمع من 3 مصادر مع دعم totals.
        """
        self._last_request = time.time()

        readers = None

        # ═══ 1) JSON ═══
        try:
            data = self._http_get("/%s.json?part=status" % NCAM_API_PREFIX)
            logger.log("NCamAPI", "JSON response: %d bytes" % len(data))
            try:
                obj = json.loads(data)
                self._last_totals = self._parse_totals(obj)
                if self._last_totals:
                    logger.log("NCamAPI",
                               "Totals: cwok=%d ecm=%d readers=%d/%d"
                               % (self._last_totals.get(
                                      "total_cwok_readers", 0),
                                  self._last_totals.get(
                                      "total_sum_all_readers_ecm", 0),
                                  self._last_totals.get(
                                      "total_connected_readers", 0),
                                  self._last_totals.get(
                                      "total_readers", 0)))
            except Exception as e:
                logger.log("NCamAPI", "totals parse error: %s" % e)

            readers = self._parse_json_readers(data)
            if readers:
                self._last_method = "json"
                logger.log("NCamAPI", "JSON OK: %d readers" % len(readers))
        except NCamAPIError as e:
            logger.log("NCamAPI", "JSON failed: %s" % e)

        # ═══ 2) XML ═══
        if not readers:
            try:
                data = self._http_get("/%s.html?part=status"
                                      % NCAM_API_PREFIX)
                readers = self._parse_xml_status(data)
                if readers:
                    self._last_method = "xml"
            except NCamAPIError as e:
                logger.log("NCamAPI", "XML failed: %s" % e)

        # ═══ 3) HTML ═══
        if not readers:
            try:
                data = self._http_get("/status.html")
                readers = self._parse_status_html(data)
                if readers:
                    self._last_method = "html"
            except NCamAPIError as e:
                logger.log("NCamAPI", "HTML failed: %s" % e)

        if not readers:
            return self._last_result

        # ═══ 4) إثراء من readers.html ═══
        try:
            html_stats = self._fetch_reader_stats_from_html()
            if html_stats:
                enriched = 0
                for r in readers:
                    s = html_stats.get(r.label)
                    if not s:
                        continue
                    if r.ecm_count == 0 and s.get("ecm_count"):
                        r.ecm_count = s["ecm_count"]
                    if r.ecmok == 0 and s.get("ecm_ok"):
                        r.ecmok = s["ecm_ok"]
                    if r.cw_count == 0 and s.get("cw_count"):
                        r.cw_count = s["cw_count"]
                    if r.avg_time_ms == 0 and s.get("avg_time_ms"):
                        r.avg_time_ms = s["avg_time_ms"]
                    if r.emm_count == 0 and s.get("emm_count"):
                        r.emm_count = s["emm_count"]
                    r.raw["_html_columns"] = s.get("_columns", {})
                    enriched += 1
                logger.log("NCamAPI",
                           "Enriched %d reader(s) from readers.html"
                           % enriched)
        except Exception as e:
            logger.log("NCamAPI", "HTML enrichment error: %s" % e)

        # ═══ 5) توزيع totals ═══
        if self._last_totals:
            total_ecm = self._last_totals.get(
                "total_sum_all_readers_ecm", 0)
            total_cwok = self._last_totals.get("total_cwok_readers", 0)
            total_cwnok = self._last_totals.get("total_cwnok_readers", 0)
            total_cwtout = self._last_totals.get("total_cwtout_readers", 0)

            readers_ecm_sum = sum(r.ecm_count for r in readers)
            readers_cw_sum = sum(r.cw_count for r in readers)

            active = [r for r in readers if r.is_connected]

            if total_ecm > 0 and readers_ecm_sum == 0 and active:
                per = total_ecm // len(active)
                rem = total_ecm % len(active)
                for i, r in enumerate(active):
                    r.ecm_count = per + (1 if i < rem else 0)
                logger.log("NCamAPI",
                           "Distributed ECM total %d among %d readers"
                           % (total_ecm, len(active)))

            if total_cwok > 0 and readers_cw_sum == 0 and active:
                per = total_cwok // len(active)
                rem = total_cwok % len(active)
                for i, r in enumerate(active):
                    val = per + (1 if i < rem else 0)
                    r.cw_count = val
                    if r.ecmok == 0:
                        r.ecmok = val

            if total_cwnok > 0 and active:
                readers_nok_sum = sum(r.ecmnok for r in readers)
                if readers_nok_sum == 0:
                    per = total_cwnok // len(active)
                    rem = total_cwnok % len(active)
                    for i, r in enumerate(active):
                        r.ecmnok = per + (1 if i < rem else 0)

            if total_cwtout > 0 and active:
                readers_tout_sum = sum(r.ecm_timeout for r in readers)
                if readers_tout_sum == 0:
                    per = total_cwtout // len(active)
                    rem = total_cwtout % len(active)
                    for i, r in enumerate(active):
                        r.ecm_timeout = per + (1 if i < rem else 0)

            for r in readers:
                r.raw["_totals"] = self._last_totals

        # ═══ 6) إثراء الكروت ═══
        if fetch_cards and readers:
            for r in readers:
                if not r.is_connected:
                    continue
                try:
                    totalcards = self.fetch_card_count(r.label)
                    if totalcards > 0:
                        r.card_count = totalcards
                        r.cards = totalcards
                except Exception as e:
                    logger.log("NCamAPI",
                               "card_count for %s failed: %s"
                               % (r.label, e))

                try:
                    details = self.fetch_card_details(r.label)
                    if details and details.get("cards"):
                        r.cards_details = details["cards"]
                        r.raw["cards_details"] = details["cards"]
                        r.raw["entitlements"] = [
                            {
                                "caid": (c.get("caid") or "").strip().upper(),
                                "system": (c.get("system") or "").strip().lower(),
                            }
                            for c in details["cards"] if c.get("caid")
                        ]
                    if details and details.get("totalcards"):
                        r.card_count = details["totalcards"]
                        r.cards = details["totalcards"]
                except Exception as e:
                    logger.log("NCamAPI",
                               "card_details for %s failed: %s"
                               % (r.label, e))

        self._last_result = readers
        return readers

    # ------------------------------------------------------------------
    #  Card count / details
    # ------------------------------------------------------------------
    def fetch_card_count(self, label, cache_seconds=30):
        if not label:
            return 0
        cache_key = "count_" + label
        now = time.time()
        if cache_key in self._entitlement_cache:
            ts, count = self._entitlement_cache[cache_key]
            if now - ts < cache_seconds:
                return count

        try:
            path = "/%s.html?part=entitlement&label=%s" % (
                NCAM_API_PREFIX, quote(label))
            data = self._http_get(path)
            if not data or "<?xml" not in data:
                return 0
            count = self._parse_entitlement_totalcards(data)
            self._entitlement_cache[cache_key] = (now, count)
            return count
        except NCamAPIError as e:
            logger.log("NCamAPI",
                       "entitlement failed for %s: %s" % (label, e))
            return 0

    def _parse_entitlement_totalcards(self, data):
        m = re.search(r'<cardlist\s+totalcards\s*=\s*["\']?(\d+)',
                      data, re.IGNORECASE)
        if m:
            try:
                return int(m.group(1))
            except (ValueError, TypeError):
                pass
        if minidom:
            try:
                dom = minidom.parseString(data)
                for cardlist in dom.getElementsByTagName("cardlist"):
                    total = cardlist.getAttribute("totalcards")
                    if total:
                        try:
                            return int(total)
                        except (ValueError, TypeError):
                            pass
            except Exception as e:
                logger.log("NCamAPI", "minidom parse error: %s" % e)
        return 0

    def fetch_card_details(self, label, cache_seconds=30):
        if not label:
            return {"cards": [], "totalcards": 0}
        cache_key = "details_" + label
        now = time.time()
        if cache_key in self._entitlement_cache:
            ts, cached = self._entitlement_cache[cache_key]
            if now - ts < cache_seconds:
                return cached

        empty = {"cards": [], "totalcards": 0,
                 "hostaddress": "", "hostport": ""}
        try:
            path = "/%s.html?part=entitlement&label=%s" % (
                NCAM_API_PREFIX, quote(label))
            data = self._http_get(path)
            if not data or "<?xml" not in data:
                self._entitlement_cache[cache_key] = (now, empty)
                return empty

            result = self._parse_entitlement_details(data)
            self._entitlement_cache[cache_key] = (now, result)
            return result
        except NCamAPIError as e:
            logger.log("NCamAPI",
                       "card_details failed for %s: %s" % (label, e))
            self._entitlement_cache[cache_key] = (now, empty)
            return empty

    def _parse_entitlement_details(self, data):
        result = {
            "totalcards": 0,
            "cards": [],
            "hostaddress": "",
            "hostport": "",
        }

        if not minidom:
            m = re.search(r'<cardlist[^>]*\btotalcards\s*=\s*["\']?(\d+)',
                          data, re.IGNORECASE)
            if m:
                try:
                    result["totalcards"] = int(m.group(1))
                except (ValueError, TypeError):
                    pass
            for m in re.finditer(
                    r'<card[^>]*\bcaid\s*=\s*["\']?([0-9A-Fa-f]+)',
                    data, re.IGNORECASE):
                caid = m.group(1).strip().upper()
                if caid and caid not in INVALID_CAIDS:
                    result["cards"].append({"caid": caid, "system": ""})
            return result

        try:
            dom = minidom.parseString(data)
        except Exception as e:
            logger.log("NCamAPI", "XML parse error: %s" % e)
            return result

        for reader in dom.getElementsByTagName("reader"):
            result["hostaddress"] = str(reader.getAttribute("hostaddress"))
            result["hostport"]    = str(reader.getAttribute("hostport"))

            for cardlist in reader.getElementsByTagName("cardlist"):
                try:
                    result["totalcards"] = int(
                        cardlist.getAttribute("totalcards"))
                except (ValueError, TypeError):
                    pass

                for card_node in cardlist.getElementsByTagName("card"):
                    caid = str(card_node.getAttribute("caid")).strip().upper()
                    card = {
                        "number":  self._to_int(card_node.getAttribute("number")),
                        "caid":    caid,
                        "system":  str(card_node.getAttribute("system")).strip().lower(),
                        "reshare": str(card_node.getAttribute("reshare")),
                        "hop":     str(card_node.getAttribute("hop")),
                        "providers": [],
                        "nodes": [],
                    }
                    for provs in card_node.getElementsByTagName("providers"):
                        for prov in provs.getElementsByTagName("provider"):
                            svc = ""
                            if prov.firstChild:
                                try:
                                    svc = str(prov.firstChild.nodeValue.strip())
                                except Exception:
                                    pass
                            card["providers"].append({
                                "number": self._to_int(prov.getAttribute("number")),
                                "caid":   str(prov.getAttribute("caid")),
                                "provid": str(prov.getAttribute("provid")),
                                "sa":     str(prov.getAttribute("sa")),
                                "service": svc,
                            })
                    for nodes in card_node.getElementsByTagName("nodes"):
                        for node in nodes.getElementsByTagName("node"):
                            nv = ""
                            if node.firstChild:
                                try:
                                    nv = str(node.firstChild.nodeValue.strip())
                                except Exception:
                                    pass
                            card["nodes"].append({
                                "number": self._to_int(node.getAttribute("number")),
                                "hexval": nv,
                            })
                    result["cards"].append(card)

        return result

    # ------------------------------------------------------------------
    #  JSON / XML / HTML Parsers
    # ------------------------------------------------------------------
    def _parse_json_readers(self, data):
        data = (data or "").strip()
        if not data or not data.startswith("{"):
            return []
        try:
            obj = json.loads(data)
        except Exception as e:
            logger.log("NCamAPI", "Invalid JSON: %s" % e)
            return []
        return self._extract_from_status_clients(obj)

    def _extract_from_status_clients(self, obj):
        if not isinstance(obj, dict):
            return []
        root = obj.get(NCAM_JSON_TAG) or obj.get("oscam") or obj
        if not isinstance(root, dict):
            return []
        status = root.get("status")
        if not isinstance(status, dict):
            return []
        clients = status.get("client", [])
        if not isinstance(clients, list):
            return []
        readers = []
        for client in clients:
            if not isinstance(client, dict):
                continue
            ctype = client.get("type", "")
            if ctype not in ("p", "r"):
                continue
            try:
                readers.append(self._client_to_reader_status(client))
            except Exception as e:
                logger.log("NCamAPI", "Client parse error: %s" % e)
        return readers

    def _client_to_reader_status(self, client):
        connection = client.get("connection", {})
        request    = client.get("request", {})
        times      = client.get("times", {})

        label = (client.get("rname_enc")
                 or client.get("name_enc")
                 or client.get("label")
                 or "")
        try:
            label = unquote(label)
        except Exception:
            pass

        ecmok  = self._to_int(connection.get("ecmok", 0))
        ecmnok = self._to_int(connection.get("ecmnok", 0))

        ecm_count = self._to_int(
            request.get("ecm")
            or connection.get("ecm")
            or client.get("ecm")
            or 0)

        cw_count = self._to_int(
            connection.get("cw")
            or connection.get("cws")
            or connection.get("cw_count")
            or 0)

        ecm_timeout = self._to_int(
            connection.get("ecm_timeout")
            or connection.get("timeouts")
            or 0)

        avg_time = self._to_float(
            request.get("ecmtime")
            or request.get("ecm_time")
            or times.get("ecmtime")
            or times.get("avg")
            or 0.0)

        idle_iso = times.get("idle")
        if avg_time == 0.0 and idle_iso:
            try:
                avg_time = float(idle_iso)
            except (ValueError, TypeError):
                pass

        if ecm_count == 0 and (ecmok > 0 or ecmnok > 0):
            ecm_count = ecmok + ecmnok
        if cw_count == 0 and ecmok > 0:
            cw_count = ecmok

        data = {
            "label":      label,
            "status":     (connection.get("status") or "UNKNOWN").upper(),
            "protocol":   client.get("protocol", ""),
            "device":     connection.get("ip", ""),
            "port":       self._to_int(connection.get("port", 0)),
            "enabled":    True,
            "au":         client.get("au", ""),
            "last_channel": (request.get("chname", "") or ""),
            "caid":       request.get("caid", ""),
            "provid":     request.get("provid", ""),
            "ecmok":      ecmok,
            "ecmnok":     ecmnok,
            "ecm_count":  ecm_count,
            "cw_count":   cw_count,
            "ecm_timeout": ecm_timeout,
            "avg_time_ms": avg_time,
        }

        proto = data["protocol"]
        m = re.search(r'(\d+\.\d+\.\d+)', proto)
        if m:
            data["cccversion"] = m.group(1)

        return ReaderStatus(data)

    def _parse_xml_status(self, data):
        data = (data or "").strip()
        if not data or "<?xml" not in data:
            return []
        if not minidom:
            return []
        try:
            dom = minidom.parseString(data)
        except Exception as e:
            logger.log("NCamAPI", "XML status parse error: %s" % e)
            return []

        readers = []
        for elem in dom.getElementsByTagName("status"):
            for node in elem.getElementsByTagName("client"):
                ctype = str(node.getAttribute("type"))
                if ctype not in ("p", "r"):
                    continue

                r = ReaderStatus()
                r.label    = str(node.getAttribute("name"))
                r.protocol = str(node.getAttribute("protocol"))
                r.au       = str(node.getAttribute("au"))

                for snode in node.childNodes:
                    if snode.nodeName == "connection":
                        r.status = str(
                            snode.firstChild.nodeValue.strip()
                            if snode.firstChild else "UNKNOWN").upper()
                        r.device = str(snode.getAttribute("ip"))
                        try:
                            r.port = int(snode.getAttribute("port"))
                        except (ValueError, TypeError):
                            r.port = 0
                    if snode.nodeName == "times":
                        try:
                            r.idle = int(float(snode.getAttribute("idle")))
                        except (ValueError, TypeError):
                            pass
                        try:
                            r.online = int(float(snode.getAttribute("online")))
                        except (ValueError, TypeError):
                            pass

                for key in ("ecm", "ecmtime", "cw", "cw_count",
                            "ecmok", "ecmnok", "emm"):
                    try:
                        v = node.getAttribute(key)
                        if v:
                            r.raw[key] = v
                            if key == "ecm":
                                r.ecm_count = int(float(v))
                            elif key == "cw":
                                r.cw_count = int(float(v))
                            elif key == "ecmtime":
                                r.avg_time_ms = float(v)
                            elif key == "emm":
                                r.emm_count = int(float(v))
                    except Exception:
                        pass

                if r.ecm_count == 0 and (r.ecmok > 0 or r.ecmnok > 0):
                    r.ecm_count = r.ecmok + r.ecmnok
                if r.cw_count == 0 and r.ecmok > 0:
                    r.cw_count = r.ecmok

                readers.append(r)
        return readers

    def _parse_status_html(self, html):
        if not html or "<tr" not in html:
            return []
        readers = []
        tr_pattern = re.compile(
            r'<tr\s+id="id_(0x[0-9a-fA-F]+)"\s+class="([pr])"[^>]*>',
            re.IGNORECASE
        )
        positions = []
        for m in tr_pattern.finditer(html):
            positions.append((m.start(), m.end(), m.group(2).lower()))
        if not positions:
            return []
        for i, (start, end, row_class) in enumerate(positions):
            next_start = (positions[i + 1][0]
                          if i + 1 < len(positions) else len(html))
            segment = html[end:next_start]
            close_m = re.search(r'</tr>', segment, re.IGNORECASE)
            row_html = segment[:close_m.start()] if close_m else segment
            reader = self._parse_html_row(row_html)
            if reader:
                readers.append(reader)
        return readers

    def _parse_html_row(self, row_html):
        try:
            data = {}
            m = re.search(
                r'<td class="statuscol4"[^>]*>(.*?)</td>',
                row_html, re.DOTALL | re.IGNORECASE
            )
            if m:
                cell = m.group(1)
                a = re.search(r'<a[^>]*>([^<]+)</a>', cell)
                if a:
                    data["label"] = a.group(1).strip()
                else:
                    data["label"] = re.sub(r"<[^>]+>", "", cell).strip()

            if not data.get("label"):
                return None

            m = re.search(
                r'<td class="statuscol5 statuscol5(ON|OFF)"',
                row_html, re.IGNORECASE
            )
            if m:
                data["enabled"] = (m.group(1).upper() == "ON")

            m = re.search(
                r'<td class="statuscol7">([^<]*)</td>',
                row_html, re.IGNORECASE
            )
            if m:
                data["device"] = m.group(1).strip()

            m = re.search(
                r'<td class="statuscol8">(\d+)</td>',
                row_html, re.IGNORECASE
            )
            if m:
                try:
                    data["port"] = int(m.group(1))
                except Exception:
                    data["port"] = 0

            m = re.search(
                r'<td class="statuscol9"[^>]*>\s*([^<\n]+)',
                row_html, re.IGNORECASE
            )
            if m:
                proto_raw = m.group(1).strip()
                data["protocol"] = proto_raw
                vm = re.search(r'\((\d+\.\d+\.\d+)', proto_raw)
                if vm:
                    data["cccversion"] = vm.group(1)

            for col, key, conv in (
                    (11, "ecm_count", int),
                    (12, "emm_count", int),
                    (13, "cw_count", int),
                    (14, "avg_time_ms", float)):
                mm = re.search(
                    r'<td class="statuscol%d"[^>]*>\s*([\d.]+)'
                    % col, row_html, re.IGNORECASE)
                if mm:
                    try:
                        data[key] = conv(mm.group(1))
                        if col == 13:
                            data["ecmok"] = int(mm.group(1))
                    except (ValueError, TypeError):
                        pass

            m = re.search(
                r'<td class="statuscol16 statuscol16([A-Z]+)"[^>]*>'
                r'(.*?)</td>',
                row_html, re.DOTALL | re.IGNORECASE
            )
            if m:
                data["status"] = m.group(1).upper()
                status_content = m.group(2)
                cm = re.search(
                    r'\((\d+)\s+of\s+(\d+)\s+cards?\)',
                    status_content
                )
                if cm:
                    data["card_count"] = int(cm.group(1))
                    data["cards"] = int(cm.group(1))
            else:
                m = re.search(
                    r'<td class="statuscol16"[^>]*>(.*?)</td>',
                    row_html, re.DOTALL | re.IGNORECASE
                )
                if m:
                    txt = re.sub(r"<[^>]+>", " ", m.group(1)).strip()
                    fw = txt.split()[0] if txt else ""
                    data["status"] = fw.upper()[:20]

            if not data.get("status"):
                data["status"] = STATUS_UNKNOWN

            if not data.get("ecm_count") and data.get("ecmok"):
                try:
                    data["ecm_count"] = (int(data["ecmok"])
                                         + int(data.get("ecmnok", 0) or 0))
                except (ValueError, TypeError):
                    pass

            return ReaderStatus(data)
        except Exception as e:
            logger.log("NCamAPI", "HTML row parse error: %s" % e)
            return None

    def get_status(self):
        try:
            data = self._http_get("/%s.json?part=status" % NCAM_API_PREFIX)
            return json.loads(data)
        except Exception:
            return {}

    def is_available(self):
        try:
            return bool(self.get_reader_status(fetch_cards=False))
        except Exception:
            return False

    def get_last_error(self):
        return self._last_error

    def get_last_method(self):
        return self._last_method

    def get_last_url(self):
        return self._last_url

    @staticmethod
    def _to_int(v):
        try:
            return int(v)
        except (ValueError, TypeError):
            return 0

    @staticmethod
    def _to_float(v):
        try:
            return float(v)
        except (ValueError, TypeError):
            return 0.0


# ═══════════════════════════════════════════════════════════════════
#  Singleton
# ═══════════════════════════════════════════════════════════════════
_default_api = None


def configure(base_url, username="", password="", timeout=5.0,
              use_ssl=False, verify_cert=False):
    global _default_api
    _default_api = NCamAPI(base_url, username, password, timeout,
                           use_ssl, verify_cert)
    return _default_api


def configure_auto():
    global _default_api
    if _default_api is None:
        _default_api = NCamAPI()
    _default_api.auto_configure()
    return _default_api


def get_default():
    return _default_api


def reset_default():
    global _default_api
    _default_api = None