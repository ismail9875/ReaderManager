# -*- coding: utf-8 -*-
"""
utils/logger.py — تسجيل الأحداث مع تدوير تلقائي.

المزايا:
    - كتابة إلى /tmp/ReaderManager.log
    - تدوير تلقائي عند تجاوز 50 KB
    - متوافق Py2/Py3
    - تسجيل الاستثناءات مع traceback

الاستخدام:
    from utils import logger
    logger.log("Tag", "message")
    logger.log_exc("Tag", "error happened")
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import sys
import time
import traceback

# ─── توافق Py2/Py3 للـ open مع encoding ───
try:
    from io import open
except ImportError:
    pass


LOG_FILE = "/tmp/ReaderManager.log"
MAX_SIZE = 50 * 1024          # 50 KB
ENABLED  = True

_fh = None


# ═══════════════════════════════════════════════════════════════════
#  إدارة الملف
# ═══════════════════════════════════════════════════════════════════
def _get_handle():
    """يفتح الملف عند الحاجة (lazy) مع تدوير إذا تجاوز الحد."""
    global _fh
    if _fh is not None:
        return _fh

    try:
        if os.path.exists(LOG_FILE):
            try:
                size = os.path.getsize(LOG_FILE)
                if size > MAX_SIZE:
                    # احذف المحتوى وابدأ من جديد
                    try:
                        os.remove(LOG_FILE)
                    except Exception:
                        # إذا فشل الحذف → اقتصر على تفريغه
                        try:
                            with open(LOG_FILE, "w"):
                                pass
                        except Exception:
                            pass
            except Exception:
                pass

        _fh = open(LOG_FILE, "a")

    except Exception as e:
        try:
            sys.stderr.write("[Logger] cannot open %s: %s\n"
                             % (LOG_FILE, e))
        except Exception:
            pass
        _fh = None

    return _fh


def _rotate():
    """يُغلق الملف الحالي ويحذف محتواه ليبدأ من جديد."""
    global _fh
    try:
        if _fh is not None:
            _fh.close()
    except Exception:
        pass
    _fh = None

    try:
        if os.path.exists(LOG_FILE):
            os.remove(LOG_FILE)
    except Exception:
        try:
            with open(LOG_FILE, "w"):
                pass
        except Exception:
            pass

    # افتح ملفاً جديداً فارغاً
    try:
        _fh = open(LOG_FILE, "a")
    except Exception:
        _fh = None


# ═══════════════════════════════════════════════════════════════════
#  Timestamp
# ═══════════════════════════════════════════════════════════════════
def _stamp():
    """يُعيد timestamp بدقة ملّي ثانية."""
    try:
        t = time.localtime()
        ms = int((time.time() % 1) * 1000)
        return "%04d-%02d-%02d %02d:%02d:%02d.%03d" % (
            t.tm_year, t.tm_mon, t.tm_mday,
            t.tm_hour, t.tm_min, t.tm_sec, ms)
    except Exception:
        return time.ctime()


# ═══════════════════════════════════════════════════════════════════
#  Public API
# ═══════════════════════════════════════════════════════════════════
def log(tag, message):
    """يكتب سطراً في السجل + stdout."""
    if not ENABLED:
        return

    line = "[%s] [%s] %s" % (_stamp(), tag, message)

    # stdout
    try:
        print(line)
    except Exception:
        pass

    # ملف السجل
    try:
        fh = _get_handle()
        if fh is not None:
            # تحقق دوري من الحجم أثناء الكتابة
            try:
                if fh.tell() > MAX_SIZE:
                    _rotate()
                    fh = _get_handle()
            except Exception:
                pass
            fh.write(line + "\n")
            fh.flush()
    except Exception:
        pass


def log_exc(tag, message, exc_info=None):
    """يكتب استثناءً مع traceback كامل."""
    log(tag, "EXCEPTION: %s" % message)
    if exc_info is None:
        exc_info = sys.exc_info()
    try:
        tb_lines = traceback.format_exception(*exc_info)
        for ln in tb_lines:
            for sub in ln.rstrip().split("\n"):
                log(tag, "  " + sub)
    except Exception:
        pass


def section(title):
    """يُضيف فاصلاً بصرياً في السجل."""
    log("=====", "")
    log("=====", "===== %s =====" % title)
    log("=====", "")


def clear():
    """يحذف محتوى السجل الحالي."""
    global _fh
    try:
        if _fh is not None:
            _fh.close()
    except Exception:
        pass
    _fh = None

    try:
        if os.path.exists(LOG_FILE):
            os.remove(LOG_FILE)
    except Exception:
        pass

    log("Logger", "Log cleared")


def get_log_path():
    """يُعيد مسار ملف السجل."""
    return LOG_FILE


def dump():
    """يُعيد محتوى السجل كاملاً (string)."""
    try:
        with open(LOG_FILE, "r") as f:
            return f.read()
    except Exception:
        return ""