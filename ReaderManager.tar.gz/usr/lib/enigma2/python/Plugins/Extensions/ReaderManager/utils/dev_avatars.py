# -*- coding: utf-8 -*-
"""
utils/dev_avatars.py — البحث عن شعار كل مطوّر في مجلد Developers.
يدعم المسار النسبي (بجانب البلوجين) وعدة مسارات بديلة.
"""
from __future__ import absolute_import, print_function

import os

from . import logger


# ⭐ تحديد المسار الأساسي ديناميكياً
# dev_avatars.py موجود في: <plugin_root>/utils/dev_avatars.py
# لذا plugin_root = مجلد utils/ ../
_THIS_FILE = os.path.abspath(__file__)
_UTILS_DIR = os.path.dirname(_THIS_FILE)
PLUGIN_ROOT = os.path.dirname(_UTILS_DIR)   # ← جذر البلوجين

# المسارات المحتملة لمجلد الصور (كلها تُجرَّب بالترتيب)
AVATARS_DIRS = [
    os.path.join(PLUGIN_ROOT, "images", "developers"),
    os.path.join(PLUGIN_ROOT, "images", "Developers"),
    os.path.join(PLUGIN_ROOT, "images", "DEVELOPERS"),
    os.path.join(PLUGIN_ROOT, "images", "Dev"),
    os.path.join(PLUGIN_ROOT, "images", "dev"),
    # fallback للمسار المطلق القديم
    "/usr/lib/enigma2/python/Plugins/Extensions/ReaderManager/images/developers",
    "/usr/lib/enigma2/python/Plugins/Extensions/ReaderManager/images/Developers",
]

SUPPORTED_EXTS = [".png", ".jpg", ".jpeg", ".gif"]

NAME_PATTERNS = [
    "{id}{ext}",
    "{id}_logo{ext}",
    "{id}_avatar{ext}",
    "{id}_banner{ext}",
    "logo{ext}",
    "avatar{ext}",
    "icon{ext}",
]


def _get_existing_dirs():
    """يُعيد قائمة المسارات الموجودة فعلاً."""
    found = []
    for d in AVATARS_DIRS:
        if os.path.isdir(d):
            found.append(d)
            logger.log("DevAvatars", "dir exists: %s" % d)
    if not found:
        logger.log("DevAvatars", "NO avatar dir found. PLUGIN_ROOT=%s" % PLUGIN_ROOT)
        # عرض ما هو موجود فعلاً للتشخيص
        try:
            images_dir = os.path.join(PLUGIN_ROOT, "images")
            if os.path.isdir(images_dir):
                logger.log("DevAvatars", "images/ contains: %s" % os.listdir(images_dir))
        except Exception:
            pass
    return found


def _list_dir_safe(path):
    try:
        if os.path.isdir(path):
            return os.listdir(path)
    except Exception as e:
        logger.log("DevAvatars", "listdir error %s: %s" % (path, e))
    return []


def get_avatar_path(dev_id):
    """إرجاع المسار الكامل لصورة المطوّر أو None."""
    if not dev_id:
        return None

    dirs = _get_existing_dirs()
    if not dirs:
        return None

    for base in dirs:
        # 1) الأنماط المباشرة
        for pattern in NAME_PATTERNS:
            for ext in SUPPORTED_EXTS:
                filename = pattern.format(id=dev_id, ext=ext)
                candidate = os.path.join(base, filename)
                if os.path.isfile(candidate):
                    logger.log("DevAvatars", "found (direct): %s" % candidate)
                    return candidate

        # 2) داخل مجلد فرعي
        for name in _list_dir_safe(base):
            if name.lower() == dev_id.lower():
                sub = os.path.join(base, name)
                if os.path.isdir(sub):
                    for pattern in NAME_PATTERNS:
                        for ext in SUPPORTED_EXTS:
                            filename = pattern.format(id=dev_id, ext=ext)
                            candidate = os.path.join(sub, filename)
                            if os.path.isfile(candidate):
                                logger.log("DevAvatars",
                                           "found (subfolder): %s" % candidate)
                                return candidate

        # 3) بحث غير حساس لحالة الأحرف
        targets = set([
            dev_id.lower(),
            (dev_id + "_logo").lower(),
            (dev_id + "_avatar").lower(),
            (dev_id + "_banner").lower(),
        ])
        for name in _list_dir_safe(base):
            base_name, ext = os.path.splitext(name)
            if base_name.lower() in targets \
                    and ext.lower() in SUPPORTED_EXTS:
                path = os.path.join(base, name)
                logger.log("DevAvatars", "found (ci): %s" % path)
                return path

    logger.log("DevAvatars", "no avatar for %s" % dev_id)
    return None


def list_all_avatars():
    """لأغراض التشخيص — يعرض كل الصور الموجودة."""
    result = []
    for base in _get_existing_dirs():
        for name in _list_dir_safe(base):
            full = os.path.join(base, name)
            if os.path.isfile(full):
                result.append(full)
    return result


def debug_dump():
    """يطبع كل ما يراه dev_avatars — للتشخيص."""
    logger.log("DevAvatars", "=== DEBUG DUMP ===")
    logger.log("DevAvatars", "PLUGIN_ROOT = %s" % PLUGIN_ROOT)
    logger.log("DevAvatars", "AVATARS_DIRS = %s" % AVATARS_DIRS)
    for d in AVATARS_DIRS:
        exists = os.path.isdir(d)
        logger.log("DevAvatars", "  [%s] %s" % ("OK" if exists else "--", d))
        if exists:
            files = _list_dir_safe(d)
            logger.log("DevAvatars", "    files: %s" % files[:20])
    logger.log("DevAvatars", "=== END DEBUG ===")


def get_fallback_color(dev_id):
    """لون ثابت مشتق من اسم المطوّر."""
    if not dev_id:
        return 0x1E90FF
    h = 0
    for ch in dev_id:
        h = (h * 31 + ord(ch)) & 0xFFFFFF
    r = 0x20 + (h & 0x3F)
    g = 0x60 + ((h >> 6) & 0x5F)
    b = 0xC0 + ((h >> 12) & 0x3F)
    return (r << 16) | (g << 8) | b


def get_initial(dev_id, display=None):
    name = display or dev_id or "?"
    for ch in name:
        if ch.isalnum():
            return ch.upper()
    return "?"