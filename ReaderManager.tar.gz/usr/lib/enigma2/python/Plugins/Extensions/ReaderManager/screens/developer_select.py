# -*- coding: utf-8 -*-
"""
screens/developer_select.py — Grid 4×2 (8 developers visible) v9.
أفاتار 120×120، صفّان × 4 أعمدة، جميع الخلفيات معتمة 100%.
"""
from __future__ import absolute_import, print_function, unicode_literals

import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.MenuList import MenuList
from Tools.LoadPixmap import LoadPixmap

from enigma import eListbox, eListboxPythonMultiContent, gFont, eTimer
from enigma import RT_HALIGN_LEFT, RT_VALIGN_CENTER, RT_HALIGN_CENTER

from Components.MultiContent import MultiContentEntryText
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except ImportError:
    from Components.MultiContent import MultiContentEntryPixmapAlphaTest as MultiContentEntryPixmapAlphaBlend

try:
    from Components.MultiContent import MultiContentEntryRectangle
    HAS_RECT = True
except ImportError:
    HAS_RECT = False

from ..utils import logger
from ..utils import emulator_installer
from ..utils import github_api
from ..utils import dev_avatars

# في أعلى الملف
from ..utils.skin_loader import get_screen_skin



# ============ أبعاد الخلية ============
ITEM_W = 290
ITEM_H = 220
ITEM_MARGIN = 6
GRID_COLS = 4

AVATAR_W = 120
AVATAR_H = 120
AVATAR_TOP = 8

BAR_H = 84
BAR_Y = ITEM_H - BAR_H

# ============ ألوان معتمة 100% ============
COLOR_BG_NORMAL   = 0x0E1E3C
COLOR_BG_SELECTED = 0x1E3A5F
COLOR_BAR         = 0x0A2428
COLOR_BORDER_SEL  = 0xFFC93C
COLOR_NAME        = 0xFFFFFF
COLOR_FILES       = 0x88FF88
COLOR_FALLBACK    = 0x66CCFF


def _utf8(s):
    if s is None:
        return ""
    try:
        if isinstance(s, unicode):
            return s.encode('utf-8')
    except NameError:
        if isinstance(s, bytes):
            return s.decode('utf-8', 'ignore')
    if isinstance(s, str):
        return s
    return str(s)


class DeveloperSelectScreen(Screen):
    screen_name = "DeveloperSelect"

    def __init__(self, session, on_emu_change=None):
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session
        self._on_emu_change = on_emu_change

        logger.log("DeveloperSelectScreen", "__init__ (grid v9 4x2)")

        self["installed"] = Label("")
        self["status"]    = Label("Loading developers from GitHub...")
        self["page_info"] = Label("0 / 0")
        self["key_red"]    = Button("Close")
        self["key_green"]  = Button("Open")
        self["key_yellow"] = Button("Refresh")
        self["key_blue"]   = Button("Info")

        try:
            self["list_dev"] = MenuList(
                [],
                mode=getattr(eListbox, 'layoutGrid', 2),
                content=eListboxPythonMultiContent,
                itemWidth=ITEM_W,
                itemHeight=ITEM_H
            )
        except TypeError:
            self["list_dev"] = MenuList([], content=eListboxPythonMultiContent)
            try: self["list_dev"].l.setItemHeight(ITEM_H)
            except Exception: pass
            try: self["list_dev"].l.setItemWidth(ITEM_W)
            except Exception: pass
            try: self["list_dev"].l.setMode(2)
            except Exception: pass

        self["list_dev"].l.setFont(0, gFont("Regular", 35))
        self["list_dev"].l.setFont(1, gFont("Regular", 25))
        self["list_dev"].l.setFont(2, gFont("Regular", 48))

        try:
            self["list_dev"].l.setBuildFunc(self._build_row, True)
        except TypeError:
            self["list_dev"].l.setBuildFunc(self._build_row)

        self.developers = []
        self.current_index = 0
        self._avatar_cache = {}
        self._timers = []

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok":     self.open_selected,
                "green":  self.open_selected,
                "cancel": self.close,
                "red":    self.close,
                "yellow": self.refresh_developers,
                "blue":   self.show_info,
                "up":     self.move_up,
                "down":   self.move_down,
                "left":   self.move_left,
                "right":  self.move_right,
            }, -1)

        try:
            self["list_dev"].onSelectionChanged.append(
                self._on_selection_changed)
        except Exception:
            pass

        self.onLayoutFinish.append(self._on_start)

    # ============================================================
    def _on_start(self):
        self._update_installed_info()
        try:
            dev_avatars.debug_dump()
        except Exception as e:
            logger.log("DeveloperSelectScreen", "debug_dump error: %s" % e)
        self.load_developers_async()

    def load_developers_async(self):
        self["status"].setText("Loading developers from GitHub...")
        try:
            from threading import Thread
            t = Thread(target=self._load_worker)
            t.setDaemon(True)
            t.start()
        except Exception:
            self._load_worker()

    def _load_worker(self):
        try:
            devs = github_api.get_developers()
            if not devs:
                devs = self._fallback_local()
            self._schedule_ui(self._apply_developers, devs)
        except Exception as e:
            logger.log("DeveloperSelectScreen", "load error: %s" % e)
            self._schedule_ui(self._apply_developers,
                              self._fallback_local())

    def _fallback_local(self):
        try:
            return emulator_installer.get_all_developers()
        except Exception:
            return []

    def _apply_developers(self, devs):
        self.developers = devs or []
        self._preload_avatars()
        self._render_list()
        self["status"].setText(
            "Loaded %d developers — OK to open" % len(self.developers))

    def _preload_avatars(self):
        self._avatar_cache = {}
        for dev in self.developers:
            dev_id = dev.get("id", "?")
            path = dev_avatars.get_avatar_path(dev_id)
            if path:
                try:
                    pix = LoadPixmap(path)
                    if pix:
                        self._avatar_cache[dev_id] = pix
                        continue
                except Exception:
                    pass
            self._avatar_cache[dev_id] = None

    def _add_rect(self, res, x, y, w, h, color):
        if HAS_RECT:
            try:
                res.append(MultiContentEntryRectangle(
                    pos=(x, y), size=(w, h), backcolor=color))
                return
            except Exception:
                pass
        res.append(MultiContentEntryText(
            pos=(x, y), size=(w, h),
            font=0, backcolor=color,
            color=color,
            text=" "))

    def _build_row(self, item, selected=False):
        if isinstance(item, tuple) and len(item) > 0:
            dev = item[0]
        else:
            dev = item

        if not isinstance(dev, dict):
            return [None, MultiContentEntryText(
                pos=(0, 0), size=(ITEM_W, ITEM_H), font=0,
                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                color=0xFFFFFFFF,
                text=_utf8(str(dev)))]

        dev_id  = dev.get("id", "?")
        display = dev.get("display") or dev_id
        files   = dev.get("files", [])
        count   = len(files)

        bg_col = COLOR_BG_SELECTED if selected else COLOR_BG_NORMAL

        res = [dev]
        self._add_rect(res, 0, 0, ITEM_W, ITEM_H, bg_col)

        pix = self._avatar_cache.get(dev_id)
        avatar_x = (ITEM_W - AVATAR_W) // 2
        avatar_y = AVATAR_TOP

        if pix:
            res.append(MultiContentEntryPixmapAlphaBlend(
                pos=(avatar_x, avatar_y),
                size=(AVATAR_W, AVATAR_H),
                png=pix))
        else:
            res.append(MultiContentEntryText(
                pos=(avatar_x, avatar_y),
                size=(AVATAR_W, AVATAR_H),
                font=2,
                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                color=COLOR_FALLBACK,
                text=_utf8(display[:1].upper())))

        self._add_rect(res, 0, BAR_Y, ITEM_W, BAR_H, COLOR_BAR)

        res.append(MultiContentEntryText(
            pos=(2, BAR_Y + 2), size=(ITEM_W - 4, 40),
            font=0,
            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            color=COLOR_NAME,
            text=_utf8(display)))

        meta = "%d file(s)" % count if count else "—"
        res.append(MultiContentEntryText(
            pos=(2, BAR_Y + 42), size=(ITEM_W - 4, 34),
            font=1,
            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            color=COLOR_FILES,
            text=_utf8(meta)))

        if selected:
            self._add_rect(res, 0, 0, ITEM_W, 3, COLOR_BORDER_SEL)
            self._add_rect(res, 0, ITEM_H - 3, ITEM_W, 3, COLOR_BORDER_SEL)
            self._add_rect(res, 0, 0, 3, ITEM_H, COLOR_BORDER_SEL)
            self._add_rect(res, ITEM_W - 3, 0, 3, ITEM_H, COLOR_BORDER_SEL)

        return res

    def _render_list(self):
        rows = []
        for dev in self.developers:
            rows.append((dev,))
        self["list_dev"].setList(rows)

        if self.developers:
            idx = min(self.current_index, len(self.developers) - 1)
            if idx < 0:
                idx = 0
            self.current_index = idx
            try:
                self["list_dev"].moveToIndex(idx)
            except Exception:
                pass

        total = len(self.developers)
        self["page_info"].setText("%d developer(s)" % total)

    def _getCurrentDev(self):
        try:
            c = self["list_dev"].getCurrent()
            if c is None:
                return None
            if isinstance(c, tuple) and len(c) > 0:
                return c[0]
            return c
        except Exception:
            return None

    def _on_selection_changed(self):
        try:
            idx = self["list_dev"].getSelectedIndex()
            if idx is not None and idx >= 0:
                self.current_index = idx
        except Exception:
            pass

    def move_up(self):
        if not self.developers:
            return
        idx = self.current_index - GRID_COLS
        if idx < 0:
            last_row_start = ((len(self.developers) - 1) // GRID_COLS) * GRID_COLS
            idx = min(last_row_start + (self.current_index % GRID_COLS),
                      len(self.developers) - 1)
        self.current_index = max(0, idx)
        try:
            self["list_dev"].moveToIndex(self.current_index)
        except Exception:
            pass

    def move_down(self):
        if not self.developers:
            return
        idx = self.current_index + GRID_COLS
        if idx >= len(self.developers):
            idx = self.current_index % GRID_COLS
            if idx >= len(self.developers):
                idx = 0
        self.current_index = idx
        try:
            self["list_dev"].moveToIndex(self.current_index)
        except Exception:
            pass

    def move_left(self):
        if not self.developers:
            return
        idx = self.current_index - 1
        if idx < 0:
            idx = len(self.developers) - 1
        self.current_index = idx
        try:
            self["list_dev"].moveToIndex(idx)
        except Exception:
            pass

    def move_right(self):
        if not self.developers:
            return
        idx = self.current_index + 1
        if idx >= len(self.developers):
            idx = 0
        self.current_index = idx
        try:
            self["list_dev"].moveToIndex(idx)
        except Exception:
            pass

    def _update_installed_info(self):
        emu_id  = emulator_installer.get_installed_emulator()
        version = emulator_installer.get_installed_version()
        if emu_id:
            text = "Installed: %s %s" % (emu_id, version or "")
        else:
            text = "Installed: (none)"
        self["installed"].setText(text)

    def refresh_developers(self):
        github_api.clear_cache()
        self["status"].setText("Refreshing from GitHub...")
        self.load_developers_async()

    def show_info(self):
        dev = self._getCurrentDev()
        if not dev or not isinstance(dev, dict):
            return

        files = dev.get("files", [])
        lines = ["Developer: %s" % dev.get("id", "?")]
        lines.append("Path: %s" % dev.get("path", ""))
        lines.append("Files: %d" % len(files))

        avatar = dev_avatars.get_avatar_path(dev.get("id", ""))
        lines.append("Avatar: %s" % (avatar if avatar else "(none)"))
        lines.append("")

        for f in files[:15]:
            lines.append("• %s (%d B)" % (f["name"], f.get("size", 0)))
        if len(files) > 15:
            lines.append("... and %d more" % (len(files) - 15))

        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=15)

    def open_selected(self):
        dev = self._getCurrentDev()
        if not dev or not isinstance(dev, dict):
            return

        dev_id = dev.get("id", "")
        files  = dev.get("files", [])

        try:
            from .install_emulator import InstallEmulatorScreen
            self.session.openWithCallback(
                self._after_emulator_screen,
                InstallEmulatorScreen,
                dev_id,
                self._on_emu_change)
        except Exception as e:
            logger.log("DeveloperSelectScreen", "open error: %s" % e)

    def _after_emulator_screen(self, *args, **kwargs):
        self._update_installed_info()
        if self._on_emu_change:
            try:
                self._on_emu_change()
            except Exception:
                pass

    def _schedule_ui(self, func, *args):
        try:
            t = eTimer()
            t.callback.append(lambda: func(*args))
            t.start(10, True)
            self._timers.append(t)
        except Exception:
            try:
                func(*args)
            except Exception:
                pass

    def close(self):
        for t in self._timers:
            try:
                t.stop()
            except Exception:
                pass
        self._timers = []
        Screen.close(self)