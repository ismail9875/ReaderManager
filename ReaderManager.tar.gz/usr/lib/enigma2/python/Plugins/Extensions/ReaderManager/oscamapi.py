# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import base64
import json
import re
import time
from os.path import exists

# ─── توافق Py2/Py3 للـ urllib ───
try:
    # Python 2.7
    from urllib2 import (build_opener, Request, HTTPHandler,
                         HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                         HTTPDigestAuthHandler, URLError, HTTPError)
    from urllib import unquote, quote
except ImportError:
    # Python 3.x
    from urllib.request import (build_opener, Request, HTTPHandler,
                                 HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                                 HTTPDigestAuthHandler)
    from urllib.error import URLError, HTTPError
    from urllib.parse import unquote, quote

try:
    from ssl import create_default_context, _create_unverified_context
except ImportError:
    create_default_context = None
    _create_unverified_context = None

from . import logger


try:
    from Components.SystemInfo import BoxInfo
except ImportError:
    BoxInfo = None

try:
    from Components.config import config
except ImportError:
    config = None


# =====================================================================
# حالات OSCam
# =====================================================================
STATUS_CONNECTED  = "CONNECTED"
STATUS_CARDOK     = "CARDOK"
STATUS_OFF        = "OFF"
STATUS_ERROR      = "ERROR"
STATUS_NEEDINIT   = "NEEDINIT"
STATUS_DISABLED   = "DISABLED"
STATUS_UNKNOWN    = "UNKNOWN"
STATUS_INIT       = "INIT"
STATUS_NOACCESS   = "NOACCESS"

INVALID_CAIDS = {"0000", "000000", "00000000", ""}


# =====================================================================
# ReaderStatus
# =====================================================================
class ReaderStatus(object):
    __slots__ = (
        "label", "enabled", "status", "protocol", "device",
        "port", "cards", "card_count", "localcards",
        "ecmok", "ecmnok", "online", "idle",
        "cccversion", "last_ecm_time", "last_channel",
        "caid", "provid", "au",
        "entitlements_count", "cards_details", "raw",
    )

    def __init__(self, data=None):
        self.label = ""
        self.enabled = False
        self.status = STATUS_UNKNOWN
        self.protocol = ""
        self.device = ""
        self.port = 0
        self.cards = 0
        self.card_count = 0
        self.localcards = 0
        self.ecmok = 0
        self.ecmnok = 0
        self.online = 0
        self.idle = 0
        self.cccversion = ""
        self.last_ecm_time = ""
        self.last_channel = ""
        self.caid = ""
        self.provid = ""
        self.au = ""
        self.entitlements_count = 0
        self.cards_details = []
        self.raw = {}

        if data:
            self._parse(data)

    def _parse(self, data):
        self.raw = data
        self.label      = data.get("label", "") or ""
        self.enabled    = bool(data.get("enabled", True))
        self.status     = ((data.get("status") or STATUS_UNKNOWN)
                           .upper().strip())
        self.protocol   = data.get("protocol", "") or ""
        self.device     = data.get("device", "") or ""
        self.port       = self._to_int(data.get("port", 0))
        self.cards      = self._to_int(data.get("cards", 0))
        self.card_count = self._to_int(
            data.get("card_count", self.cards))
        self.localcards = self._to_int(data.get("localcards", 0))
        self.ecmok      = self._to_int(data.get("ecmok", 0))
        self.ecmnok     = self._to_int(data.get("ecmnok", 0))
        self.online     = self._to_int(data.get("online", 0))
        self.idle       = self._to_int(data.get("idle", 0))
        self.cccversion = data.get("cccversion", "") or ""
        self.last_ecm_time = data.get("last_ecm_time", "") or ""
        self.last_channel  = data.get("last_channel", "") or ""
        self.caid       = data.get("caid", "") or ""
        self.provid     = data.get("provid", "") or ""
        self.au         = data.get("au", "") or ""
        self.entitlements_count = self._to_int(
            data.get("entitlements_count", 0))
        self.cards_details = data.get("cards_details", []) or []

    @staticmethod
    def _to_int(v):
        try:
            return int(v)
        except (ValueError, TypeError):
            return 0

    @property
    def is_connected(self):
        return self.status in (STATUS_CONNECTED, STATUS_CARDOK)

    @property
    def is_off(self):
        return self.status in (STATUS_OFF, STATUS_DISABLED)

    @property
    def is_error(self):
        return self.status in (STATUS_ERROR, STATUS_NOACCESS)

    @property
    def is_working(self):
        return self.is_connected and self.ecmok > 0

    @property
    def display_status(self):
        return self.status

    @property
    def display_cards(self):
        if not self.is_connected:
            return "-"
        if self.card_count > 0:
            return str(self.card_count)
        return "0"

    def get_caids(self):
        """يُرجع قائمة CAIDs فريدة (strings) مع فلترة 0000."""
        caids = set()
        raw = self.raw or {}

        # ① entitlements (من fetch_reader_entitlements)
        ents = raw.get("entitlements", [])
        if isinstance(ents, list):
            for ent in ents:
                if isinstance(ent, dict):
                    c = (ent.get("caid") or "").strip().upper()
                    if c and c not in INVALID_CAIDS:
                        caids.add(c)

        # ② entitlements داخل connection
        conn = raw.get("connection", {})
        if isinstance(conn, dict):
            ents2 = conn.get("entitlements", [])
            if isinstance(ents2, list):
                for ent in ents2:
                    if isinstance(ent, dict):
                        for key in ("caid", "caid_list", "caids"):
                            v = ent.get(key)
                            if v:
                                for part in str(v).replace(",", " ") \
                                        .replace(";", " ").split():
                                    part = part.strip().upper()
                                    if part and part not in INVALID_CAIDS:
                                        caids.add(part)

        # ③ cards_details
        for card in (raw.get("cards_details") or []):
            if isinstance(card, dict):
                c = (card.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    caids.add(c)

        # ④ caid الأساسي (فقط إذا ليس 0000)
        if self.caid:
            for part in str(self.caid).replace(",", " ") \
                    .replace(";", " ").split():
                part = part.strip().upper()
                if part and part not in INVALID_CAIDS:
                    caids.add(part)

        return sorted(caids)

    def get_caids_dict(self):
        """يُرجع list من dicts: [{"caid": "0500", "system": "viaccess"}, ...]"""
        result = {}
        raw = self.raw or {}

        # ① من entitlements (raw)
        for ent in (raw.get("entitlements") or []):
            if isinstance(ent, dict):
                c = (ent.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    if c not in result:
                        result[c] = {
                            "caid": c,
                            "system": (ent.get("system") or "").strip().lower(),
                        }
                    else:
                        if not result[c]["system"]:
                            s = (ent.get("system") or "").strip().lower()
                            if s:
                                result[c]["system"] = s

        # ② من cards_details
        for card in (raw.get("cards_details") or []):
            if isinstance(card, dict):
                c = (card.get("caid") or "").strip().upper()
                if c and c not in INVALID_CAIDS:
                    if c not in result:
                        result[c] = {
                            "caid": c,
                            "system": (card.get("system") or "").strip().lower(),
                        }
                    else:
                        if not result[c]["system"]:
                            s = (card.get("system") or "").strip().lower()
                            if s:
                                result[c]["system"] = s

        # ③ caid الأساسي (بدون system)
        if self.caid:
            for part in str(self.caid).replace(",", " ") \
                    .replace(";", " ").split():
                part = part.strip().upper()
                if part and part not in INVALID_CAIDS and part not in result:
                    result[part] = {"caid": part, "system": ""}

        return sorted(result.values(), key=lambda x: x["caid"])

    def to_dict(self):
        return {
            "label": self.label,
            "enabled": self.enabled,
            "status": self.status,
            "protocol": self.protocol,
            "device": self.device,
            "port": self.port,
            "cards": self.cards,
            "card_count": self.card_count,
            "localcards": self.localcards,
            "ecmok": self.ecmok,
            "ecmnok": self.ecmnok,
            "online": self.online,
            "idle": self.idle,
            "cccversion": self.cccversion,
            "last_ecm_time": self.last_ecm_time,
            "last_channel": self.last_channel,
            "caid": self.caid,
            "provid": self.provid,
            "au": self.au,
            "entitlements_count": self.entitlements_count,
            "is_connected": self.is_connected,
            "is_working": self.is_working,
        }

    def __repr__(self):
        return "<ReaderStatus %s: %s cards=%d ecm=%d>" % (
            self.label, self.status, self.card_count, self.ecmok)


# =====================================================================
# OSCamAPIError
# =====================================================================
class OSCamAPIError(Exception):
    pass


# =====================================================================
# OSCamAPI
# =====================================================================
class OSCamAPI(object):
    def __init__(self, base_url=None, username="", password="",
                 timeout=5.0):
        self.base_url = (base_url or "").rstrip("/")
        self.username = username or ""
        self.password = password or ""
        self.timeout = timeout
        self._last_request = 0
        self._last_result = []
        self._last_error = ""
        self._last_method = ""
        # label → (ts, {"caids": [...], "cards": [...], "totalcards": N})
        self._entitlement_cache = {}

    def _make_auth_header(self):
        if not self.username:
            return {}
        creds = "%s:%s" % (self.username, self.password)
        try:
            token = base64.b64encode(creds.encode("utf-8")).decode("ascii")
        except Exception:
            token = base64.b64encode(creds)
            if isinstance(token, bytes):
                token = token.decode("ascii")
        return {"Authorization": "Basic %s" % token}

    def _http_get(self, path, timeout=None):
        if not self.base_url:
            raise OSCamAPIError("Base URL not configured")

        url = "%s%s" % (self.base_url, path)

        cache_buster = ("&_t=%d" % int(time.time() * 1000)
                        if "?" in path
                        else "?_t=%d" % int(time.time() * 1000))
        url += cache_buster

        headers = self._make_auth_header()
        headers["User-Agent"] = "Enigma2-ReaderManager/1.0"
        headers["Accept"] = "application/json, text/xml, text/html, */*"
        headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        headers["Pragma"] = "no-cache"

        try:
            req = Request(url, headers=headers)
            resp = build_opener(HTTPHandler).open(
                req, timeout=timeout or self.timeout)
            data = resp.read()
            if isinstance(data, bytes):
                data = data.decode("utf-8", "replace")
            return data
        except HTTPError as e:
            msg = "HTTP %d: %s" % (e.code, e.reason)
            self._last_error = msg
            raise OSCamAPIError(msg)
        except URLError as e:
            msg = "URL error: %s" % e.reason
            self._last_error = msg
            raise OSCamAPIError(msg)
        except Exception as e:
            msg = "Request failed: %s" % e
            self._last_error = msg
            raise OSCamAPIError(msg)

    # ------------------------------------------------------------------
    #  Public API
    # ------------------------------------------------------------------
    def get_reader_status(self):
        self._last_request = time.time()

        try:
            data = self._http_get("/oscamapi.json?part=status")
            logger.log("OSCamAPI", "JSON response: %d bytes" % len(data))
            result = self._parse_json_readers(data)
            if result:
                self._last_result = result
                self._last_error = ""
                self._last_method = "json"
                logger.log("OSCamAPI", "JSON OK: %d readers" % len(result))
                self._enrich_with_entitlements()
                return self._last_result
            else:
                logger.log("OSCamAPI", "JSON empty or not parseable")
        except OSCamAPIError as e:
            logger.log("OSCamAPI", "JSON failed: %s" % e)

        try:
            data = self._http_get("/oscamapi.html?part=status")
            logger.log("OSCamAPI", "XML response: %d bytes" % len(data))
            result = self._parse_xml_readers(data)
            if result:
                self._last_result = result
                self._last_error = ""
                self._last_method = "xml"
                logger.log("OSCamAPI", "XML OK: %d readers" % len(result))
                self._enrich_with_entitlements()
                return self._last_result
            else:
                logger.log("OSCamAPI", "XML empty or not parseable")
        except OSCamAPIError as e:
            logger.log("OSCamAPI", "XML failed: %s" % e)

        try:
            data = self._http_get("/status.html")
            logger.log("OSCamAPI", "HTML response: %d bytes" % len(data))
            result = self._parse_status_html(data)
            if result:
                self._last_result = result
                self._last_error = ""
                self._last_method = "html"
                logger.log("OSCamAPI", "HTML OK: %d readers" % len(result))
                self._enrich_with_entitlements()
                return self._last_result
            else:
                logger.log("OSCamAPI", "HTML empty or not parseable")
        except OSCamAPIError as e:
            logger.log("OSCamAPI", "HTML failed: %s" % e)

        return self._last_result

    def _enrich_with_entitlements(self):
        """يثري كل ReaderStatus متصل بـ CAIDs + cards_details."""
        if not self._last_result:
            return

        for r in self._last_result:
            if not r.is_connected:
                continue
            try:
                ent = self.fetch_reader_entitlements(r.label)
                if ent.get("caids"):
                    r.raw["entitlements"] = ent["caids"]
                if ent.get("cards"):
                    r.cards_details = ent["cards"]
                    r.raw["cards_details"] = ent["cards"]
                if ent.get("totalcards"):
                    r.card_count = ent["totalcards"]
                    r.cards = ent["totalcards"]
            except Exception as e:
                logger.log("OSCamAPI",
                           "entitlement for %s failed: %s"
                           % (r.label, e))

    # ------------------------------------------------------------------
    #  Entitlement endpoint (المصدر الأساسي لـ CAIDs)
    # ------------------------------------------------------------------
    def _parse_entitlement_caids(self, data):
        result = {"caids": [], "cards": [], "totalcards": 0}
        seen = set()

        m = re.search(r'<cardlist[^>]*\btotalcards\s*=\s*["\']?(\d+)',
                      data, re.IGNORECASE)
        if m:
            try:
                result["totalcards"] = int(m.group(1))
            except (ValueError, TypeError):
                pass

        card_pattern = re.compile(
            r'<card\s+([^>]+?)(?:/>|>(.*?)</card>)',
            re.IGNORECASE | re.DOTALL)

        for card_match in card_pattern.finditer(data):
            attrs = card_match.group(1)
            body = card_match.group(2) or ""

            caid_m = re.search(r'\bcaid\s*=\s*["\']?([0-9A-Fa-f]+)',
                               attrs, re.IGNORECASE)
            if not caid_m:
                continue
            caid = caid_m.group(1).strip().upper()
            if not caid or caid in INVALID_CAIDS:
                continue

            sys_m = re.search(r'\bsystem\s*=\s*["\']?([^"\'\s>]+)',
                              attrs, re.IGNORECASE)
            system = sys_m.group(1).strip().lower() if sys_m else ""

            num_m = re.search(r'\bnumber\s*=\s*["\']?(\d+)', attrs)
            res_m = re.search(r'\breshare\s*=\s*["\']?([^"\'\s>]+)', attrs)
            hop_m = re.search(r'\bhop\s*=\s*["\']?([^"\'\s>]+)', attrs)

            providers = []
            for prov_m in re.finditer(
                    r'<provider\s+([^>]+?)(?:/>|>(.*?)</provider>)',
                    body, re.IGNORECASE | re.DOTALL):
                pattrs = prov_m.group(1)
                ptext = (prov_m.group(2) or "").strip()
                p_sa = re.search(r'\bsa\s*=\s*["\']?([^"\'\s>]*)', pattrs)
                p_caid = re.search(r'\bcaid\s*=\s*["\']?([^"\'\s>]+)',
                                   pattrs)
                p_prov = re.search(r'\bprovid\s*=\s*["\']?([^"\'\s>]+)',
                                   pattrs)
                providers.append({
                    "sa": p_sa.group(1) if p_sa else "",
                    "caid": p_caid.group(1) if p_caid else caid,
                    "provid": p_prov.group(1) if p_prov else "",
                    "service": ptext,
                })

            card = {
                "number": int(num_m.group(1)) if num_m else 0,
                "caid": caid,
                "system": system,
                "reshare": res_m.group(1) if res_m else "",
                "hop": hop_m.group(1) if hop_m else "",
                "providers": providers,
            }
            result["cards"].append(card)

            if caid not in seen:
                seen.add(caid)
                result["caids"].append({
                    "caid": caid,
                    "system": system,
                })

        return result

    def fetch_reader_entitlements(self, label, cache_seconds=30):
        if not label:
            return {"caids": [], "cards": [], "totalcards": 0}

        now = time.time()
        if label in self._entitlement_cache:
            ts, cached = self._entitlement_cache[label]
            if now - ts < cache_seconds:
                return cached

        empty = {"caids": [], "cards": [], "totalcards": 0}
        try:
            path = "/oscamapi.html?part=entitlement&label=%s" % quote(label)
            data = self._http_get(path)
            if not data or "<?xml" not in data:
                logger.log("OSCamAPI",
                           "entitlement: no XML for %s" % label)
                self._entitlement_cache[label] = (now, empty)
                return empty

            result = self._parse_entitlement_caids(data)
            self._entitlement_cache[label] = (now, result)
            logger.log("OSCamAPI",
                       "entitlement OK: %s → %d CAID(s) / %d cards"
                       % (label, len(result["caids"]),
                          result["totalcards"]))
            return result
        except OSCamAPIError as e:
            logger.log("OSCamAPI",
                       "entitlement failed for %s: %s" % (label, e))
            self._entitlement_cache[label] = (now, empty)
            return empty

    def get_status(self):
        try:
            data = self._http_get("/oscamapi.json?part=status")
            return json.loads(data)
        except Exception:
            return {}

    def is_available(self):
        try:
            return bool(self.get_reader_status())
        except Exception:
            return False

    def get_last_error(self):
        return self._last_error

    def get_last_method(self):
        return self._last_method

    def get_readers_dict(self):
        result = {}
        for r in self.get_reader_status():
            result[r.label] = r
        return result

    @staticmethod
    def _extract_card_count(connection):
        if not isinstance(connection, dict):
            return 0

        for key in ("card_count", "cards"):
            v = connection.get(key)
            if v is not None:
                try:
                    n = int(v)
                    if n > 0:
                        return n
                except (ValueError, TypeError):
                    pass

        entitlements = connection.get("entitlements", [])
        if not isinstance(entitlements, list):
            return 0

        best = 0
        for ent in entitlements:
            if not isinstance(ent, dict):
                continue
            for key in ("cccount", "cccreshare", "locals"):
                v = ent.get(key)
                if v is None:
                    continue
                try:
                    n = int(v)
                    if n > best:
                        best = n
                    if best > 0:
                        break
                except (ValueError, TypeError):
                    pass

        return best

    @staticmethod
    def _extract_local_cards(connection):
        if not isinstance(connection, dict):
            return 0
        entitlements = connection.get("entitlements", [])
        if not isinstance(entitlements, list):
            return 0
        best = 0
        for ent in entitlements:
            if not isinstance(ent, dict):
                continue
            v = ent.get("locals")
            if v is None:
                continue
            try:
                n = int(v)
                if n > best:
                    best = n
            except (ValueError, TypeError):
                pass
        return best

    @staticmethod
    def _extract_entitlements_count(connection):
        if not isinstance(connection, dict):
            return 0
        v = connection.get("totentitlements")
        if v is not None:
            try:
                return int(v)
            except (ValueError, TypeError):
                pass
        entitlements = connection.get("entitlements", [])
        if isinstance(entitlements, list):
            return len(entitlements)
        return 0

    @staticmethod
    def _to_int(v):
        try:
            return int(v)
        except (ValueError, TypeError):
            return 0

    def _parse_json_readers(self, data):
        data = (data or "").strip()
        if not data or not data.startswith("{"):
            return []

        try:
            obj = json.loads(data)
        except Exception as e:
            logger.log("OSCamAPI", "Invalid JSON: %s" % e)
            return []

        readers = self._extract_from_status_clients(obj)
        if readers:
            return readers

        readers_list = None
        if isinstance(obj, dict):
            rs = obj.get("readerstatus")
            if isinstance(rs, dict):
                readers_list = rs.get("readers")
            if readers_list is None and "readers" in obj:
                readers_list = obj["readers"]
            if readers_list is None and "oscam" in obj:
                oscam = obj["oscam"]
                if isinstance(oscam, dict):
                    rs = oscam.get("readerstatus")
                    if isinstance(rs, dict):
                        readers_list = rs.get("readers")

        if isinstance(readers_list, dict):
            readers_list = [readers_list]

        if not isinstance(readers_list, list):
            return []

        result = []
        for item in readers_list:
            if isinstance(item, dict):
                try:
                    if "connection" in item and isinstance(
                            item["connection"], dict):
                        if "entitlements" not in item:
                            item["entitlements"] = \
                                item["connection"].get("entitlements", [])
                    result.append(ReaderStatus(item))
                except Exception as e:
                    logger.log("OSCamAPI", "Reader parse error: %s" % e)
        return result

    def _extract_from_status_clients(self, obj):
        if not isinstance(obj, dict):
            return []

        oscam = obj.get("oscam")
        if not isinstance(oscam, dict):
            return []

        status = oscam.get("status")
        if not isinstance(status, dict):
            return []

        clients = status.get("client", [])
        if not isinstance(clients, list):
            return []

        readers = []
        for client in clients:
            if not isinstance(client, dict):
                continue
            ctype = client.get("type", "")
            if ctype not in ("p", "r", "c"):
                continue
            try:
                readers.append(self._client_to_reader_status(client))
            except Exception as e:
                logger.log("OSCamAPI", "Client parse error: %s" % e)
        return readers

    def _client_to_reader_status(self, client):
        connection = client.get("connection", {})
        request    = client.get("request", {})
        times      = client.get("times", {})

        card_count  = self._extract_card_count(connection)
        local_cards = self._extract_local_cards(connection)
        ent_count   = self._extract_entitlements_count(connection)

        label = (client.get("rname_enc")
                 or client.get("name_enc")
                 or client.get("label")
                 or "")

        entitlements = connection.get("entitlements", [])
        if not isinstance(entitlements, list):
            entitlements = []

        data = {
            "label":      label,
            "status":     (connection.get("status") or "UNKNOWN").upper(),
            "protocol":   client.get("protocol", ""),
            "device":     connection.get("ip", ""),
            "port":       self._to_int(connection.get("port", 0)),
            "card_count": card_count,
            "cards":      card_count,
            "localcards": local_cards,
            "entitlements_count": ent_count,
            "entitlements": entitlements,
            "enabled":    True,
            "ecmok":      self._to_int(connection.get("ecmok", 0)),
            "ecmnok":     self._to_int(connection.get("ecmnok", 0)),
            "last_channel": (request.get("chname", "") or ""),
            "caid":       request.get("caid", ""),
            "provid":     request.get("provid", ""),
        }

        proto = data["protocol"]
        m = re.search(r'(\d+\.\d+\.\d+)', proto)
        if m:
            data["cccversion"] = m.group(1)

        idle_iso = times.get("idle")
        if idle_iso:
            try:
                data["idle"] = int(float(idle_iso))
            except (ValueError, TypeError):
                pass

        return ReaderStatus(data)

    def _parse_xml_readers(self, data):
        data = (data or "").strip()
        if not data or "<" not in data[:30]:
            return []

        readers = []
        for match in re.finditer(r"<reader>(.*?)</reader>", data,
                                 re.DOTALL | re.IGNORECASE):
            block = match.group(1)
            reader_data = {}
            for m in re.finditer(
                    r"<([a-zA-Z_][a-zA-Z0-9_]*)>([^<]*)</\1>", block):
                key = m.group(1).lower()
                val = m.group(2).strip()
                if val.isdigit():
                    reader_data[key] = int(val)
                elif val.lower() in ("true", "false"):
                    reader_data[key] = val.lower() == "true"
                else:
                    reader_data[key] = val
            if reader_data:
                try:
                    readers.append(ReaderStatus(reader_data))
                except Exception as e:
                    logger.log("OSCamAPI", "XML reader parse: %s" % e)
        return readers

    def _parse_status_html(self, html):
        if not html or "<tr" not in html:
            return []

        readers = []
        tr_pattern = re.compile(
            r'<tr\s+id="id_(0x[0-9a-fA-F]+)"\s+class="([prs])"[^>]*>',
            re.IGNORECASE
        )

        positions = []
        for m in tr_pattern.finditer(html):
            positions.append((m.start(), m.end(), m.group(2).lower()))

        if not positions:
            logger.log("OSCamAPI", "HTML: no reader rows found")
            return []

        for i, (start, end, row_class) in enumerate(positions):
            next_start = (positions[i + 1][0]
                          if i + 1 < len(positions) else len(html))
            segment = html[end:next_start]
            close_m = re.search(r'</tr>', segment, re.IGNORECASE)
            row_html = segment[:close_m.start()] if close_m else segment

            if row_class == "s":
                continue

            reader = self._parse_html_row(row_html)
            if reader:
                readers.append(reader)

        logger.log("OSCamAPI",
                   "HTML parsed: %d reader(s) from %d rows"
                   % (len(readers), len(positions)))
        return readers

    def _parse_html_row(self, row_html):
        try:
            data = {}

            m = re.search(
                r'<td class="statuscol4"[^>]*>(.*?)</td>',
                row_html, re.DOTALL | re.IGNORECASE
            )
            if m:
                cell = m.group(1)
                a = re.search(r'<a[^>]*>([^<]+)</a>', cell)
                if a:
                    data["label"] = a.group(1).strip()
                else:
                    data["label"] = re.sub(r"<[^>]+>", "", cell).strip()

            if not data.get("label"):
                return None

            m = re.search(
                r'<td class="statuscol5 statuscol5(ON|OFF)"',
                row_html, re.IGNORECASE
            )
            if m:
                data["enabled"] = (m.group(1).upper() == "ON")
            else:
                m = re.search(
                    r'<td class="statuscol5">\s*(ON|OFF)',
                    row_html, re.IGNORECASE
                )
                if m:
                    data["enabled"] = (m.group(1).upper() == "ON")

            m = re.search(
                r'<td class="statuscol7">([^<]*)</td>',
                row_html, re.IGNORECASE
            )
            if m:
                data["device"] = m.group(1).strip()

            m = re.search(
                r'<td class="statuscol8">(\d+)</td>',
                row_html, re.IGNORECASE
            )
            if m:
                try:
                    data["port"] = int(m.group(1))
                except Exception:
                    data["port"] = 0

            m = re.search(
                r'<td class="statuscol9"[^>]*>\s*([^<\n]+)',
                row_html, re.IGNORECASE
            )
            if m:
                proto_raw = m.group(1).strip()
                data["protocol"] = proto_raw
                vm = re.search(r'\((\d+\.\d+\.\d+)', proto_raw)
                if vm:
                    data["cccversion"] = vm.group(1)

            m = re.search(
                r'<td class="statuscol16 statuscol16([A-Z]+)"[^>]*>'
                r'(.*?)</td>',
                row_html, re.DOTALL | re.IGNORECASE
            )

            if m:
                data["status"] = m.group(1).upper()
                status_content = m.group(2)

                cm = re.search(
                    r'\((\d+)\s+of\s+(\d+)\s+cards?\)',
                    status_content
                )
                if cm:
                    data["card_count"] = int(cm.group(1))
                    data["cards"] = int(cm.group(1))
                else:
                    cm = re.search(r'card_count=(\d+)', status_content)
                    if cm:
                        data["card_count"] = int(cm.group(1))
                        data["cards"] = int(cm.group(1))
            else:
                m = re.search(
                    r'<td class="statuscol16"[^>]*>(.*?)</td>',
                    row_html, re.DOTALL | re.IGNORECASE
                )
                if m:
                    txt = re.sub(r"<[^>]+>", " ", m.group(1)).strip()
                    first_word = txt.split()[0] if txt else ""
                    data["status"] = first_word.upper()[:20]

            if not data.get("status"):
                data["status"] = STATUS_UNKNOWN

            return ReaderStatus(data)

        except Exception as e:
            logger.log("OSCamAPI", "Row parse error: %s" % e)
            return None


# =====================================================================
# Auto-detect helper
# =====================================================================
def configure_auto():
    ver_files = [
        "/tmp/.oscam/oscam.version",
        "/tmp/.ncam/ncam.version",
    ]

    ver_file = None
    for p in ver_files:
        if exists(p):
            ver_file = p
            break

    if not ver_file:
        raise OSCamAPIError("oscam.version not found")

    try:
        with open(ver_file, "r") as f:
            content = f.read()
    except Exception as e:
        raise OSCamAPIError("Cannot read %s: %s" % (ver_file, e))

    port = None
    config_dir = "/etc/tuxbox/config"
    ipv6_compiled = False

    for line in content.splitlines():
        line_low = line.lower()
        if "webifport:" in line_low:
            try:
                port = line.split(":")[1].strip()
            except Exception:
                pass
        elif "configdir:" in line_low:
            try:
                config_dir = line.split(":", 1)[1].strip()
            except Exception:
                pass
        elif "ipv6 support:" in line_low:
            v = line.split(":")[1].strip().lower()
            ipv6_compiled = (v == "yes")

    if not port or port == "0":
        raise OSCamAPIError("WebIF disabled")

    user = "root"
    pwd = ""
    proto = "http"
    blocked = True
    ip = "127.0.0.1"
    conf_file = config_dir.rstrip("/") + "/oscam.conf"
    if not exists(conf_file):
        conf_file = config_dir.rstrip("/") + "/ncam.conf"

    if exists(conf_file):
        try:
            with open(conf_file, "r") as f:
                for line in f:
                    line_low = line.lower().strip()
                    if line_low.startswith("httpuser"):
                        user = line.split("=", 1)[1].strip()
                    elif line_low.startswith("httppwd"):
                        pwd = line.split("=", 1)[1].strip()
                    elif line_low.startswith("httpport"):
                        v = line.split("=", 1)[1].strip()
                        if v.startswith("+"):
                            proto = "https"
                            port = v.replace("+", "").strip()
                        else:
                            port = v
                    elif line_low.startswith("httpallowed"):
                        blocked = False
                        allowed = line.split("=", 1)[1].strip()
                        if "::1" in allowed and ipv6_compiled:
                            ip = "::1"
                        elif "127.0.0.1" in allowed:
                            ip = "127.0.0.1"
        except Exception as e:
            logger.log("OSCamAPI", "conf read error: %s" % e)

    if blocked:
        raise OSCamAPIError("WebIF blocks localhost")

    base_url = "%s://%s:%s" % (proto, ip, port)
    logger.log("OSCamAPI",
               "Auto-detected: %s user=%s" % (base_url, user))
    return configure(base_url, user, pwd, timeout=5.0)


# =====================================================================
# Singleton
# =====================================================================
_default_api = None


def configure(base_url, username="", password="", timeout=5.0):
    global _default_api
    _default_api = OSCamAPI(base_url, username, password, timeout)
    return _default_api


def get_default():
    return _default_api


def reset_default():
    global _default_api
    _default_api = None