# -*- coding: utf-8 -*-
"""
core/softcam_paths.py — اكتشاف مسارات ملفات readers حسب المحاكي النشط.

يدعم المحاكيات ذات المسارات المستقلة مثل:
    - oscam        → /etc/tuxbox/config/oscam
    - oscamicam    → /etc/tuxbox/config/oscamicam
    - ncam         → /etc/tuxbox/config/ncam
    - oscam-emu    → /etc/tuxbox/config/oscam-emu
    - oscam-smod   → /etc/tuxbox/config/oscam-smod
    - gcam         → /etc/tuxbox/config/gcam
"""
from __future__ import absolute_import, print_function, unicode_literals

import os

from ..utils import logger


# ═══════════════════════════════════════════════════════════════════
#  خريطة: اسم المحاكي → قائمة مسارات config محتملة (بالترتيب)
# ═══════════════════════════════════════════════════════════════════
SOFTCAM_CONFIG_PATHS = {
    "oscam": [
        "/etc/tuxbox/config/oscam",
        "/etc/tuxbox/config/OSCam_11725-kitte888",
        "/etc/tuxbox/config",
        "/usr/keys/oscam",
        "/var/etc/oscam",
    ],
    "oscamicam": [
        "/etc/tuxbox/config/oscamicam",
        "/etc/tuxbox/config/oscam-icam",
        "/etc/tuxbox/config/oscam_icam",
    ],
    "oscam-icam": [
        "/etc/tuxbox/config/oscamicam",
        "/etc/tuxbox/config/oscam-icam",
    ],
    "ncam": [
        "/etc/tuxbox/config/ncam",
        "/etc/tuxbox/config",
    ],
    "oscam-emu": [
        "/etc/tuxbox/config/oscam-emu",
        "/etc/tuxbox/config/oscam_emu",
    ],
    "oscam-smod": [
        "/etc/tuxbox/config/oscam-smod",
        "/etc/tuxbox/config/oscam_smod",
    ],
    "gcam": [
        "/etc/tuxbox/config/gcam",
    ],
    "cccam": [
        "/etc/tuxbox/config/cccam",
    ],
}


# ═══════════════════════════════════════════════════════════════════
#  أسماء ملفات readers المحتملة (بالترتيب)
# ═══════════════════════════════════════════════════════════════════
READER_FILENAMES = [
    "oscam.reader",
    "oscam.server",
    "ncam.reader",
    "ncam.server",
    "gcam.reader",
    "reader.conf",
]


# ═══════════════════════════════════════════════════════════════════
#  تطبيع اسم المحاكي
# ═══════════════════════════════════════════════════════════════════
def _normalize_name(name):
    if not name:
        return ""
    key = name.lower().strip()
    key = key.replace(" ", "").replace("_", "-")
    return key


# ═══════════════════════════════════════════════════════════════════
#  اكتشاف مجلد config
# ═══════════════════════════════════════════════════════════════════
def detect_config_dir(softcam_name):
    """
    يُرجع أول مجلد config موجود فعلياً للمحاكي.
    إذا لم يوجد أي مجلد، يُرجع أول مسار من القائمة (للإنشاء لاحقاً).
    """
    if not softcam_name:
        return None

    key = _normalize_name(softcam_name)
    candidates = SOFTCAM_CONFIG_PATHS.get(key)

    # بحث جزئي إذا لم يوجد تطابق تام
    if not candidates:
        for map_key, paths in SOFTCAM_CONFIG_PATHS.items():
            if map_key in key or key in map_key:
                candidates = paths
                break

    if not candidates:
        return None

    for path in candidates:
        if os.path.isdir(path):
            return path

    # لم يوجد مجلد موجود — نُرجع الأول كاقتراح
    return candidates[0] if candidates else None


# ═══════════════════════════════════════════════════════════════════
#  اكتشاف ملف readers
# ═══════════════════════════════════════════════════════════════════
def detect_reader_file(softcam_name):
    """
    يُرجع مسار ملف readers النشط للمحاكي.
    - إذا وُجد ملف ضمن READER_FILENAMES، يُرجعه.
    - وإلا يُرجع مسار افتراضي (oscam.reader داخل config_dir).
    """
    if not softcam_name:
        return None

    config_dir = detect_config_dir(softcam_name)
    if not config_dir:
        return None

    for fname in READER_FILENAMES:
        full = os.path.join(config_dir, fname)
        if os.path.isfile(full):
            return full

    # افتراضي
    return os.path.join(config_dir, "oscam.reader")


# ═══════════════════════════════════════════════════════════════════
#  قائمة كل المحاكيات المتوفرة على الجهاز
# ═══════════════════════════════════════════════════════════════════
def list_available_softcams():
    """
    يُرجع قائمة المحاكيات التي لها ملف readers موجود فعلاً.
    كل عنصر: {"name", "config_dir", "reader_file"}
    """
    result = []
    seen_files = set()

    for name in SOFTCAM_CONFIG_PATHS:
        config_dir = detect_config_dir(name)
        if not config_dir:
            continue

        reader_file = None
        for fname in READER_FILENAMES:
            full = os.path.join(config_dir, fname)
            if os.path.isfile(full):
                reader_file = full
                break

        if not reader_file:
            continue

        # تجنّب التكرار (نفس الملف لأسماء مختلفة)
        if reader_file in seen_files:
            continue
        seen_files.add(reader_file)

        result.append({
            "name": name,
            "config_dir": config_dir,
            "reader_file": reader_file,
        })

    return result


# ═══════════════════════════════════════════════════════════════════
#  تحديد tag مناسب لمسار معيّن
# ═══════════════════════════════════════════════════════════════════
def tag_for_path(path):
    """يُرجع tag قصير للمسار (OSCAM / NCAM / OSCAM-ICAM ...)."""
    if not path:
        return "UNKNOWN"

    base = os.path.basename(path).lower()
    parent = os.path.basename(os.path.dirname(path)).lower()
    full = (parent + "/" + base)

    if "oscamicam" in full or "oscam-icam" in full or "oscam_icam" in full:
        return "OSCAM-ICAM"
    if "ncam" in full:
        return "NCAM"
    if "oscam-emu" in full or "oscam_emu" in full:
        return "OSCAM-EMU"
    if "oscam-smod" in full or "oscam_smod" in full:
        return "OSCAM-SMOD"
    if "oscam" in full:
        return "OSCAM"
    if "gcam" in full:
        return "GCAM"
    if "cccam" in full:
        return "CCCAM"

    return (parent or base or "UNKNOWN").upper()