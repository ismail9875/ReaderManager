# -*- coding: utf-8 -*-
"""
screens/log_viewer.py — عارض ملف السجل.
"""
from __future__ import absolute_import, print_function, unicode_literals

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.ScrollLabel import ScrollLabel

from ..utils import logger
from ..utils.skin_loader import get_screen_skin


class LogViewer(Screen):

    screen_name = "LogViewer"

    def __init__(self, session):
        # ⭐ اسنِ السكين قبل Screen.__init__
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session

        self["status"]     = Label(logger.get_log_path())
        self["log_status"] = Label("")
        self["content"]    = ScrollLabel("")
        self["key_red"]    = Button("Close")
        self["key_green"]  = Button("Refresh")
        self["key_yellow"] = Button("Clear")
        self["key_blue"]   = Button("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.close, "cancel": self.close, "red": self.close,
                "green":  self.refresh, "yellow": self.clear_log,
                "up":     self.scroll_up, "down": self.scroll_down,
                "left":   self.page_up,   "right": self.page_down,
            }, -1)

        self.onLayoutFinish.append(self.refresh)

    def _call_scroll(self, names):
        w = self["content"]
        for name in names:
            if hasattr(w, name):
                try:
                    getattr(w, name)()
                    return
                except Exception:
                    pass

    def scroll_up(self):   self._call_scroll(["up", "moveUp"])
    def scroll_down(self): self._call_scroll(["down", "moveDown"])
    def page_up(self):     self._call_scroll(["pageUp", "movePageUp"])
    def page_down(self):   self._call_scroll(["pageDown", "movePageDown"])

    def refresh(self):
        try:
            with open(logger.get_log_path(), "r") as f:
                data = f.read()
        except Exception as e:
            data = "Cannot read log: %s" % e

        lines = data.splitlines()
        if len(lines) > 300:
            lines = lines[-300:]

        self["content"].setText("\n".join(lines))
        self["status"].setText(logger.get_log_path())
        self["log_status"].setText("%d lines" % len(lines))

    def clear_log(self):
        try:
            logger.clear()
        except Exception as e:
            logger.log("LogViewer", "Clear error: %s" % e)
        self.refresh()