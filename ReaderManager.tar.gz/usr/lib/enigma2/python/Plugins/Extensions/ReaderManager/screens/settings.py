# -*- coding: utf-8 -*-
"""
screens/settings.py — جميع شاشات الإعدادات.

يحتوي على:
    - BaseSetupScreen    : الشاشة الأساسية المشتركة
    - GeneralSettings    : الإعدادات العامة + خيارات التحديث التلقائي
    - OscamSettings      : إعدادات OSCam WebIF
    - NcamSettings       : إعدادات NCam WebIF
    - SettingsMenu       : ⭐ قائمة الإعدادات على شكل Grid 4×2
                            مع أيقونات PNG حقيقية من مجلد icons/
                            قسم Diagnostics يستدعي DiagnosticsScreen
"""
from __future__ import absolute_import, print_function, unicode_literals

import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.MenuList import MenuList
from Components.ConfigList import ConfigListScreen
from Components.config import config, getConfigListEntry
from Tools.LoadPixmap import LoadPixmap

from enigma import (
    eListbox, eListboxPythonMultiContent, gFont, eTimer,
    RT_HALIGN_LEFT, RT_VALIGN_CENTER, RT_HALIGN_CENTER
)

from Components.MultiContent import MultiContentEntryText
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except ImportError:
    from Components.MultiContent import MultiContentEntryPixmapAlphaTest as MultiContentEntryPixmapAlphaBlend

try:
    from Components.MultiContent import MultiContentEntryRectangle
    HAS_RECT = True
except ImportError:
    HAS_RECT = False

from .developer_select import DeveloperSelectScreen
from ..utils import logger
from ..utils import oscamapi
from ..utils import ncamapi
from ..utils import restart_oscam
from ..utils import restart_ncam
from ..utils.paths import bootstrap as _paths_bootstrap
from ..core.helpers import validate_url
from ..core.webif_updater import apply_webif_settings
from ..core.softcam_detect import (
    detect_active_softcam, is_oscam_active, is_ncam_active,
    get_status_for_active
)

from ..utils.skin_loader import get_screen_skin


# ═══════════════════════════════════════════════════════════════════
#  مسارات ملفات الإعدادات
# ═══════════════════════════════════════════════════════════════════
_bootstrap = _paths_bootstrap()
CONFIG_DIR      = _bootstrap["config_dir"]
OSCAM_CONF_FILE = os.path.join(CONFIG_DIR, "oscam.conf")
NCAM_CONF_FILE  = os.path.join(CONFIG_DIR, "ncam.conf")


# ═══════════════════════════════════════════════════════════════════
#  أبعاد Grid — مطابقة لـ DeveloperSelectScreen
# ═══════════════════════════════════════════════════════════════════
ITEM_W = 290
ITEM_H = 220
ITEM_MARGIN = 6
GRID_COLS = 4

ICON_SIZE = 120
ICON_TOP = 8

BAR_H = 84
BAR_Y = ITEM_H - BAR_H

# ── ألوان معتمة 100% ──
COLOR_BG_NORMAL   = 0x0E1E3C
COLOR_BG_SELECTED = 0x1E3A5F
COLOR_BAR         = 0x0A2428
COLOR_BORDER_SEL  = 0xFFC93C
COLOR_NAME        = 0xFFFFFF
COLOR_DESC        = 0x88FF88
COLOR_ICON_TEXT   = 0x66CCFF


def _utf8(s):
    if s is None:
        return ""
    try:
        if isinstance(s, unicode):
            return s.encode('utf-8')
    except NameError:
        if isinstance(s, bytes):
            return s.decode('utf-8', 'ignore')
    if isinstance(s, str):
        return s
    return str(s)


# ═══════════════════════════════════════════════════════════════════
#  Helper: ضمان وجود إعدادات التحديث
# ═══════════════════════════════════════════════════════════════════
def _ensure_update_config():
    try:
        from Components.config import (
            ConfigYesNo, ConfigInteger, ConfigSelection)

        m = config.plugins.OscamReaderManager

        if not hasattr(m, "update_auto_check"):
            m.update_auto_check = ConfigYesNo(default=True)

        if not hasattr(m, "update_check_interval"):
            m.update_check_interval = ConfigSelection(
                choices=[
                    ("daily",   "Daily"),
                    ("weekly",  "Weekly"),
                    ("monthly", "Monthly"),
                ],
                default="daily")

        if not hasattr(m, "update_show_banner"):
            m.update_show_banner = ConfigYesNo(default=True)

        if not hasattr(m, "update_last_check"):
            m.update_last_check = ConfigInteger(default=0)

        return True
    except Exception as e:
        logger.log("Settings", "_ensure_update_config error: %s" % e)
        return False


_ensure_update_config()


# ═══════════════════════════════════════════════════════════════════
#  BaseSetupScreen — الشاشة الأساسية المشتركة
# ═══════════════════════════════════════════════════════════════════
class BaseSetupScreen(ConfigListScreen, Screen):
    screen_name = "BaseSetup"

    def __init__(self, session, title, subtitle, config_list,
                 yellow_label="", blue_label=""):
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session
        self._config_list = config_list or []

        self["section_title"] = Label(title)
        self["status"]        = Label(subtitle or get_status_for_active())
        self["key_red"]       = Button("Cancel")
        self["key_green"]     = Button("Save")
        self["key_yellow"]    = Button(yellow_label or "")

        ConfigListScreen.__init__(self, self._config_list, session=session)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "cancel": self.cancel,
                "red":    self.cancel,
                "green":  self.save,
                "ok":     self.save,
                "yellow": self.yellow_action,
                "blue":   self.blue_action,
            }, -1)

    def yellow_action(self):
        pass

    def blue_action(self):
        pass

    def save(self):
        errors = []
        try:
            for x in self["config"].list:
                x[1].save()
            config.plugins.OscamReaderManager.save()
        except Exception as e:
            errors.append(str(e))
            logger.log("Setup", "Save error: %s" % e)

        if errors:
            self.session.open(MessageBox,
                "Save failed:\n%s" % "\n".join(errors),
                MessageBox.TYPE_ERROR, timeout=5)
        else:
            self.close(True)

    def cancel(self):
        try:
            for x in self["config"].list:
                x[1].cancel()
        except Exception:
            pass
        self.close(False)


# ═══════════════════════════════════════════════════════════════════
#  GeneralSettings — الإعدادات العامة + خيارات التحديث التلقائي
# ═══════════════════════════════════════════════════════════════════
class GeneralSettings(BaseSetupScreen):
    screen_name = "BaseSetup"
    def __init__(self, session):
        # تأكد من وجود الإعدادات
        _ensure_update_config()

        lst = [
            # ─── الإعدادات العامة ───
            getConfigListEntry("Poll Interval (sec)",
                config.plugins.OscamReaderManager.poll_interval),
            getConfigListEntry("Sort readers",
                config.plugins.OscamReaderManager.sort_mode),
            getConfigListEntry("Editor Mode",
                config.plugins.OscamReaderManager.default_editor_mode),
            getConfigListEntry("Auto restart after changes",
                config.plugins.OscamReaderManager.auto_restart),
            getConfigListEntry("Restart delay",
                config.plugins.OscamReaderManager.restart_delay),
            getConfigListEntry("Confirm before restart",
                config.plugins.OscamReaderManager.confirm_restart),

            # ─── ⭐ إعدادات التحديث التلقائي ───
            getConfigListEntry("Auto-check for updates",
                config.plugins.OscamReaderManager.update_auto_check),
            getConfigListEntry("Update check interval",
                config.plugins.OscamReaderManager.update_check_interval),
            getConfigListEntry("Show update notification",
                config.plugins.OscamReaderManager.update_show_banner),
        ]
        BaseSetupScreen.__init__(self, session,
            title="General Settings",
            subtitle="Reader Manager - General",
            config_list=lst,
            yellow_label="Check now")

    def yellow_action(self):
        """
        فتح شاشة التحديث مباشرة (يدوياً).
        """
        try:
            from .update_screen import UpdateScreen
            self.session.openWithCallback(
                self._after_update_screen,
                UpdateScreen,
                auto_check=True)
        except Exception as e:
            logger.log("GeneralSettings",
                       "yellow_action error: %s" % e)

    def _after_update_screen(self, *args, **kwargs):
        """يُستدعى عند إغلاق UpdateScreen."""
        logger.log("GeneralSettings", "_after_update_screen called")


# ═══════════════════════════════════════════════════════════════════
#  OscamSettings
# ═══════════════════════════════════════════════════════════════════
class OscamSettings(BaseSetupScreen):
    screen_name = "BaseSetup"
    def __init__(self, session):
        self._old_url  = config.plugins.OscamReaderManager.oscam_url.value
        self._old_user = config.plugins.OscamReaderManager.oscam_user.value
        self._old_pwd  = config.plugins.OscamReaderManager.oscam_pass.value

        lst = [
            getConfigListEntry("Enable OSCam WebIF",
                config.plugins.OscamReaderManager.oscam_enabled),
            getConfigListEntry("Auto-detect (oscam.version)",
                config.plugins.OscamReaderManager.oscam_autoconf),
            getConfigListEntry("WebIF URL",
                config.plugins.OscamReaderManager.oscam_url),
            getConfigListEntry("Username",
                config.plugins.OscamReaderManager.oscam_user),
            getConfigListEntry("Password",
                config.plugins.OscamReaderManager.oscam_pass),
            getConfigListEntry("Timeout (sec)",
                config.plugins.OscamReaderManager.oscam_timeout),
        ]
        BaseSetupScreen.__init__(self, session,
            title="OSCam WebIF Settings",
            subtitle="Reader Manager - OSCam",
            config_list=lst,
            yellow_label="Test OSCam")

    def save(self):
        errors = []
        try:
            for x in self["config"].list:
                x[1].save()
            config.plugins.OscamReaderManager.save()
        except Exception as e:
            errors.append(str(e))
            logger.log("Setup", "Save error: %s" % e)

        if errors:
            self.session.open(MessageBox,
                "Save failed:\n%s" % "\n".join(errors),
                MessageBox.TYPE_ERROR, timeout=5)
            return

        new_url  = config.plugins.OscamReaderManager.oscam_url.value
        new_user = config.plugins.OscamReaderManager.oscam_user.value
        new_pwd  = config.plugins.OscamReaderManager.oscam_pass.value

        if (new_url, new_user, new_pwd) == (
                self._old_url, self._old_user, self._old_pwd):
            self.close(True)
            return

        ok, msg, changed = apply_webif_settings(
            "oscam", OSCAM_CONF_FILE, NCAM_CONF_FILE,
            config.plugins.OscamReaderManager)

        if not ok:
            self.session.open(
                MessageBox,
                "Plugin settings saved, but failed to update oscam.conf:\n%s"
                % msg,
                MessageBox.TYPE_ERROR, timeout=8)
            self.close(True)
            return

        if not changed:
            self.close(True)
            return

        active = detect_active_softcam()
        if is_oscam_active(active):
            logger.log("WebIF",
                       "Restarting OSCam to apply new WebIF settings")
            try:
                restart_oscam.restart_silent()
            except Exception as e:
                logger.log("WebIF", "restart_oscam failed: %s" % e)

        self.session.open(
            MessageBox,
            "OSCam WebIF settings updated in oscam.conf.\n"
            "SoftCam will be restarted if active.",
            MessageBox.TYPE_INFO, timeout=5)

        self.close(True)

    def yellow_action(self):
        url = config.plugins.OscamReaderManager.oscam_url.value
        user = config.plugins.OscamReaderManager.oscam_user.value
        pwd = config.plugins.OscamReaderManager.oscam_pass.value
        try:
            timeout = float(
                config.plugins.OscamReaderManager.oscam_timeout.value)
        except (TypeError, ValueError):
            timeout = 5.0

        ok, err = validate_url(url)
        if not ok:
            self.session.open(MessageBox,
                "Invalid URL: %s" % err,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        self["status"].setText("Testing OSCam...")
        lines = ["=== OSCam WebIF Test ===", ""]
        try:
            api = oscamapi.OSCamAPI(url, user, pwd, timeout=timeout)
            readers = api.get_reader_status()
            if readers:
                method = api.get_last_method() or "?"
                lines.append("OK - %d reader(s) via %s"
                             % (len(readers), method))
                lines.append("")
                for r in readers[:10]:
                    lines.append("* %s -> %s [%d cards]"
                                 % (r.label, r.status, r.card_count))
                self["status"].setText(
                    "OSCam OK: %d readers" % len(readers))
            else:
                err_msg = api.get_last_error()
                lines.append("EMPTY response")
                lines.append(err_msg or "no readers found")
                self["status"].setText("OSCam failed")
        except Exception as e:
            lines.append("FAILED: %s" % e)
            self["status"].setText("OSCam failed")

        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=15)


# ═══════════════════════════════════════════════════════════════════
#  NcamSettings
# ═══════════════════════════════════════════════════════════════════
class NcamSettings(BaseSetupScreen):
    screen_name = "BaseSetup"    
    def __init__(self, session):
        self._old_url  = config.plugins.OscamReaderManager.ncam_url.value
        self._old_user = config.plugins.OscamReaderManager.ncam_user.value
        self._old_pwd  = config.plugins.OscamReaderManager.ncam_pass.value

        lst = [
            getConfigListEntry("Enable NCam WebIF",
                config.plugins.OscamReaderManager.ncam_enabled),
            getConfigListEntry("Auto-detect (ncam.version)",
                config.plugins.OscamReaderManager.ncam_autoconf),
            getConfigListEntry("WebIF URL",
                config.plugins.OscamReaderManager.ncam_url),
            getConfigListEntry("Username",
                config.plugins.OscamReaderManager.ncam_user),
            getConfigListEntry("Password",
                config.plugins.OscamReaderManager.ncam_pass),
            getConfigListEntry("Timeout (sec)",
                config.plugins.OscamReaderManager.ncam_timeout),
        ]
        BaseSetupScreen.__init__(self, session,
            title="NCam WebIF Settings",
            subtitle="Reader Manager - NCam",
            config_list=lst,
            yellow_label="Test NCam")

    def save(self):
        errors = []
        try:
            for x in self["config"].list:
                x[1].save()
            config.plugins.OscamReaderManager.save()
        except Exception as e:
            errors.append(str(e))
            logger.log("Setup", "Save error: %s" % e)

        if errors:
            self.session.open(MessageBox,
                "Save failed:\n%s" % "\n".join(errors),
                MessageBox.TYPE_ERROR, timeout=5)
            return

        new_url  = config.plugins.OscamReaderManager.ncam_url.value
        new_user = config.plugins.OscamReaderManager.ncam_user.value
        new_pwd  = config.plugins.OscamReaderManager.ncam_pass.value

        if (new_url, new_user, new_pwd) == (
                self._old_url, self._old_user, self._old_pwd):
            self.close(True)
            return

        ok, msg, changed = apply_webif_settings(
            "ncam", OSCAM_CONF_FILE, NCAM_CONF_FILE,
            config.plugins.OscamReaderManager)

        if not ok:
            self.session.open(
                MessageBox,
                "Plugin settings saved, but failed to update ncam.conf:\n%s"
                % msg,
                MessageBox.TYPE_ERROR, timeout=8)
            self.close(True)
            return

        if not changed:
            self.close(True)
            return

        active = detect_active_softcam()
        if is_ncam_active(active):
            logger.log("WebIF",
                       "Restarting NCam to apply new WebIF settings")
            try:
                restart_ncam.restart_silent()
            except Exception as e:
                logger.log("WebIF", "restart_ncam failed: %s" % e)

        self.session.open(
            MessageBox,
            "NCam WebIF settings updated in ncam.conf.\n"
            "SoftCam will be restarted if active.",
            MessageBox.TYPE_INFO, timeout=5)

        self.close(True)

    def yellow_action(self):
        url = config.plugins.OscamReaderManager.ncam_url.value
        user = config.plugins.OscamReaderManager.ncam_user.value
        pwd = config.plugins.OscamReaderManager.ncam_pass.value
        try:
            timeout = float(
                config.plugins.OscamReaderManager.ncam_timeout.value)
        except (TypeError, ValueError):
            timeout = 5.0

        ok, err = validate_url(url)
        if not ok:
            self.session.open(MessageBox,
                "Invalid URL: %s" % err,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        self["status"].setText("Testing NCam...")
        lines = ["=== NCam WebIF Test ===", ""]
        try:
            api = ncamapi.NCamAPI(url, user, pwd, timeout=timeout)
            readers = api.get_reader_status(fetch_cards=True)
            if readers:
                method = api.get_last_method() or "?"
                lines.append("OK - %d reader(s) via %s"
                             % (len(readers), method))
                lines.append("")
                for r in readers[:10]:
                    lines.append("* %s -> %s [%d cards]"
                                 % (r.label, r.status, r.card_count))
                self["status"].setText(
                    "NCam OK: %d readers" % len(readers))
            else:
                err_msg = api.get_last_error()
                lines.append("EMPTY response")
                lines.append(err_msg or "no readers found")
                self["status"].setText("NCam failed")
        except Exception as e:
            lines.append("FAILED: %s" % e)
            self["status"].setText("NCam failed")

        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=15)


# ═══════════════════════════════════════════════════════════════════
#  SettingsMenu — Grid 4×2 مع أيقونات PNG حقيقية
# ═══════════════════════════════════════════════════════════════════
class SettingsMenu(Screen):
    screen_name = "SettingsMenu"

    def __init__(self, session, on_emu_change=None):
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session
        self._on_emu_change = on_emu_change

        self["active_cam"] = Label("")
        self["status"]     = Label("Choose a category — OK to open")
        self["page_info"]  = Label("")
        self["key_red"]    = Button("Close")
        self["key_green"]  = Button("Open")
        self["key_yellow"] = Button("Refresh")
        self["key_blue"]   = Button("Info")

        # ── MenuList بوضع Grid ──
        try:
            self["list_menu"] = MenuList(
                [],
                mode=getattr(eListbox, 'layoutGrid', 2),
                content=eListboxPythonMultiContent,
                itemWidth=ITEM_W,
                itemHeight=ITEM_H
            )
        except TypeError:
            self["list_menu"] = MenuList([], content=eListboxPythonMultiContent)
            try: self["list_menu"].l.setItemHeight(ITEM_H)
            except Exception: pass
            try: self["list_menu"].l.setItemWidth(ITEM_W)
            except Exception: pass
            try: self["list_menu"].l.setMode(2)
            except Exception: pass

        # ── الخطوط ──
        self["list_menu"].l.setFont(0, gFont("Regular", 35))   # اسم العنصر
        self["list_menu"].l.setFont(1, gFont("Regular", 25))   # وصف
        self["list_menu"].l.setFont(2, gFont("Regular", 48))   # بديل نصي

        # ── setBuildFunc ──
        try:
            self["list_menu"].l.setBuildFunc(self._build_row, True)
        except TypeError:
            self["list_menu"].l.setBuildFunc(self._build_row)

        # ⭐ العناصر — (label, key, icon_file, description)
        self._menu_items = [
            ("General",     "general",   "general.png",     "Polling / Sort / Updates"),
            ("OSCam WebIF", "oscam",     "oscam.png",       "URL / User / Password"),
            ("NCam WebIF",  "ncam",      "ncam.png",        "URL / User / Password"),
            ("Emulators",   "emulators", "emulators.png",   "Manage installed emus"),
            ("Install",     "install",   "install.png",     "Download emulators"),
            ("Updates",     "updates",   "update.png",      "Check for plugin updates"),
            ("Diagnostics", "diag",      "diagnostics.png", "Stats / Fastest / Providing"),
            ("About",       "about",     "about.png",       "Plugin info & credits"),
        ]

        # ── مسار الأيقونات ──
        self._icons_dir = self._resolve_icons_dir()

        # ── بناء بيانات العناصر + تحميل الأيقونات مسبقاً ──
        self._avatar_cache = {}
        self._items_data = []
        for label, key, icon_file, desc in self._menu_items:
            pix = self._load_icon(icon_file)
            self._avatar_cache[key] = pix
            self._items_data.append({
                "label":     label,
                "key":       key,
                "icon_file": icon_file,
                "icon":      label[:1].upper(),
                "desc":      desc,
            })

        self.current_index = 0
        self._timers = []

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok":     self.open_selected,
                "green":  self.open_selected,
                "cancel": self.close,
                "red":    self.close,
                "yellow": self.refresh_info,
                "blue":   self.show_info,
                "up":     self.move_up,
                "down":   self.move_down,
                "left":   self.move_left,
                "right":  self.move_right,
            }, -1)

        try:
            self["list_menu"].onSelectionChanged.append(
                self._on_selection_changed)
        except Exception:
            pass

        self.onLayoutFinish.append(self._on_start)

    # ============================================================
    #  مسار الأيقونات — بحث مرن
    # ============================================================
    def _resolve_icons_dir(self):
        """
        يبحث عن مجلد icons في عدة مسارات محتملة:
          1. ~/ReaderManager/icons
          2. <plugin_dir>/icons
          3. <plugin_dir>/images/settings
          4. <plugin_dir>/images
          5. مسارات Enigma2 الشائعة
        """
        candidates = []

        # 1) من ملف المستخدم
        try:
            home = os.path.expanduser("~")
            candidates.append(os.path.join(home, "ReaderManager", "icons"))
        except Exception:
            pass

        # 2) بجانب الملف الحالي
        try:
            here = os.path.dirname(os.path.abspath(__file__))
            plugin_dir = os.path.dirname(here)
            candidates.append(os.path.join(plugin_dir, "icons"))
            candidates.append(os.path.join(plugin_dir, "images", "settings"))
            candidates.append(os.path.join(plugin_dir, "images"))
        except Exception:
            pass

        # 3) مسارات Enigma2 الشائعة
        candidates += [
            "/usr/lib/enigma2/python/Plugins/Extensions/ReaderManager/icons",
            "/usr/lib/enigma2/python/Plugins/Extensions/OscamReaderManager/icons",
        ]

        for c in candidates:
            try:
                if c and os.path.isdir(c):
                    logger.log("SettingsMenu",
                               "icons dir = %s" % c)
                    return c
            except Exception:
                continue

        logger.log("SettingsMenu", "No icons dir found — using fallback")
        return None

    def _load_icon(self, filename):
        """يحمّل أيقونة PNG من مجلد icons."""
        if not self._icons_dir or not filename:
            return None
        path = os.path.join(self._icons_dir, filename)
        if not os.path.isfile(path):
            logger.log("SettingsMenu",
                       "icon missing: %s" % path)
            return None
        try:
            pix = LoadPixmap(path)
            return pix
        except Exception as e:
            logger.log("SettingsMenu",
                       "load icon failed %s: %s" % (path, e))
            return None

    # ============================================================
    def _on_start(self):
        self._render_list()
        self._update_active_cam()

    def _update_active_cam(self):
        try:
            active = detect_active_softcam()
            status = get_status_for_active()
            name = (active or {}).get("name", "") if active else ""
            ver  = (active or {}).get("version", "") if active else ""
            text = "Active: %s %s | %s" % (name or "-", ver or "", status)
            self["active_cam"].setText(text)
        except Exception:
            self["active_cam"].setText("Active: -")

    # ============================================================
    def _add_rect(self, res, x, y, w, h, color):
        if HAS_RECT:
            try:
                res.append(MultiContentEntryRectangle(
                    pos=(x, y), size=(w, h), backcolor=color))
                return
            except Exception:
                pass
        res.append(MultiContentEntryText(
            pos=(x, y), size=(w, h),
            font=0, backcolor=color, color=color,
            text=" "))

    def _build_row(self, item, selected=False):
        if isinstance(item, tuple) and len(item) > 0:
            data = item[0]
        else:
            data = item

        if not isinstance(data, dict):
            return [None, MultiContentEntryText(
                pos=(0, 0), size=(ITEM_W, ITEM_H), font=0,
                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                color=0xFFFFFFFF,
                text=_utf8(str(data)))]

        label = data.get("label", "?")
        desc  = data.get("desc", "")
        key   = data.get("key", "")
        icon  = data.get("icon", label[:1].upper())

        bg_col = COLOR_BG_SELECTED if selected else COLOR_BG_NORMAL
        res = [data]

        # خلفية الخلية
        self._add_rect(res, 0, 0, ITEM_W, ITEM_H, bg_col)

        # ⭐ الأيقونة PNG (أو بديل نصي)
        pix = self._avatar_cache.get(key)
        icon_x = (ITEM_W - ICON_SIZE) // 2
        icon_y = ICON_TOP

        if pix:
            res.append(MultiContentEntryPixmapAlphaBlend(
                pos=(icon_x, icon_y),
                size=(ICON_SIZE, ICON_SIZE),
                png=pix))
        else:
            res.append(MultiContentEntryText(
                pos=(icon_x, icon_y),
                size=(ICON_SIZE, ICON_SIZE),
                font=2,
                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                color=COLOR_ICON_TEXT,
                text=_utf8(icon)))

        # الشريط السفلي
        self._add_rect(res, 0, BAR_Y, ITEM_W, BAR_H, COLOR_BAR)

        # الاسم
        res.append(MultiContentEntryText(
            pos=(2, BAR_Y + 2), size=(ITEM_W - 4, 40),
            font=0,
            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            color=COLOR_NAME,
            text=_utf8(label)))

        # الوصف
        res.append(MultiContentEntryText(
            pos=(2, BAR_Y + 42), size=(ITEM_W - 4, 34),
            font=1,
            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            color=COLOR_DESC,
            text=_utf8(desc)))

        # إطار التحديد
        if selected:
            self._add_rect(res, 0, 0, ITEM_W, 3, COLOR_BORDER_SEL)
            self._add_rect(res, 0, ITEM_H - 3, ITEM_W, 3, COLOR_BORDER_SEL)
            self._add_rect(res, 0, 0, 3, ITEM_H, COLOR_BORDER_SEL)
            self._add_rect(res, ITEM_W - 3, 0, 3, ITEM_H, COLOR_BORDER_SEL)

        return res

    # ============================================================
    def _render_list(self):
        rows = [(d,) for d in self._items_data]
        self["list_menu"].setList(rows)

        if self._items_data:
            idx = min(self.current_index, len(self._items_data) - 1)
            if idx < 0:
                idx = 0
            self.current_index = idx
            try:
                self["list_menu"].moveToIndex(idx)
            except Exception:
                pass

        self["page_info"].setText("%d option(s)" % len(self._items_data))

    # ============================================================
    def _getCurrent(self):
        try:
            c = self["list_menu"].getCurrent()
            if c is None:
                return None
            if isinstance(c, tuple) and len(c) > 0:
                return c[0]
            return c
        except Exception:
            return None

    def _on_selection_changed(self):
        try:
            idx = self["list_menu"].getSelectedIndex()
            if idx is not None and idx >= 0:
                self.current_index = idx
        except Exception:
            pass

    # ── تنقّل شبكي 4 أعمدة ──
    def move_up(self):
        if not self._items_data:
            return
        idx = self.current_index - GRID_COLS
        if idx < 0:
            last_row_start = ((len(self._items_data) - 1) // GRID_COLS) * GRID_COLS
            idx = min(last_row_start + (self.current_index % GRID_COLS),
                      len(self._items_data) - 1)
        self.current_index = max(0, idx)
        try:
            self["list_menu"].moveToIndex(self.current_index)
        except Exception:
            pass

    def move_down(self):
        if not self._items_data:
            return
        idx = self.current_index + GRID_COLS
        if idx >= len(self._items_data):
            idx = self.current_index % GRID_COLS
            if idx >= len(self._items_data):
                idx = 0
        self.current_index = idx
        try:
            self["list_menu"].moveToIndex(self.current_index)
        except Exception:
            pass

    def move_left(self):
        if not self._items_data:
            return
        idx = self.current_index - 1
        if idx < 0:
            idx = len(self._items_data) - 1
        self.current_index = idx
        try:
            self["list_menu"].moveToIndex(idx)
        except Exception:
            pass

    def move_right(self):
        if not self._items_data:
            return
        idx = self.current_index + 1
        if idx >= len(self._items_data):
            idx = 0
        self.current_index = idx
        try:
            self["list_menu"].moveToIndex(idx)
        except Exception:
            pass

    # ============================================================
    def open_selected(self):
        data = self._getCurrent()
        if not isinstance(data, dict):
            return
        key = data.get("key", "")

        try:
            if key == "general":
                self.session.openWithCallback(
                    self._after_general, GeneralSettings)
            elif key == "oscam":
                self.session.open(OscamSettings)
            elif key == "ncam":
                self.session.open(NcamSettings)
            elif key == "emulators":
                from .emulator_screen import EmulatorManagerScreen
                self.session.openWithCallback(
                    self._after_emulators,
                    EmulatorManagerScreen,
                    self._on_emu_change)
            elif key == "install":
                self.session.openWithCallback(
                    self._after_install_screen,
                    DeveloperSelectScreen,
                    self._on_emu_change)
            elif key == "updates":
                from .update_screen import UpdateScreen
                self.session.openWithCallback(
                    self._after_update_screen,
                    UpdateScreen,
                    auto_check=True)
            elif key == "diag":
                # ⭐ شاشة الإحصائيات والتشخيص الكاملة
                from .diagnostics import DiagnosticsScreen
                self.session.openWithCallback(
                    self._after_diagnostics,
                    DiagnosticsScreen)
            elif key == "about":
                self._show_about()
        except Exception as e:
            logger.log("SettingsMenu", "Open error: %s" % e)
            self.session.open(MessageBox,
                "Failed to open: %s" % e,
                MessageBox.TYPE_ERROR, timeout=5)

    # ============================================================
    def refresh_info(self):
        self._update_active_cam()
        self._render_list()
        self["status"].setText("Refreshed")

    def show_info(self):
        data = self._getCurrent()
        if not isinstance(data, dict):
            return
        label = data.get("label", "?")
        key = data.get("key", "?")
        desc = data.get("desc", "")
        icon_file = data.get("icon_file", "")
        icon_path = ""
        if self._icons_dir and icon_file:
            icon_path = os.path.join(self._icons_dir, icon_file)

        lines = [
            "Option: %s" % label,
            "Key: %s" % key,
            "",
            desc,
            "",
            "Icon: %s" % (icon_path or "(none)"),
        ]
        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=10)

    # ============================================================
    def _show_about(self):
        lines = [
            "Oscam Reader Manager",
            "",
            "Version: 6.x (grid UI + icons + diagnostics)",
            "",
            "Features:",
            "  • Reader management (OSCam / NCam)",
            "  • WebIF auto-detection",
            "  • Emulator installer",
            "  • Auto-update checker",
            "  • Diagnostics & statistics",
        ]
        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=15)

    # ============================================================
    def _after_general(self, *args, **kwargs):
        logger.log("SettingsMenu", "_after_general called")
        if self._on_emu_change:
            try:
                self._on_emu_change()
            except Exception:
                pass

    def _after_emulators(self, *args, **kwargs):
        if self._on_emu_change:
            try:
                self._on_emu_change()
            except Exception as e:
                logger.log("SettingsMenu",
                           "emu change callback error: %s" % e)

    def _after_install_screen(self, *args, **kwargs):
        logger.log("SettingsMenu", "_after_install_screen called")
        if self._on_emu_change:
            try:
                self._on_emu_change()
            except Exception as e:
                logger.log("SettingsMenu",
                           "install callback error: %s" % e)

    def _after_update_screen(self, *args, **kwargs):
        logger.log("SettingsMenu", "_after_update_screen called")

    def _after_diagnostics(self, *args, **kwargs):
        logger.log("SettingsMenu", "_after_diagnostics called")

    # ============================================================
    def close(self):
        for t in self._timers:
            try:
                t.stop()
            except Exception:
                pass
        self._timers = []
        Screen.close(self)