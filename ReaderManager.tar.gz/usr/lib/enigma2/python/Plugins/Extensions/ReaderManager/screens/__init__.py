# -*- coding: utf-8 -*-
"""
screens — شاشات Enigma2 للبلوجين.

يحتوي على:
    - settings.py         : BaseSetupScreen + General + OSCam + NCam + Menu
    - log_viewer.py       : LogViewer
    - emulator_screen.py  : EmulatorManagerScreen
    - reader_manager.py   : ReaderManager (الشاشة الرئيسية)
"""
from __future__ import absolute_import, print_function, unicode_literals


__all__ = [
    "settings",
    "log_viewer",
    "emulator_screen",
    "reader_manager",
    "update_screen",
    "install_emulator",
    "devloper_select"
]