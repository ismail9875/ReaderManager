# -*- coding: utf-8 -*-
"""
utils/reader_bench.py — قياس سرعة استجابة WebIF لكل قارئ.

v2.1 (نهائي):
    - يدعم progress_callback
    - يدعم OSCam و NCam
    - قياس متوازي مع semaphore
    - دعم cancel_check للإلغاء الآمن
    - fallback آمن عند فشل endpoint
"""
from __future__ import absolute_import, print_function, unicode_literals

import time
import threading

try:
    from urllib2 import (build_opener, Request, HTTPHandler,
                         HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                         HTTPDigestAuthHandler, URLError, HTTPError)
    from urllib import quote
except ImportError:
    from urllib.request import (build_opener, Request, HTTPHandler,
                                 HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                                 HTTPDigestAuthHandler)
    from urllib.error import URLError, HTTPError
    from urllib.parse import quote

try:
    import base64
except ImportError:
    pass

from . import logger


# ═══════════════════════════════════════════════════════════════════
#  الإعدادات
# ═══════════════════════════════════════════════════════════════════
DEFAULT_SAMPLES   = 3
DEFAULT_TIMEOUT   = 3.0
MAX_PARALLEL      = 4


# ═══════════════════════════════════════════════════════════════════
#  HTTP Helpers
# ═══════════════════════════════════════════════════════════════════
def _make_opener(username="", password="", base_url=""):
    """يبني opener مع Basic Auth إن لزم."""
    if username and password:
        pwman = HTTPPasswordMgrWithDefaultRealm()
        pwman.add_password(None, base_url, username, password)
        authhandler = HTTPDigestAuthHandler(pwman)
        return build_opener(HTTPHandler, authhandler)
    return build_opener(HTTPHandler)


def _http_get_timed(base_url, path, username="", password="",
                    timeout=DEFAULT_TIMEOUT):
    """
    يرسل طلب HTTP ويُرجع (elapsed_ms, success, error).

    Args:
        base_url: مثل http://127.0.0.1:8888
        path: مثل /oscamapi.html?part=entitlement&label=xxx

    Returns:
        (elapsed_ms, success_bool, error_string)
    """
    if not base_url:
        return 0.0, False, "no base_url"

    url = "%s%s" % (base_url, path)

    # Cache buster
    sep = "&" if "?" in url else "?"
    url += "%s_t=%d" % (sep, int(time.time() * 1000))

    headers = {
        "User-Agent": "Enigma2-ReaderBench/2.1",
        "Accept": "text/html,application/xhtml+xml,application/xml,*/*",
        "Cache-Control": "no-cache, no-store",
        "Pragma": "no-cache",
    }

    # Basic auth
    if username:
        creds = "%s:%s" % (username, password)
        try:
            token = base64.b64encode(creds.encode("utf-8")).decode("ascii")
        except Exception:
            token = base64.b64encode(creds)
            if isinstance(token, bytes):
                token = token.decode("ascii")
        headers["Authorization"] = "Basic %s" % token

    t0 = time.time()
    try:
        req = Request(url, headers=headers)
        opener = _make_opener(username, password, base_url)
        resp = opener.open(req, timeout=timeout)
        resp.read()
        t1 = time.time()
        elapsed_ms = (t1 - t0) * 1000.0
        return elapsed_ms, True, ""
    except HTTPError as e:
        t1 = time.time()
        return (t1 - t0) * 1000.0, False, "HTTP %d" % e.code
    except URLError as e:
        t1 = time.time()
        return (t1 - t0) * 1000.0, False, "URLError: %s" % e.reason
    except Exception as e:
        t1 = time.time()
        return (t1 - t0) * 1000.0, False, str(e)


# ═══════════════════════════════════════════════════════════════════
#  قياس قارئ واحد
# ═══════════════════════════════════════════════════════════════════
def bench_reader(reader_label, base_url, username="", password="",
                 samples=DEFAULT_SAMPLES, timeout=DEFAULT_TIMEOUT,
                 softcam_type="oscam"):
    """
    يقيس زمن استجابة قارئ واحد عبر endpoint entitlement.

    Args:
        reader_label: اسم القارئ (label)
        base_url:     عنوان WebIF
        username:     مصادقة
        password:     مصادقة
        samples:      عدد الطلبات
        timeout:      مهلة كل طلب (ثوان)
        softcam_type: "oscam" أو "ncam"

    Returns:
        dict:
            {
                "label":         str,
                "avg_time_ms":   float,
                "min_time_ms":   float,
                "max_time_ms":   float,
                "samples":       list of float,
                "success_count": int,
                "fail_count":    int,
                "errors":        list of str,
            }
    """
    result = {
        "label":         reader_label,
        "avg_time_ms":   0.0,
        "min_time_ms":   0.0,
        "max_time_ms":   0.0,
        "samples":       [],
        "success_count": 0,
        "fail_count":    0,
        "errors":        [],
    }

    if not reader_label or not base_url:
        return result

    # ─── اختر endpoint حسب نوع المحاكي ───
    if softcam_type == "ncam":
        path = "/ncamapi.html?part=entitlement&label=%s" % quote(reader_label)
    else:
        path = "/oscamapi.html?part=entitlement&label=%s" % quote(reader_label)

    success_times = []

    for _ in range(samples):
        elapsed, ok, err = _http_get_timed(
            base_url, path,
            username=username, password=password,
            timeout=timeout)
        if ok:
            success_times.append(elapsed)
            result["success_count"] += 1
        else:
            result["fail_count"] += 1
            if err and err not in result["errors"]:
                result["errors"].append(err)

    if success_times:
        result["samples"] = success_times
        result["avg_time_ms"] = sum(success_times) / len(success_times)
        result["min_time_ms"] = min(success_times)
        result["max_time_ms"] = max(success_times)

    return result


# ═══════════════════════════════════════════════════════════════════
#  قياس كل القراء (متوازي)
# ═══════════════════════════════════════════════════════════════════
def bench_all_readers(reader_labels, base_url, username="", password="",
                      samples=DEFAULT_SAMPLES, timeout=DEFAULT_TIMEOUT,
                      max_parallel=MAX_PARALLEL,
                      cancel_check=None,
                      progress_callback=None,
                      softcam_type="oscam"):
    """
    يقيس كل القراء مع التحكم في التوازي.

    Args:
        reader_labels:     قائمة أسماء القراء
        base_url:          عنوان WebIF
        username:          مصادقة
        password:          مصادقة
        samples:           عدد الطلبات لكل قارئ
        timeout:           مهلة كل طلب
        max_parallel:      أقصى عدد قياسات متزامنة
        cancel_check:      دالة تُرجع True إذا يجب الإلغاء
        progress_callback: دالة(done, total) تُستدعى بعد كل قياس
        softcam_type:      "oscam" أو "ncam"

    Returns:
        dict: {label: bench_result_dict}
    """
    results = {}
    results_lock = threading.Lock()
    semaphore = threading.Semaphore(max_parallel)
    total = len(reader_labels)

    logger.log("ReaderBench",
               "bench_all_readers: labels=%d, parallel=%d, samples=%d"
               % (total, max_parallel, samples))

    def _worker(label):
        if cancel_check and cancel_check():
            return
        with semaphore:
            if cancel_check and cancel_check():
                return
            try:
                r = bench_reader(
                    label, base_url,
                    username=username, password=password,
                    samples=samples, timeout=timeout,
                    softcam_type=softcam_type)
                with results_lock:
                    results[label] = r
                    done = len(results)
                if progress_callback:
                    try:
                        progress_callback(done, total)
                    except Exception as e:
                        logger.log("ReaderBench",
                                   "progress_callback error: %s" % e)
            except Exception as e:
                logger.log("ReaderBench",
                           "worker error %s: %s" % (label, e))
                with results_lock:
                    results[label] = {
                        "label":         label,
                        "avg_time_ms":   0.0,
                        "min_time_ms":   0.0,
                        "max_time_ms":   0.0,
                        "samples":       [],
                        "success_count": 0,
                        "fail_count":    0,
                        "errors":        [str(e)],
                    }
                    done = len(results)
                if progress_callback:
                    try:
                        progress_callback(done, total)
                    except Exception:
                        pass

    threads = []
    for label in reader_labels:
        t = threading.Thread(target=_worker, args=(label,))
        t.setDaemon(True)
        t.start()
        threads.append(t)

    # انتظر انتهاء الكل
    for t in threads:
        t.join(timeout=timeout * samples + 5)

    # ملخص
    success_labels = [k for k, v in results.items()
                      if v.get("success_count", 0) > 0]
    logger.log("ReaderBench",
               "bench_all_readers: done, %d/%d successful"
               % (len(success_labels), total))

    return results


# ═══════════════════════════════════════════════════════════════════
#  دمج النتائج في ReaderStatus
# ═══════════════════════════════════════════════════════════════════
def apply_bench_to_readers(readers_status_list, bench_results):
    """
    يُحدّث avg_time_ms / min_time_ms / max_time_ms في كل ReaderStatus.

    Args:
        readers_status_list: list of ReaderStatus
        bench_results: dict {label: bench_result_dict}
    """
    if not readers_status_list or not bench_results:
        return

    applied = 0
    for reader in readers_status_list:
        label = getattr(reader, "label", None)
        if not label:
            continue
        bench = bench_results.get(label)
        if not bench:
            continue
        if bench.get("success_count", 0) == 0:
            continue
        try:
            reader.avg_time_ms = bench.get("avg_time_ms", 0.0)
            reader.min_time_ms = bench.get("min_time_ms", 0.0)
            reader.max_time_ms = bench.get("max_time_ms", 0.0)
            applied += 1
        except Exception:
            pass

    logger.log("ReaderBench",
               "apply_bench: applied to %d/%d readers"
               % (applied, len(readers_status_list)))