# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import glob
import subprocess
import threading

try:
    from io import open
except ImportError:
    pass

try:
    _TimeoutExpired = subprocess.TimeoutExpired
except AttributeError:
    class _TimeoutExpired(Exception):
        pass

from . import logger


# =====================================================================
#  الإعدادات
# =====================================================================
BIN_DIR = "/usr/bin"
INIT_DIR = "/etc/init.d"

BINARY_PATTERNS = [
    r"^oscam(?:[._-].+)?$",
    r"^OSCam(?:[._-].+)?$",
    r"^ncam(?:[._-].+)?$",
    r"^NCam(?:[._-].+)?$",
]

FAMILY_OSCAM = "oscam"
FAMILY_NCAM  = "ncam"

INIT_SCRIPT_PATTERNS = [
    "/etc/init.d/softcam.oscam-*",
    "/etc/init.d/softcam.OSCam-*",
    "/etc/init.d/softcam.oscam",
    "/etc/init.d/softcam.OSCam",
    "/etc/init.d/softcam_oscam*",
    "/etc/init.d/oscam",
    "/etc/init.d/softcam.ncam-*",
    "/etc/init.d/softcam.NCam-*",
    "/etc/init.d/softcam.ncam",
    "/etc/init.d/softcam.NCam",
    "/etc/init.d/softcam_ncam*",
    "/etc/init.d/ncam",
    "/etc/init.d/softcam",
]

CMD_TIMEOUT = 20


# =====================================================================
#  EmulatorInfo
# =====================================================================
class EmulatorInfo(object):
    __slots__ = (
        "key", "name", "family", "version", "binary_path",
        "init_script", "enabled", "running",
        "description", "extra",
    )

    def __init__(self, name, family, binary_path):
        self.key = "emu:%s:%s" % (family, os.path.basename(binary_path))
        self.name = name
        self.family = family
        self.version = ""
        self.binary_path = binary_path
        self.init_script = ""
        self.enabled = False
        self.running = False
        self.description = ""
        self.extra = {}

    def to_dict(self):
        return {
            "key": self.key,
            "name": self.name,
            "family": self.family,
            "version": self.version,
            "binary_path": self.binary_path,
            "init_script": self.init_script,
            "enabled": self.enabled,
            "running": self.running,
        }

    def __repr__(self):
        return "<Emulator %s v%s running=%s>" % (
            self.name, self.version or "?", self.running)


# =====================================================================
#  Helpers — subprocess
# =====================================================================
def _run(cmd, timeout=CMD_TIMEOUT):
    """ينفّذ أمر shell ويُعيد (rc, stdout, stderr)."""
    p = None
    try:
        p = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = p.communicate(timeout=timeout)
        except TypeError:
            result = [b"", b""]

            def _target():
                try:
                    result[0], result[1] = p.communicate()
                except Exception:
                    pass

            t = threading.Thread(target=_target)
            t.setDaemon(True)
            t.start()
            t.join(timeout)
            if t.isAlive():
                try:
                    p.kill()
                except Exception:
                    pass
                return -1, "", "timeout"
            out, err = result

        if isinstance(out, bytes):
            out = out.decode("utf-8", "ignore")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "ignore")
        return p.returncode, out, err
    except _TimeoutExpired:
        if p:
            try:
                p.kill()
            except Exception:
                pass
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)


# =====================================================================
#  EmulatorManager
# =====================================================================
class EmulatorManager(object):
    """يكتشف المحاكيات من /usr/bin ويبني أوامر التحكم من /etc/init.d.

    كل عملية تحكم (start / stop / restart / toggle) تستهدف
    **محاكياً واحداً فقط** يُمرَّر كوسيط (emu).
    """

    def __init__(self, bin_dir=BIN_DIR, init_dir=INIT_DIR):
        self.bin_dir = bin_dir
        self.init_dir = init_dir
        self._cache = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    #  Discovery
    # ------------------------------------------------------------------
    def discover(self, force=False):
        with self._lock:
            if self._cache is not None and not force:
                return self._cache

            emus = []
            seen_paths = set()

            try:
                entries = sorted(os.listdir(self.bin_dir))
            except Exception as e:
                logger.log("EmuManager",
                           "Cannot list %s: %s" % (self.bin_dir, e))
                self._cache = []
                return []

            for fname in entries:
                full_path = os.path.join(self.bin_dir, fname)

                if not os.path.isfile(full_path):
                    continue
                if not os.access(full_path, os.X_OK):
                    continue
                if full_path in seen_paths:
                    continue

                family = self._detect_family(fname)
                if not family:
                    continue

                seen_paths.add(full_path)

                emu = EmulatorInfo(fname, family, full_path)
                emu.version = self._extract_version(emu)
                emu.init_script = self._find_init_script(emu)
                emu.running = self._check_running(emu)
                emu.enabled = emu.running
                emu.description = "%s binary (%s)" % (
                    family.upper(), emu.version or "unknown version")

                emus.append(emu)

            emus.sort(key=lambda e: (
                0 if e.family == FAMILY_OSCAM else 1,
                e.name.lower()))

            self._cache = emus
            logger.log("EmuManager",
                       "Discovered %d emulator(s) in %s"
                       % (len(emus), self.bin_dir))
            return emus

    def refresh(self):
        return self.discover(force=True)

    # ------------------------------------------------------------------
    #  Family detection
    # ------------------------------------------------------------------
    @staticmethod
    def _detect_family(fname):
        low = fname.lower()
        for pattern in BINARY_PATTERNS:
            try:
                if re.match(pattern, fname, re.IGNORECASE):
                    if low.startswith("oscam"):
                        return FAMILY_OSCAM
                    if low.startswith("ncam"):
                        return FAMILY_NCAM
            except Exception:
                continue
        return None

    # ------------------------------------------------------------------
    #  Version extraction
    # ------------------------------------------------------------------
    def _extract_version(self, emu):
        v = self._version_from_name(emu.name)
        if v:
            return v

        v = self._version_from_binary(emu.binary_path)
        if v:
            return v

        v = self._version_from_tmp(emu.family)
        if v:
            return v

        return ""

    @staticmethod
    def _version_from_name(name):
        m = re.search(r"[._-]v?(\d+(?:[._-]\d+)*)", name)
        if m:
            return m.group(1).replace("_", ".")
        return ""

    def _version_from_binary(self, path):
        for args in (["-V"], ["--build-info"], ["-h"]):
            try:
                rc, out, err = _run(
                    "%s %s 2>&1" % (path, " ".join(args)),
                    timeout=5)
                if rc != 0 and not out and not err:
                    continue

                text = (out or "") + "\n" + (err or "")

                patterns = [
                    r"Version:\s*([^\s@]+)",
                    r"version[:\s]+([0-9][0-9A-Za-z._-]+)",
                    r"v(\d+\.\d+[0-9A-Za-z._-]*)",
                    r"(\d+\.\d+\.\d+)",
                    r"svn[:\s]+r?(\d+)",
                ]
                for pat in patterns:
                    m = re.search(pat, text, re.IGNORECASE)
                    if m:
                        return m.group(1).strip()
            except Exception:
                continue
        return ""

    @staticmethod
    def _version_from_tmp(family):
        paths = [
            "/tmp/.%s/%s.version" % (family, family),
            "/tmp/%s.version" % family,
            "/var/tmp/%s.version" % family,
        ]
        for path in paths:
            if not os.path.isfile(path):
                continue
            try:
                with open(path, "r", encoding="utf-8",
                          errors="ignore") as f:
                    for line in f:
                        if line.startswith("Version:"):
                            v = line.replace("Version:", "").strip()
                            v = v.split("@")[0].strip()
                            m = re.match(r"(\d+(?:\.\d+)*)", v)
                            if m:
                                return m.group(1)
                            return v
            except Exception:
                continue
        return ""

    # ------------------------------------------------------------------
    #  Init script search
    # ------------------------------------------------------------------
    def _find_init_script(self, emu):
        family = emu.family
        version = emu.version
        candidates = []
        base = emu.name

        if version:
            for sep in ("-", "_", "."):
                candidates.append(
                    os.path.join(self.init_dir,
                                 "softcam.%s%s%s" % (base, sep, version)))
                candidates.append(
                    os.path.join(self.init_dir,
                                 "softcam.%s%s%s" % (family, sep, version)))

        candidates.append(
            os.path.join(self.init_dir, "softcam.%s-*" % base))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s-*" % family))

        candidates.append(
            os.path.join(self.init_dir, "softcam.%s" % base))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s" % family))

        candidates.append(os.path.join(self.init_dir, family))

        candidates.append(
            os.path.join(self.init_dir, "softcam.%s.sh" % base))

        for pat in INIT_SCRIPT_PATTERNS:
            candidates.append(pat)

        seen = set()
        for cand in candidates:
            if cand in seen:
                continue
            seen.add(cand)

            if "*" in cand or "?" in cand:
                try:
                    matches = sorted(glob.glob(cand), reverse=True)
                except Exception:
                    matches = []
                for m in matches:
                    if self._is_valid_script(m):
                        logger.log("EmuManager",
                                   "init script for %s: %s"
                                   % (emu.name, m))
                        return m
            else:
                if self._is_valid_script(cand):
                    logger.log("EmuManager",
                               "init script for %s: %s"
                               % (emu.name, cand))
                    return cand

        logger.log("EmuManager",
                   "No init script found for %s" % emu.name)
        return ""

    @staticmethod
    def _is_valid_script(path):
        try:
            return (os.path.isfile(path)
                    and os.access(path, os.X_OK))
        except Exception:
            return False

    # ------------------------------------------------------------------
    #  Running check
    # ------------------------------------------------------------------
    def _check_running(self, emu):
        base = emu.name

        rc, out, _ = _run("pidof %s 2>/dev/null" % base, timeout=3)
        if rc == 0 and out.strip():
            return True

        try:
            for pid_dir in os.listdir("/proc"):
                if not pid_dir.isdigit():
                    continue
                try:
                    comm_path = "/proc/%s/comm" % pid_dir
                    if os.path.isfile(comm_path):
                        with open(comm_path, "r") as f:
                            comm = f.read().strip()
                        if comm == base:
                            return True
                    cmdline_path = "/proc/%s/cmdline" % pid_dir
                    if os.path.isfile(cmdline_path):
                        with open(cmdline_path, "rb") as f:
                            cmdline = f.read().decode(
                                "utf-8", "ignore"
                            ).replace("\0", " ")
                        if base in cmdline:
                            return True
                except (IOError, OSError):
                    continue
        except Exception:
            pass

        return False

    # ==================================================================
    #  Control — كل عملية تستهدف محاكياً واحداً (emu)
    # ==================================================================
    def start(self, emu):
        """يشغّل محاكياً واحداً."""
        return self._control(emu, "start")

    def stop(self, emu):
        """يوقف محاكياً واحداً."""
        return self._control(emu, "stop")

    def restart(self, emu):
        """يعيد تشغيل محاكياً واحداً."""
        return self._control(emu, "restart")

    def toggle(self, emu):
        """يبدّل حالة محاكٍ واحد:
        يعمل → stop، متوقف → start.
        """
        if emu is None:
            return False, "No emulator"
        if emu.running:
            return self.stop(emu)
        return self.start(emu)

    def _control(self, emu, action):
        if emu is None:
            return False, "No emulator"
    
        script = emu.init_script
        if not script or not self._is_valid_script(script):
            return False, "No init script for %s" % emu.name
    
        # ─── مبدأ الاستبعاد المتبادل: قبل start نوقف البقية ───
        stopped_others = []
        if action == "start":
            stopped_others = self._stop_others(emu)
    
        cmd = "%s %s" % (script, action)
        logger.log("EmuManager", "Executing: %s" % cmd)
    
        rc, out, err = _run(cmd, timeout=CMD_TIMEOUT)
    
        if rc == 0:
            emu.running = self._check_running(emu)
            emu.enabled = emu.running
    
            msg = "%s: %s OK" % (emu.name, action)
            if stopped_others:
                msg += " (stopped: %s)" % ", ".join(stopped_others)
            logger.log("EmuManager", msg)
            return True, msg
    
        # بعض السكربتات تُرجع rc != 0 رغم نجاح العملية
        emu.running = self._check_running(emu)
        emu.enabled = emu.running
    
        if action == "stop" and not emu.running:
            return True, "%s: stopped" % emu.name
        if action == "start" and emu.running:
            msg = "%s: started" % emu.name
            if stopped_others:
                msg += " (stopped: %s)" % ", ".join(stopped_others)
            return True, msg
        if action == "restart" and emu.running:
            return True, "%s: restarted" % emu.name
    
        err_msg = (err or out or "").strip().split("\n")[-1][:120]
        msg = "%s: %s failed (rc=%d) %s" % (
            emu.name, action, rc, err_msg)
        logger.log("EmuManager", msg)
        return False, msg
    
    def _stop_others(self, keep_emu):
        """يوقف كل المحاكيات الأخرى غير keep_emu.
    
        يُعيد قائمة بأسماء المحاكيات التي أُوقفت بنجاح.
        """
        stopped = []
        try:
            emus = self.discover()
        except Exception as e:
            logger.log("EmuManager",
                       "_stop_others: discover failed: %s" % e)
            return stopped
    
        for other in emus:
            if other.key == keep_emu.key:
                continue
    
            # تحقق من الحالة الفعلية قبل الإيقاف
            is_running = self._check_running(other)
            other.running = is_running
            other.enabled = is_running
    
            if not is_running:
                continue
    
            # أوقف هذا المحاكي
            script = other.init_script
            if not script or not self._is_valid_script(script):
                logger.log("EmuManager",
                           "_stop_others: no init for %s" % other.name)
                continue
    
            cmd = "%s stop" % script
            logger.log("EmuManager",
                       "_stop_others: %s" % cmd)
            rc, out, err = _run(cmd, timeout=CMD_TIMEOUT)
    
            # تحقق من الحالة بعد الإيقاف
            still_running = self._check_running(other)
            other.running = still_running
            other.enabled = still_running
    
            if not still_running:
                stopped.append(other.name)
                logger.log("EmuManager",
                           "_stop_others: %s stopped OK" % other.name)
            else:
                logger.log("EmuManager",
                           "_stop_others: %s still running (rc=%d)"
                           % (other.name, rc))
    
        if stopped:
            logger.log("EmuManager",
                       "Mutual exclusion: stopped %s before starting %s"
                       % (", ".join(stopped), keep_emu.name))
    
        return stopped
    # ------------------------------------------------------------------
    #  Status helpers
    # ------------------------------------------------------------------
    def get_running_count(self):
        emus = self.discover()
        return (sum(1 for e in emus if e.running), len(emus))

    def get_status(self, emu):
        if emu is None:
            return "unknown"
        emu.running = self._check_running(emu)
        emu.enabled = emu.running
        return "running" if emu.running else "stopped"