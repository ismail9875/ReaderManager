# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import glob
import time as _time
import subprocess
import threading

try:
    from io import open
except ImportError:
    pass

try:
    _TimeoutExpired = subprocess.TimeoutExpired
except AttributeError:
    class _TimeoutExpired(Exception):
        pass

from . import logger


# =====================================================================
#  الإعدادات
# =====================================================================
BIN_DIR = "/usr/bin"
INIT_DIR = "/etc/init.d"

BINARY_PATTERNS = [
    r"^oscam(?:[._-].+)?$",
    r"^OSCam(?:[._-].+)?$",
    r"^ncam(?:[._-].+)?$",
    r"^NCam(?:[._-].+)?$",
]

FAMILY_OSCAM = "oscam"
FAMILY_NCAM  = "ncam"

INIT_SCRIPT_PATTERNS = [
    "/etc/init.d/softcam.oscam-*",
    "/etc/init.d/softcam.OSCam-*",
    "/etc/init.d/softcam.oscam",
    "/etc/init.d/softcam.OSCam",
    "/etc/init.d/softcam_oscam*",
    "/etc/init.d/oscam",
    "/etc/init.d/softcam.ncam-*",
    "/etc/init.d/softcam.NCam-*",
    "/etc/init.d/softcam.ncam",
    "/etc/init.d/softcam.NCam",
    "/etc/init.d/softcam_ncam*",
    "/etc/init.d/ncam",
    "/etc/init.d/softcam",
]

CMD_TIMEOUT = 20

SOFTCAM_LINK       = "/etc/init.d/softcam"
SOFTCAM_NONE       = "/etc/init.d/softcam.None"
ENIGMA_SETTINGS    = "/etc/enigma2/settings"

# ✅ الحد الأقصى لانتظار توقف المحاكي (بالثواني)
STOP_WAIT_TIMEOUT  = 3.0
STOP_POLL_INTERVAL = 0.1


# =====================================================================
#  EmulatorInfo
# =====================================================================
class EmulatorInfo(object):
    __slots__ = (
        "key", "name", "family", "version", "binary_path",
        "init_script", "enabled", "running",
        "description", "extra",
    )

    def __init__(self, name, family, binary_path):
        self.key = "emu:%s:%s" % (family, os.path.basename(binary_path))
        self.name = name
        self.family = family
        self.version = ""
        self.binary_path = binary_path
        self.init_script = ""
        self.enabled = False
        self.running = False
        self.description = ""
        self.extra = {}

    def to_dict(self):
        return {
            "key": self.key,
            "name": self.name,
            "family": self.family,
            "version": self.version,
            "binary_path": self.binary_path,
            "init_script": self.init_script,
            "enabled": self.enabled,
            "running": self.running,
        }

    def __repr__(self):
        return "<Emulator %s v%s running=%s>" % (
            self.name, self.version or "?", self.running)


# =====================================================================
#  Helpers — subprocess
# =====================================================================
def _run(cmd, timeout=CMD_TIMEOUT):
    """ينفّذ أمر shell وينتظر النتيجة."""
    p = None
    try:
        p = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = p.communicate(timeout=timeout)
        except TypeError:
            result = [b"", b""]

            def _target():
                try:
                    result[0], result[1] = p.communicate()
                except Exception:
                    pass

            t = threading.Thread(target=_target)
            t.setDaemon(True)
            t.start()
            t.join(timeout)
            if t.isAlive():
                try:
                    p.kill()
                except Exception:
                    pass
                return -1, "", "timeout"
            out, err = result

        if isinstance(out, bytes):
            out = out.decode("utf-8", "ignore")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "ignore")
        return p.returncode, out, err
    except _TimeoutExpired:
        if p:
            try:
                p.kill()
            except Exception:
                pass
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)


def _run_async(cmd):
    """ينفّذ أمر shell في الخلفية بدون انتظار."""
    try:
        subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            close_fds=True)
        return True
    except Exception as e:
        logger.log("EmuManager", "_run_async error: %s" % e)
        return False


# =====================================================================
#  Helpers — File IO
# =====================================================================
def _safe_read(path):
    try:
        if not os.path.isfile(path):
            return ""
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def _safe_write(path, content):
    try:
        d = os.path.dirname(path)
        if d and not os.path.isdir(d):
            try:
                os.makedirs(d)
            except Exception:
                pass
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except Exception as e:
        logger.log("EmuManager", "Cannot write %s: %s" % (path, e))
        return False


def _get_enigma_config():
    try:
        from Components.config import config
        return config
    except Exception:
        return None


# =====================================================================
#  استخراج اسم CAM من السكربت
# =====================================================================
def _get_cam_name_from_script(script_path):
    """يستخرج اسم CAM من مسار السكربت."""
    if not script_path:
        return ""
    try:
        basename = os.path.basename(script_path)
        prefix = "softcam."
        if basename.startswith(prefix):
            return basename[len(prefix):]
    except Exception:
        pass
    return ""


def _read_active_cam_link():
    """يقرأ اسم المحاكي النشط من الرابط الرمزي."""
    try:
        if not os.path.islink(SOFTCAM_LINK):
            return None, None
        target = os.readlink(SOFTCAM_LINK)
        prefix = "softcam."
        if prefix in target:
            name = target.split(prefix, 1)[1]
            if name.lower() == "none" or not name:
                return None, target
            return name, target
    except Exception:
        pass
    return None, None


# =====================================================================
#  ✅ كتابة/حذف مفتاح في settings
# =====================================================================
def _write_settings_key(key, value):
    """يكتب مفتاحاً في /etc/enigma2/settings مباشرة."""
    try:
        if not os.path.isfile(ENIGMA_SETTINGS):
            logger.log("EmuManager",
                       "settings file not found: %s" % ENIGMA_SETTINGS)
            return False

        lines = _safe_read(ENIGMA_SETTINGS).splitlines()
        new_lines = []
        found = False
        prefix = key + "="

        for line in lines:
            if line.startswith(prefix):
                new_lines.append("%s=%s" % (key, value))
                found = True
            else:
                new_lines.append(line)

        if not found:
            new_lines.append("%s=%s" % (key, value))

        _safe_write(ENIGMA_SETTINGS, "\n".join(new_lines) + "\n")
        logger.log("EmuManager", "Wrote %s=%s in settings" % (key, value))
        return True
    except Exception as e:
        logger.log("EmuManager", "_write_settings_key error: %s" % e)
        return False


# =====================================================================
#  ✅ تحديث config في الذاكرة
# =====================================================================
def _update_enigma_config_memory(cam_name):
    """يُحدّث config.misc.softcams في الذاكرة فقط."""
    cfg = _get_enigma_config()
    if cfg is None:
        return False

    try:
        if hasattr(cfg, "misc") and hasattr(cfg.misc, "softcams"):
            cfg.misc.softcams.value = cam_name or "None"
            logger.log("EmuManager",
                       "config.misc.softcams=%s (memory)" % cam_name)
            return True
    except Exception as e:
        logger.log("EmuManager",
                   "update memory config failed: %s" % e)

    return False


# =====================================================================
#  ✅ إعادة تحميل خدمة Softcam
# =====================================================================
def _reload_softcam_service():
    """إعادة تحميل خدمة Softcam بدون إعادة تشغيل المحاكي."""
    try:
        from Components.SystemInfo import updateSysSoftCam
        updateSysSoftCam()
        logger.log("EmuManager", "updateSysSoftCam() called")
    except Exception as e:
        logger.log("EmuManager",
                   "updateSysSoftCam failed: %s" % e)

    try:
        from enigma import eDVBResourceManager
        rm = eDVBResourceManager.getInstance()
        if rm is not None:
            try:
                cam_name, _ = _read_active_cam_link()
                rm.setCamName(cam_name or "")
            except Exception:
                pass
    except Exception:
        pass

    try:
        from Screens.InfoBar import InfoBar
        inst = InfoBar.instance
        if inst is not None:
            if hasattr(inst, "reloadSoftcam"):
                try:
                    inst.reloadSoftcam()
                except Exception:
                    pass
    except Exception:
        pass


# =====================================================================
#  EmulatorManager
# =====================================================================
class EmulatorManager(object):
    """يكتشف المحاكيات ويتحكم بها بسرعة عالية.

    ✅ الواجهة تستجيب في < 50ms.
    ✅ العملية الفعلية في Thread منفصل.
    ✅ انتظار ذكي لتوقف المحاكي القديم.
    """

    def __init__(self, bin_dir=BIN_DIR, init_dir=INIT_DIR):
        self.bin_dir = bin_dir
        self.init_dir = init_dir
        self._cache = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    #  Discovery
    # ------------------------------------------------------------------
    def discover(self, force=False):
        with self._lock:
            if self._cache is not None and not force:
                return self._cache

            emus = []
            seen_paths = set()

            try:
                entries = sorted(os.listdir(self.bin_dir))
            except Exception as e:
                logger.log("EmuManager",
                           "Cannot list %s: %s" % (self.bin_dir, e))
                self._cache = []
                return []

            for fname in entries:
                full_path = os.path.join(self.bin_dir, fname)

                if not os.path.isfile(full_path):
                    continue
                if not os.access(full_path, os.X_OK):
                    continue
                if full_path in seen_paths:
                    continue

                family = self._detect_family(fname)
                if not family:
                    continue

                seen_paths.add(full_path)

                emu = EmulatorInfo(fname, family, full_path)
                emu.version = self._extract_version(emu)
                emu.init_script = self._find_init_script(emu)
                emu.running = self._check_running(emu)
                emu.enabled = emu.running
                emu.description = "%s binary (%s)" % (
                    family.upper(), emu.version or "unknown version")

                emus.append(emu)

            emus.sort(key=lambda e: (
                0 if e.family == FAMILY_OSCAM else 1,
                e.name.lower()))

            self._cache = emus
            logger.log("EmuManager",
                       "Discovered %d emulator(s) in %s"
                       % (len(emus), self.bin_dir))
            return emus

    def refresh(self):
        return self.discover(force=True)

    # ------------------------------------------------------------------
    #  Family / Version / Script search
    # ------------------------------------------------------------------
    @staticmethod
    def _detect_family(fname):
        low = fname.lower()
        for pattern in BINARY_PATTERNS:
            try:
                if re.match(pattern, fname, re.IGNORECASE):
                    if low.startswith("oscam"):
                        return FAMILY_OSCAM
                    if low.startswith("ncam"):
                        return FAMILY_NCAM
            except Exception:
                continue
        return None

    def _extract_version(self, emu):
        v = self._version_from_name(emu.name)
        if v:
            return v
        v = self._version_from_binary(emu.binary_path)
        if v:
            return v
        v = self._version_from_tmp(emu.family)
        if v:
            return v
        return ""

    @staticmethod
    def _version_from_name(name):
        m = re.search(r"[._-]v?(\d+(?:[._-]\d+)*)", name)
        if m:
            return m.group(1).replace("_", ".")
        return ""

    def _version_from_binary(self, path):
        for args in (["-V"], ["--build-info"], ["-h"]):
            try:
                rc, out, err = _run(
                    "%s %s 2>&1" % (path, " ".join(args)),
                    timeout=5)
                if rc != 0 and not out and not err:
                    continue

                text = (out or "") + "\n" + (err or "")

                patterns = [
                    r"Version:\s*([^\s@]+)",
                    r"version[:\s]+([0-9][0-9A-Za-z._-]+)",
                    r"v(\d+\.\d+[0-9A-Za-z._-]*)",
                    r"(\d+\.\d+\.\d+)",
                    r"svn[:\s]+r?(\d+)",
                ]
                for pat in patterns:
                    m = re.search(pat, text, re.IGNORECASE)
                    if m:
                        return m.group(1).strip()
            except Exception:
                continue
        return ""

    @staticmethod
    def _version_from_tmp(family):
        paths = [
            "/tmp/.%s/%s.version" % (family, family),
            "/tmp/%s.version" % family,
            "/var/tmp/%s.version" % family,
        ]
        for path in paths:
            if not os.path.isfile(path):
                continue
            try:
                with open(path, "r", encoding="utf-8",
                          errors="ignore") as f:
                    for line in f:
                        if line.startswith("Version:"):
                            v = line.replace("Version:", "").strip()
                            v = v.split("@")[0].strip()
                            m = re.match(r"(\d+(?:\.\d+)*)", v)
                            if m:
                                return m.group(1)
                            return v
            except Exception:
                continue
        return ""

    def _find_init_script(self, emu):
        family = emu.family
        version = emu.version
        candidates = []
        base = emu.name

        if version:
            for sep in ("-", "_", "."):
                candidates.append(
                    os.path.join(self.init_dir,
                                 "softcam.%s%s%s" % (base, sep, version)))
                candidates.append(
                    os.path.join(self.init_dir,
                                 "softcam.%s%s%s" % (family, sep, version)))

        candidates.append(
            os.path.join(self.init_dir, "softcam.%s-*" % base))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s-*" % family))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s" % base))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s" % family))
        candidates.append(os.path.join(self.init_dir, family))
        candidates.append(
            os.path.join(self.init_dir, "softcam.%s.sh" % base))

        for pat in INIT_SCRIPT_PATTERNS:
            candidates.append(pat)

        seen = set()
        for cand in candidates:
            if cand in seen:
                continue
            seen.add(cand)

            if "*" in cand or "?" in cand:
                try:
                    matches = sorted(glob.glob(cand), reverse=True)
                except Exception:
                    matches = []
                for m in matches:
                    if self._is_valid_script(m):
                        logger.log("EmuManager",
                                   "init script for %s: %s"
                                   % (emu.name, m))
                        return m
            else:
                if self._is_valid_script(cand):
                    logger.log("EmuManager",
                               "init script for %s: %s"
                               % (emu.name, cand))
                    return cand

        return ""

    @staticmethod
    def _is_valid_script(path):
        try:
            return (os.path.isfile(path)
                    and os.access(path, os.X_OK))
        except Exception:
            return False

    def _check_running(self, emu):
        base = emu.name

        rc, out, _ = _run("pidof %s 2>/dev/null" % base, timeout=3)
        if rc == 0 and out.strip():
            return True

        try:
            for pid_dir in os.listdir("/proc"):
                if not pid_dir.isdigit():
                    continue
                try:
                    comm_path = "/proc/%s/comm" % pid_dir
                    if os.path.isfile(comm_path):
                        with open(comm_path, "r") as f:
                            comm = f.read().strip()
                        if comm == base:
                            return True
                    cmdline_path = "/proc/%s/cmdline" % pid_dir
                    if os.path.isfile(cmdline_path):
                        with open(cmdline_path, "rb") as f:
                            cmdline = f.read().decode(
                                "utf-8", "ignore"
                            ).replace("\0", " ")
                        if base in cmdline:
                            return True
                except (IOError, OSError):
                    continue
        except Exception:
            pass

        return False

    # ==================================================================
    #  ✅ Active Cam — تحديث فوري
    # ==================================================================
    def _set_active_cam_state(self, emu):
        """يعيّن محاكياً كـ Active Cam بشكل فوري.

        ملاحظة: تُستدعى فقط من main thread.
        """
        if emu is None:
            return

        script = emu.init_script
        if not script or not os.path.isfile(script):
            logger.log("EmuManager",
                       "Cannot set active cam: no script for %s"
                       % emu.name)
            return

        cam_name = _get_cam_name_from_script(script)
        if not cam_name:
            logger.log("EmuManager",
                       "Cannot extract cam name from %s" % script)
            return

        # ─── 1) إنشاء الرابط الرمزي ───
        try:
            rc, _, _ = _run(
                "ln -sf %s %s" % (script, SOFTCAM_LINK),
                timeout=3)
            if rc != 0:
                logger.log("EmuManager",
                           "ln -sf failed (rc=%d)" % rc)
                return
            logger.log("EmuManager",
                       "Linked %s -> %s" % (SOFTCAM_LINK, script))
        except Exception as e:
            logger.log("EmuManager", "link error: %s" % e)
            return

        # ─── 2) تحديث الذاكرة ───
        _update_enigma_config_memory(cam_name)

        # ─── 3) كتابة settings ───
        _write_settings_key("config.misc.softcams", cam_name)

        # ─── 4) إعادة تحميل الخدمة ───
        _reload_softcam_service()

        logger.log("EmuManager",
                   "Active cam set: %s" % cam_name)

    def _clear_active_cam_state(self, previous_emu=None):
        """يمسح Active Cam بشكل فوري."""
        # ─── 1) تحويل الرابط إلى None ───
        try:
            if os.path.isfile(SOFTCAM_NONE):
                _run("ln -sf %s %s" % (SOFTCAM_NONE, SOFTCAM_LINK),
                     timeout=3)
            elif os.path.islink(SOFTCAM_LINK):
                os.unlink(SOFTCAM_LINK)
            logger.log("EmuManager", "Link set to None")
        except Exception as e:
            logger.log("EmuManager", "link None failed: %s" % e)

        # ─── 2) تحديث الذاكرة ───
        _update_enigma_config_memory("None")

        # ─── 3) كتابة settings ───
        _write_settings_key("config.misc.softcams", "None")

        # ─── 4) إعادة تحميل الخدمة ───
        _reload_softcam_service()

        logger.log("EmuManager", "Active cam cleared")

    def clear_active_cam(self):
        self._clear_active_cam_state()
        return True

    # ==================================================================
    #  Control — Start/Stop/Restart
    # ==================================================================
    def start(self, emu):
        return self._control(emu, "start")

    def stop(self, emu):
        return self._control(emu, "stop")

    def restart(self, emu):
        return self._control(emu, "restart")

    def toggle(self, emu):
        if emu is None:
            return False, "No emulator"
        if emu.running:
            return self.stop(emu)
        return self.start(emu)

    def _control(self, emu, action):
        """تنفيذ سريع + العملية الفعلية في Thread منفصل.

        ✅ main thread يُحدّث Active Cam فوراً.
        ✅ Thread يُوقف البقية وينفّذ الأمر.
        ✅ الواجهة لا تُجمّد.
        """
        if emu is None:
            return False, "No emulator"

        script = emu.init_script
        if not script or not self._is_valid_script(script):
            return False, "No init script for %s" % emu.name

        logger.log("EmuManager",
                   "_control: %s %s (fast interface, background work)"
                   % (emu.name, action))

        # ─── 1) تحديث Active Cam فوراً في main thread ───
        try:
            if action in ("start", "restart"):
                self._set_active_cam_state(emu)
            elif action == "stop":
                current, _ = _read_active_cam_link()
                if current and current.lower() == emu.name.lower():
                    self._clear_active_cam_state(emu)
        except Exception as e:
            logger.log("EmuManager",
                       "_control active cam update failed: %s" % e)

        # ─── 2) العملية الفعلية في Thread منفصل ───
        try:
            t = threading.Thread(
                target=self._do_control_bg,
                args=(emu, action, script))
            t.setDaemon(True)
            t.start()
        except Exception as e:
            logger.log("EmuManager",
                       "_control thread spawn failed: %s" % e)

        # ─── 3) رسالة فورية للواجهة ───
        if action == "start":
            msg = "%s: activating..." % emu.name
        elif action == "stop":
            msg = "%s: deactivating..." % emu.name
        elif action == "restart":
            msg = "%s: restarting..." % emu.name
        else:
            msg = "%s: %s OK" % (emu.name, action)
        return True, msg

    def _do_control_bg(self, emu, action, script):
        """العملية الكاملة في الخلفية.

        - إيقاف البقية مع انتظار فعلي.
        - تشغيل الأمر.
        - تحديث الحالة.
        """
        try:
            stopped_others = []

            # ─── إيقاف البقية مع انتظار ───
            if action in ("start", "restart"):
                stopped_others = self._stop_others_sync(emu)

            # ─── تنفيذ الأمر ───
            cmd = "%s %s" % (script, action)
            logger.log("EmuManager",
                       "Background exec: %s" % cmd)
            rc, out, err = _run(cmd, timeout=CMD_TIMEOUT)

            # ─── تحديث الحالة الفعلية ───
            emu.running = self._check_running(emu)
            emu.enabled = emu.running

            msg = "%s: %s %s (rc=%d)" % (
                emu.name, action,
                "OK" if rc == 0 else "failed", rc)
            if stopped_others:
                msg += " (stopped: %s)" % ", ".join(stopped_others)
            logger.log("EmuManager", msg)
        except Exception as e:
            logger.log("EmuManager",
                       "_do_control_bg error: %s" % e)

    def _stop_others_sync(self, keep_emu):
        """يوقف المحاكيات الأخرى وينتظر انتهاءها فعلاً.

        ✅ يعمل داخل Thread — استخدام time.sleep آمن.
        ✅ ينتظر حتى 3 ثواني، ثم killall -9 كحل أخير.
        """
        stopped = []
        try:
            emus = self.discover()
        except Exception as e:
            logger.log("EmuManager",
                       "_stop_others_sync: discover failed: %s" % e)
            return stopped

        for other in emus:
            if other.key == keep_emu.key:
                continue

            is_running = self._check_running(other)
            if not is_running:
                continue

            script = other.init_script
            if not script or not self._is_valid_script(script):
                continue

            logger.log("EmuManager",
                       "_stop_others_sync: stopping %s ..."
                       % other.name)

            # ─── إرسال أمر الإيقاف ───
            _run_async("%s stop" % script)

            # ─── انتظار انتهاء العملية (بحد أقصى 3 ثواني) ───
            start = _time.time()
            while _time.time() - start < STOP_WAIT_TIMEOUT:
                rc, out, _ = _run(
                    "pidof %s 2>/dev/null" % other.name,
                    timeout=1)
                if rc != 0 or not out.strip():
                    break
                _time.sleep(STOP_POLL_INTERVAL)

            elapsed = _time.time() - start
            if elapsed >= STOP_WAIT_TIMEOUT:
                logger.log("EmuManager",
                           "_stop_others_sync: %s timeout - killall"
                           % other.name)
                _run_async("killall -9 %s 2>/dev/null" % other.name)
                _time.sleep(0.3)
            else:
                logger.log("EmuManager",
                           "_stop_others_sync: %s stopped in %.2fs"
                           % (other.name, elapsed))

            other.running = False
            other.enabled = False
            stopped.append(other.name)

        return stopped

    # ------------------------------------------------------------------
    #  Status
    # ------------------------------------------------------------------
    def get_running_count(self):
        emus = self.discover()
        return (sum(1 for e in emus if e.running), len(emus))

    def get_status(self, emu):
        if emu is None:
            return "unknown"
        emu.running = self._check_running(emu)
        emu.enabled = emu.running
        return "running" if emu.running else "stopped"

    # ------------------------------------------------------------------
    #  Active Cam getter
    # ------------------------------------------------------------------
    def get_active_cam_name(self):
        """يقرأ اسم المحاكي النشط."""
        name, target = _read_active_cam_link()
        if name:
            return name

        try:
            cfg = _get_enigma_config()
            if cfg is not None:
                if hasattr(cfg, "misc") and \
                        hasattr(cfg.misc, "softcams"):
                    v = (cfg.misc.softcams.value or "").strip()
                    if v and v.lower() != "none":
                        return v
        except Exception:
            pass

        return "No CAM active"