# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import shutil

# ─── توافق Py2/Py3 للـ open مع encoding ───
try:
    from io import open
except ImportError:
    pass

# ─── توافق Py2: os.replace غير متاح ───
try:
    os.replace
    _HAS_OS_REPLACE = True
except AttributeError:
    _HAS_OS_REPLACE = False

    def _os_replace(src, dst):
        try:
            os.remove(dst)
        except OSError:
            pass
        os.rename(src, dst)

    os.replace = _os_replace


# ═══════════════════════════════════════════════════════════════════
#  ترتيب الحقول
# ═══════════════════════════════════════════════════════════════════
REQUIRED_ORDER = [
    "label", "protocol", "device", "user", "password", "group",
]

# حقول مباشرة إضافية
EXTRA_DIRECT = [
    "caid", "ident", "emmcache", "emu_auproviders",
    "inactivitytimeout",
]

# كل الحقول المباشرة
DIRECT_ATTRS = set(REQUIRED_ORDER) | set(EXTRA_DIRECT)

# ترتيب حقول extra
EXTRA_ORDER = [
    "cccversion", "newcamd_version", "key", "deskey",
    "cccreconnect", "cccmaxhops", "ccchop", "ccckeepalive",
    "chid", "provid", "srvid",
    "ecmwhitelist", "ecmheaderwhitelist",
    "au", "emm", "audisabled",
    "cacheex", "cacheex_mode", "cacheex_maxhop",
    "keepalive", "reconnect", "timeout",
    "disablecrccws", "disablecrccws_only_for", "dropbadcws",
    "ratelimitecm", "cooldown",
    "blockemm_u", "blockemm_s", "blockemm_g", "blockemm_unknown",
    "saveemm_u", "saveemm_s", "saveemm_g",
    "cardmhz", "mhz", "card_mhrz", "mhrz",
    "pin", "boxid", "detect",
]

# ترجمة اسم الخاصية → اسم السطر في الملف
ATTR_TO_FILE = {
    "blockemm_u":       "blockemm-u",
    "blockemm_s":       "blockemm-s",
    "blockemm_g":       "blockemm-g",
    "blockemm_unknown": "blockemm-unknown",
    "saveemm_u":        "saveemm-u",
    "saveemm_s":        "saveemm-s",
    "saveemm_g":        "saveemm-g",
}

# ترجمة اسم السطر → اسم الخاصية
FILE_TO_ATTR = {v: k for k, v in ATTR_TO_FILE.items()}


# ⭐ قيم "صفرية" لا تُكتب
ZERO_VALUES = {"", "0", "0.0", "00", "none", "null"}

# ⭐ حقول تُكتب دائماً (حتى لو كانت "0")
ALWAYS_WRITE = {"port", "device", "label", "protocol"}


def _should_write(attr, val):
    """
    هل يجب كتابة هذا الحقل؟

    القواعد:
        1. None → لا
        2. "" → لا
        3. "0", "0.0", "00", "none", "null" → لا
        4. استثناءات: port, device, label, protocol → نعم دائماً
    """
    if val is None:
        return False

    s = str(val).strip()
    if not s:
        return False

    if attr in ALWAYS_WRITE:
        return True

    if s.lower() in ZERO_VALUES:
        return False

    return True


def _normalize_key(key):
    """يطبّع اسم الحقل."""
    k = key.lower().strip()
    k = k.replace("-", "_")
    return k


# ═══════════════════════════════════════════════════════════════════
#  Reader
# ═══════════════════════════════════════════════════════════════════
class Reader(object):
    """نموذج بيانات القارئ."""

    def __init__(self, **kwargs):
        # الإلزامية
        self.label              = kwargs.get("label", u"")
        self.enabled            = kwargs.get("enabled", True)
        self.protocol           = kwargs.get("protocol", u"")
        self.device             = kwargs.get("device", u"")
        self.user               = kwargs.get("user", u"")
        self.password           = kwargs.get("password", u"")
        self.group              = kwargs.get("group", u"")

        # المباشرة الإضافية
        self.caid               = kwargs.get("caid", u"")
        self.ident              = kwargs.get("ident", u"")
        self.emmcache           = kwargs.get("emmcache", u"")
        self.emu_auproviders    = kwargs.get("emu_auproviders", u"")
        self.inactivitytimeout  = kwargs.get("inactivitytimeout", u"")

        # الاختيارية
        self.extra              = dict(kwargs.get("extra", {}) or {})

        # إدارية
        self.source_file        = kwargs.get("source_file", u"")
        self.source_tag         = kwargs.get("source_tag", u"")

    def __repr__(self):
        return "<Reader %s %s:%s>" % (
            self.label, self.protocol, self.device)

    # ------------------------------------------------------------------
    def set_field(self, key, value):
        """الحقول المباشرة → setattr، الباقي → extra"""
        attr = FILE_TO_ATTR.get(key, _normalize_key(key))
        if attr in DIRECT_ATTRS:
            setattr(self, attr, value)
        else:
            self.extra[attr] = value

    def get_field(self, key, default=u""):
        """قراءة حقل مباشر أو من extra."""
        attr = FILE_TO_ATTR.get(key, _normalize_key(key))
        if attr in DIRECT_ATTRS:
            return getattr(self, attr, default)
        return self.extra.get(attr, default)

    def iter_fields(self):
        """
        يُولّد (attr, value) بترتيب الكتابة المناسب.

        ⚠️ القاعدة:
            - لا نُصدر أي حقل قيمته: "", "0", "0.0", None
            - استثناء: `port`, `device`, `label`, `protocol` تُكتب دائماً
            - استثناء: `enable = 0` يُكتب عند تعطيل القارئ
        """
        # ① الإلزامية
        for attr in REQUIRED_ORDER:
            val = getattr(self, attr, "")
            if _should_write(attr, val):
                yield attr, val

        # ② enable: فقط عند OFF
        if not self.enabled:
            yield "enable", "0"

        # ③ المباشرة الإضافية
        for attr in EXTRA_DIRECT:
            val = getattr(self, attr, "")
            if _should_write(attr, val):
                yield attr, val

        # ④ الاختيارية بترتيب معروف
        emitted = set()
        for attr in EXTRA_ORDER:
            if attr in self.extra:
                val = self.extra[attr]
                if _should_write(attr, val):
                    yield attr, val
                    emitted.add(attr)

        # ⑤ أي حقول مجهولة
        for attr, val in self.extra.items():
            if attr in emitted:
                continue
            if _should_write(attr, val):
                yield attr, val

    def to_lines(self):
        """يُعيد أسطر القارئ جاهزة للكتابة."""
        lines = ["[reader]"]
        for attr, val in self.iter_fields():
            file_name = ATTR_TO_FILE.get(attr, attr)
            lines.append("%-30s= %s" % (file_name, val))
        lines.append("")
        return lines


# ═══════════════════════════════════════════════════════════════════
#  ReaderParser
# ═══════════════════════════════════════════════════════════════════
class ReaderParser(object):
    """قراءة/كتابة ملفات oscam.server / ncam.server."""

    SECTION_RE = re.compile(r"^\[(reader|account|user)\]\s*$", re.IGNORECASE)
    KV_RE = re.compile(r"^\s*#?\s*([A-Za-z0-9_\-]+)\s*=\s*(.*?)\s*$")

    # ------------------------------------------------------------------
    #  قراءة
    # ------------------------------------------------------------------
    def parse_file(self, path):
        """يقرأ كل القُرّاء من ملف."""
        if not path or not os.path.exists(path):
            return []

        readers = []
        try:
            with open(path, "r", encoding="utf-8",
                      errors="ignore") as f:
                content = f.read()
        except TypeError:
            try:
                with open(path, "r") as f:
                    content = f.read()
                if isinstance(content, bytes):
                    content = content.decode("utf-8", "ignore")
            except Exception:
                return []
        except Exception:
            return []

        for block in self._split_sections(content):
            if not block.strip():
                continue
            r = self._parse_block(block)
            if r:
                readers.append(r)
        return readers

    def _split_sections(self, content):
        """يُقسّم المحتوى إلى كتل حسب [reader]/[account]/[user]."""
        blocks = []
        current = []
        for line in content.splitlines():
            if self.SECTION_RE.match(line):
                if current:
                    blocks.append("\n".join(current))
                current = [line]
            else:
                current.append(line)
        if current:
            blocks.append("\n".join(current))
        return blocks

    def _parse_block(self, block):
        """يحوّل كتلة نصية إلى Reader."""
        r = Reader()
        enabled = True

        for raw in block.splitlines():
            if not raw.strip():
                continue
            if self.SECTION_RE.match(raw):
                continue

            line_enabled = not raw.lstrip().startswith("#")
            m = self.KV_RE.match(raw)
            if not m:
                continue

            key = m.group(1).lower().strip()
            val = m.group(2).strip()

            if key == "enable":
                enabled = (val != "0")
                continue

            if not line_enabled:
                enabled = False

            r.set_field(key, val)

        r.enabled = enabled

        if not (r.label or r.device or r.protocol):
            return None
        return r

    # ------------------------------------------------------------------
    #  كتابة
    # ------------------------------------------------------------------
    def _backup(self, path):
        """نسخة احتياطية .bak."""
        if not path or not os.path.exists(path):
            return
        try:
            shutil.copy2(path, path + ".bak")
        except Exception:
            pass

    def _extract_header(self, path):
        """يستخرج الأسطر قبل أول [reader]."""
        header_lines = []
        if not path or not os.path.exists(path):
            return header_lines

        try:
            with open(path, "r", encoding="utf-8",
                      errors="ignore") as f:
                for line in f:
                    if self.SECTION_RE.match(line):
                        break
                    header_lines.append(line.rstrip("\n"))
        except TypeError:
            try:
                with open(path, "r") as f:
                    for line in f:
                        if isinstance(line, bytes):
                            line = line.decode("utf-8", "ignore")
                        if self.SECTION_RE.match(line):
                            break
                        header_lines.append(line.rstrip("\n"))
            except Exception:
                pass
        except Exception:
            pass

        return header_lines

    def write_file(self, path, readers):
        """يكتب كل القُرّاء إلى ملف (مع نسخة احتياطية)."""
        if not path:
            raise ValueError("No target file")

        self._backup(path)

        out = []
        header = self._extract_header(path)
        if header:
            out.extend(header)
            if header[-1].strip():
                out.append("")

        for r in readers:
            out.extend(r.to_lines())

        content = "\n".join(out)
        if not content.endswith("\n"):
            content += "\n"

        folder = os.path.dirname(path) or "."
        tmp_path = os.path.join(folder, ".%s.tmp" % os.path.basename(path))

        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                f.write(content)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
        except TypeError:
            with open(tmp_path, "w") as f:
                if isinstance(content, bytes):
                    content = content.decode("utf-8", "ignore")
                f.write(content)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
        except Exception:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass
            raise

        try:
            os.replace(tmp_path, path)
        except Exception:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass
            raise

    def write_single(self, reader, path):
        """يكتب قارئاً واحداً (يُحدّثه إن وُجد أو يُضيفه)."""
        if not path:
            path = reader.source_file
        if not path:
            raise ValueError("No target file for reader")

        readers = self.parse_file(path)

        found = False
        for i, r in enumerate(readers):
            if r.label == reader.label:
                readers[i] = reader
                found = True
                break

        if not found:
            readers.append(reader)

        self.write_file(path, readers)

        if not self._verify_written(reader, path):
            raise RuntimeError(
                "Verification failed: reader '%s' not found in %s"
                % (reader.label, path))

        reader.source_file = path
        return True

    def remove_from_file(self, reader):
        """يحذف قارئاً من ملفه."""
        path = reader.source_file
        if not path or not os.path.exists(path):
            return False

        readers = self.parse_file(path)
        new_readers = [r for r in readers if r.label != reader.label]

        if len(new_readers) == len(readers):
            return False

        self.write_file(path, new_readers)

        labels = {r.label for r in self.parse_file(path)}
        if reader.label in labels:
            raise RuntimeError(
                "Verification failed: '%s' still in %s"
                % (reader.label, path))
        return True

    def _verify_written(self, reader, path):
        """يتحقق من وجود القارئ في الملف بعد الكتابة."""
        try:
            if not os.path.exists(path):
                return False
            labels = {r.label for r in self.parse_file(path)}
            return reader.label in labels
        except Exception:
            return False

    def reader_exists(self, label, path):
        """هل القارئ موجود في الملف؟"""
        try:
            labels = {r.label for r in self.parse_file(path)}
            return label in labels
        except Exception:
            return False