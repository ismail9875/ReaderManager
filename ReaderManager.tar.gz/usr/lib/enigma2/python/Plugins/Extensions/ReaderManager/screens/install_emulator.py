# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import threading

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.MenuList import MenuList
from Components.ScrollLabel import ScrollLabel
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import (
    eTimer, eListboxPythonMultiContent, gFont,
    RT_HALIGN_LEFT, RT_HALIGN_CENTER, RT_VALIGN_CENTER
)

from ..utils import logger
from ..utils import emulator_installer
from ..utils import dev_avatars
from ..utils.skin_loader import get_screen_skin

try:
    from ..utils import github_api
    HAS_GITHUB_API = True
except Exception:
    github_api = None
    HAS_GITHUB_API = False


# ═══════════════════════════════════════════════════════════════════
#  ثوابت الحالة
# ═══════════════════════════════════════════════════════════════════
STATUS_NONE      = getattr(emulator_installer, "STATUS_NONE", "not-installed")
STATUS_INSTALLED = getattr(emulator_installer, "STATUS_INSTALLED", "installed")
STATUS_UPDATE    = getattr(emulator_installer, "STATUS_UPDATE", "update")


_RE_FILENAME_VER_REV = re.compile(
    r"_(\d+)-(\d+)(?:_all|_mips|_arm|_aarch64|\.ipk|$)",
    re.IGNORECASE
)


def extract_version_revision(filename, info=None):
    """استخراج (version, revision) من اسم الملف."""
    version = None
    revision = None

    if filename:
        base = filename
        if base.lower().endswith(".ipk"):
            base = base[:-4]

        m = _RE_FILENAME_VER_REV.search(base + "_all")
        if m:
            version = m.group(1)
            revision = m.group(2)
        else:
            m2 = re.search(r"_(\d+)-(\d+)", base)
            if m2:
                version = m2.group(1)
                revision = m2.group(2)

    if version is None and info:
        v = info.get("version")
        if v is not None:
            version = str(v).strip() or None
    if revision is None and info:
        r = info.get("revision")
        if r is not None:
            revision = str(r).strip() or None

    version_str = version if version else "-"

    if revision and revision not in ("-", ""):
        if revision.lower().startswith("r"):
            revision_str = revision
        else:
            revision_str = "r" + revision
    else:
        revision_str = "-"

    return version_str, revision_str


# ═══════════════════════════════════════════════════════════════════
#  إحداثيات widget list_emu
# ═══════════════════════════════════════════════════════════════════
LIST_X = 40
LIST_Y = 152
ROW_HEIGHT = 55

HEADER_NUM_X      = 70
HEADER_NUM_W      = 60
HEADER_FILE_X     = 140
HEADER_FILE_W     = 460
HEADER_FAMILY_X   = 620
HEADER_FAMILY_W   = 140
HEADER_VERSION_X  = 770
HEADER_VERSION_W  = 150
HEADER_REV_X      = 930
HEADER_REV_W      = 150
HEADER_STATUS_X   = 1090
HEADER_STATUS_W   = 140

COL_NUM_X     = HEADER_NUM_X     - LIST_X
COL_NUM_W     = HEADER_NUM_W
COL_FILE_X    = HEADER_FILE_X    - LIST_X
COL_FILE_W    = HEADER_FILE_W
COL_FAMILY_X  = HEADER_FAMILY_X  - LIST_X
COL_FAMILY_W  = HEADER_FAMILY_W
COL_VERSION_X = HEADER_VERSION_X - LIST_X
COL_VERSION_W = HEADER_VERSION_W
COL_REV_X     = HEADER_REV_X     - LIST_X
COL_REV_W     = HEADER_REV_W
COL_STATUS_X  = HEADER_STATUS_X  - LIST_X
COL_STATUS_W  = HEADER_STATUS_W


class InstallEmulatorScreen(Screen):
    screen_name = "InstallEmulator"

    def __init__(self, session, developer=None, on_change_callback=None):
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content
        Screen.__init__(self, session)
        self.session = session
        self._developer = developer
        self.on_change_callback = on_change_callback

        self["title"]               = Label("Install Emulators")
        self["dev_name"]            = Label(developer or "?")
        self["dev_avatar"]          = Pixmap()
        self["dev_avatar_fallback"] = Label("")
        self["installed"]           = Label("")
        self["status"]              = Label("Loading...")
        self["key_red"]             = Button("Close")
        self["key_green"]           = Button("Install")
        self["key_yellow"]          = Button("Refresh")
        self["key_blue"]            = Button("Details")

        self["list_emu"] = MenuList([], True, eListboxPythonMultiContent)
        self["list_emu"].l.setFont(0, gFont("Regular", 22))
        self["list_emu"].l.setItemHeight(ROW_HEIGHT)

        self._files = []
        self._parsed = []
        self._statuses = {}
        self._checking = False
        self._busy = False
        self._closing = False
        self._pending_timers = []
        self._avatar_pixmap = None

        self._load_developer_avatar(developer)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions",
             "DirectionActions", "MenuActions"],
            {
                "ok":     self.ok_pressed,
                "cancel": self.close,
                "red":    self.close,
                "green":  self.ok_pressed,
                "yellow": self.refresh,
                "blue":   self.show_details,
                "up":     self.move_up,
                "down":   self.move_down,
            }, -1)

        try:
            self["list_emu"].onSelectionChanged.append(
                self._on_selection_changed)
        except Exception:
            pass

        self.onLayoutFinish.append(self._on_start)

    # ═══════════════════════════════════════════════════════════════
    #  تحميل صورة المطور واسمه
    # ═══════════════════════════════════════════════════════════════
    def _load_developer_avatar(self, developer):
        if not developer:
            self["dev_name"].setText("Unknown Developer")
            self["dev_avatar_fallback"].setText("?")
            return

        display = developer
        path = None

        try:
            path = dev_avatars.get_avatar_path(developer)
            logger.log("InstallEmuScreen",
                       "avatar path for '%s': %s" % (developer, path))
        except Exception as e:
            logger.log("InstallEmuScreen",
                       "get_avatar_path error: %s" % e)

        if HAS_GITHUB_API:
            try:
                devs = github_api.get_developers()
                if devs:
                    for d in devs:
                        if d.get("id") == developer:
                            display = d.get("display") or developer
                            break
            except Exception as e:
                logger.log("InstallEmuScreen",
                           "get_developers error: %s" % e)

        self["dev_name"].setText(display)

        if path and os.path.isfile(path):
            try:
                pix = LoadPixmap(path)
                if pix:
                    self._avatar_pixmap = pix
                    self["dev_avatar"].instance.setPixmap(pix)
                    self["dev_avatar_fallback"].setText("")
                    logger.log("InstallEmuScreen",
                               "avatar loaded OK for '%s'" % developer)
                    return
            except Exception as e:
                logger.log("InstallEmuScreen",
                           "load avatar error: %s" % e)

        self["dev_avatar_fallback"].setText(
            (display[:1] or "?").upper())

    # ------------------------------------------------------------------
    def _on_start(self):
        self._update_installed_info()
        self.refresh()

    def _update_installed_info(self):
        emu_id = emulator_installer.get_installed_emulator()
        version = emulator_installer.get_installed_version()
        if emu_id:
            text = "Installed: %s %s" % (emu_id, version or "")
        else:
            text = "Installed: (none)"
        self["installed"].setText(text)

    # ------------------------------------------------------------------
    def refresh(self):
        if self._checking or self._closing:
            return

        self._checking = True
        self["status"].setText("Loading files from GitHub...")
        self._files = []
        self._parsed = []
        self._statuses = {}
        self["list_emu"].setList([])

        t = threading.Thread(target=self._load_worker)
        t.setDaemon(True)
        t.start()

    def _load_worker(self):
        developer = self._developer
        if not developer:
            self._schedule_ui(self._after_load, False, "No developer")
            return

        ok, files_or_err = emulator_installer.list_developer_files(
            developer, timeout=15.0)

        if not ok:
            self._schedule_ui(self._after_load, False, files_or_err)
            return

        parsed = []
        for f in files_or_err:
            info = emulator_installer.parse_ipk_filename(f.get("name", ""))
            info["url"] = f.get("url", "")
            info["name"] = f.get("name", "")
            info["size"] = f.get("size", 0)
            parsed.append(info)

        def _sort_key(item):
            v_str, r_str = extract_version_revision(
                item.get("name", ""), item)
            try:
                v = int(v_str) if v_str != "-" else 0
            except Exception:
                v = 0
            try:
                r_clean = r_str.lstrip("r") if r_str != "-" else "0"
                r = int(r_clean) if r_clean else 0
            except Exception:
                r = 0
            return (v, r)

        try:
            parsed.sort(key=_sort_key, reverse=True)
        except Exception:
            pass

        self._files = files_or_err
        self._parsed = parsed

        self._schedule_ui(self._after_load, True, "")

    def _after_load(self, ok, msg):
        self._checking = False
        if not ok:
            self["status"].setText("Load failed: %s" % msg)
            return
        self._build_list()
        self["status"].setText("%d file(s) loaded" % len(self._parsed))

    def _build_row(self, info, index):
        name = info.get("name", "?")
        family = (info.get("family", "") or "-").upper()
        version_str, revision_str = extract_version_revision(name, info)

        status = self._get_status(info)
        self._statuses[name] = status

        name_display = name if len(name) <= 52 else name[:49] + "..."

        row = [info]

        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            COL_NUM_X, 0, COL_NUM_W, ROW_HEIGHT,
            0,
            RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            str(index + 1),
        ))
        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            COL_FILE_X, 0, COL_FILE_W, ROW_HEIGHT,
            0,
            RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            name_display,
        ))
        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            COL_FAMILY_X, 0, COL_FAMILY_W, ROW_HEIGHT,
            0,
            RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            family,
        ))
        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            COL_VERSION_X, 0, COL_VERSION_W, ROW_HEIGHT,
            0,
            RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            version_str,
        ))
        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            COL_REV_X, 0, COL_REV_W, ROW_HEIGHT,
            0,
            RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            revision_str,
        ))
        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            COL_STATUS_X, 0, COL_STATUS_W, ROW_HEIGHT,
            0,
            RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            status,
        ))

        return row

    def _build_list(self):
        if self._closing:
            return

        rows = []
        for i, info in enumerate(self._parsed):
            rows.append(self._build_row(info, i))

        self["list_emu"].setList(rows)

        if self._parsed:
            try:
                self["list_emu"].moveToIndex(0)
            except Exception:
                pass

        self._update_green_button()

    def _get_status(self, info):
        try:
            return emulator_installer.get_emulator_status(info)
        except Exception as e:
            logger.log("InstallEmuScreen", "get_status error: %s" % e)
            return STATUS_NONE

    def _update_green_button(self):
        try:
            idx = self["list_emu"].getSelectedIndex()
        except Exception:
            idx = -1

        if idx < 0 or idx >= len(self._parsed):
            self["key_green"].setText("Install")
            return

        info = self._parsed[idx]
        status = self._statuses.get(info.get("name", ""), STATUS_NONE)

        if status == STATUS_INSTALLED:
            self["key_green"].setText("Remove")
        elif status == STATUS_UPDATE:
            self["key_green"].setText("Update")
        else:
            self["key_green"].setText("Install")

    def _on_selection_changed(self):
        self._update_green_button()

    def move_up(self):
        if not self._parsed:
            return
        try:
            idx = self["list_emu"].getSelectedIndex()
        except Exception:
            return
        if idx <= 0:
            idx = len(self._parsed) - 1
        else:
            idx -= 1
        try:
            self["list_emu"].moveToIndex(idx)
        except Exception:
            pass
        self._update_green_button()

    def move_down(self):
        if not self._parsed:
            return
        try:
            idx = self["list_emu"].getSelectedIndex()
        except Exception:
            return
        if idx >= len(self._parsed) - 1:
            idx = 0
        else:
            idx += 1
        try:
            self["list_emu"].moveToIndex(idx)
        except Exception:
            pass
        self._update_green_button()

    def ok_pressed(self):
        if self._busy or self._closing:
            return

        idx = self["list_emu"].getSelectedIndex()
        if idx < 0 or idx >= len(self._parsed):
            return

        info = self._parsed[idx]
        status = self._statuses.get(info.get("name", ""), STATUS_NONE)

        if status == STATUS_INSTALLED:
            self._confirm_uninstall(info)
        else:
            self._confirm_install(info)

    def _confirm_install(self, info):
        name = info.get("display", info.get("name", "?"))
        url = info.get("url", "")

        self.session.openWithCallback(
            lambda ans: self._do_install(ans, info),
            MessageBox,
            "Install '%s'?\n\n"
            "Source: %s\n\n"
            "Enigma2 will restart after installation.\n\n"
            "Continue?" % (name, url),
            MessageBox.TYPE_YESNO)

    def _do_install(self, answer, info):
        if not answer:
            return
        self._busy = True
        try:
            self.session.open(
                InstallProgressScreen,
                info,
                self._after_operation,
                operation="install")
        except Exception as e:
            logger.log("InstallEmuScreen",
                       "open progress failed: %s" % e)
            self._busy = False

    def _confirm_uninstall(self, info):
        name = info.get("display", info.get("name", "?"))
        self.session.openWithCallback(
            lambda ans: self._do_uninstall(ans, info),
            MessageBox,
            "Remove '%s'?\n\n"
            "The package will be removed via opkg.\n"
            "Config files in /etc/tuxbox/config are PRESERVED.\n\n"
            "Enigma2 will restart after removal.\n\n"
            "Continue?" % name,
            MessageBox.TYPE_YESNO)

    def _do_uninstall(self, answer, info):
        if not answer:
            return
        self._busy = True
        try:
            self.session.open(
                InstallProgressScreen,
                info,
                self._after_operation,
                operation="uninstall")
        except Exception as e:
            logger.log("InstallEmuScreen",
                       "open progress failed: %s" % e)
            self._busy = False

    def _after_operation(self, result):
        self._busy = False
        if result and result.get("ok"):
            self._update_installed_info()
            self.refresh()

    def show_details(self):
        idx = self["list_emu"].getSelectedIndex()
        if idx < 0 or idx >= len(self._parsed):
            return

        info = self._parsed[idx]
        status = self._statuses.get(info.get("name", ""), STATUS_NONE)

        version_str, revision_str = extract_version_revision(
            info.get("name", ""), info)

        lines = [
            "Developer: %s" % (self._developer or "?"),
            "File:     %s" % info.get("name", "?"),
            "Family:   %s" % (info.get("family", "?") or "").upper(),
            "Version:  %s" % version_str,
            "Revision: %s" % revision_str,
            "Status:   %s" % status,
            "Size:     %s" % self._format_size(info.get("size", 0)),
            "",
            "URL:",
            "  %s" % info.get("url", "?"),
        ]

        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=20)

    @staticmethod
    def _format_size(size):
        try:
            size = int(size)
        except Exception:
            return "?"
        if size < 1024:
            return "%d B" % size
        if size < 1024 * 1024:
            return "%.1f KB" % (size / 1024.0)
        return "%.1f MB" % (size / (1024.0 * 1024.0))

    def _schedule_ui(self, func, *args):
        if self._closing:
            return
        try:
            t = eTimer()
            t.callback.append(lambda: func(*args))
            t.start(10, True)
            self._pending_timers.append(t)
        except Exception:
            try:
                func(*args)
            except Exception:
                pass

    def close(self):
        self._closing = True
        for t in list(self._pending_timers):
            try:
                t.stop()
            except Exception:
                pass
        self._pending_timers = []
        Screen.close(self)


# ═══════════════════════════════════════════════════════════════════
#  شاشة التقدّم
# ═══════════════════════════════════════════════════════════════════
class InstallProgressScreen(Screen):
    screen_name = "InstallProgress"

    MAX_LOG_LINES = 22

    def __init__(self, session, info, callback=None, operation="install"):
        # ⭐ اسنِ السكين قبل Screen.__init__
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session
        self.info = info
        self._callback = callback
        self._operation = operation
        self._log_lines = []
        self._result = None
        self._closing = False

        op_title = ("Installing..." if operation == "install"
                    else "Removing...")
        op_start = ("Starting installation..." if operation == "install"
                    else "Starting removal...")

        self["title"]       = Label(op_title)
        self["emu_name"]    = Label(info.get("display", info.get("name", "?")))
        self["status"]      = Label(op_start)
        self["log_content"] = ScrollLabel("")
        self["footer"]      = Label("Please wait...")

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok":     self._noop,
                "cancel": self._noop,
                "red":    self._noop,
                "green":  self._noop,
            }, -1)

        self.onLayoutFinish.append(self._on_start)

    def _noop(self):
        pass

    def _on_start(self):
        t = threading.Thread(target=self._worker)
        t.setDaemon(True)
        t.start()

    def _worker(self):
        def on_line(line):
            self._append_log(line)

        try:
            if self._operation == "install":
                result = emulator_installer.install_ipk(
                    self.info.get("url", ""),
                    self.info.get("name", ""),
                    on_line=on_line)
            else:
                result = emulator_installer.uninstall_ipk(
                    self.info, on_line=on_line)

            self._schedule_ui(self._after_done, result)
        except Exception as e:
            logger.log("InstallProgressScreen",
                       "%s error: %s" % (self._operation, e))
            self._schedule_ui(
                self._after_done,
                {"ok": False, "error": str(e), "output": ""})

    def _append_log(self, line):
        self._log_lines.append(line)
        if len(self._log_lines) > self.MAX_LOG_LINES:
            self._log_lines = self._log_lines[-self.MAX_LOG_LINES:]
        text = "\n".join(self._log_lines)
        self._schedule_ui(self._update_log, text)

    def _update_log(self, text):
        try:
            self["log_content"].setText(text)
            try:
                self["log_content"].down()
                self["log_content"].down()
            except Exception:
                pass
        except Exception:
            pass

    def _after_done(self, result):
        self._result = result

        if result.get("ok"):
            msg = ("Installation successful! Restarting Enigma2..."
                   if self._operation == "install"
                   else "Removal successful! Restarting Enigma2...")
            self["status"].setText(msg)
            self["footer"].setText("Enigma2 will restart in 3 seconds")
            self._schedule_ui(self._restart_after_delay, 3)
        else:
            err = result.get("error", "unknown error")
            title = ("Installation failed" if self._operation == "install"
                     else "Removal failed")
            self["status"].setText(title)
            self["footer"].setText("Failed: %s" % err)

            self.session.openWithCallback(
                self._close_with_result,
                MessageBox,
                "%s:\n%s\n\nClose this window?" % (title, err),
                MessageBox.TYPE_INFO,
                timeout=15)

    def _restart_after_delay(self, delay):
        if self._closing:
            return
        self._closing = True
        try:
            if self._callback:
                self._callback(self._result)
        except Exception:
            pass
        try:
            emulator_installer.restart_enigma(delay_seconds=delay)
        except Exception:
            pass

    def _close_with_result(self, *args, **kwargs):
        self._closing = True
        try:
            if self._callback:
                self._callback(self._result)
        except Exception:
            pass
        self.close()

    def _schedule_ui(self, func, *args):
        try:
            t = eTimer()
            t.callback.append(lambda: func(*args))
            t.start(10, True)
            if not hasattr(self, "_timers"):
                self._timers = []
            self._timers.append(t)
        except Exception:
            try:
                func(*args)
            except Exception:
                pass

    def close(self):
        if self._closing:
            Screen.close(self)