# -*- coding: utf-8 -*-
"""
core/webif_updater.py — تحديث قسم [webif] في oscam.conf / ncam.conf

يُوفّر:
    - update_webif_config()    : تحديث ملف معيّن
    - apply_webif_settings()   : طبّق إعدادات kind ("oscam"|"ncam")

آمن: يُنشئ نسخة .bak قبل الكتابة، ويكتب عبر tmp + os.replace.
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import shutil

from ..utils import logger
from .helpers import (
    read_text_file, write_text_file, extract_port_from_url,
    WEBIF_SECTION_RE, SECTION_RE_ANY, KV_RE
)


# ═══════════════════════════════════════════════════════════════════
#  تحليل قسم [webif]
# ═══════════════════════════════════════════════════════════════════
def _parse_webif_section(content):
    """
    يُحلّل محتوى ملف ويُرجع معلومات قسم [webif].

    Returns:
        (lines, webif_start, webif_end, existing)
        - lines        : قائمة الأسطر (بدون \n)
        - webif_start  : فهرس أول سطر في [webif] أو None
        - webif_end    : فهرس أول سطر بعد [webif] أو None
        - existing     : dict للمفاتيح الموجودة (lowercase)
    """
    lines = content.splitlines()
    webif_start = None
    webif_end = None
    existing = {}

    for i, line in enumerate(lines):
        if WEBIF_SECTION_RE.match(line):
            webif_start = i

            # ابحث عن نهاية القسم
            for j in range(i + 1, len(lines)):
                if SECTION_RE_ANY.match(lines[j]):
                    webif_end = j
                    break
            if webif_end is None:
                webif_end = len(lines)

            # استخرج المفاتيح الموجودة
            for k in range(i + 1, webif_end):
                m = KV_RE.match(lines[k])
                if m:
                    existing[m.group(1).lower()] = m.group(2).strip()
            break

    return lines, webif_start, webif_end, existing


# ═══════════════════════════════════════════════════════════════════
#  تحديث ملف الإعدادات
# ═══════════════════════════════════════════════════════════════════
def update_webif_config(conf_path, httpport=None, httpuser=None,
                         httppwd=None):
    """
    تحديث قسم [webif] في ملف oscam.conf / ncam.conf.

    Args:
        conf_path : مسار الملف
        httpport  : رقم المنفذ (int|str) أو None لتجاهله
        httpuser  : اسم المستخدم أو None
        httppwd   : كلمة المرور أو None

    Returns:
        (ok: bool, message: str, changed: bool)
    """
    if not conf_path:
        return False, "No config path", False

    if not os.path.exists(conf_path):
        return False, "File not found: %s" % conf_path, False

    content = read_text_file(conf_path)
    if content is None:
        return False, "Cannot read: %s" % conf_path, False

    lines, w_start, w_end, existing = _parse_webif_section(content)

    # القيم الجديدة المطلوب كتابتها
    updates = {}
    if httpport is not None:
        updates["httpport"] = str(httpport)
    if httpuser is not None:
        updates["httpuser"] = str(httpuser)
    if httppwd is not None:
        updates["httppwd"] = str(httppwd)

    # هل هناك تغيير فعلي؟
    changed = False
    for k, v in updates.items():
        if existing.get(k) != v:
            changed = True
            break

    if not changed:
        return True, "No changes needed", False

    # ═══════════════════════════════════════════════════════════════
    #  لا يوجد قسم [webif] → أضِفه في نهاية الملف
    # ═══════════════════════════════════════════════════════════════
    if w_start is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines.append("[webif]")
        for k in ("httpport", "httpuser", "httppwd"):
            if k in updates:
                lines.append("%-13s = %s" % (k, updates[k]))

    # ═══════════════════════════════════════════════════════════════
    #  القسم موجود → حدّث المفاتيح داخله
    # ═══════════════════════════════════════════════════════════════
    else:
        section_lines = lines[w_start + 1:w_end]
        seen = set()
        new_section = []

        for ln in section_lines:
            m = KV_RE.match(ln)
            if m:
                key = m.group(1).lower()
                if key in updates:
                    new_section.append("%-13s = %s" % (key, updates[key]))
                    seen.add(key)
                else:
                    new_section.append(ln)
            else:
                new_section.append(ln)

        # أضِف المفاتيح الجديدة في نهاية القسم
        for k in ("httpport", "httpuser", "httppwd"):
            if k in updates and k not in seen:
                new_section.append("%-13s = %s" % (k, updates[k]))

        lines = lines[:w_start + 1] + new_section + lines[w_end:]

    # ═══════════════════════════════════════════════════════════════
    #  أعِد بناء المحتوى
    # ═══════════════════════════════════════════════════════════════
    new_content = "\n".join(lines)
    if not new_content.endswith("\n"):
        new_content += "\n"

    # نسخة احتياطية
    try:
        shutil.copy2(conf_path, conf_path + ".bak")
    except Exception:
        pass

    if not write_text_file(conf_path, new_content):
        return False, "Write failed", False

    return True, "Updated", True


# ═══════════════════════════════════════════════════════════════════
#  تطبيق إعدادات WebIF حسب النوع
# ═══════════════════════════════════════════════════════════════════
def apply_webif_settings(kind, oscam_conf_file, ncam_conf_file,
                          config_section):
    """
    يطبّق إعدادات WebIF على ملف الإعدادات المناسب.

    Args:
        kind             : "oscam" أو "ncam"
        oscam_conf_file  : مسار oscam.conf
        ncam_conf_file   : مسار ncam.conf
        config_section   : config.plugins.OscamReaderManager

    Returns:
        (ok: bool, message: str, changed: bool)
    """
    if kind == "oscam":
        conf_path = oscam_conf_file
        url  = config_section.oscam_url.value
        user = config_section.oscam_user.value
        pwd  = config_section.oscam_pass.value
    else:
        conf_path = ncam_conf_file
        url  = config_section.ncam_url.value
        user = config_section.ncam_user.value
        pwd  = config_section.ncam_pass.value

    port = extract_port_from_url(url)
    if port is None:
        return False, "Cannot extract port from URL: %s" % url, False

    ok, msg, changed = update_webif_config(
        conf_path, httpport=port, httpuser=user, httppwd=pwd)

    logger.log("WebIF",
               "%s: %s (changed=%s) file=%s"
               % (kind, msg, changed, conf_path))

    return ok, msg, changed