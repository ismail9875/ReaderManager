# -*- coding: utf-8 -*-
"""
core/helpers.py — دوال مساعدة عامة + ثوابت + Maps/Regex

يحتوي على:
    - ثوابت عامة (HOST_MASK)
    - Regex للـ [webif] (WEBIF_SECTION_RE, SECTION_RE_ANY, KV_RE)
    - دوال URL (validate_url, extract_port_from_url)
    - دوال الملفات (read_text_file, write_text_file)
    - دوال العرض (display_host)

الاستخدام:
    from core.helpers import display_host, validate_url, read_text_file
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import re

# ─── توافق Py2/Py3 للـ open مع encoding ───
try:
    from io import open
except ImportError:
    pass

from ..utils import logger


# ═══════════════════════════════════════════════════════════════════
#  ثوابت عامة
# ═══════════════════════════════════════════════════════════════════
HOST_MASK = "*****"


# ═══════════════════════════════════════════════════════════════════
#  Regex — قسم [webif] والـ key=value
# ═══════════════════════════════════════════════════════════════════
WEBIF_SECTION_RE = re.compile(r"^\s*\[\s*webif\s*\]\s*$", re.IGNORECASE)
SECTION_RE_ANY   = re.compile(r"^\s*\[[^\]]+\]\s*$")
KV_RE            = re.compile(r"^\s*([A-Za-z0-9_\-]+)\s*=\s*(.*?)\s*$")


# ═══════════════════════════════════════════════════════════════════
#  دوال العرض
# ═══════════════════════════════════════════════════════════════════
def display_host(host):
    """
    إخفاء عنوان المضيف للعرض الآمن.

    Examples:
        display_host("192.168.1.100")  ->  "*****"
        display_host("-")              ->  "-"
        display_host("")               ->  ""
    """
    if not host or host == "-":
        return host
    return HOST_MASK


# ═══════════════════════════════════════════════════════════════════
#  دوال URL
# ═══════════════════════════════════════════════════════════════════
def validate_url(url):
    """
    التحقق من صحة URL (http/https فقط).

    Returns:
        (ok: bool, error_message: str)
    """
    try:
        try:
            from urllib.parse import urlparse
        except ImportError:
            from urlparse import urlparse

        p = urlparse(url)
        if p.scheme not in ("http", "https"):
            return False, "Only http/https allowed"
        if not p.hostname:
            return False, "Missing hostname"
        return True, ""
    except Exception as e:
        return False, str(e)


def extract_port_from_url(url, default=None):
    """
    استخراج رقم المنفذ من URL.

    Examples:
        extract_port_from_url("http://127.0.0.1:8888")  ->  8888
        extract_port_from_url("http://host")            ->  None
    """
    try:
        try:
            from urllib.parse import urlparse
        except ImportError:
            from urlparse import urlparse

        p = urlparse(url)
        if p.port:
            return p.port
    except Exception:
        pass
    return default


# ═══════════════════════════════════════════════════════════════════
#  دوال الملفات
# ═══════════════════════════════════════════════════════════════════
def read_text_file(path):
    """
    قراءة ملف نصي مع توافق Py2/Py3.

    Returns:
        str | None
    """
    if not path or not os.path.exists(path):
        return None

    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except TypeError:
        # Py2: open() لا يقبل encoding keyword
        try:
            with open(path, "r") as f:
                data = f.read()
            if isinstance(data, bytes):
                data = data.decode("utf-8", "ignore")
            return data
        except Exception:
            return None
    except Exception:
        return None


def write_text_file(path, content):
    """
    كتابة آمنة عبر tmp + os.replace.

    - يكتب إلى ملف مؤقت أولاً.
    - ينقل الملف المؤقت إلى الهدف (atomic).
    - في حال الفشل: ينظّف الملف المؤقت.

    Returns:
        bool
    """
    folder = os.path.dirname(path) or "."
    tmp_path = os.path.join(folder, ".%s.tmp" % os.path.basename(path))

    try:
        try:
            # Py3: open() مع encoding
            with open(tmp_path, "w", encoding="utf-8") as f:
                f.write(content)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
        except TypeError:
            # Py2: open() بدون encoding
            with open(tmp_path, "w") as f:
                if isinstance(content, bytes):
                    content = content.decode("utf-8", "ignore")
                f.write(content)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass

        os.replace(tmp_path, path)
        return True

    except Exception as e:
        # تنظيف الملف المؤقت عند الفشل
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass

        logger.log("Helpers", "write failed for %s: %s" % (path, e))
        return False