# -*- coding: utf-8 -*-
"""
OscamReaderManager — Enigma2 Plugin

Manage OSCam & NCam readers via WebIF with:
  - Reader management (Add/Edit/Delete/Toggle)
  - WebIF settings for OSCam & NCam
  - Emulator (SoftCam) manager
  - Real-time reader status
  - Multi-language field help

البنية:
    OscamReaderManager/
    ├── plugin.py              # نقطة الدخول (PluginDescriptor)
    ├── core/                  # منطق البلوجين
    │   ├── config_setup.py
    │   ├── helpers.py
    │   ├── webif_updater.py
    │   └── softcam_detect.py
    ├── screens/               # شاشات Enigma2
    │   ├── settings.py
    │   ├── emulator_screen.py
    │   ├── log_viewer.py
    │   └── reader_manager.py
    ├── utils/                 # وحدات مستقلة قابلة لإعادة الاستخدام
    │   ├── logger.py
    │   ├── paths.py
    │   ├── reader_parser.py
    │   ├── reader_dialog.py
    │   ├── reader_view.py
    │   ├── field_help.py
    │   ├── oscamapi.py
    │   ├── ncamapi.py
    │   ├── restart_oscam.py
    │   ├── restart_ncam.py
    │   ├── emu_manager.py
    │   └── test_queue.py
    └── images/                # موارد PNG
"""
from __future__ import absolute_import, print_function, unicode_literals


__version__ = "2.0.0"
__author__  = "Reader Manager"
__all__ = []