# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

from .plugin import main, Plugins

__version__ = "1.0"
__author__  = "IsmailSaidi"
__name__    = "Reader Manager"