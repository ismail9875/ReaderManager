# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import sys
import time
import traceback

# ─── توافق Py2/Py3 للـ open مع encoding ───
try:
    from io import open
except ImportError:
    pass


LOG_FILE = "/tmp/ReaderManager.log"
MAX_SIZE = 50 * 1024          # 50 KB
ENABLED  = True

_fh = None


def _get_handle():
    global _fh
    if _fh is not None:
        return _fh
    try:
        if os.path.exists(LOG_FILE):
            try:
                size = os.path.getsize(LOG_FILE)
                if size > MAX_SIZE:
                    # عند الوصول للحد → احذف المحتوى وابدأ من جديد
                    try:
                        os.remove(LOG_FILE)
                    except Exception:
                        # إذا فشل الحذف → اقتصر على تفريغه
                        try:
                            with open(LOG_FILE, "w"):
                                pass
                        except Exception:
                            pass
            except Exception:
                pass
        _fh = open(LOG_FILE, "a")
    except Exception as e:
        try:
            sys.stderr.write("[Logger] cannot open %s: %s\n"
                             % (LOG_FILE, e))
        except Exception:
            pass
        _fh = None
    return _fh


def _stamp():
    try:
        t = time.localtime()
        ms = int((time.time() % 1) * 1000)
        return "%04d-%02d-%02d %02d:%02d:%02d.%03d" % (
            t.tm_year, t.tm_mon, t.tm_mday,
            t.tm_hour, t.tm_min, t.tm_sec, ms)
    except Exception:
        return time.ctime()


def log(tag, message):
    if not ENABLED:
        return
    line = "[%s] [%s] %s" % (_stamp(), tag, message)
    try:
        print(line)
    except Exception:
        pass
    try:
        fh = _get_handle()
        if fh is not None:
            # تحقق دوري من الحجم أثناء الكتابة
            try:
                if fh.tell() > MAX_SIZE:
                    _rotate()
                    fh = _get_handle()
            except Exception:
                pass
            fh.write(line + "\n")
            fh.flush()
    except Exception:
        pass


def _rotate():
    """يُغلق الملف الحالي ويحذف محتواه ليبدأ من جديد."""
    global _fh
    try:
        if _fh is not None:
            _fh.close()
    except Exception:
        pass
    _fh = None
    try:
        if os.path.exists(LOG_FILE):
            os.remove(LOG_FILE)
    except Exception:
        try:
            with open(LOG_FILE, "w"):
                pass
        except Exception:
            pass
    # افتح ملف جديد فارغ
    try:
        _fh = open(LOG_FILE, "a")
    except Exception:
        _fh = None


def log_exc(tag, message, exc_info=None):
    log(tag, "EXCEPTION: %s" % message)
    if exc_info is None:
        exc_info = sys.exc_info()
    try:
        tb_lines = traceback.format_exception(*exc_info)
        for ln in tb_lines:
            for sub in ln.rstrip().split("\n"):
                log(tag, "  " + sub)
    except Exception:
        pass


def section(title):
    log("=====", "")
    log("=====", "===== %s =====" % title)
    log("=====", "")


def clear():
    global _fh
    try:
        if _fh is not None:
            _fh.close()
    except Exception:
        pass
    _fh = None
    try:
        if os.path.exists(LOG_FILE):
            os.remove(LOG_FILE)
    except Exception:
        pass
    log("Logger", "Log cleared")


def get_log_path():
    return LOG_FILE


def dump():
    try:
        with open(LOG_FILE, "r") as f:
            return f.read()
    except Exception:
        return ""