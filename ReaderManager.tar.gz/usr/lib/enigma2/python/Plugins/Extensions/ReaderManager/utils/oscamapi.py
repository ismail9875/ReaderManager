# -*- coding: utf-8 -*-
"""
utils/oscamapi.py — عميل OSCam WebIF API مستقل.

v6 (نهائي):
    - المصادر الثلاثة:
        1) part=status     → totals
        2) part=readerlist → ECMs/CWs لكل قارئ (ecmsok, ecmsnok...)
        3) readers.html    → avg_time / min / max
    - دعم كامل للإصدارات القديمة
"""
from __future__ import absolute_import, print_function, unicode_literals

import base64
import json
import re
import time
from os.path import exists

try:
    from urllib2 import (build_opener, Request, HTTPHandler,
                         HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                         HTTPDigestAuthHandler, URLError, HTTPError)
    from urllib import unquote, quote
except ImportError:
    from urllib.request import (build_opener, Request, HTTPHandler,
                                 HTTPSHandler, HTTPPasswordMgrWithDefaultRealm,
                                 HTTPDigestAuthHandler)
    from urllib.error import URLError, HTTPError
    from urllib.parse import unquote, quote

try:
    from ssl import create_default_context, _create_unverified_context
except ImportError:
    create_default_context = None
    _create_unverified_context = None

from . import logger

try:
    from . import restart_oscam
    _HAS_RESTART = True
except Exception:
    restart_oscam = None
    _HAS_RESTART = False


# ═══════════════════════════════════════════════════════════════════
#  حالات OSCam
# ═══════════════════════════════════════════════════════════════════
STATUS_CONNECTED  = "CONNECTED"
STATUS_CARDOK     = "CARDOK"
STATUS_OFF        = "OFF"
STATUS_ERROR      = "ERROR"
STATUS_NEEDINIT   = "NEEDINIT"
STATUS_DISABLED   = "DISABLED"
STATUS_UNKNOWN    = "UNKNOWN"
STATUS_INIT       = "INIT"
STATUS_NOACCESS   = "NOACCESS"
STATUS_ONLINE     = "ONLINE"
STATUS_ACTIVE     = "ACTIVE"

INVALID_CAIDS = {"0000", "000000", "00000000", ""}


# ═══════════════════════════════════════════════════════════════════
#  ReaderStatus
# ═══════════════════════════════════════════════════════════════════
class ReaderStatus(object):
    __slots__ = (
        "label", "enabled", "status", "protocol", "device",
        "port", "cards", "card_count", "localcards",
        "ecmok", "ecmnok", "online", "idle",
        "cccversion", "last_ecm_time", "last_channel",
        "caid", "provid", "au",
        "entitlements_count", "cards_details", "raw",
        "ecm_count", "cw_count", "ecm_timeout", "emm_count",
        "avg_time_ms", "min_time_ms", "max_time_ms",
        "success_rate_val",
    )

    def __init__(self, data=None):
        self.label = ""
        self.enabled = False
        self.status = STATUS_UNKNOWN
        self.protocol = ""
        self.device = ""
        self.port = 0
        self.cards = 0
        self.card_count = 0
        self.localcards = 0
        self.ecmok = 0
        self.ecmnok = 0
        self.online = 0
        self.idle = 0
        self.cccversion = ""
        self.last_ecm_time = ""
        self.last_channel = ""
        self.caid = ""
        self.provid = ""
        self.au = ""
        self.entitlements_count = 0
        self.cards_details = []
        self.raw = {}
        self.ecm_count = 0
        self.cw_count = 0
        self.ecm_timeout = 0
        self.emm_count = 0
        self.avg_time_ms = 0.0
        self.min_time_ms = 0.0
        self.max_time_ms = 0.0
        self.success_rate_val = None

        if data:
            self._parse(data)

    def _parse(self, data):
        self.raw = data
        self.label      = data.get("label", "") or ""
        self.enabled    = bool(data.get("enabled", True))
        self.status     = ((data.get("status") or STATUS_UNKNOWN)
                           .upper().strip())
        self.protocol   = data.get("protocol", "") or ""
        self.device     = data.get("device", "") or ""
        self.port       = self._to_int(data.get("port", 0))
        self.cards      = self._to_int(data.get("cards", 0))
        self.card_count = self._to_int(
            data.get("card_count", self.cards))
        self.localcards = self._to_int(data.get("localcards", 0))
        self.ecmok      = self._to_int(data.get("ecmok", 0))
        self.ecmnok     = self._to_int(data.get("ecmnok", 0))
        self.online     = self._to_int(data.get("online", 0))
        self.idle       = self._to_int(data.get("idle", 0))
        self.cccversion = data.get("cccversion", "") or ""
        self.last_ecm_time = data.get("last_ecm_time", "") or ""
        self.last_channel  = data.get("last_channel", "") or ""
        self.caid       = data.get("caid", "") or ""
        self.provid     = data.get("provid", "") or ""
        self.au         = data.get("au", "") or ""
        self.entitlements_count = self._to_int(
            data.get("entitlements_count", 0))
        self.cards_details = data.get("cards_details", []) or []

        self.ecm_count = self._to_int(
            data.get("ecm_count") or data.get("ecm") or 0)
        self.cw_count = self._to_int(
            data.get("cw_count") or data.get("cw") or data.get("cws") or 0)
        self.ecm_timeout = self._to_int(
            data.get("ecm_timeout") or data.get("timeouts") or 0)
        self.emm_count = self._to_int(
            data.get("emm_count") or data.get("emm") or 0)
        self.avg_time_ms = self._to_float(
            data.get("avg_time_ms") or data.get("avg_time")
            or data.get("ecmtime") or 0.0)
        self.min_time_ms = self._to_float(
            data.get("min_time_ms") or data.get("min_time") or 0.0)
        self.max_time_ms = self._to_float(
            data.get("max_time_ms") or data.get("max_time") or 0.0)

        sr = data.get("success_rate_val")
        if sr is not None:
            self.success_rate_val = self._to_float(sr)

        if self.ecm_count == 0 and (self.ecmok > 0 or self.ecmnok > 0):
            self.ecm_count = self.ecmok + self.ecmnok
        if self.cw_count == 0 and self.ecmok > 0:
            self.cw_count = self.ecmok

    @staticmethod
    def _to_int(v):
        if v is None:
            return 0
        if isinstance(v, bool):
            return 1 if v else 0
        try:
            if isinstance(v, str):
                m = re.search(r"-?\d+", v.replace(",", "").replace(".", ""))
                if m:
                    return int(m.group())
            return int(v)
        except (ValueError, TypeError):
            return 0

    @staticmethod
    def _to_float(v):
        if v is None:
            return 0.0
        try:
            if isinstance(v, str):
                v = v.replace(",", ".").strip()
                m = re.search(r"[-+]?\d*\.?\d+", v)
                if m:
                    return float(m.group())
            return float(v)
        except (ValueError, TypeError):
            return 0.0

    @property
    def is_connected(self):
        return self.status in (STATUS_CONNECTED, STATUS_CARDOK,
                                STATUS_ONLINE, STATUS_ACTIVE)

    @property
    def is_off(self):
        return self.status in (STATUS_OFF, STATUS_DISABLED)

    @property
    def is_error(self):
        return self.status in (STATUS_ERROR, STATUS_NOACCESS)

    @property
    def is_working(self):
        return self.is_connected and self.ecmok > 0

    @property
    def display_status(self):
        return self.status

    @property
    def display_cards(self):
        if not self.is_connected:
            return "-"
        if self.card_count > 0:
            return str(self.card_count)
        return "0"

    @property
    def success_rate(self):
        if self.success_rate_val is not None:
            return self.success_rate_val
        if self.ecm_count > 0:
            return (self.ecmok * 100.0) / self.ecm_count
        if self.ecmok > 0:
            return 100.0
        return 0.0

    def to_dict(self):
        return {
            "label": self.label,
            "enabled": self.enabled,
            "status": self.status,
            "protocol": self.protocol,
            "device": self.device,
            "port": self.port,
            "cards": self.cards,
            "card_count": self.card_count,
            "localcards": self.localcards,
            "ecmok": self.ecmok,
            "ecmnok": self.ecmnok,
            "ecm_count": self.ecm_count,
            "cw_count": self.cw_count,
            "ecm_timeout": self.ecm_timeout,
            "emm_count": self.emm_count,
            "avg_time_ms": self.avg_time_ms,
            "min_time_ms": self.min_time_ms,
            "max_time_ms": self.max_time_ms,
            "success_rate": self.success_rate,
            "online": self.online,
            "idle": self.idle,
            "cccversion": self.cccversion,
            "last_channel": self.last_channel,
            "caid": self.caid,
            "provid": self.provid,
            "au": self.au,
            "entitlements_count": self.entitlements_count,
            "is_connected": self.is_connected,
            "is_working": self.is_working,
        }

    def __repr__(self):
        return "<ReaderStatus %s: %s cards=%d ecm=%d/%d avg=%.0f>" % (
            self.label, self.status, self.card_count,
            self.ecmok, self.ecm_count, self.avg_time_ms)


# ═══════════════════════════════════════════════════════════════════
#  OSCamAPIError
# ═══════════════════════════════════════════════════════════════════
class OSCamAPIError(Exception):
    pass


# ═══════════════════════════════════════════════════════════════════
#  OSCamAPI
# ═══════════════════════════════════════════════════════════════════
class OSCamAPI(object):
    def __init__(self, base_url=None, username="", password="",
                 timeout=5.0):
        self.base_url = (base_url or "").rstrip("/")
        self.username = username or ""
        self.password = password or ""
        self.timeout = timeout
        self._last_request = 0
        self._last_result = []
        self._last_error = ""
        self._last_method = ""
        self._last_totals = {}
        self._entitlement_cache = {}

    # ------------------------------------------------------------------
    #  HTTP
    # ------------------------------------------------------------------
    def _make_auth_header(self):
        if not self.username:
            return {}
        creds = "%s:%s" % (self.username, self.password)
        try:
            token = base64.b64encode(creds.encode("utf-8")).decode("ascii")
        except Exception:
            token = base64.b64encode(creds)
            if isinstance(token, bytes):
                token = token.decode("ascii")
        return {"Authorization": "Basic %s" % token}

    def _http_get(self, path, timeout=None):
        if not self.base_url:
            raise OSCamAPIError("Base URL not configured")
        url = "%s%s" % (self.base_url, path)
        cache_buster = ("&_t=%d" % int(time.time() * 1000)
                        if "?" in path
                        else "?_t=%d" % int(time.time() * 1000))
        url += cache_buster

        headers = self._make_auth_header()
        headers["User-Agent"] = "Enigma2-ReaderManager/1.0"
        headers["Accept"] = "application/json, text/xml, text/html, */*"
        headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        headers["Pragma"] = "no-cache"

        try:
            req = Request(url, headers=headers)
            resp = build_opener(HTTPHandler).open(
                req, timeout=timeout or self.timeout)
            data = resp.read()
            if isinstance(data, bytes):
                data = data.decode("utf-8", "replace")
            return data
        except HTTPError as e:
            msg = "HTTP %d: %s" % (e.code, e.reason)
            self._last_error = msg
            raise OSCamAPIError(msg)
        except URLError as e:
            msg = "URL error: %s" % e.reason
            self._last_error = msg
            raise OSCamAPIError(msg)
        except Exception as e:
            msg = "Request failed: %s" % e
            self._last_error = msg
            raise OSCamAPIError(msg)

    # ------------------------------------------------------------------
    #  Control API
    # ------------------------------------------------------------------
    def restart(self, force=True, script_hint=None, binary_hint=None):
        if not _HAS_RESTART:
            return False, "restart_oscam module not available"
        try:
            if script_hint:
                restart_oscam.set_script_hint(script_hint)
            if binary_hint:
                restart_oscam.set_binary_hint(binary_hint)
            return restart_oscam.restart(force=force)
        except Exception as e:
            return False, "restart exception: %s" % e

    def stop(self, script_hint=None):
        if not _HAS_RESTART:
            return False, "restart_oscam module not available"
        try:
            if script_hint:
                restart_oscam.set_script_hint(script_hint)
            if hasattr(restart_oscam, "stop_only"):
                return restart_oscam.stop_only()
            return False, "stop_only not implemented"
        except Exception as e:
            return False, "stop exception: %s" % e

    def start(self, script_hint=None, binary_hint=None):
        if not _HAS_RESTART:
            return False, "restart_oscam module not available"
        try:
            if script_hint:
                restart_oscam.set_script_hint(script_hint)
            if binary_hint:
                restart_oscam.set_binary_hint(binary_hint)
            if hasattr(restart_oscam, "start_only"):
                return restart_oscam.start_only()
            return False, "start_only not implemented"
        except Exception as e:
            return False, "start exception: %s" % e

    def is_running(self):
        if not _HAS_RESTART:
            return False
        try:
            if hasattr(restart_oscam, "is_running"):
                running, _ = restart_oscam.is_running()
                return bool(running)
            return False
        except Exception:
            return False

    # ------------------------------------------------------------------
    #  Main API
    # ------------------------------------------------------------------
    def get_reader_status(self):
        """
        v6: 3 مصادر:
            1) part=status     → totals
            2) part=readerlist → إحصائيات لكل قارئ
            3) readers.html    → avg_time / min / max
        """
        self._last_request = time.time()
        self._last_totals = {}

        self._fetch_status_and_totals()
        self._fetch_readerlist()
        self._enrich_with_html_times()   # ⭐ جديد
        self._enrich_with_entitlements()

        return self._last_result

    def _fetch_status_and_totals(self):
        try:
            data = self._http_get("/oscamapi.json?part=status")
            logger.log("OSCamAPI", "status: %d bytes" % len(data))
            obj = json.loads(data)
            self._last_totals = self._parse_totals(obj)
            if self._last_totals:
                logger.log("OSCamAPI",
                           "Totals: cwok=%d cwnok=%d ecm=%d readers=%d/%d"
                           % (self._last_totals.get("total_cwok_readers", 0),
                              self._last_totals.get("total_cwnok_readers", 0),
                              self._last_totals.get("total_sum_all_readers_ecm", 0),
                              self._last_totals.get("total_connected_readers", 0),
                              self._last_totals.get("total_readers", 0)))
        except Exception as e:
            logger.log("OSCamAPI", "status/totals error: %s" % e)

    def _fetch_readerlist(self):
        try:
            data = self._http_get("/oscamapi.json?part=readerlist")
            logger.log("OSCamAPI", "readerlist: %d bytes" % len(data))
            readers = self._parse_readerlist(data)
            if readers:
                self._last_result = readers
                self._last_method = "readerlist"
                self._last_error = ""
                logger.log("OSCamAPI",
                           "readerlist OK: %d readers" % len(readers))
                return readers
        except OSCamAPIError as e:
            logger.log("OSCamAPI", "readerlist failed: %s" % e)

        # fallback
        try:
            data = self._http_get("/oscamapi.html?part=status")
            readers = self._parse_xml_readers(data)
            if readers:
                self._last_result = readers
                self._last_method = "xml"
                return readers
        except OSCamAPIError:
            pass

        try:
            data = self._http_get("/readers.html")
            readers = self._parse_status_html(data)
            if readers:
                self._last_result = readers
                self._last_method = "html"
                return readers
        except OSCamAPIError:
            pass

        return []

    # ------------------------------------------------------------------
    #  ⭐ HTML times enrichment
    # ------------------------------------------------------------------
    def _enrich_with_html_times(self):
        """
        يقرأ readers.html ويستخرج avg_time/min/max لكل قارئ.
        OSCam يعرضها في statuscol14 و statuscol15/16.
        """
        if not self._last_result:
            return

        try:
            data = self._http_get("/readers.html")
        except OSCamAPIError as e:
            logger.log("OSCamAPI",
                       "readers.html fetch failed: %s" % e)
            return

        if not data or "<table" not in data:
            return

        # ─── استخرج القيم لكل قارئ ───
        times_map = {}

        row_pattern = re.compile(
            r'<tr\s+id="id_(0x[0-9a-fA-F]+)"\s+class="([rp])"[^>]*>(.*?)</tr>',
            re.DOTALL | re.IGNORECASE)

        for row_match in row_pattern.finditer(data):
            row = row_match.group(3)

            label = None
            m = re.search(
                r'<td[^>]*class="[^"]*statuscol4[^"]*"[^>]*>'
                r'(?:<a[^>]*>)?\s*([^<\s]+)',
                row, re.IGNORECASE)
            if m:
                label = m.group(1).strip()
            if not label:
                continue

            # ابحث عن avg_time في statuscol14
            avg = 0.0
            m = re.search(
                r'<td[^>]*class="[^"]*statuscol14[^"]*"[^>]*>\s*([\d.]+)',
                row, re.IGNORECASE)
            if m:
                try:
                    avg = float(m.group(1))
                except (ValueError, TypeError):
                    pass

            # min في statuscol15
            mn = 0.0
            m = re.search(
                r'<td[^>]*class="[^"]*statuscol15[^"]*"[^>]*>\s*([\d.]+)',
                row, re.IGNORECASE)
            if m:
                try:
                    mn = float(m.group(1))
                except (ValueError, TypeError):
                    pass

            # max في statuscol16
            mx = 0.0
            m = re.search(
                r'<td[^>]*class="[^"]*statuscol16[^"]*"[^>]*>\s*([\d.]+)',
                row, re.IGNORECASE)
            if m:
                try:
                    mx = float(m.group(1))
                except (ValueError, TypeError):
                    pass

            if avg > 0 or mn > 0 or mx > 0:
                times_map[label] = {
                    "avg": avg,
                    "min": mn,
                    "max": mx,
                }

        # ─── ادمج مع القراء ───
        enriched = 0
        for r in self._last_result:
            t = times_map.get(r.label)
            if not t:
                continue
            if t["avg"] > 0:
                r.avg_time_ms = t["avg"]
            if t["min"] > 0:
                r.min_time_ms = t["min"]
            if t["max"] > 0:
                r.max_time_ms = t["max"]
            enriched += 1

        if enriched > 0:
            logger.log("OSCamAPI",
                       "Enriched %d reader(s) with HTML times" % enriched)

    # ------------------------------------------------------------------
    #  parser: readerlist
    # ------------------------------------------------------------------
    def _parse_readerlist(self, data):
        result = []

        if not data or not data.strip().startswith("{"):
            return result

        try:
            obj = json.loads(data)
        except Exception as e:
            logger.log("OSCamAPI", "readerlist parse: %s" % e)
            return result

        oscam = obj.get("oscam", {})
        if not isinstance(oscam, dict):
            return result

        readers_list = oscam.get("readers", [])
        if not isinstance(readers_list, list):
            return result

        for item in readers_list:
            if not isinstance(item, dict):
                continue
            try:
                r = self._readerlist_item_to_status(item)
                if r:
                    result.append(r)
            except Exception as e:
                logger.log("OSCamAPI",
                           "readerlist item error: %s" % e)

        return result

    def _readerlist_item_to_status(self, item):
        stats = item.get("stats", {})
        if not isinstance(stats, dict):
            stats = {}

        ecmsok = self._to_int(stats.get("ecmsok", 0))
        ecmsnok = self._to_int(stats.get("ecmsnok", 0))
        ecmstout = self._to_int(stats.get("ecmstout", 0))

        sr = None
        rel_str = stats.get("ecmsokrel", "")
        if rel_str:
            m = re.search(r"([\d.]+)", str(rel_str))
            if m:
                try:
                    sr = float(m.group(1))
                except (ValueError, TypeError):
                    pass

        raw_status = item.get("status", "") or ""
        clean_status = re.sub(r'<[^>]+>', '', raw_status).strip().upper()

        cls = (item.get("classname", "") or "").lower()
        if "connected" in cls:
            clean_status = "CONNECTED"
        elif "online" in cls:
            clean_status = "ONLINE"
        elif "disabled" in cls:
            clean_status = "DISABLED"
        elif "off" in cls and "offline" not in cls:
            clean_status = "OFF"

        if not clean_status:
            clean_status = "UNKNOWN"

        enabled_raw = item.get("enabled", "1")
        enabled = str(enabled_raw).lower() in ("1", "true", "yes", "on")

        data = {
            "label":       (item.get("label") or "").strip(),
            "enabled":     enabled,
            "status":      clean_status,
            "protocol":    item.get("protocol", "") or "",
            "device":      item.get("ip", "") or "",
            "port":        self._to_int(item.get("port", 0)),
            "ecm_count":   ecmsok + ecmsnok + ecmstout,
            "ecmok":       ecmsok,
            "ecmnok":      ecmsnok,
            "ecm_timeout": ecmstout,
            "cw_count":    ecmsok,
            "success_rate_val": sr,
        }

        return ReaderStatus(data)

    # ------------------------------------------------------------------
    #  parser: totals
    # ------------------------------------------------------------------
    def _parse_totals(self, obj):
        result = {
            "total_readers": 0,
            "total_connected_readers": 0,
            "total_active_readers": 0,
            "total_cwok_readers": 0,
            "total_cwnok_readers": 0,
            "total_cwtout_readers": 0,
            "rel_cwok_readers": 0.0,
            "rel_cwnok_readers": 0.0,
            "total_sum_all_readers_ecm": 0,
            "total_sum_all_readers_emm": 0,
            "total_cw": 0,
            "total_cwok": 0,
        }

        if not isinstance(obj, dict):
            return result
        oscam = obj.get("oscam", {})
        if not isinstance(oscam, dict):
            return result
        totals = oscam.get("totals", {})
        if not isinstance(totals, dict):
            return result

        def _i(v):
            try:
                return int(v)
            except (ValueError, TypeError):
                return 0

        def _f(v):
            try:
                return float(v)
            except (ValueError, TypeError):
                return 0.0

        result["total_readers"] = _i(totals.get("total_readers", 0))
        result["total_connected_readers"] = _i(
            totals.get("total_connected_readers", 0))
        result["total_active_readers"] = _i(
            totals.get("total_active_readers", 0))
        result["total_cwok_readers"] = _i(
            totals.get("total_cwok_readers", 0))
        result["total_cwnok_readers"] = _i(
            totals.get("total_cwnok_readers", 0))
        result["total_cwtout_readers"] = _i(
            totals.get("total_cwtout_readers", 0))
        result["rel_cwok_readers"] = _f(
            totals.get("rel_cwok_readers", 0.0))
        result["rel_cwnok_readers"] = _f(
            totals.get("rel_cwnok_readers", 0.0))
        result["total_sum_all_readers_ecm"] = _i(
            totals.get("total_sum_all_readers_ecm", 0))
        result["total_sum_all_readers_emm"] = _i(
            totals.get("total_sum_all_readers_emm", 0))
        result["total_cw"] = _i(totals.get("total_cw", 0))
        result["total_cwok"] = _i(totals.get("total_cwok", 0))

        return result

    def get_totals(self):
        return self._last_totals or {}

    # ------------------------------------------------------------------
    #  Entitlements
    # ------------------------------------------------------------------
    def _enrich_with_entitlements(self):
        if not self._last_result:
            return
        for r in self._last_result:
            if not r.is_connected:
                continue
            try:
                ent = self.fetch_reader_entitlements(r.label)
                if ent.get("caids"):
                    r.raw["entitlements"] = ent["caids"]
                if ent.get("cards"):
                    r.cards_details = ent["cards"]
                    r.raw["cards_details"] = ent["cards"]
                if ent.get("totalcards"):
                    r.card_count = ent["totalcards"]
                    r.cards = ent["totalcards"]
            except Exception as e:
                logger.log("OSCamAPI",
                           "entitlement for %s failed: %s"
                           % (r.label, e))

    def _parse_entitlement_caids(self, data):
        result = {"caids": [], "cards": [], "totalcards": 0}
        seen = set()

        m = re.search(r'<cardlist[^>]*\btotalcards\s*=\s*["\']?(\d+)',
                      data, re.IGNORECASE)
        if m:
            try:
                result["totalcards"] = int(m.group(1))
            except (ValueError, TypeError):
                pass

        card_pattern = re.compile(
            r'<card\s+([^>]+?)(?:/>|>(.*?)</card>)',
            re.IGNORECASE | re.DOTALL)

        for card_match in card_pattern.finditer(data):
            attrs = card_match.group(1)
            body = card_match.group(2) or ""

            caid_m = re.search(r'\bcaid\s*=\s*["\']?([0-9A-Fa-f]+)',
                               attrs, re.IGNORECASE)
            if not caid_m:
                continue
            caid = caid_m.group(1).strip().upper()
            if not caid or caid in INVALID_CAIDS:
                continue

            sys_m = re.search(r'\bsystem\s*=\s*["\']?([^"\'\s>]+)',
                              attrs, re.IGNORECASE)
            system = sys_m.group(1).strip().lower() if sys_m else ""

            num_m = re.search(r'\bnumber\s*=\s*["\']?(\d+)', attrs)
            res_m = re.search(r'\breshare\s*=\s*["\']?([^"\'\s>]+)', attrs)
            hop_m = re.search(r'\bhop\s*=\s*["\']?([^"\'\s>]+)', attrs)

            providers = []
            for prov_m in re.finditer(
                    r'<provider\s+([^>]+?)(?:/>|>(.*?)</provider>)',
                    body, re.IGNORECASE | re.DOTALL):
                pattrs = prov_m.group(1)
                ptext = (prov_m.group(2) or "").strip()
                p_sa = re.search(r'\bsa\s*=\s*["\']?([^"\'\s>]*)', pattrs)
                p_caid = re.search(r'\bcaid\s*=\s*["\']?([^"\'\s>]+)', pattrs)
                p_prov = re.search(r'\bprovid\s*=\s*["\']?([^"\'\s>]+)', pattrs)
                providers.append({
                    "sa": p_sa.group(1) if p_sa else "",
                    "caid": p_caid.group(1) if p_caid else caid,
                    "provid": p_prov.group(1) if p_prov else "",
                    "service": ptext,
                })

            card = {
                "number": int(num_m.group(1)) if num_m else 0,
                "caid": caid,
                "system": system,
                "reshare": res_m.group(1) if res_m else "",
                "hop": hop_m.group(1) if hop_m else "",
                "providers": providers,
            }
            result["cards"].append(card)

            if caid not in seen:
                seen.add(caid)
                result["caids"].append({"caid": caid, "system": system})

        return result

    def fetch_reader_entitlements(self, label, cache_seconds=30):
        if not label:
            return {"caids": [], "cards": [], "totalcards": 0}

        now = time.time()
        if label in self._entitlement_cache:
            ts, cached = self._entitlement_cache[label]
            if now - ts < cache_seconds:
                return cached

        empty = {"caids": [], "cards": [], "totalcards": 0}
        try:
            path = "/oscamapi.html?part=entitlement&label=%s" % quote(label)
            data = self._http_get(path)
            if not data or "<?xml" not in data:
                self._entitlement_cache[label] = (now, empty)
                return empty
            result = self._parse_entitlement_caids(data)
            self._entitlement_cache[label] = (now, result)
            return result
        except OSCamAPIError:
            self._entitlement_cache[label] = (now, empty)
            return empty

    # ------------------------------------------------------------------
    #  Public helpers
    # ------------------------------------------------------------------
    def get_status(self):
        try:
            data = self._http_get("/oscamapi.json?part=status")
            return json.loads(data)
        except Exception:
            return {}

    def is_available(self):
        try:
            return bool(self.get_reader_status())
        except Exception:
            return False

    def get_last_error(self):
        return self._last_error

    def get_last_method(self):
        return self._last_method

    def get_readers_dict(self):
        result = {}
        for r in self.get_reader_status():
            result[r.label] = r
        return result

    # ------------------------------------------------------------------
    #  XML / HTML Parsing (fallback)
    # ------------------------------------------------------------------
    def _parse_xml_readers(self, data):
        data = (data or "").strip()
        if not data or "<" not in data[:30]:
            return []
        readers = []
        for match in re.finditer(r"<reader>(.*?)</reader>", data,
                                 re.DOTALL | re.IGNORECASE):
            block = match.group(1)
            reader_data = {}
            for m in re.finditer(
                    r"<([a-zA-Z_][a-zA-Z0-9_]*)>([^<]*)</\1>", block):
                key = m.group(1).lower()
                val = m.group(2).strip()
                if val.isdigit():
                    reader_data[key] = int(val)
                elif val.lower() in ("true", "false"):
                    reader_data[key] = val.lower() == "true"
                else:
                    reader_data[key] = val
            if reader_data:
                try:
                    readers.append(ReaderStatus(reader_data))
                except Exception:
                    pass
        return readers

    def _parse_status_html(self, html):
        if not html or "<tr" not in html:
            return []
        readers = []
        tr_pattern = re.compile(
            r'<tr\s+id="id_(0x[0-9a-fA-F]+)"\s+class="([prs])"[^>]*>',
            re.IGNORECASE)
        positions = []
        for m in tr_pattern.finditer(html):
            positions.append((m.start(), m.end(), m.group(2).lower()))
        if not positions:
            return []
        for i, (start, end, row_class) in enumerate(positions):
            if row_class == "s":
                continue
            next_start = (positions[i + 1][0]
                          if i + 1 < len(positions) else len(html))
            segment = html[end:next_start]
            close_m = re.search(r'</tr>', segment, re.IGNORECASE)
            row_html = segment[:close_m.start()] if close_m else segment
            reader = self._parse_html_row(row_html)
            if reader:
                readers.append(reader)
        return readers

    def _parse_html_row(self, row_html):
        try:
            data = {}
            m = re.search(r'<td class="statuscol4"[^>]*>(.*?)</td>',
                          row_html, re.DOTALL | re.IGNORECASE)
            if m:
                cell = m.group(1)
                a = re.search(r'<a[^>]*>([^<]+)</a>', cell)
                if a:
                    data["label"] = a.group(1).strip()
                else:
                    data["label"] = re.sub(r"<[^>]+>", "", cell).strip()
            if not data.get("label"):
                return None
            m = re.search(r'<td class="statuscol5 statuscol5(ON|OFF)"',
                          row_html, re.IGNORECASE)
            if m:
                data["enabled"] = (m.group(1).upper() == "ON")
            m = re.search(
                r'<td class="statuscol16 statuscol16([A-Z]+)"[^>]*>(.*?)</td>',
                row_html, re.DOTALL | re.IGNORECASE)
            if m:
                data["status"] = m.group(1).upper()
            if not data.get("status"):
                data["status"] = STATUS_UNKNOWN
            return ReaderStatus(data)
        except Exception:
            return None

    @staticmethod
    def _to_int(v):
        try:
            return int(v)
        except (ValueError, TypeError):
            return 0

    @staticmethod
    def _to_float(v):
        try:
            return float(v)
        except (ValueError, TypeError):
            return 0.0


# ═══════════════════════════════════════════════════════════════════
#  Auto-detect
# ═══════════════════════════════════════════════════════════════════
def configure_auto():
    ver_files = [
        "/tmp/.oscam/oscam.version",
        "/tmp/.ncam/ncam.version",
    ]
    ver_file = None
    for p in ver_files:
        if exists(p):
            ver_file = p
            break
    if not ver_file:
        raise OSCamAPIError("oscam.version not found")

    try:
        with open(ver_file, "r") as f:
            content = f.read()
    except Exception as e:
        raise OSCamAPIError("Cannot read %s: %s" % (ver_file, e))

    port = None
    config_dir = "/etc/tuxbox/config"
    ipv6_compiled = False

    for line in content.splitlines():
        line_low = line.lower()
        if "webifport:" in line_low:
            try:
                port = line.split(":")[1].strip()
            except Exception:
                pass
        elif "configdir:" in line_low:
            try:
                config_dir = line.split(":", 1)[1].strip()
            except Exception:
                pass
        elif "ipv6 support:" in line_low:
            v = line.split(":")[1].strip().lower()
            ipv6_compiled = (v == "yes")

    if not port or port == "0":
        raise OSCamAPIError("WebIF disabled")

    user = "root"
    pwd = ""
    proto = "http"
    blocked = True
    ip = "127.0.0.1"
    conf_file = config_dir.rstrip("/") + "/oscam.conf"
    if not exists(conf_file):
        conf_file = config_dir.rstrip("/") + "/ncam.conf"

    if exists(conf_file):
        try:
            with open(conf_file, "r") as f:
                for line in f:
                    line_low = line.lower().strip()
                    if line_low.startswith("httpuser"):
                        user = line.split("=", 1)[1].strip()
                    elif line_low.startswith("httppwd"):
                        pwd = line.split("=", 1)[1].strip()
                    elif line_low.startswith("httpport"):
                        v = line.split("=", 1)[1].strip()
                        if v.startswith("+"):
                            proto = "https"
                            port = v.replace("+", "").strip()
                        else:
                            port = v
                    elif line_low.startswith("httpallowed"):
                        blocked = False
                        allowed = line.split("=", 1)[1].strip()
                        if "::1" in allowed and ipv6_compiled:
                            ip = "::1"
                        elif "127.0.0.1" in allowed:
                            ip = "127.0.0.1"
        except Exception as e:
            logger.log("OSCamAPI", "conf read error: %s" % e)

    if blocked:
        raise OSCamAPIError("WebIF blocks localhost")

    base_url = "%s://%s:%s" % (proto, ip, port)
    logger.log("OSCamAPI",
               "Auto-detected: %s user=%s" % (base_url, user))
    return configure(base_url, user, pwd, timeout=5.0)


# ═══════════════════════════════════════════════════════════════════
#  Singleton
# ═══════════════════════════════════════════════════════════════════
_default_api = None


def configure(base_url, username="", password="", timeout=5.0):
    global _default_api
    _default_api = OSCamAPI(base_url, username, password, timeout)
    return _default_api


def get_default():
    return _default_api


def reset_default():
    global _default_api
    _default_api = None