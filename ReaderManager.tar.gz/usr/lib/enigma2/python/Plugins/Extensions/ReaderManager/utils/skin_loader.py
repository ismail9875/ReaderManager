# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import time

from . import logger


def _resolve_skin_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    plugin_dir = os.path.dirname(here)
    return os.path.join(plugin_dir, "skin")


SKIN_DIR = _resolve_skin_dir()

# Cache مع TTL قصير (1 ثانية)
_cache = {}
_cache_time = {}
CACHE_TTL = 1.0   # ثانية — أي طلب أقدم من ثانية يُعاد قراءته


def get_screen_skin(screen_name):
    if not screen_name:
        return None

    now = time.time()

    # ⭐ إذا كان الـ cache حديثاً (< 1s) → أعده
    if screen_name in _cache:
        age = now - _cache_time.get(screen_name, 0)
        if age < CACHE_TTL:
            return _cache[screen_name]

    filename = "%s.xml" % screen_name
    skin_path = os.path.join(SKIN_DIR, filename)

    if not os.path.isfile(skin_path):
        print("[SkinLoader] NOT FOUND: %s" % skin_path)
        return None

    try:
        with open(skin_path, "r") as f:
            content = f.read()
        _cache[screen_name] = content
        _cache_time[screen_name] = now
        print("[SkinLoader] ✓ %s loaded (%d bytes)"
              % (filename, len(content)))
        return content
    except Exception as e:
        print("[SkinLoader] ✗ read failed %s: %s" % (filename, e))
        return None


def load_screen_skin(screen_name):
    return get_screen_skin(screen_name)


def reload_all():
    """يُفرّغ الـ cache بالكامل."""
    global _cache, _cache_time
    n = len(_cache)
    _cache = {}
    _cache_time = {}
    print("[SkinLoader] reload_all: cleared %d" % n)
    return n


def get_loaded_count():
    return len(_cache)