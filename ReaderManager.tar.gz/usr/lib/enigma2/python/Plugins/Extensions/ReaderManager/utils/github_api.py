# -*- coding: utf-8 -*-
"""
utils/github_api.py — التعامل مع GitHub API لاستخراج المطورين والملفات.
"""
from __future__ import absolute_import, print_function, unicode_literals

import json
import os
import time

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
except ImportError:
    from urllib2 import Request, urlopen, HTTPError, URLError

from . import logger


# ============ الإعدادات ============
GITHUB_OWNER  = "ismail9875"
GITHUB_REPO   = "EmuCams"
GITHUB_BRANCH = "main"
GITHUB_TOKEN  = ""

API_BASE = "https://api.github.com"

CACHE_DIR = "/tmp/emucams_cache"
CACHE_TTL = 3600


def _headers():
    h = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "EmuCams-Enigma2-Plugin"
    }
    if GITHUB_TOKEN:
        h["Authorization"] = "Bearer %s" % GITHUB_TOKEN
    return h


def _cache_path(key):
    if not os.path.isdir(CACHE_DIR):
        try:
            os.makedirs(CACHE_DIR)
        except Exception:
            pass
    safe = key.replace("/", "_").replace("?", "_").replace(":", "_")
    return os.path.join(CACHE_DIR, safe + ".json")


def _read_cache(key):
    path = _cache_path(key)
    if not os.path.isfile(path):
        return None
    try:
        if time.time() - os.path.getmtime(path) > CACHE_TTL:
            return None
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return None


def _write_cache(key, data):
    try:
        with open(_cache_path(key), "w") as f:
            json.dump(data, f)
    except Exception:
        pass


def _api_get(url, use_cache=True):
    cache_key = url
    if use_cache:
        cached = _read_cache(cache_key)
        if cached is not None:
            logger.log("GitHubAPI", "cache hit: %s" % url)
            return cached

    logger.log("GitHubAPI", "GET %s" % url)
    req = Request(url, headers=_headers())

    try:
        resp = urlopen(req, timeout=20)
        raw = resp.read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        data = json.loads(raw)
        if use_cache:
            _write_cache(cache_key, data)
        return data

    except HTTPError as e:
        logger.log("GitHubAPI", "HTTPError %s for %s" % (e.code, url))
        if e.code == 403:
            logger.log("GitHubAPI", "Rate limit? Add GITHUB_TOKEN.")
        return None

    except URLError as e:
        logger.log("GitHubAPI", "URLError %s" % e)
        return None

    except Exception as e:
        logger.log("GitHubAPI", "Exception %s" % e)
        return None


def get_root_tree():
    branch_url = "%s/repos/%s/%s/branches/%s" % (
        API_BASE, GITHUB_OWNER, GITHUB_REPO, GITHUB_BRANCH)
    branch_data = _api_get(branch_url)
    if not branch_data:
        return []

    sha = branch_data.get("commit", {}).get("sha")
    if not sha:
        return []

    tree_url = "%s/repos/%s/%s/git/trees/%s?recursive=1" % (
        API_BASE, GITHUB_OWNER, GITHUB_REPO, sha)
    tree_data = _api_get(tree_url)
    if not tree_data:
        return []

    return tree_data.get("tree", [])


def _build_file_urls(path):
    return {
        "github_blob": "https://github.com/%s/%s/blob/%s/%s" % (
            GITHUB_OWNER, GITHUB_REPO, GITHUB_BRANCH, path),
        "github_raw": "https://raw.githubusercontent.com/%s/%s/%s/%s" % (
            GITHUB_OWNER, GITHUB_REPO, GITHUB_BRANCH, path),
        "download": "https://github.com/%s/%s/raw/%s/%s" % (
            GITHUB_OWNER, GITHUB_REPO, GITHUB_BRANCH, path),
    }


def get_developers():
    tree = get_root_tree()
    if not tree:
        return []

    developers = {}
    all_files = []

    for item in tree:
        path = item.get("path", "")
        typ  = item.get("type", "")

        parts = path.split("/")
        if not parts:
            continue
        dev_id = parts[0]

        if typ == "tree" and len(parts) == 1:
            developers[dev_id] = {
                "id": dev_id,
                "display": dev_id,
                "path": path,
                "sha": item.get("sha", ""),
                "files": []
            }

        elif typ == "blob" and len(parts) >= 2:
            file_entry = {
                "name": parts[-1],
                "path": path,
                "folder": "/".join(parts[:-1]),
                "sha": item.get("sha", ""),
                "size": item.get("size", 0),
                "urls": _build_file_urls(path)
            }
            all_files.append(file_entry)

    for f in all_files:
        root = f["path"].split("/")[0]
        if root in developers:
            developers[root]["files"].append(f)

    result = sorted(developers.values(), key=lambda d: d["id"].lower())
    logger.log("GitHubAPI", "developers found: %d" % len(result))
    return result


def get_files_for_developer(dev_id):
    for dev in get_developers():
        if dev["id"] == dev_id:
            return dev.get("files", [])
    return []


def download_file(url, dest_path, timeout=60):
    try:
        req = Request(url, headers=_headers())
        resp = urlopen(req, timeout=timeout)
        with open(dest_path, "wb") as f:
            f.write(resp.read())
        logger.log("GitHubAPI", "downloaded: %s" % dest_path)
        return True
    except Exception as e:
        logger.log("GitHubAPI", "download error: %s" % e)
        return False


def clear_cache():
    try:
        if os.path.isdir(CACHE_DIR):
            for f in os.listdir(CACHE_DIR):
                try:
                    os.remove(os.path.join(CACHE_DIR, f))
                except Exception:
                    pass
        return True
    except Exception:
        return False