# -*- coding: utf-8 -*-
"""
core/config_setup.py — إعدادات config.plugins.OscamReaderManager

يُنشئ قسم الإعدادات مرة واحدة عند الاستيراد، ويُوفّر:
    - General settings  (poll interval, sort mode, editor mode, ...)
    - OSCam WebIF       (enabled, autoconf, url, user, pass, timeout)
    - NCam WebIF        (enabled, autoconf, url, user, pass, timeout)
    - CAID temp bridge

الاستخدام:
    from core import config_setup   # يُنشئ config.plugins.OscamReaderManager
    from Components.config import config
    cfg = config.plugins.OscamReaderManager
"""
from __future__ import absolute_import, print_function, unicode_literals

from Components.config import (
    config, ConfigSubsection, ConfigYesNo, ConfigSelection,
    ConfigText, ConfigInteger, ConfigPassword
)


def init_config():
    """يُنشئ قسم الإعدادات إذا لم يكن موجوداً، أو يُعيده إن وُجد."""
    if hasattr(config.plugins, "OscamReaderManager"):
        return config.plugins.OscamReaderManager

    cfg = ConfigSubsection()
    config.plugins.OscamReaderManager = cfg

    # ═══════════════════════════════════════════════════════════════
    #  General Settings
    # ═══════════════════════════════════════════════════════════════
    cfg.auto_restart = ConfigYesNo(default=True)

    cfg.restart_delay = ConfigSelection(
        default="3",
        choices=[
            ("0",  "Immediate"),
            ("1",  "1 second"),
            ("3",  "3 seconds"),
            ("5",  "5 seconds"),
            ("10", "10 seconds"),
        ])

    cfg.confirm_restart = ConfigYesNo(default=False)

    cfg.poll_interval = ConfigSelection(
        default="10",
        choices=[
            (str(i), "%d second%s" % (i, "" if i == 1 else "s"))
            for i in range(1, 11)
        ])

    cfg.sort_mode = ConfigSelection(
        default="alpha",
        choices=[
            ("alpha",      "Alphabetical (A-Z)"),
            ("file",       "Original file order"),
            ("proto",      "Protocol"),
            ("cards_asc",  "Connected cards (ascending)"),
            ("cards_desc", "Connected cards (descending)"),
        ])

    cfg.default_editor_mode = ConfigSelection(
        default="simple",
        choices=[
            ("simple",   "Simple (Basic fields)"),
            ("advanced", "Advanced (All fields)"),
        ])

    # ═══════════════════════════════════════════════════════════════
    #  OSCam WebIF
    # ═══════════════════════════════════════════════════════════════
    cfg.oscam_enabled  = ConfigYesNo(default=True)
    cfg.oscam_autoconf = ConfigYesNo(default=True)
    cfg.oscam_url      = ConfigText(
        default="http://127.0.0.1:8888", fixed_size=False)
    cfg.oscam_user     = ConfigText(
        default="root", fixed_size=False)
    cfg.oscam_pass     = ConfigPassword(
        default="", fixed_size=False)
    cfg.oscam_timeout  = ConfigInteger(
        default=5, limits=(1, 30))

    # ═══════════════════════════════════════════════════════════════
    #  NCam WebIF
    # ═══════════════════════════════════════════════════════════════
    cfg.ncam_enabled  = ConfigYesNo(default=True)
    cfg.ncam_autoconf = ConfigYesNo(default=True)
    cfg.ncam_url      = ConfigText(
        default="http://127.0.0.1:8181", fixed_size=False)
    cfg.ncam_user     = ConfigText(
        default="root", fixed_size=False)
    cfg.ncam_pass     = ConfigPassword(
        default="", fixed_size=False)
    cfg.ncam_timeout  = ConfigInteger(
        default=5, limits=(1, 30))

    # ═══════════════════════════════════════════════════════════════
    #  CAID temp bridge (للاستخدام المستقبلي)
    # ═══════════════════════════════════════════════════════════════
    cfg.temp_caid = ConfigText(default="", fixed_size=False)

    return cfg


# ─── تنفيذ التهيئة عند أول استيراد ───
init_config()