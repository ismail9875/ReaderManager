# -*- coding: utf-8 -*-

from __future__ import absolute_import, print_function, unicode_literals

import os

# ═══════════════════════════════════════════════════════════════════
#  تهيئة الإعدادات (يجب أن تكون أولاً قبل أي استيراد آخر)
# ═══════════════════════════════════════════════════════════════════
from .core import config_setup  # noqa: F401


# ═══════════════════════════════════════════════════════════════════
#  المسارات العامة (للاستخدام الخارجي)
# ═══════════════════════════════════════════════════════════════════
from .utils import paths

_bootstrap = paths.bootstrap()
OSCAM_FILE = _bootstrap["oscam_file"]
NCAM_FILE  = _bootstrap["ncam_file"]

CONFIG_DIR       = _bootstrap["config_dir"]
OSCAM_CONF_FILE  = os.path.join(CONFIG_DIR, "oscam.conf")
NCAM_CONF_FILE   = os.path.join(CONFIG_DIR, "ncam.conf")


# ═══════════════════════════════════════════════════════════════════
#  ⭐ تحميل السكينات — يجب أن يكون قبل استيراد الشاشات
# ═══════════════════════════════════════════════════════════════════
from .utils import skin_loader

# حمّل كل السكينات من مجلد Skins/ فوراً
try:
    _loaded_skins, _total_skins = skin_loader.load_all()
    print("[ReaderManager] Skins loaded: %d/%d"
          % (_loaded_skins, _total_skins))
except Exception as _e:
    print("[ReaderManager] skin_loader error: %s" % _e)


# ═══════════════════════════════════════════════════════════════════
#  إعادة تصدير للتوافق الخلفي
# ═══════════════════════════════════════════════════════════════════

# ─── Logger ───
from .utils import logger  # noqa: F401

# ─── SoftCam detection ───
from .core.softcam_detect import (
    detect_active_softcam,
    is_oscam_active as _is_oscam_active,
    is_ncam_active as _is_ncam_active,
    restart_active_softcam as _restart_active_softcam,
    get_status_for_active as _get_status_for_active,
)

# ─── Helpers ───
from .core.helpers import (
    display_host,
    validate_url as _validate_url,
    extract_port_from_url as _extract_port_from_url,
)

# ─── WebIF updater ───
from .core.webif_updater import (
    update_webif_config,
    apply_webif_settings as _apply_webif_settings,
)


# ═══════════════════════════════════════════════════════════════════
#  الشاشات
# ═══════════════════════════════════════════════════════════════════
from .screens.settings import (
    SettingsMenu,
    GeneralSettings,
    OscamSettings,
    NcamSettings,
)
from .screens.emulator_screen import EmulatorManagerScreen
from .screens.log_viewer import LogViewer
from .screens.reader_manager import ReaderManager
from .screens.developer_select import DeveloperSelectScreen


# ═══════════════════════════════════════════════════════════════════
#  Enigma2 Plugin Descriptor
# ═══════════════════════════════════════════════════════════════════
from Plugins.Plugin import PluginDescriptor


# ═══════════════════════════════════════════════════════════════════
#  التحقق التلقائي من التحديث عند الإقلاع
# ═══════════════════════════════════════════════════════════════════
def _schedule_startup_check(session=None):
    """
    يجدول فحص التحديث عند إقلاع Enigma2.

    يُستدعى من `sessionstart` عند reason=0.
    لا يفعل شيئاً إذا كان auto_check معطّلاً.
    """
    try:
        from .utils import startup_check
        startup_check.schedule_check(delay=45, session=session)
    except Exception as e:
        try:
            logger.log("Plugin",
                       "_schedule_startup_check error: %s" % e)
        except Exception:
            print("[ReaderManager] startup_check error: %s" % e)


def sessionstart(reason, **kwargs):
    """
    يُستدعى تلقائياً من Enigma2 عند بدء/إيقاف session.

    Args:
        reason : 0 = start, 1 = stop
        kwargs : يحتوي على session في بعض الصور

    ملاحظة:
        - السكينات تم تحميلها بالفعل عند استيراد plugin.py
        - هنا نُعيد تحميلها احتياطاً إذا فشلت المرة الأولى
        - نجدول فحص التحديث التلقائي
    """
    if reason != 0:
        return

    # ⭐ إعادة تحميل السكينات احتياطاً (في حال فشل التحميل الأولي)
    try:
        if _loaded_skins == 0 and _total_skins > 0:
            print("[ReaderManager] Retry skin load...")
            loaded, total = skin_loader.load_all(force=True)
            print("[ReaderManager] Skins reloaded: %d/%d"
                  % (loaded, total))
        else:
            # تحقق أن الملفات تم تحميلها فعلاً (قد يكون تم تحديثها)
            skin_loader.load_all(force=False)
    except Exception as e:
        print("[ReaderManager] sessionstart skin error: %s" % e)

    # جدول فحص التحديث
    session = kwargs.get("session")
    _schedule_startup_check(session)


def main(session, **kwargs):
    """نقطة الدخول الرئيسية — من قائمة البلوجينات."""
    session.open(ReaderManager)


def Plugins(**kwargs):
    """تعريف البلوجين في Enigma2."""
    return [
        PluginDescriptor(
            name="Readers Manager",
            description="Manage Oscam & NCam readers via WebIF",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main),
        PluginDescriptor(
            name="Readers Manager Settings",
            description="Configure OSCam & NCam WebIF",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon="plugin.png",
            fnc=lambda session, **kw: session.open(SettingsMenu)),
        PluginDescriptor(
            name="Softcam Settings",
            description="Switch between SoftCams",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon="plugin.png",
            fnc=lambda session, **kw: session.open(EmulatorManagerScreen)),
        PluginDescriptor(
            name="Install Emus",
            description="Switch between SoftCams",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon="plugin.png",
            fnc=lambda session, **kw: session.open(DeveloperSelectScreen)),
    ]


# ═══════════════════════════════════════════════════════════════════
#  __all__ — للتوافق الخلفي
# ═══════════════════════════════════════════════════════════════════
__all__ = [
    # مسارات
    "OSCAM_FILE", "NCAM_FILE",
    "OSCAM_CONF_FILE", "NCAM_CONF_FILE",
    "CONFIG_DIR",

    # Enigma2
    "main", "Plugins", "sessionstart",

    # الشاشات
    "ReaderManager",
    "SettingsMenu",
    "GeneralSettings",
    "OscamSettings",
    "NcamSettings",
    "EmulatorManagerScreen",
    "LogViewer",
    'DeveloperSelectScreen',

    # Backward compat — softcam
    "_is_oscam_active", "_is_ncam_active",
    "_restart_active_softcam", "_get_status_for_active",
    "detect_active_softcam",

    # Backward compat — helpers
    "_validate_url", "_extract_port_from_url",
    "display_host",

    # Backward compat — webif
    "_apply_webif_settings",
    "update_webif_config",

    # Logger
    "logger",

    # ⭐ Skins
    "skin_loader",
]