# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

import os
import re
import subprocess
import time
import threading
import glob as globmod

try:
    _TimeoutExpired = subprocess.TimeoutExpired
except AttributeError:
    class _TimeoutExpired(Exception):
        pass


CAM = "ncam"

CAM_SCRIPTS = [
    "/etc/init.d/softcam.ncam-*",
    "/etc/init.d/softcam.ncam",
    "/etc/init.d/softcam.NCam-*",
    "/etc/init.d/softcam.NCam",
    "/etc/init.d/softcam.ncam*",
    "/etc/init.d/softcam.NCam*",
    "/etc/init.d/softcam_ncam*",
    "/etc/init.d/softcam_NCam*",
    "/etc/init.d/ncam",
    "/etc/init.d/softcam",
    "/usr/script/ncam.sh",
    "/usr/camscript/Ncam_Oscam.sh",
    "/usr/camscript/Ncam*.sh",
]

CAM_PROCESSES = [
    "ncam", "ncam-svn", "ncam-relay", "ncam-master",
    "NCam", "ncam_emu", "ncam-streamrelay",
    "ncam-15.8", "ncam-15.9", "ncam-16.0",
    "NCam-15.8", "NCam-15.9",
    "ncam.arm", "ncam.mips", "ncam.aarch64",
]

DIRECT_BINARIES = [
    "/usr/bin/ncam",
    "/usr/bin/NCam",
    "/usr/bin/ncam-emu",
    "/usr/bin/ncam_emu",
    "/usr/bin/ncam-svn",
    "/usr/bin/ncam-master",
    "/usr/softcams/ncam",
    "/usr/softcams/NCam",
]

VERSION_FILES = [
    "/tmp/.ncam/ncam.version",
    "/tmp/ncam.version",
    "/var/tmp/ncam.version",
]

TAG = "[ncam]"
CACHE_KEY = "ncam"


# ═══════════════════════════════════════════════════════════════════
#  Hints
# ═══════════════════════════════════════════════════════════════════
_SCRIPT_HINT = None
_BINARY_HINT = None
_CAM_NAME_HINT = None


def set_script_hint(script_path):
    global _SCRIPT_HINT
    _SCRIPT_HINT = script_path
    _log("Script hint set: %s" % script_path)


def set_binary_hint(binary_path):
    global _BINARY_HINT
    _BINARY_HINT = binary_path
    _log("Binary hint set: %s" % binary_path)


def set_cam_name(cam_name):
    global _CAM_NAME_HINT
    _CAM_NAME_HINT = cam_name
    _log("Cam name hint set: %s" % cam_name)


def set_hints(cam_name=None, script=None, binary=None):
    if cam_name:
        set_cam_name(cam_name)
    if script:
        set_script_hint(script)
    if binary:
        set_binary_hint(binary)


def clear_hints():
    global _SCRIPT_HINT, _BINARY_HINT, _CAM_NAME_HINT
    _SCRIPT_HINT = None
    _BINARY_HINT = None
    _CAM_NAME_HINT = None


# ═══════════════════════════════════════════════════════════════════
#  Logger
# ═══════════════════════════════════════════════════════════════════
try:
    from . import logger
    _HAS_LOGGER = True
except Exception:
    _HAS_LOGGER = False


def _log(msg):
    if _HAS_LOGGER:
        try:
            logger.log("RestartNCam", msg)
            return
        except Exception:
            pass
    try:
        print("%s %s" % (TAG, msg))
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════
def _run(cmd, timeout=15):
    p = None
    try:
        p = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = p.communicate(timeout=timeout)
        except TypeError:
            result = [b"", b""]

            def _target():
                try:
                    result[0], result[1] = p.communicate()
                except Exception:
                    pass

            t = threading.Thread(target=_target)
            t.setDaemon(True)
            t.start()
            t.join(timeout)
            if t.isAlive():
                try:
                    p.kill()
                except Exception:
                    pass
                return -1, "", "timeout"
            out, err = result

        if isinstance(out, bytes):
            out = out.decode("utf-8", "ignore")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "ignore")
        return p.returncode, out, err
    except _TimeoutExpired:
        if p:
            try:
                p.kill()
            except Exception:
                pass
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)


# ═══════════════════════════════════════════════════════════════════
#  PID
# ═══════════════════════════════════════════════════════════════════
def _get_pid_proc():
    try:
        for pid_dir in os.listdir("/proc"):
            if not pid_dir.isdigit():
                continue
            try:
                with open("/proc/%s/comm" % pid_dir, "r") as f:
                    comm = f.read().strip()

                cmdline = ""
                try:
                    with open("/proc/%s/cmdline" % pid_dir, "rb") as f:
                        cmdline = f.read().decode("utf-8", "ignore") \
                            .replace("\0", " ").strip()
                except Exception:
                    pass

                for name in CAM_PROCESSES:
                    if (name.lower() in comm.lower()
                            or name.lower() in cmdline.lower()):
                        return int(pid_dir), cmdline or comm
            except (IOError, OSError):
                continue
    except Exception:
        pass
    return None, ""


def _get_pid_pidof():
    for name in CAM_PROCESSES:
        rc, out, _ = _run("pidof %s 2>/dev/null" % name, timeout=5)
        if rc == 0 and out.strip():
            try:
                pid = int(out.strip().split()[0])
                try:
                    with open("/proc/%d/cmdline" % pid, "rb") as f:
                        cmdline = f.read().decode("utf-8", "ignore") \
                            .replace("\0", " ").strip()
                except Exception:
                    cmdline = name
                return pid, cmdline
            except Exception:
                pass
    return None, ""


def get_pid():
    pid, _ = _get_pid_proc()
    if pid:
        return pid
    pid, _ = _get_pid_pidof()
    return pid


def is_running():
    pid, cmdline = _get_pid_proc()
    if pid:
        return True, "%d (%s)" % (pid, cmdline)
    pid, cmdline = _get_pid_pidof()
    if pid:
        return True, "%d (%s)" % (pid, cmdline)
    return False, ""


def is_active():
    if is_running()[0]:
        return True
    for path in VERSION_FILES:
        if os.path.exists(path):
            return True
    return False


# ═══════════════════════════════════════════════════════════════════
#  البحث الذكي
# ═══════════════════════════════════════════════════════════════════
def _is_valid_script(path):
    try:
        return (os.path.isfile(path)
                and os.access(path, os.X_OK))
    except Exception:
        return False


def _find_script_for_cam(cam_name):
    if not cam_name:
        return None

    candidates = [
        "/etc/init.d/softcam.%s" % cam_name,
        "/etc/init.d/softcam.%s" % cam_name.lower(),
        "/etc/init.d/softcam_%s" % cam_name,
        "/etc/init.d/%s" % cam_name,
    ]

    for c in candidates:
        if _is_valid_script(c):
            _log("Found script for %s: %s" % (cam_name, c))
            return c

    for pattern in [
        "/etc/init.d/softcam.*%s*" % re.escape(cam_name),
        "/etc/init.d/*%s*" % re.escape(cam_name),
    ]:
        try:
            matches = sorted(globmod.glob(pattern), reverse=True)
            for m in matches:
                if _is_valid_script(m):
                    _log("Found via glob for %s: %s" % (cam_name, m))
                    return m
        except Exception:
            pass

    _log("No script found for cam: %s" % cam_name)
    return None


def _expand_scripts():
    found = []
    seen = set()

    for pattern in CAM_SCRIPTS:
        if "*" in pattern or "?" in pattern:
            try:
                matches = sorted(globmod.glob(pattern), reverse=True)
            except Exception:
                matches = []
            for path in matches:
                if path in seen:
                    continue
                seen.add(path)
                if _is_valid_script(path):
                    found.append(path)
        else:
            if pattern in seen:
                continue
            seen.add(pattern)
            if _is_valid_script(pattern):
                found.append(pattern)

    return found


def find_script():
    scripts = find_all_scripts()
    return scripts[0] if scripts else None


def find_all_scripts():
    scripts = _expand_scripts()

    if _SCRIPT_HINT and _is_valid_script(_SCRIPT_HINT):
        if _SCRIPT_HINT in scripts:
            scripts.remove(_SCRIPT_HINT)
        scripts.insert(0, _SCRIPT_HINT)
        _log("script_hint at front: %s" % _SCRIPT_HINT)

    elif _CAM_NAME_HINT:
        correct_script = _find_script_for_cam(_CAM_NAME_HINT)
        if correct_script:
            if correct_script in scripts:
                scripts.remove(correct_script)
            scripts.insert(0, correct_script)
            _log("cam_name_hint script at front: %s" % correct_script)

    if len(scripts) > 1:
        specific = []
        generic = []
        for s in scripts:
            basename = os.path.basename(s)
            if basename == "softcam" or basename == "ncam":
                generic.append(s)
            else:
                specific.append(s)
        scripts = specific + generic

    return scripts


# ═══════════════════════════════════════════════════════════════════
#  cache
# ═══════════════════════════════════════════════════════════════════
def _cache_path():
    try:
        plugin_dir = os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))
        cache_dir = os.path.join(plugin_dir, "cache")
        if not os.path.isdir(cache_dir):
            os.makedirs(cache_dir)
        return os.path.join(cache_dir, "restart_methods.json")
    except Exception:
        return "/tmp/.cam_restart_method.json"


def _load_cache():
    try:
        import json
        path = _cache_path()
        if not os.path.exists(path):
            return {}
        with open(path, "r") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_cache(cache):
    try:
        import json
        path = _cache_path()
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(cache, f, indent=2, sort_keys=True)
        os.rename(tmp, path)
        return True
    except Exception as e:
        _log("Cannot save cache: %s" % e)
        return False


def _cache_key():
    if _CAM_NAME_HINT:
        return "%s:%s" % (CACHE_KEY, _CAM_NAME_HINT)
    return CACHE_KEY


def get_recorded_method():
    cache = _load_cache()
    entry = cache.get(_cache_key(), {})
    return entry.get("method") if entry else None


def set_recorded_method(method_id, script=None):
    cache = _load_cache()
    cache[_cache_key()] = {
        "method": method_id,
        "script": script,
        "cam_name": _CAM_NAME_HINT,
        "recorded_at": time.time(),
    }
    _save_cache(cache)


def clear_recorded_method():
    cache = _load_cache()
    key = _cache_key()
    if key in cache:
        del cache[key]
        _save_cache(cache)
        _log("Cleared recorded method for %s" % key)


# ═══════════════════════════════════════════════════════════════════
#  طرق إعادة التشغيل
# ═══════════════════════════════════════════════════════════════════
def _try_restart(script):
    rc, out, err = _run("%s restart" % script, timeout=15)
    if rc == 0:
        return True, "restart rc=0"
    return False, "restart rc=%d" % rc


def _try_stop_start(script, wait=2):
    _run("%s stop" % script, timeout=10)
    time.sleep(wait)
    rc, out, err = _run("%s start" % script, timeout=15)
    if rc == 0:
        return True, "stop+start rc=0"
    return False, "stop+start rc=%d" % rc


def _try_killall_start(script, wait=2):   # ← نفس الدالة
    for proc in CAM_PROCESSES:
        _run("killall -TERM %s 2>/dev/null" % proc, timeout=5)
    time.sleep(1)
    for proc in CAM_PROCESSES:
        _run("killall -9 %s 2>/dev/null" % proc, timeout=3)
    time.sleep(wait)
    rc, out, err = _run("%s start" % script, timeout=15)
    if rc == 0:
        return True, "killall+start rc=0"
    return False, "killall+start rc=%d" % rc

def _try_start_only(script, wait=2):
    rc, out, err = _run("%s start" % script, timeout=15)
    if rc == 0:
        return True, "start rc=0"
    return False, "start rc=%d" % rc


def _try_binary(binary, wait=2):
    if not _is_valid_script(binary):
        return False, "binary not found: %s" % binary

    for flags in ["-b", "-b -c /etc/tuxbox/config/ncam", ""]:
        cmd = "%s %s" % (binary, flags) if flags else binary
        rc, out, err = _run(cmd, timeout=12)
        if rc == 0:
            time.sleep(wait)
            if is_running()[0]:
                return True, "binary %s %s" % (binary, flags)
    return False, "binary %s failed" % binary


def _try_direct_binary(wait=2):
    if _BINARY_HINT and _is_valid_script(_BINARY_HINT):
        ok, msg = _try_binary(_BINARY_HINT, wait)
        if ok:
            return True, msg

    for binary in DIRECT_BINARIES:
        ok, msg = _try_binary(binary, wait)
        if ok:
            return True, msg
    return False, "no binary worked"


def _verify(old_pid, wait=2, retries=2):
    time.sleep(wait)

    last_pid_info = None
    for attempt in range(retries):
        running, pid_info = is_running()
        last_pid_info = pid_info

        if running:
            try:
                new_pid = int(str(pid_info).split()[0])
            except Exception:
                new_pid = None

            if old_pid is not None and new_pid == old_pid:
                if attempt < retries - 1:
                    time.sleep(0.5)
                    continue
                return False, new_pid, "PID unchanged (%s)" % old_pid

            return True, new_pid, "PID %s -> %s" % (old_pid, new_pid)

        if attempt < retries - 1:
            time.sleep(0.5)

    return False, None, "no process after restart (last: %s)" % last_pid_info


# ═══════════════════════════════════════════════════════════════════
#  start_only / stop_only
# ═══════════════════════════════════════════════════════════════════
def start_only(wait_seconds=3, retries=2):
    _log("=" * 50)
    _log("Starting NCAM only...")

    if is_running()[0]:
        return True, "NCam already running"

    old_pid = get_pid()

    if _SCRIPT_HINT and _is_valid_script(_SCRIPT_HINT):
        _log("Trying script_hint: %s start" % _SCRIPT_HINT)
        rc, out, err = _run("%s start" % _SCRIPT_HINT, timeout=15)
        if rc == 0:
            verified, new_pid, vmsg = _verify(old_pid, wait_seconds, retries)
            if verified:
                return True, "NCam started via %s (%s)" % (
                    _SCRIPT_HINT, vmsg)

    if _CAM_NAME_HINT:
        correct = _find_script_for_cam(_CAM_NAME_HINT)
        if correct:
            _log("Trying cam_name script: %s start" % correct)
            rc, out, err = _run("%s start" % correct, timeout=15)
            if rc == 0:
                verified, new_pid, vmsg = _verify(old_pid, wait_seconds, retries)
                if verified:
                    return True, "NCam started via %s (%s)" % (
                        correct, vmsg)

    scripts = find_all_scripts()
    for script in scripts:
        try:
            rc, out, err = _run("%s start" % script, timeout=15)
            if rc == 0:
                verified, new_pid, vmsg = _verify(old_pid, wait_seconds, retries)
                if verified:
                    return True, "NCam started via %s (%s)" % (
                        script, vmsg)
        except Exception:
            continue

    ok, msg = _try_direct_binary(wait_seconds)
    if ok and is_running()[0]:
        return True, "NCam started via direct binary"

    return False, "Could not start NCam"


def stop_only(wait_seconds=3):
    _log("=" * 50)
    _log("Stopping NCAM only...")

    if not is_running()[0]:
        return True, "NCam already stopped"

    if _SCRIPT_HINT and _is_valid_script(_SCRIPT_HINT):
        rc, out, err = _run("%s stop" % _SCRIPT_HINT, timeout=10)
        if rc == 0:
            time.sleep(wait_seconds)
            if not is_running()[0]:
                return True, "NCam stopped via %s" % _SCRIPT_HINT

    if _CAM_NAME_HINT:
        correct = _find_script_for_cam(_CAM_NAME_HINT)
        if correct:
            rc, out, err = _run("%s stop" % correct, timeout=10)
            if rc == 0:
                time.sleep(wait_seconds)
                if not is_running()[0]:
                    return True, "NCam stopped via %s" % correct

    scripts = find_all_scripts()
    for script in scripts:
        try:
            rc, out, err = _run("%s stop" % script, timeout=10)
            if rc == 0:
                time.sleep(wait_seconds)
                if not is_running()[0]:
                    return True, "NCam stopped via %s" % script
        except Exception:
            continue

    for proc in CAM_PROCESSES:
        _run("killall -TERM %s 2>/dev/null" % proc, timeout=5)
    time.sleep(1)
    for proc in CAM_PROCESSES:
        _run("killall -9 %s 2>/dev/null" % proc, timeout=3)

    time.sleep(wait_seconds)
    if not is_running()[0]:
        return True, "NCam stopped via killall"

    return False, "Could not stop NCam"


# ═══════════════════════════════════════════════════════════════════
#  restart() — ذكي
# ═══════════════════════════════════════════════════════════════════
def restart(wait_seconds=2, force=False):
    _log("=" * 50)
    _log("Restarting NCAM (wait=%s, force=%s, cam=%s)"
         % (wait_seconds, force, _CAM_NAME_HINT or "auto"))

    if not is_active():
        return False, "NCam is not active"

    old_pid = get_pid()
    _log("PID before: %s" % (old_pid or "none"))

    # ① FAST PATH
    target_script = None

    if _SCRIPT_HINT and _is_valid_script(_SCRIPT_HINT):
        target_script = _SCRIPT_HINT
        _log("Target script from hint: %s" % target_script)
    elif _CAM_NAME_HINT:
        target_script = _find_script_for_cam(_CAM_NAME_HINT)
        _log("Target script from cam_name: %s" % target_script)

    if target_script:
        _log("=" * 50)
        _log("FAST PATH: trying %s only" % target_script)
        _log("=" * 50)

        for method_name, method_fn, needs_wait in [
            ("restart",       _try_restart,       False),
            ("stop_start",    _try_stop_start,    True),
            ("killall_start", _try_killall_start, True),
        ]:
            _log("-> [%s] %s" % (method_name, target_script))

            try:
                if needs_wait:
                    ok, msg = method_fn(target_script, wait_seconds)
                else:
                    ok, msg = method_fn(target_script)
            except Exception as e:
                ok, msg = False, "exception: %s" % e

            if not ok:
                _log("  FAIL %s" % msg)
                continue

            verified, new_pid, vmsg = _verify(old_pid, wait_seconds)
            if verified:
                _log("  OK %s - %s" % (msg, vmsg))
                set_recorded_method(
                    "%s:%s" % (target_script, method_name),
                    script=target_script)
                return True, "NCAM restarted via %s on %s (%s)" % (
                    method_name, target_script, vmsg)
            else:
                _log("  FAIL %s but %s" % (msg, vmsg))

        _log("FAST PATH failed — falling back")
        old_pid = get_pid()

    # ② cache
    if not force:
        recorded = get_recorded_method()
        if recorded:
            parts = recorded.split(":", 1)
            rec_script = parts[0]
            rec_method = parts[1] if len(parts) > 1 else "restart"

            if _is_valid_script(rec_script):
                if rec_method == "restart":
                    ok, msg = _try_restart(rec_script)
                elif rec_method == "stop_start":
                    ok, msg = _try_stop_start(rec_script, wait_seconds)
                elif rec_method == "killall_start":
                    ok, msg = _try_killall_start(rec_script, wait_seconds)
                else:
                    ok, msg = False, "unknown method"

                if ok:
                    verified, new_pid, vmsg = _verify(old_pid, wait_seconds)
                    if verified:
                        return True, "NCAM restarted via recorded (%s)" % vmsg

            clear_recorded_method()
            old_pid = get_pid()

    # ③ fallback
    scripts = find_all_scripts()
    if not scripts:
        ok, msg = _try_direct_binary(wait_seconds)
        if ok:
            verified, new_pid, vmsg = _verify(old_pid, wait_seconds)
            if verified:
                return True, "NCAM restarted via direct binary (%s)" % vmsg
        return False, "No control script found for NCAM"

    _log("Available scripts (%d):" % len(scripts))
    for s in scripts:
        _log("  %s" % s)

    tried = []
    for script in scripts:
        for method_name, method_fn, needs_wait in [
            ("restart",       _try_restart,       False),
            ("stop_start",    _try_stop_start,    True),
            ("killall_start", _try_killall_start, True),
        ]:
            pid_before = get_pid()
            try:
                if needs_wait:
                    ok, msg = method_fn(script, wait_seconds)
                else:
                    ok, msg = method_fn(script)
            except Exception as e:
                ok, msg = False, "exception: %s" % e

            tried.append((script, method_name, ok))
            if not ok:
                continue

            verified, new_pid, vmsg = _verify(pid_before, wait_seconds)
            if verified:
                set_recorded_method(
                    "%s:%s" % (script, method_name), script=script)
                return True, "NCAM restarted via %s on %s (%s)" % (
                    method_name, script, vmsg)

    ok, msg = _try_direct_binary(wait_seconds)
    if ok:
        verified, new_pid, vmsg = _verify(old_pid, wait_seconds)
        if verified:
            return True, "NCAM restarted via direct binary (%s)" % vmsg

    return False, "All restart methods failed for NCAM"


def restart_silent():
    try:
        return restart()
    except Exception:
        return False, "exception"


def get_status():
    running, pid = is_running()
    recorded = get_recorded_method() or "-"
    cam = _CAM_NAME_HINT or "auto"
    if running:
        return "NCAM [%s]: Running (PID %s) [method: %s]" % (
            cam, pid, recorded)
    return "NCAM [%s]: Stopped [method: %s]" % (cam, recorded)


def _main():
    import sys

    if len(sys.argv) > 1:
        if sys.argv[1] == "status":
            print(get_status())
            sys.exit(0)
        elif sys.argv[1] == "force":
            ok, msg = restart(force=True)
            print(msg)
            sys.exit(0 if ok else 2)
        elif sys.argv[1] == "start":
            ok, msg = start_only()
            print(msg)
            sys.exit(0 if ok else 2)
        elif sys.argv[1] == "stop":
            ok, msg = stop_only()
            print(msg)
            sys.exit(0 if ok else 2)
        elif sys.argv[1] == "cam" and len(sys.argv) > 2:
            set_cam_name(sys.argv[2])
            ok, msg = restart(force=True)
            print(msg)
            sys.exit(0 if ok else 2)
        elif sys.argv[1] == "reset":
            clear_recorded_method()
            print("Cache cleared")
            sys.exit(0)

    ok, msg = restart()
    print(msg)
    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    _main()