# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import subprocess

# ─── توافق Py2/Py3 ───
try:
    from io import open
except ImportError:
    pass

try:
    DEVNULL = subprocess.DEVNULL
except AttributeError:
    DEVNULL = open(os.devnull, "wb")

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.config import (
    ConfigText, ConfigSelection, ConfigYesNo, ConfigInteger,
    ConfigPassword, getConfigListEntry
)
from Components.ConfigList import ConfigListScreen

from .reader_parser import ReaderParser, Reader
from .plugin import OSCAM_FILE, NCAM_FILE
from .field_help import get_help, has_help


# ======================================================================
#  Masked / Placeholder-aware ConfigText
# ======================================================================
class _MaskedText(ConfigText):
    """ConfigText that NEVER reveals the real value."""

    MASK = "*******"

    def __init__(self, placeholder="", mask=True, field_name="", **kwargs):
        self._placeholder = placeholder or ""
        self._mask_enabled = bool(mask)
        self._field_name = field_name or ""
        super(_MaskedText, self).__init__(
            default="", fixed_size=False, **kwargs)

    def getValue(self):
        try:
            v = super(_MaskedText, self).getValue()
        except Exception:
            return ""
        if self._mask_enabled and v == self.MASK:
            return ""
        if self._placeholder and v == self._placeholder:
            return ""
        return v

    def _masked_repr(self):
        if self._field_name:
            return "%s = %s" % (self._field_name, self.MASK)
        return self.MASK

    def getText(self):
        try:
            raw = super(_MaskedText, self).getText()
        except Exception:
            return self._placeholder or ""
        if not raw:
            return self._placeholder or ""
        if self._mask_enabled:
            return self._masked_repr()
        return raw

    def getMulti(self, selected):
        try:
            raw = super(_MaskedText, self).getMulti(selected)
        except Exception:
            return self._placeholder or ""
        if not raw:
            return self._placeholder or ""
        if self._mask_enabled:
            return self._masked_repr()
        return raw

    def handleKey(self, key, *args, **kwargs):
        try:
            current = super(_MaskedText, self).getValue()
        except Exception:
            current = ""
        try:
            if self._mask_enabled and (
                    current == self.MASK
                    or current.endswith("= " + self.MASK)
                    or current == self._masked_repr()):
                self.setValue("")
            elif self._placeholder and current == self._placeholder:
                self.setValue("")
        except Exception:
            pass
        try:
            return super(_MaskedText, self).handleKey(
                key, *args, **kwargs)
        except TypeError:
            return super(_MaskedText, self).handleKey(key)


# ======================================================================
#  Placeholder-aware ConfigText
# ======================================================================
class _PlaceholderText(ConfigText):
    """ConfigText with placeholder behavior (value IS visible)."""

    def __init__(self, placeholder="", **kwargs):
        self._placeholder = placeholder or ""
        super(_PlaceholderText, self).__init__(
            default="", fixed_size=False, **kwargs)

    def getValue(self):
        try:
            v = super(_PlaceholderText, self).getValue()
        except Exception:
            return ""
        if self._placeholder and v == self._placeholder:
            return ""
        return v

    def getText(self):
        try:
            raw = super(_PlaceholderText, self).getText()
        except Exception:
            return self._placeholder or ""
        if not raw and self._placeholder:
            return self._placeholder
        return raw

    def getMulti(self, selected):
        try:
            value = super(_PlaceholderText, self).getMulti(selected)
        except Exception:
            return self._placeholder or ""
        if not value and self._placeholder:
            return self._placeholder
        return value

    def handleKey(self, key, *args, **kwargs):
        try:
            current = super(_PlaceholderText, self).getValue()
        except Exception:
            current = ""
        try:
            if self._placeholder and current == self._placeholder:
                self.setValue("")
        except Exception:
            pass
        try:
            return super(_PlaceholderText, self).handleKey(
                key, *args, **kwargs)
        except TypeError:
            return super(_PlaceholderText, self).handleKey(key)


# ======================================================================
#  Placeholder-aware ConfigSelection
#  ✅ choices MUST be a list (not tuple)
# ======================================================================
class _PlaceholderSelection(ConfigSelection):
    """ConfigSelection with a default '-- select --' that is never exported."""

    PLACEHOLDER_KEY = "__placeholder__"
    DEFAULT_LABEL = "-- select --"

    def __init__(self, choices, placeholder_label=None, **kwargs):
        self._placeholder_label = placeholder_label or self.DEFAULT_LABEL

        # ✅ choices always list
        if isinstance(choices, dict):
            choices_list = list(choices.items())
        elif isinstance(choices, tuple):
            choices_list = list(choices)
        elif isinstance(choices, list):
            choices_list = list(choices)
        else:
            choices_list = []

        self._real_choices = list(choices_list)

        all_choices = [(self.PLACEHOLDER_KEY, self._placeholder_label)]
        all_choices.extend(choices_list)

        super(_PlaceholderSelection, self).__init__(
            choices=all_choices,
            default=self.PLACEHOLDER_KEY,
            **kwargs)

    def getValue(self):
        try:
            v = super(_PlaceholderSelection, self).getValue()
        except Exception:
            return ""
        if v == self.PLACEHOLDER_KEY:
            return ""
        return v

    def getText(self):
        try:
            v = super(_PlaceholderSelection, self).getText()
        except Exception:
            return self._placeholder_label
        if v == self.PLACEHOLDER_KEY:
            return self._placeholder_label
        return v

    def getMulti(self, selected):
        try:
            v = super(_PlaceholderSelection, self).getMulti(selected)
        except Exception:
            return self._placeholder_label
        if v == self.PLACEHOLDER_KEY:
            return self._placeholder_label
        return v

    def setValue(self, value):
        if value in ("", None, self.PLACEHOLDER_KEY):
            super(_PlaceholderSelection, self).setValue(
                self.PLACEHOLDER_KEY)
        else:
            super(_PlaceholderSelection, self).setValue(value)

    def handleKey(self, key, *args, **kwargs):
        try:
            return super(_PlaceholderSelection, self).handleKey(
                key, *args, **kwargs)
        except TypeError:
            return super(_PlaceholderSelection, self).handleKey(key)


# ======================================================================
#  Range Constants
# ======================================================================
CCCAM_VERSIONS = [
    "2.0.11", "2.1.1", "2.1.2", "2.1.3",
    "2.2.0", "2.2.1", "2.2.2", "2.3.0",
    "2.3.1", "2.3.2"
]

CACHEEX_MODES = [
    ("1", "Cache Pull"),
    ("2", "Cache Push"),
    ("3", "Reverse Cache Push"),
]

DETECT_MODES = [
    ("cd",   "CD (Carrier Detect)"),
    ("dsr",  "DSR (Data Set Ready)"),
    ("cts",  "CTS (Clear To Send)"),
    ("ring", "RING (Ring Indicator)"),
    ("none", "NONE (Always inserted)"),
]

GROUP_CHOICES = [(str(i), str(i)) for i in range(1, 65)]

ENABLE_CHOICES = [("1", "Enabled"), ("0", "Disabled")]

RATELIMIT_ECM_VALUES = (
    [("0", "Disabled")] +
    [(str(i), str(i)) for i in range(1, 21)]
)

RATELIMIT_TIME_VALUES = [
    ("3000",  "3 seconds"),
    ("4000",  "4 seconds"),
    ("5000",  "5 seconds"),
    ("6000",  "6 seconds"),
    ("7000",  "7 seconds"),
    ("8000",  "8 seconds (min safe)"),
    ("9000",  "9 seconds (recommended)"),
    ("10000", "10 seconds"),
    ("11000", "11 seconds"),
]

SRVID_HOLD_TIME_VALUES = [
    ("0",    "Disabled"),
    ("500",  "0.5 second"),
    ("1000", "1 second"),
    ("1500", "1.5 seconds"),
    ("2000", "2 seconds (default)"),
    ("3000", "3 seconds"),
    ("4000", "4 seconds"),
    ("5000", "5 seconds (max)"),
]

INACTIVITY_TIMEOUT_VALUES = [
    ("-1",  "Reconnect on failure (Newcamd)"),
    ("0",   "Disabled (keep alive)"),
    ("15",  "15 seconds"),
    ("30",  "30 seconds (unstable)"),
    ("60",  "60 seconds (stable)"),
    ("90",  "90 seconds"),
    ("120", "120 seconds (max)"),
]

RECONNECT_TIMEOUT_VALUES = [
    ("1",  "1 second"),
    ("3",  "3 seconds"),
    ("5",  "5 seconds (default)"),
    ("10", "10 seconds"),
    ("15", "15 seconds"),
    ("30", "30 seconds"),
    ("60", "60 seconds (max)"),
]

COOLDOWN_VALUES = [
    ("",        "Disabled"),
    ("10,60",   "10s delay, 60s max"),
    ("20,120",  "20s delay, 120s max"),
    ("30,180",  "30s delay, 180s max"),
    ("60,300",  "60s delay, 300s max"),
    ("120,600", "120s delay, 600s max"),
]

CCCRECONNECT_VALUES = (
    [("0", "Immediate")] +
    [(str(i), "%d ms" % i) for i in range(50, 1000, 50)] +
    [(str(i), "%d ms" % i) for i in range(1000, 9001, 500)]
)

CCC_MAXHOPS_VALUES = [(str(i), str(i)) for i in range(0, 11)]

CACHEEX_MAXHOP_VALUES = [(str(i), str(i)) for i in range(0, 11)]

CARD_MHZ_VALUES = [
    ("357",  "357 (3.57 MHz - standard)"),
    ("368",  "368 (3.68 MHz)"),
    ("400",  "400 (4.00 MHz)"),
    ("500",  "500 (5.00 MHz)"),
    ("600",  "600 (6.00 MHz)"),
    ("680",  "680 (6.80 MHz)"),
    ("800",  "800 (8.00 MHz)"),
    ("1000", "1000 (10.00 MHz)"),
]

READER_MHZ_VALUES = list(CARD_MHZ_VALUES)

MHRZ_VALUES = (
    [("0", "0 (disabled)")] +
    [(str(i), str(i)) for i in (50, 100, 150, 200, 250, 300, 350, 400,
                                 450, 500, 600, 700, 800, 900, 1000)]
)

CARD_MHRZ_VALUES = list(MHRZ_VALUES)

CLASS_FILTER_VALUES = [
    ("",           "All classes"),
    ("01",         "01 (Seca)"),
    ("01,02",      "01,02 (Seca + Viaccess)"),
    ("01,!1b",     "01 exclude 1b"),
    ("0E",         "0E (PowerVu)"),
    ("0B",         "0B (Conax)"),
]

EMMCACHE_VALUES = [
    ("",         "Disabled"),
    ("1,2,2,1",  "Recommended (1,2,2,1)"),
    ("2,1,2,1",  "Alt (2,1,2,1)"),
    ("1,3,2,1",  "Verbose (1,3,2,1)"),
    ("0,0,0,0",  "Cache off"),
]

BLOCKEMM_BYLEN_VALUES = [
    ("",           "None"),
    ("50-60",      "50-60"),
    ("100-110",    "100-110"),
    ("50-60,100-110", "50-60,100-110"),
    ("3-6,50-60",  "3-6,50-60"),
]


# ======================================================================
#  Protocol categorisation
# ======================================================================
ALL_PROTOCOLS = [
    "cccam", "newcamd", "mgcamd", "cacheex", "internal",
    "cs378x", "camd35", "gbox", "radegast",
    "mouse", "smartreader", "pcsc", "constcw", "emu",
]

SIMPLE_PROTOCOLS = ["cccam", "newcamd", "mgcamd", "emu"]

AUTH_PROTOCOLS = {
    "cccam", "newcamd", "mgcamd", "cacheex",
    "cs378x", "camd35", "gbox", "radegast",
}

KEY_PROTOCOLS = {"newcamd", "mgcamd"}

CCCVERSION_PROTOCOLS = {"cccam"}

DETECT_PROTOCOLS = {"mouse"}

NO_PORT_PROTOCOLS = {"internal", "constcw", "emu"}

LOCAL_PROTOCOLS = {"mouse", "smartreader", "pcsc", "internal"}

AES_PROTOCOLS = {"internal", "pcsc", "smartreader"}

TCP_PROTOCOLS = {
    "cccam", "newcamd", "mgcamd", "cacheex",
    "cs378x", "camd35", "gbox", "radegast",
}

SOFTCAM_SCRIPT = "/etc/init.d/softcam"


MANAGED_EXTRA_KEYS = set([
    "cccversion", "cccreconnect", "cccmaxhops", "key",
    "cacheex", "cacheex_mode", "cacheex_maxhop",
    "chid", "keepalive", "disablecrccws_only_for",
    "pin", "boxid", "mhrz", "detect", "card_mhrz",

    "blockemm-u", "blockemm-s", "blockemm-g", "blockemm-unknown",
    "blockemm-bylen", "saveemm-u", "saveemm-s", "saveemm-g",
    "saveemm-unknown", "emmcache",

    "cardmhz", "mhz", "autospeed", "deprecated",
    "smargopatch", "sc8in1_dtrrts_patch",

    "ratelimitecm", "ratelimittime", "srvidholdtime",
    "cooldown", "ecmunique",

    "services", "class", "aeskey", "aeskeys",
    "fallback", "dropbadcws", "disablecrccws", "audisabled",
    "inactivitytimeout", "reconnecttimeout",
    "cacheexmode", "cacheexwait",
])


def resolve_protocol_for_file(ui_protocol, target_file):
    proto = (ui_protocol or "").lower().strip()
    if proto == "mgcamd":
        if target_file and "ncam" in target_file.lower():
            return "mgcamd"
        return "newcamd"
    if proto == "emu":
        return "emu"
    return proto


# ======================================================================
#  ReaderEditor
# ======================================================================
class ReaderEditor(ConfigListScreen, Screen):
    skin = """
    <screen name="ReaderEditor" position="center,center" size="1280,720" title="Reader Editor" flags="wfNoBorder" backgroundColor="#0B1A34" cornerRadius="25">
        <eLabel position="0,80" size="1280,2" backgroundColor="#1E90FF"/>

        <eLabel position="130,15" size="500,60" text="Reader Editor" font="Regular;50" backgroundColor="#0B1A3F" foregroundColor="#FFFFFF" halign="center" valign="center"/>
        <widget name="config" position="40,110" size="1200,470" scrollbarMode="showOnDemand" itemHeight="50" font="Regular;45" backgroundColorSelected="#FB9A34" backgroundColor="#0B1A34" valign="center" halign="center"/>

        <widget name="key_red"    position="140,660" size="200,36" font="Regular;18" backgroundColor="red"    foregroundColor="#FFFFFF" halign="center" valign="center" transparent="0" cornerRadius="25"/>
        <widget name="key_green"  position="372,660" size="200,36" font="Regular;18" backgroundColor="green"  foregroundColor="#FFFFFF" halign="center" valign="center" transparent="0" cornerRadius="25"/>
        <widget name="key_yellow" position="604,660" size="200,36" font="Regular;18" backgroundColor="yellow" foregroundColor="#FFFFFF" halign="center" valign="center" transparent="0" cornerRadius="25"/>
        <widget name="key_blue"   position="836,660" size="200,36" font="Regular;18" backgroundColor="blue"   foregroundColor="#FFFFFF" halign="center" valign="center" transparent="0" cornerRadius="25"/>
    </screen>
    """

    PH_LABEL    = "Reader name"
    PH_HOST     = "Server address or device path"
    PH_USER     = "Username"
    PH_PASSWORD = "Password"
    PH_KEY      = "DES key (hex)"
    PH_CAID     = "e.g. 0500,0604"
    PH_IDENT    = "e.g. 050000,060400"
    PH_CHID     = "e.g. 0001,0002"
    PH_DISCRC   = "e.g. 0500:050000"
    PH_PIN      = "e.g. 1234"
    PH_BOXID    = "e.g. 1234567"
    PH_AESKEY   = "AES key (hex)"
    PH_AESKEYS  = "Multiple AES keys"

    # ------------------------------------------------------------------
    def __init__(self, session, reader=None, target_file=OSCAM_FILE,
                 api_module=None):
        Screen.__init__(self, session)

        self.session = session
        self.target_file = target_file
        self.original = reader
        self.is_editing = reader is not None
        self.original_label = reader.label if reader else None

        self.api_module = api_module
        self._use_api = self._check_api(api_module)

        self._editor_mode = self._get_global_editor_mode()

        if self._use_api:
            try:
                self.template = api_module.get_reader_fields_template()
                self.validate_func = api_module.validate_reader
            except Exception as e:
                self._log("Template load failed: %s" % e)
                self._use_api = False
                self.template = None
                self.validate_func = None
        else:
            self.template = None
            self.validate_func = None

        self.server_data = self._load_server_data(reader)

        self["infoLabel"] = Label(
            "Mode: %s | Press INFO for field help"
            % self._editor_mode.upper())
        self["key_red"]    = Button("Cancel")
        self["key_green"]  = Button("Save")
        self["key_yellow"] = Button("Reset")
        self["key_blue"]   = Button("Toggle State")

        self._init_config_elements()

        ConfigListScreen.__init__(self, [], session=session)

        self.protocol.addNotifier(self.update_fields, initial_call=True)
        if hasattr(self, "cacheex"):
            self.cacheex.addNotifier(self.update_fields,
                                     initial_call=False)

        # ✅ ActionMap واحد فقط (بدون ActionMap منفصل لـ Info)
        #    لمنع تجميد الواجهة بعد إغلاق MessageBox
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions",
             "InfobarActions", "EPGSelectActions"],
            {
                "cancel":        self.exit,
                "red":           self.exit,
                "green":         self.save_config,
                "yellow":        self.reset_fields,
                "blue":          self.toggle_state,
                "info":          self.show_field_info,
                "epg":           self.show_field_info,
                "showEventInfo": self.show_field_info,
            }, -1)
        self._log("INFO handler registered in main ActionMap")

        self.create_setup()

    # ------------------------------------------------------------------
    def _log(self, msg):
        try:
            from . import logger
            logger.log("ReaderEditor", msg)
        except Exception:
            pass

    def _check_api(self, api_module):
        if api_module is None:
            return False
        try:
            return (hasattr(api_module, "get_reader_fields_template")
                    and hasattr(api_module, "validate_reader"))
        except Exception:
            return False

    def _get_global_editor_mode(self):
        try:
            from .plugin import config
            mode = config.plugins.OscamReaderManager.default_editor_mode.value
            return mode if mode in ("simple", "advanced") else "simple"
        except Exception as e:
            self._log("Cannot read global editor mode: %s" % e)
            return "simple"

    # ------------------------------------------------------------------
    def _get_default_data(self):
        return {
            "label":                  "",
            "enable":                 "1",
            "protocol":               "",
            "host":                   "",
            "port":                   12000,
            "user":                   "",
            "password":               "",
            "group":                  "1",
            "keepalive":              "1",
            "caid":                   "",
            "ident":                  "",
            "chid":                   "",
            "cccversion":             "2.3.2",
            "key":                    "",
            "detect":                 "cd",

            "blockemm_u":             "0",
            "blockemm_s":             "0",
            "blockemm_g":             "0",
            "blockemm_unknown":       "0",
            "blockemm_bylen":         "",
            "saveemm_u":              "0",
            "saveemm_s":              "0",
            "saveemm_g":              "0",
            "saveemm_unknown":        "0",
            "emmcache":               "",

            "cardmhz":                "357",
            "mhz":                    "357",
            "autospeed":              "1",
            "deprecated":             "0",
            "smargopatch":            "0",

            "ratelimitecm":           "0",
            "ratelimittime":          "9000",
            "srvidholdtime":          "2000",
            "cooldown":               "",
            "ecmunique":              "0",

            "inactivitytimeout":      "0",
            "reconnecttimeout":       "5",

            "services":               "",
            "class":                  "",
            "aeskey":                 "",
            "aeskeys":                "",
            "fallback":               "0",
            "dropbadcws":             "0",
            "disablecrccws":          "0",
            "audisabled":             "0",
            "cacheexmode":            "1",
            "cacheexwait":            "",

            "disablecrccws_only_for": "",
            "cccreconnect":           "0",
            "cccmaxhops":             "0",
            "cacheex":                False,
            "cacheex_mode":           "1",
            "cacheex_maxhop":         "0",

            "pin":                    "",
            "boxid":                  "",
            "mhrz":                   "200",
            "card_mhrz":              "450",
        }

    def _load_server_data(self, reader):
        if reader is None:
            return self._get_default_data()

        device = (reader.device or "").split(",")
        host = device[0] if len(device) > 0 else ""
        port = 0
        if len(device) > 1:
            try:
                port = int(device[1])
            except Exception:
                port = 0

        data = {
            "label":                  reader.label or "",
            "enable":                 "1" if reader.enabled else "0",
            "protocol":               reader.protocol or "",
            "host":                   host,
            "port":                   port,
            "user":                   reader.user or "",
            "password":               reader.password or "",
            "group":                  reader.group or "1",
            "keepalive":              reader.extra.get("keepalive", "1") or "1",
            "caid":                   reader.caid or "",
            "ident":                  reader.ident or "",
            "chid":                   reader.extra.get("chid", ""),
            "cccversion":             reader.extra.get("cccversion", "2.3.2") or "2.3.2",
            "key":                    reader.extra.get("key", ""),
            "detect":                 reader.extra.get("detect", "cd") or "cd",

            "blockemm_u":             reader.extra.get("blockemm-u", "0") or "0",
            "blockemm_s":             reader.extra.get("blockemm-s", "0") or "0",
            "blockemm_g":             reader.extra.get("blockemm-g", "0") or "0",
            "blockemm_unknown":       reader.extra.get("blockemm-unknown", "0") or "0",
            "blockemm_bylen":         reader.extra.get("blockemm-bylen", ""),
            "saveemm_u":              reader.extra.get("saveemm-u", "0") or "0",
            "saveemm_s":              reader.extra.get("saveemm-s", "0") or "0",
            "saveemm_g":              reader.extra.get("saveemm-g", "0") or "0",
            "saveemm_unknown":        reader.extra.get("saveemm-unknown", "0") or "0",
            "emmcache":               reader.extra.get("emmcache", ""),

            "cardmhz":                reader.extra.get("cardmhz", "357") or "357",
            "mhz":                    reader.extra.get("mhz", "357") or "357",
            "autospeed":              reader.extra.get("autospeed", "1") or "1",
            "deprecated":             reader.extra.get("deprecated", "0") or "0",
            "smargopatch":            reader.extra.get("smargopatch", "0") or "0",

            "ratelimitecm":           reader.extra.get("ratelimitecm", "0") or "0",
            "ratelimittime":          reader.extra.get("ratelimittime", "9000") or "9000",
            "srvidholdtime":          reader.extra.get("srvidholdtime", "2000") or "2000",
            "cooldown":               reader.extra.get("cooldown", ""),
            "ecmunique":              reader.extra.get("ecmunique", "0") or "0",

            "inactivitytimeout":      reader.extra.get("inactivitytimeout", "0") or "0",
            "reconnecttimeout":       reader.extra.get("reconnecttimeout", "5") or "5",

            "services":               reader.extra.get("services", ""),
            "class":                  reader.extra.get("class", ""),
            "aeskey":                 reader.extra.get("aeskey", ""),
            "aeskeys":                reader.extra.get("aeskeys", ""),
            "fallback":               reader.extra.get("fallback", "0") or "0",
            "dropbadcws":             reader.extra.get("dropbadcws", "0") or "0",
            "disablecrccws":          reader.extra.get("disablecrccws", "0") or "0",
            "audisabled":             reader.extra.get("audisabled", "0") or "0",
            "cacheexmode":            reader.extra.get("cacheexmode", "1") or "1",
            "cacheexwait":            reader.extra.get("cacheexwait", ""),

            "disablecrccws_only_for": reader.extra.get("disablecrccws_only_for", ""),
            "cccreconnect":           reader.extra.get("cccreconnect", "0") or "0",
            "cccmaxhops":             reader.extra.get("cccmaxhops", "0") or "0",
            "cacheex":                bool(reader.extra.get("cacheex", False)),
            "cacheex_mode":           reader.extra.get("cacheex_mode", "1") or "1",
            "cacheex_maxhop":         reader.extra.get("cacheex_maxhop", "0") or "0",

            "pin":                    reader.extra.get("pin", "") or "",
            "boxid":                  reader.extra.get("boxid", "") or "",
            "mhrz":                   reader.extra.get("mhrz", "200") or "200",
            "card_mhrz":              reader.extra.get("card_mhrz", "450") or "450",
        }

        return data

    # ==================================================================
    #  UI Elements
    # ==================================================================
    def _init_config_elements(self):
        d = self.server_data

        is_advanced = (self._editor_mode == "advanced")

        if is_advanced:
            protocol_choices = [
                ("cccam",       "CCcam"),
                ("newcamd",     "NewCamd"),
                ("mgcamd",      "MgCamd (NCam)"),
                ("cs378x",      "CS378x"),
                ("camd35",      "Camd35"),
                ("gbox",        "GBox"),
                ("radegast",    "Radegast"),
                ("mouse",       "Mouse"),
                ("smartreader", "SmartReader"),
                ("pcsc",        "PCSC"),
                ("constcw",     "ConstCW"),
                ("cacheex",     "CacheEx"),
                ("internal",    "Internal"),
                ("emu",         "Emu"),
            ]
            protocol_placeholder = "-- select protocol --"
        else:
            protocol_choices = [
                ("cccam",   "CCcam"),
                ("newcamd", "NewCamd"),
                ("mgcamd",  "MgCamd (NCam)"),
                ("emu",     "Emu"),
            ]
            protocol_placeholder = "-- select protocol --"

        self.protocol = _PlaceholderSelection(
            choices=protocol_choices,
            placeholder_label=protocol_placeholder)

        existing_proto = (d.get("protocol") or "").strip().lower()
        if existing_proto:
            available = [k for k, _ in protocol_choices]
            if existing_proto not in available:
                self.protocol._real_choices.append(
                    (existing_proto,
                     existing_proto.upper() + " (advanced only)"))
                try:
                    new_choices = [
                        (self.protocol.PLACEHOLDER_KEY,
                         self.protocol._placeholder_label)
                    ]
                    new_choices.extend(self.protocol._real_choices)
                    self.protocol.setChoices(
                        new_choices, default=self.protocol.PLACEHOLDER_KEY)
                except Exception:
                    pass
            self.protocol.setValue(existing_proto)

        # ─── General ───
        self.label = _PlaceholderText(placeholder=self.PH_LABEL)
        if d["label"]:
            self.label.value = d["label"]

        self.enable = ConfigSelection(
            choices=ENABLE_CHOICES, default=d["enable"])

        self.host = _MaskedText(
            placeholder=self.PH_HOST, mask=True, field_name="Host")
        if d["host"]:
            self.host.value = d["host"]

        self.port = ConfigInteger(
            default=int(d["port"]) if d["port"] else 12000,
            limits=(0, 65535))

        self.user = _MaskedText(
            placeholder=self.PH_USER, mask=True, field_name="Username")
        if d["user"]:
            self.user.value = d["user"]

        self.password = _MaskedText(
            placeholder=self.PH_PASSWORD, mask=True, field_name="Password")
        if d["password"]:
            self.password.value = d["password"]

        self.group = _PlaceholderSelection(
            choices=GROUP_CHOICES,
            placeholder_label="-- select group --")
        if d["group"]:
            try:
                self.group.setValue(str(d["group"]))
            except Exception:
                pass

        self.keepalive = ConfigSelection(
            choices=ENABLE_CHOICES, default=d["keepalive"])

        self.caid = _PlaceholderText(placeholder=self.PH_CAID)
        if d["caid"]:
            self.caid.value = d["caid"]

        self.ident = _PlaceholderText(placeholder=self.PH_IDENT)
        if d["ident"]:
            self.ident.value = d["ident"]

        self.chid = _PlaceholderText(placeholder=self.PH_CHID)
        if d["chid"]:
            self.chid.value = d["chid"]

        self.cccversion = _PlaceholderSelection(
            choices=[(v, v) for v in CCCAM_VERSIONS],
            placeholder_label="-- select version --")
        if d["cccversion"]:
            self.cccversion.setValue(d["cccversion"])

        self.key = _MaskedText(
            placeholder=self.PH_KEY, mask=True, field_name="Key")
        if d["key"]:
            self.key.value = d["key"]

        self.detect = ConfigSelection(
            choices=DETECT_MODES,
            default=d["detect"]
            if d["detect"] in [k for k, _ in DETECT_MODES]
            else "cd")

        # ─── EMM ───
        self.blockemm_u = ConfigYesNo(default=(d["blockemm_u"] == "1"))
        self.blockemm_s = ConfigYesNo(default=(d["blockemm_s"] == "1"))
        self.blockemm_g = ConfigYesNo(default=(d["blockemm_g"] == "1"))
        self.blockemm_unknown = ConfigYesNo(
            default=(d["blockemm_unknown"] == "1"))

        self.blockemm_bylen = _PlaceholderSelection(
            choices=BLOCKEMM_BYLEN_VALUES[1:],
            placeholder_label="-- select lengths --")
        if d["blockemm_bylen"]:
            self.blockemm_bylen.setValue(d["blockemm_bylen"])

        self.saveemm_u = ConfigYesNo(default=(d["saveemm_u"] == "1"))
        self.saveemm_s = ConfigYesNo(default=(d["saveemm_s"] == "1"))
        self.saveemm_g = ConfigYesNo(default=(d["saveemm_g"] == "1"))
        self.saveemm_unknown = ConfigYesNo(
            default=(d["saveemm_unknown"] == "1"))

        self.emmcache = _PlaceholderSelection(
            choices=EMMCACHE_VALUES[1:],
            placeholder_label="-- select emmcache --")
        if d["emmcache"]:
            self.emmcache.setValue(d["emmcache"])

        # ─── Frequency ───
        self.cardmhz = _PlaceholderSelection(
            choices=CARD_MHZ_VALUES,
            placeholder_label="-- select card mhz --")
        if d["cardmhz"]:
            self.cardmhz.setValue(d["cardmhz"])

        self.mhz = _PlaceholderSelection(
            choices=READER_MHZ_VALUES,
            placeholder_label="-- select reader mhz --")
        if d["mhz"]:
            self.mhz.setValue(d["mhz"])

        self.autospeed = ConfigYesNo(default=(d["autospeed"] == "1"))
        self.deprecated = ConfigYesNo(default=(d["deprecated"] == "1"))
        self.smargopatch = ConfigYesNo(default=(d["smargopatch"] == "1"))

        # ─── Rate Limiting ───
        self.ratelimitecm = _PlaceholderSelection(
            choices=RATELIMIT_ECM_VALUES[1:],
            placeholder_label="-- select ratelimit --")
        if d["ratelimitecm"]:
            self.ratelimitecm.setValue(str(d["ratelimitecm"]))

        self.ratelimittime = _PlaceholderSelection(
            choices=RATELIMIT_TIME_VALUES,
            placeholder_label="-- select time --")
        if d["ratelimittime"]:
            try:
                self.ratelimittime.setValue(str(d["ratelimittime"]))
            except Exception:
                pass

        self.srvidholdtime = _PlaceholderSelection(
            choices=SRVID_HOLD_TIME_VALUES,
            placeholder_label="-- select time --")
        if d["srvidholdtime"]:
            try:
                self.srvidholdtime.setValue(str(d["srvidholdtime"]))
            except Exception:
                pass

        self.cooldown = _PlaceholderSelection(
            choices=COOLDOWN_VALUES[1:],
            placeholder_label="-- select cooldown --")
        if d["cooldown"]:
            try:
                self.cooldown.setValue(d["cooldown"])
            except Exception:
                pass

        self.ecmunique = ConfigYesNo(default=(d["ecmunique"] == "1"))

        # ─── Timeouts ───
        self.inactivitytimeout = _PlaceholderSelection(
            choices=INACTIVITY_TIMEOUT_VALUES[1:],
            placeholder_label="-- select timeout --")
        if d["inactivitytimeout"]:
            try:
                self.inactivitytimeout.setValue(
                    str(d["inactivitytimeout"]))
            except Exception:
                pass

        self.reconnecttimeout = _PlaceholderSelection(
            choices=RECONNECT_TIMEOUT_VALUES,
            placeholder_label="-- select timeout --")
        if d["reconnecttimeout"]:
            try:
                self.reconnecttimeout.setValue(
                    str(d["reconnecttimeout"]))
            except Exception:
                pass

        # ─── Class Filter ───
        self.class_filter = _PlaceholderSelection(
            choices=CLASS_FILTER_VALUES[1:],
            placeholder_label="-- select class --")
        if d["class"]:
            try:
                self.class_filter.setValue(d["class"])
            except Exception:
                pass

        # ─── AES ───
        self.aeskey = _MaskedText(
            placeholder=self.PH_AESKEY, mask=True, field_name="AES Key")
        if d["aeskey"]:
            self.aeskey.value = d["aeskey"]

        self.aeskeys = _MaskedText(
            placeholder=self.PH_AESKEYS, mask=True, field_name="AES Keys")
        if d["aeskeys"]:
            self.aeskeys.value = d["aeskeys"]

        self.fallback = ConfigYesNo(default=(d["fallback"] == "1"))
        self.dropbadcws = ConfigYesNo(default=(d["dropbadcws"] == "1"))
        self.disablecrccws = ConfigYesNo(default=(d["disablecrccws"] == "1"))
        self.audisabled = ConfigYesNo(default=(d["audisabled"] == "1"))

        self.cacheexmode = _PlaceholderSelection(
            choices=CACHEEX_MODES,
            placeholder_label="-- select mode --")
        if d["cacheexmode"]:
            try:
                self.cacheexmode.setValue(str(d["cacheexmode"]))
            except Exception:
                pass

        self.cacheexwait = _PlaceholderText(placeholder="ms")
        if d["cacheexwait"]:
            self.cacheexwait.value = d["cacheexwait"]

        # ─── CCcam Advanced ───
        self.disablecrccws_only_for = _PlaceholderText(
            placeholder=self.PH_DISCRC)
        if d["disablecrccws_only_for"]:
            self.disablecrccws_only_for.value = d["disablecrccws_only_for"]

        self.cccreconnect = ConfigSelection(
            choices=CCCRECONNECT_VALUES,
            default=d["cccreconnect"]
            if d["cccreconnect"] in [x[0] for x in CCCRECONNECT_VALUES]
            else "0")

        self.cccmaxhops = ConfigSelection(
            choices=CCC_MAXHOPS_VALUES,
            default=d["cccmaxhops"]
            if d["cccmaxhops"] in [x[0] for x in CCC_MAXHOPS_VALUES]
            else "0")

        self.cacheex = ConfigYesNo(default=d["cacheex"])

        self.cacheex_mode = ConfigSelection(
            choices=CACHEEX_MODES,
            default=d["cacheex_mode"]
            if d["cacheex_mode"] in [x[0] for x in CACHEEX_MODES]
            else "1")

        self.cacheex_maxhop = ConfigSelection(
            choices=CACHEEX_MAXHOP_VALUES,
            default=d["cacheex_maxhop"]
            if d["cacheex_maxhop"] in [x[0] for x in CACHEEX_MAXHOP_VALUES]
            else "0")

        # ─── Internal ───
        self.pin = _MaskedText(
            placeholder=self.PH_PIN, mask=True, field_name="PIN")
        if d["pin"]:
            self.pin.value = d["pin"]

        self.boxid = _PlaceholderText(placeholder=self.PH_BOXID)
        if d["boxid"]:
            self.boxid.value = d["boxid"]

        self.mhrz = ConfigSelection(
            choices=MHRZ_VALUES,
            default=d["mhrz"]
            if d["mhrz"] in [x[0] for x in MHRZ_VALUES]
            else "200")

        self.card_mhrz = ConfigSelection(
            choices=CARD_MHRZ_VALUES,
            default=d["card_mhrz"]
            if d["card_mhrz"] in [x[0] for x in CARD_MHRZ_VALUES]
            else "450")

    # ------------------------------------------------------------------
    def update_fields(self, config_element=None):
        proto = self.protocol.value

        if proto == "internal":
            self.host._placeholder = "/dev/sci0"
            self.port.value = 0
        elif proto == "emu":
            self.host._placeholder = "0"
            self.port.value = 0
        elif proto == "smartreader":
            self.host._placeholder = "0"
        elif proto == "pcsc":
            self.host._placeholder = "0"
        elif proto == "constcw":
            self.host._placeholder = "/var/keys/constant.cw"
        elif proto == "mouse":
            self.host._placeholder = "/dev/ttyUSB0"
        elif proto in ("cccam", "newcamd", "mgcamd", "cs378x", "camd35",
                       "gbox", "radegast", "cacheex"):
            self.host._placeholder = "Server address (IP or DNS)"
        else:
            self.host._placeholder = self.PH_HOST

        self.create_setup()

    # ==================================================================
    #  Build field list
    # ==================================================================
    def create_setup(self):
        proto = self.protocol.value
        is_advanced = (self._editor_mode == "advanced")

        needs_auth   = proto in AUTH_PROTOCOLS
        needs_key    = proto in KEY_PROTOCOLS
        needs_cccver = proto in CCCVERSION_PROTOCOLS
        needs_detect = proto in DETECT_PROTOCOLS
        needs_port   = proto not in NO_PORT_PROTOCOLS
        is_tcp       = proto in TCP_PROTOCOLS

        self.list = [
            ("Label",            self.label,         "Unique name."),
            ("Status",           self.enable,        "Enable or disable."),
            ("Protocol",         self.protocol,      "Protocol type."),
            ("Host ",            self.host,          "Server hostname, IP, or device path."),
            ("Port",             self.port if needs_port else None,
                                                     "Server port."),
            ("Username",         self.user if needs_auth else None,
                                                     "Login username."),
            ("Password",         self.password if needs_auth else None,
                                                     "Login password."),
            ("Group",            self.group,         "Group number (1-64)."),
            ("Keepalive",        self.keepalive,     "Keepalive enabled or disabled."),
            ("CCcam Version",    self.cccversion if needs_cccver else None,
                                                     "CCcam version."),
            ("Key",              self.key if needs_key else None,
                                                     "DES key (hexadecimal)."),
            ("Detect",           self.detect if needs_detect else None,
                                                     "Card detect mode."),
        ]

        if is_advanced:
            self.list += self._build_advanced_fields(proto, is_tcp)

        filtered = [item[:2] for item in self.list if item[1] is not None]
        self["config"].list = filtered
        self["config"].setList(filtered)

    # ------------------------------------------------------------------
    def _build_advanced_fields(self, proto, is_tcp):
        """يعرض فقط الحقول المناسبة لكل بروتوكول."""
        fields = []

        is_share      = proto in ("cccam", "newcamd", "mgcamd",
                                   "cs378x", "camd35", "gbox", "radegast")
        is_local      = proto in ("internal", "mouse",
                                   "smartreader", "pcsc")
        is_emu        = proto in ("emu", "constcw")
        is_cacheex    = (proto == "cacheex")
        is_serial     = proto in ("mouse", "smartreader", "internal")
        is_internal   = (proto == "internal")

        # ─── CAID / Ident ───
        if not is_emu:
            fields += [
                ("CAID",  self.caid,  "CAID list (comma-separated)"),
                ("Ident", self.ident, "Provider IDs"),
            ]

        # ─── CHID: CacheEx فقط ───
        if is_cacheex:
            fields += [
                ("CHID", self.chid, "Channel IDs for Cache-Exchange"),
            ]

        # ─── EMM Management ───
        if not is_emu and not is_cacheex:
            fields += [
                ("Block Unique EMM",  self.blockemm_u,       "Block unique EMMs"),
                ("Block Shared EMM",  self.blockemm_s,       "Block shared EMMs"),
                ("Block Global EMM",  self.blockemm_g,       "Block global EMMs"),
                ("Block Unknown EMM", self.blockemm_unknown, "Block unknown EMMs"),
                ("Block EMM by Length", self.blockemm_bylen, "e.g. 50-60,100-110"),
                ("Save Unique EMM",   self.saveemm_u,        "Save unique EMMs"),
                ("Save Shared EMM",   self.saveemm_s,        "Save shared EMMs"),
                ("Save Global EMM",   self.saveemm_g,        "Save global EMMs"),
                ("EMM Cache",         self.emmcache,         "usecache,rewrite,logging"),
            ]

        # ─── Rate Limiting ───
        if not is_emu:
            fields += [
                ("Rate Limit ECM",  self.ratelimitecm,  "Max concurrent ECMs (0-20)"),
                ("Rate Limit Time", self.ratelimittime, "Slot release delay (3-11 sec)"),
                ("SRVID Hold Time", self.srvidholdtime, "SRVID hold after slot (0-5 sec)"),
                ("Cooldown",        self.cooldown,      "delay,duration (seconds)"),
                ("ECM Unique",      self.ecmunique,     "Prevent ECM duplicates"),
            ]

        # ─── Timeouts: TCP فقط ───
        if is_tcp:
            fields += [
                ("Inactivity Timeout", self.inactivitytimeout,
                 "Idle connection close (-1 to 120 sec)"),
                ("Reconnect Timeout",  self.reconnecttimeout,
                 "TCP reconnect delay (1-60 sec)"),
            ]

        # ─── Class Filter: share protocols فقط ───
        if is_share:
            fields += [
                ("Class Filter", self.class_filter, "e.g. 01,02,!1b"),
            ]

        # ─── Fallback ───
        if not is_emu and not is_cacheex:
            fields += [
                ("Fallback", self.fallback, "Fallback reader"),
            ]

        # ─── Drop / Crc / AU ───
        if not is_emu and not is_cacheex:
            fields += [
                ("Drop Bad CWs",    self.dropbadcws,   "Drop bad CWs"),
                ("Disable CRC CWS", self.disablecrccws,"Disable CRC check"),
                ("AU Disabled",     self.audisabled,   "Disable AU"),
                ("Disable CRC For", self.disablecrccws_only_for,
                 "e.g. 0500:050000"),
            ]

        # ─── Frequency: serial + internal ───
        if is_serial:
            fields += [
                ("Card MHz", self.cardmhz, "Card frequency (10 kHz)"),
                ("Reader MHz", self.mhz,   "Reader frequency"),
                ("Auto Speed", self.autospeed, "Auto speed"),
            ]
            if proto in ("mouse", "smartreader"):
                fields += [
                    ("Deprecated Mode", self.deprecated, "Deprecated mode"),
                    ("Smargo Patch",    self.smargopatch,"Smargo patch"),
                ]

        # ─── AES: internal + pcsc + smartreader ───
        if proto in ("internal", "pcsc", "smartreader"):
            fields += [
                ("AES Key",  self.aeskey,  "AES key (hex)"),
                ("AES Keys", self.aeskeys, "Multiple AES keys"),
            ]

        # ─── Internal-only ───
        if is_internal:
            fields += [
                ("PIN Code",  self.pin,       "PIN"),
                ("BoxID",     self.boxid,     "BoxID"),
                ("Mhrz",      self.mhrz,      "Mhrz (0-1000)"),
                ("Card Mhrz", self.card_mhrz, "Card Mhrz (0-1000)"),
            ]

        # ─── CCcam-specific ───
        if proto == "cccam":
            fields += [
                ("Reconnect Time < 9000", self.cccreconnect, "Reconnect delay"),
                ("CCC Max Hops < 10",     self.cccmaxhops,   "Max hops"),
                ("Enable CacheEx",        self.cacheex,      "Enable CacheEx"),
            ]
            if self.cacheex.value:
                fields += [
                    ("CacheEx Mode",   self.cacheex_mode,   "CacheEx mode"),
                    ("CacheEx MaxHop", self.cacheex_maxhop, "CacheEx max hop"),
                ]

        # ─── CacheEx-specific ───
        if is_cacheex:
            fields += [
                ("CacheEx Mode", self.cacheexmode, "CacheEx mode (1/2/3)"),
                ("CacheEx Wait", self.cacheexwait, "CacheEx wait time (ms)"),
            ]

        return fields

    # ------------------------------------------------------------------
    #  Show field info (help) — مع openWithCallback لمنع التجميد
    # ------------------------------------------------------------------
    def show_field_info(self):
        """عرض مساعدة الحقل الحالي عند الضغط على Info."""
        self._log("INFO pressed")

        try:
            current = self["config"].getCurrent()
        except Exception as e:
            self._log("INFO: getCurrent error: %s" % e)
            return

        if not current:
            self._log("INFO: no current field")
            return

        try:
            field_title = current[0]
        except Exception:
            self._log("INFO: cannot get field title")
            return

        self._log("INFO field: %r" % field_title)

        # جلب نص المساعدة
        help_txt = ""
        try:
            if has_help(field_title):
                help_txt = get_help(field_title)
                self._log("INFO: found in field_help (len=%d)"
                          % len(help_txt or ""))
        except Exception as e:
            self._log("INFO: field_help error: %s" % e)

        if not help_txt:
            for item in self.list:
                if item[0] == field_title and len(item) > 2 and item[2]:
                    help_txt = item[2]
                    self._log("INFO: fallback found")
                    break

        if not help_txt:
            help_txt = "No help available for:\n\n%s" % field_title
            self._log("INFO: no help")

        # ✅ openWithCallback يضمن إعادة التركيز بعد الإغلاق
        try:
            self.session.openWithCallback(
                self._after_info_closed,
                MessageBox,
                help_txt,
                MessageBox.TYPE_INFO,
                title=field_title)
        except Exception as e:
            self._log("INFO: openWithCallback error: %s" % e)

    def _after_info_closed(self, *args, **kwargs):
        """
        يُستدعى عند إغلاق MessageBox المساعدة.
        يُعيد التركيز على ConfigList.
        """
        try:
            self._log("INFO: MessageBox closed - restoring focus")
            # تفعيل ConfigList مرة أخرى
            self["config"].instance.setSelectionEnable(1)
        except Exception as e:
            self._log("INFO: restore focus error: %s" % e)

    def toggle_state(self):
        self.enable.value = "0" if self.enable.value == "1" else "1"
        self["infoLabel"].setText(
            "State: %s" % ("Enabled" if self.enable.value == "1"
                           else "Disabled"))

    def reset_fields(self):
        self.server_data = self._get_default_data()
        self._init_config_elements()
        self.create_setup()
        self["infoLabel"].setText("All fields cleared - start over")

    # ==================================================================
    #  Validation
    # ==================================================================
    def _validate(self):
        errors = []
        proto = self.protocol.value
        is_advanced = (self._editor_mode == "advanced")

        label = (self.label.value or "").strip()
        if not label:
            errors.append("- Label (reader name)")
        elif not re.match(r"^[A-Za-z0-9_\-.]+$", label):
            errors.append("- Label contains invalid characters")
        elif self._is_duplicate_label(label):
            errors.append("- Label '%s' already exists" % label)

        if not proto:
            errors.append("- Protocol (select one)")
        elif proto not in ALL_PROTOCOLS:
            errors.append("- Unsupported protocol: %s" % proto)
        elif not is_advanced and proto not in SIMPLE_PROTOCOLS:
            errors.append(
                "- Protocol '%s' is only available in Advanced Mode. "
                "Switch to Advanced Mode in General Settings." % proto)

        host = (self.host.value or "").strip()
        if not host:
            errors.append("- Host / Device")

        if proto in AUTH_PROTOCOLS:
            user = (self.user.value or "").strip()
            pwd  = (self.password.value or "").strip()
            if not user:
                errors.append("- Username (required for %s)" % proto)
            if not pwd:
                errors.append("- Password (required for %s)" % proto)

        if proto in KEY_PROTOCOLS:
            key = (self.key.value or "").strip()
            if not key:
                errors.append("- Key (required for %s)" % proto)
            elif not re.match(r"^[A-Fa-f0-9]{8,64}$", key):
                errors.append("- Key must be hexadecimal (8-64 chars)")

        if errors:
            return errors, None

        return [], self._collect_values()

    def _is_duplicate_label(self, label):
        if not label:
            return False
        path = (self.original.source_file if self.original
                else self.target_file)
        if not path or not os.path.exists(path):
            return False
        try:
            existing = ReaderParser().parse_file(path)
        except Exception:
            return False

        for r in existing:
            if r.label != label:
                continue
            if self.is_editing and self.original_label == label:
                continue
            return True
        return False

    # ------------------------------------------------------------------
    def _collect_values(self):
        def safe_text(cfg, placeholder):
            v = (cfg.value or "").strip()
            if placeholder and v == placeholder:
                return ""
            return v

        def safe_sel(cfg, default=""):
            v = cfg.value
            if not v or v == getattr(cfg, "PLACEHOLDER_KEY", "__x__"):
                return default
            return str(v)

        is_advanced = (self._editor_mode == "advanced")

        values = {
            "label":                  safe_text(self.label, self.PH_LABEL),
            "enable":                 self.enable.value,
            "protocol":               self.protocol.value or "",
            "host":                   safe_text(self.host, self.host._placeholder),
            "port":                   self.port.value,
            "user":                   safe_text(self.user, self.PH_USER),
            "password":               safe_text(self.password, self.PH_PASSWORD),
            "group":                  self.group.value or "1",
            "keepalive":              self.keepalive.value,
            "caid":                   safe_text(self.caid, self.PH_CAID),
            "ident":                  safe_text(self.ident, self.PH_IDENT),
            "chid":                   safe_text(self.chid, self.PH_CHID),
            "cccversion":             self.cccversion.value or "",
            "key":                    safe_text(self.key, self.PH_KEY),
            "detect":                 self.detect.value,
            "advanced":               is_advanced,
        }

        if is_advanced:
            values.update({
                "blockemm_u":             "1" if self.blockemm_u.value else "0",
                "blockemm_s":             "1" if self.blockemm_s.value else "0",
                "blockemm_g":             "1" if self.blockemm_g.value else "0",
                "blockemm_unknown":       "1" if self.blockemm_unknown.value else "0",
                "blockemm_bylen":         safe_sel(self.blockemm_bylen, ""),
                "saveemm_u":              "1" if self.saveemm_u.value else "0",
                "saveemm_s":              "1" if self.saveemm_s.value else "0",
                "saveemm_g":              "1" if self.saveemm_g.value else "0",
                "saveemm_unknown":        "1" if self.saveemm_unknown.value else "0",
                "emmcache":               safe_sel(self.emmcache, ""),

                "cardmhz":                safe_sel(self.cardmhz, "357"),
                "mhz":                    safe_sel(self.mhz, "357"),
                "autospeed":              "1" if self.autospeed.value else "0",
                "deprecated":             "1" if self.deprecated.value else "0",
                "smargopatch":            "1" if self.smargopatch.value else "0",

                "ratelimitecm":           safe_sel(self.ratelimitecm, "0"),
                "ratelimittime":          safe_sel(self.ratelimittime, "9000"),
                "srvidholdtime":          safe_sel(self.srvidholdtime, "2000"),
                "cooldown":               safe_sel(self.cooldown, ""),
                "ecmunique":              "1" if self.ecmunique.value else "0",

                "inactivitytimeout":      safe_sel(self.inactivitytimeout, "0"),
                "reconnecttimeout":       safe_sel(self.reconnecttimeout, "5"),

                "class":                  safe_sel(self.class_filter, ""),
                "aeskey":                 safe_text(self.aeskey, self.PH_AESKEY),
                "aeskeys":                safe_text(self.aeskeys, self.PH_AESKEYS),
                "fallback":               "1" if self.fallback.value else "0",
                "dropbadcws":             "1" if self.dropbadcws.value else "0",
                "disablecrccws":          "1" if self.disablecrccws.value else "0",
                "audisabled":             "1" if self.audisabled.value else "0",
                "cacheexmode":            safe_sel(self.cacheexmode, "1"),
                "cacheexwait":            safe_text(self.cacheexwait, "ms"),

                "disablecrccws_only_for": safe_text(self.disablecrccws_only_for,
                                                    self.PH_DISCRC),
                "cccreconnect":           self.cccreconnect.value,
                "cccmaxhops":             self.cccmaxhops.value,
                "cacheex":                bool(self.cacheex.value),
                "cacheex_mode":           self.cacheex_mode.value,
                "cacheex_maxhop":         self.cacheex_maxhop.value,

                "pin":                    safe_text(self.pin, self.PH_PIN),
                "boxid":                  safe_text(self.boxid, self.PH_BOXID),
                "mhrz":                   self.mhrz.value,
                "card_mhrz":              self.card_mhrz.value,
            })
        else:
            values.update({
                "blockemm_u":             "0",
                "blockemm_s":             "0",
                "blockemm_g":             "0",
                "blockemm_unknown":       "0",
                "blockemm_bylen":         "",
                "saveemm_u":              "0",
                "saveemm_s":              "0",
                "saveemm_g":              "0",
                "saveemm_unknown":        "0",
                "emmcache":               "",
                "cardmhz":                "357",
                "mhz":                    "357",
                "autospeed":              "1",
                "deprecated":             "0",
                "smargopatch":            "0",
                "ratelimitecm":           "0",
                "ratelimittime":          "9000",
                "srvidholdtime":          "2000",
                "cooldown":               "",
                "ecmunique":              "0",
                "inactivitytimeout":      "0",
                "reconnecttimeout":       "5",
                "services":               "",
                "class":                  "",
                "aeskey":                 "",
                "aeskeys":                "",
                "fallback":               "0",
                "dropbadcws":             "0",
                "disablecrccws":          "0",
                "audisabled":             "0",
                "cacheexmode":            "1",
                "cacheexwait":            "",
                "disablecrccws_only_for": "",
                "cccreconnect":           "0",
                "cccmaxhops":             "0",
                "cacheex":                False,
                "cacheex_mode":           "1",
                "cacheex_maxhop":         "0",
                "pin":                    "",
                "boxid":                  "",
                "mhrz":                   "200",
                "card_mhrz":              "450",
            })

        return values

    # ==================================================================
    #  Build Reader
    # ==================================================================
    def _build_reader(self, values):
        reader = Reader()
        ui_proto = values["protocol"]
        file_proto = resolve_protocol_for_file(
            ui_proto,
            self.original.source_file if self.original
            else self.target_file
        )
        reader.protocol = file_proto

        reader.label    = values["label"]
        reader.enabled  = (values["enable"] == "1")
        reader.user     = values["user"]
        reader.password = values["password"]
        reader.group    = values["group"]

        if ui_proto == "internal":
            reader.device = "%s,0" % values["host"]
        elif ui_proto == "emu":
            reader.device = values["host"] or "0"
        elif ui_proto == "constcw":
            reader.device = values["host"]
        else:
            reader.device = "%s,%s" % (values["host"], values["port"])

        if values["caid"]:
            reader.caid = values["caid"]
        if values["ident"]:
            reader.ident = values["ident"]
        if values["chid"]:
            reader.extra["chid"] = values["chid"]
        if values.get("keepalive"):
            reader.extra["keepalive"] = values["keepalive"]

        reader.extra["advanced"] = values["advanced"]

        if ui_proto == "cccam":
            if values["cccversion"]:
                reader.extra["cccversion"] = values["cccversion"]
            if values["advanced"]:
                if values["cccreconnect"] and values["cccreconnect"] != "0":
                    reader.extra["cccreconnect"] = values["cccreconnect"]
                if values["cccmaxhops"] and values["cccmaxhops"] != "0":
                    reader.extra["cccmaxhops"] = values["cccmaxhops"]
                if values["cacheex"]:
                    reader.extra["cacheex"] = "1"
                    if values["cacheex_mode"]:
                        reader.extra["cacheex_mode"] = values["cacheex_mode"]
                    if (values["cacheex_maxhop"]
                            and values["cacheex_maxhop"] != "0"):
                        reader.extra["cacheex_maxhop"] = \
                            values["cacheex_maxhop"]

        elif ui_proto in ("newcamd", "mgcamd"):
            if values["key"]:
                reader.extra["key"] = values["key"]

        elif ui_proto == "emu":
            if values["key"]:
                reader.extra["key"] = values["key"]

        elif ui_proto == "mouse":
            if values["detect"]:
                reader.extra["detect"] = values["detect"]

        elif ui_proto == "cacheex":
            reader.extra["cacheex"] = "1"
            if values["cacheex_mode"]:
                reader.extra["cacheex_mode"] = values["cacheex_mode"]
            if (values["cacheex_maxhop"]
                    and values["cacheex_maxhop"] != "0"):
                reader.extra["cacheex_maxhop"] = values["cacheex_maxhop"]

        if values["advanced"]:
            reader.extra["blockemm-u"] = values["blockemm_u"]
            reader.extra["blockemm-s"] = values["blockemm_s"]
            reader.extra["blockemm-g"] = values["blockemm_g"]
            reader.extra["blockemm-unknown"] = values["blockemm_unknown"]
            if values["blockemm_bylen"]:
                reader.extra["blockemm-bylen"] = values["blockemm_bylen"]
            reader.extra["saveemm-u"] = values["saveemm_u"]
            reader.extra["saveemm-s"] = values["saveemm_s"]
            reader.extra["saveemm-g"] = values["saveemm_g"]
            reader.extra["saveemm-unknown"] = values["saveemm_unknown"]
            if values["emmcache"]:
                reader.extra["emmcache"] = values["emmcache"]

            if ui_proto in LOCAL_PROTOCOLS:
                if values["cardmhz"]:
                    reader.extra["cardmhz"] = values["cardmhz"]
                if values["mhz"]:
                    reader.extra["mhz"] = values["mhz"]
                if values["autospeed"] != "1":
                    reader.extra["autospeed"] = values["autospeed"]
                if values["deprecated"] == "1":
                    reader.extra["deprecated"] = values["deprecated"]
                if values["smargopatch"] == "1":
                    reader.extra["smargopatch"] = values["smargopatch"]

            if values["ratelimitecm"] and values["ratelimitecm"] != "0":
                reader.extra["ratelimitecm"] = values["ratelimitecm"]
            if values["ratelimittime"]:
                reader.extra["ratelimittime"] = values["ratelimittime"]
            if values["srvidholdtime"]:
                reader.extra["srvidholdtime"] = values["srvidholdtime"]
            if values["cooldown"]:
                reader.extra["cooldown"] = values["cooldown"]
            if values["ecmunique"] == "1":
                reader.extra["ecmunique"] = values["ecmunique"]

            if ui_proto in TCP_PROTOCOLS:
                if values["inactivitytimeout"]:
                    reader.extra["inactivitytimeout"] = \
                        values["inactivitytimeout"]
                if values["reconnecttimeout"]:
                    reader.extra["reconnecttimeout"] = \
                        values["reconnecttimeout"]

            if values["services"]:
                reader.extra["services"] = values["services"]
            if values["class"]:
                reader.extra["class"] = values["class"]
            if values["aeskey"]:
                reader.extra["aeskey"] = values["aeskey"]
            if values["aeskeys"]:
                reader.extra["aeskeys"] = values["aeskeys"]
            if values["fallback"] == "1":
                reader.extra["fallback"] = values["fallback"]
            if values["dropbadcws"] == "1":
                reader.extra["dropbadcws"] = values["dropbadcws"]
            if values["disablecrccws"] == "1":
                reader.extra["disablecrccws"] = values["disablecrccws"]
            if values["audisabled"] == "1":
                reader.extra["audisabled"] = values["audisabled"]
            if values["cacheexmode"]:
                reader.extra["cacheexmode"] = values["cacheexmode"]
            if values["cacheexwait"]:
                reader.extra["cacheexwait"] = values["cacheexwait"]
            if values["disablecrccws_only_for"]:
                reader.extra["disablecrccws_only_for"] = \
                    values["disablecrccws_only_for"]

            if ui_proto == "internal":
                if values["pin"]:
                    reader.extra["pin"] = values["pin"]
                if values["boxid"]:
                    reader.extra["boxid"] = values["boxid"]
                if values["mhrz"]:
                    reader.extra["mhrz"] = values["mhrz"]
                if values["card_mhrz"]:
                    reader.extra["card_mhrz"] = values["card_mhrz"]

        reader.source_file = (self.original.source_file if self.original
                              else self.target_file)
        reader.source_tag = (self.original.source_tag if self.original
                             else ("OSCAM" if "oscam" in self.target_file
                                   else "NCAM"))

        return reader

    # ==================================================================
    #  Merge with original
    # ==================================================================
    def _merge_with_original(self, new_reader, original_reader):
        if original_reader is None:
            return new_reader

        if not new_reader.extra.get("advanced", False):
            for k in list(new_reader.extra.keys()):
                if k in MANAGED_EXTRA_KEYS:
                    if k in ("chid", "keepalive", "advanced"):
                        continue
                    if k in ("cccversion", "key", "detect", "cacheex",
                             "cacheex_mode", "cacheex_maxhop"):
                        continue
                    del new_reader.extra[k]

        for k, v in (original_reader.extra or {}).items():
            if k in MANAGED_EXTRA_KEYS:
                continue
            if k == "advanced":
                continue
            if k in new_reader.extra:
                continue
            if v is None or str(v).strip() == "":
                continue
            new_reader.extra[k] = v

        for attr in ("emmcache", "emu_auproviders",
                     "inactivitytimeout", "services"):
            new_val = getattr(new_reader, attr, "")
            old_val = getattr(original_reader, attr, "")
            if not new_val and old_val:
                setattr(new_reader, attr, old_val)

        return new_reader

    # ==================================================================
    #  CAID detection + softcam restart
    # ==================================================================
    def _caid_changed(self, new_caid):
        new_caid = (new_caid or "").strip()
        if self.original is None:
            return bool(new_caid)
        old_caid = (getattr(self.original, "caid", "") or "").strip()
        return old_caid != new_caid

    def _restart_softcam_script(self):
        if not os.path.exists(SOFTCAM_SCRIPT):
            self._log("softcam script not found: %s" % SOFTCAM_SCRIPT)
            return False
        try:
            subprocess.Popen(
                [SOFTCAM_SCRIPT, "restart"],
                stdout=DEVNULL, stderr=DEVNULL, close_fds=True)
            self._log("softcam restart launched")
            return True
        except Exception as e:
            self._log("softcam restart failed: %s" % e)
            return False

    # ==================================================================
    #  Save
    # ==================================================================
    def save_config(self):
        errors, values = self._validate()
        if errors:
            short_msg = "Missing %d field(s):\n\n%s" % (
                len(errors), "\n".join(errors[:5]))
            if len(errors) > 5:
                short_msg += "\n\n... and %d more" % (len(errors) - 5)
            self.session.open(MessageBox, short_msg,
                              MessageBox.TYPE_ERROR, timeout=8)
            self["infoLabel"].setText(
                "Fill the required fields above, then press Green")
            return

        try:
            new_reader = self._build_reader(values)
        except Exception as e:
            self.session.open(MessageBox,
                "Build error: %s" % e,
                MessageBox.TYPE_ERROR, timeout=6)
            return

        if self.is_editing and self.original is not None:
            try:
                new_reader = self._merge_with_original(
                    new_reader, self.original)
            except Exception as e:
                self.session.open(MessageBox,
                    "Merge error: %s" % e,
                    MessageBox.TYPE_ERROR, timeout=6)
                return

        caid_changed = self._caid_changed(new_reader.caid)

        self._log("SAVE mode=%s label=%r proto=%r caid=%r (changed=%s) extra=%r"
                  % (self._editor_mode, new_reader.label,
                     new_reader.protocol, new_reader.caid,
                     caid_changed, new_reader.extra))

        parser = ReaderParser()
        try:
            if (self.is_editing
                    and self.original_label
                    and self.original_label != new_reader.label):
                parser.write_single(new_reader, new_reader.source_file)
                self.original.label = self.original_label
                parser.remove_from_file(self.original)
            else:
                parser.write_single(new_reader, new_reader.source_file)
        except Exception as e:
            self.session.open(
                MessageBox,
                "Save failed:\n%s" % e,
                MessageBox.TYPE_ERROR, timeout=8)
            self["infoLabel"].setText("Save failed - file unchanged")
            return

        if caid_changed:
            self["infoLabel"].setText(
                "CAID changed - restarting softcam...")
            self._restart_softcam_script()

        self["infoLabel"].setText("Saved: %s" % new_reader.label)
        self.close(new_reader)

    # ------------------------------------------------------------------
    def exit(self):
        self.close(None)