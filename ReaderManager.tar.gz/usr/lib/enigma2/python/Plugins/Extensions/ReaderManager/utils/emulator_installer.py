# -*- coding: utf-8 -*-
"""
utils/emulator_installer.py — تنصيب/إزالة المحاكيات عبر ملفات IPK.

التوافق: Python 2.7 + Python 3.x

المنطق الجديد:
    - المستودع: https://github.com/ismail9875/EmuCams
    - جلب قائمة الملفات من GitHub API
    - تنزيل ملف .ipk
    - تثبيت عبر opkg install
    - إلغاء التثبيت عبر opkg remove

المطوّرون المتاحون:
    - Audi06_19
    - MohamedOs
    - kitte888
    - levi-45
"""
from __future__ import absolute_import, print_function, unicode_literals

import os
import re
import time
import glob as globmod
import subprocess
import threading

try:
    from io import open
except ImportError:
    pass

try:
    from urllib2 import (build_opener, Request, HTTPHandler,
                         HTTPSHandler, URLError, HTTPError)
except ImportError:
    from urllib.request import (build_opener, Request, HTTPHandler,
                                 HTTPSHandler)
    from urllib.error import URLError, HTTPError

try:
    from ssl import _create_unverified_context
except ImportError:
    _create_unverified_context = None

try:
    import json
except ImportError:
    json = None

from . import logger


# ═══════════════════════════════════════════════════════════════════
#  حالات المحاكي
# ═══════════════════════════════════════════════════════════════════
STATUS_INSTALLED = "Installed"
STATUS_UPDATE    = "Update"
STATUS_NONE      = "-"
STATUS_UNKNOWN   = "?"


# ═══════════════════════════════════════════════════════════════════
#  إعدادات المستودع
# ═══════════════════════════════════════════════════════════════════
REPO_USER   = "ismail9875"
REPO_NAME   = "EmuCams"
REPO_BRANCH = "main"

REPO_API_BASE = ("https://api.github.com/repos/%s/%s"
                 % (REPO_USER, REPO_NAME))

REPO_RAW_BASE = ("https://raw.githubusercontent.com/%s/%s/%s"
                 % (REPO_USER, REPO_NAME, REPO_BRANCH))

# قائمة المطوّرين المتاحة (اسم المجلد في المستودع)
DEVELOPERS = [
    {
        "id":      "Audi06_19",
        "display": "Audi06_19",
    },
    {
        "id":      "MohamedOs",
        "display": "MohamedOs",
    },
    {
        "id":      "kitte888",
        "display": "kitte888",
    },
    {
        "id":      "levi-45",
        "display": "levi-45",
    },
]


# ═══════════════════════════════════════════════════════════════════
#  HTTP
# ═══════════════════════════════════════════════════════════════════
def _make_opener():
    handlers = []
    try:
        if _create_unverified_context:
            ctx = _create_unverified_context()
            handlers.append(HTTPSHandler(context=ctx))
        else:
            handlers.append(HTTPSHandler())
    except Exception:
        handlers.append(HTTPSHandler())
    handlers.append(HTTPHandler)
    return build_opener(*handlers)


def _http_get(url, timeout=15.0, as_json=False):
    """
    ينفّذ HTTP GET.

    Returns:
        (ok: bool, data_or_error: any)
    """
    try:
        req = Request(url, headers={
            "User-Agent": "Enigma2-ReaderManager/1.0",
            "Accept":     "application/vnd.github.v3+json, */*",
            "Cache-Control": "no-cache",
        })
        opener = _make_opener()
        resp = opener.open(req, timeout=timeout)
        data = resp.read()

        if isinstance(data, bytes):
            data = data.decode("utf-8", "ignore")

        if as_json:
            if json is None:
                return False, "json module not available"
            try:
                return True, json.loads(data)
            except Exception as e:
                return False, "JSON parse error: %s" % e

        return True, data

    except HTTPError as e:
        return False, "HTTP %d: %s" % (e.code, e.reason)
    except URLError as e:
        return False, "URL error: %s" % e.reason
    except Exception as e:
        return False, "Fetch error: %s" % e


def _download_file(url, dest_path, timeout=60.0, on_progress=None):
    """
    ينزّل ملفاً إلى مسار محدد.

    Args:
        url         : رابط الملف
        dest_path   : المسار النهائي
        timeout     : المهلة
        on_progress : callback(downloaded, total)

    Returns:
        (ok: bool, msg: str)
    """
    try:
        req = Request(url, headers={
            "User-Agent": "Enigma2-ReaderManager/1.0",
        })
        opener = _make_opener()
        resp = opener.open(req, timeout=timeout)

        total = 0
        try:
            total = int(resp.headers.get("Content-Length", 0))
        except Exception:
            total = 0

        chunk_size = 64 * 1024
        downloaded = 0

        with open(dest_path, "wb") as f:
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if on_progress:
                    try:
                        on_progress(downloaded, total)
                    except Exception:
                        pass

        if not os.path.isfile(dest_path) or os.path.getsize(dest_path) == 0:
            return False, "Downloaded file is empty"

        return True, "Downloaded %d bytes" % os.path.getsize(dest_path)

    except HTTPError as e:
        return False, "HTTP %d: %s" % (e.code, e.reason)
    except URLError as e:
        return False, "URL error: %s" % e.reason
    except Exception as e:
        return False, "Download error: %s" % e


# ═══════════════════════════════════════════════════════════════════
#  جلب قائمة الملفات من المستودع
# ═══════════════════════════════════════════════════════════════════
def list_developer_files(developer, timeout=15.0):
    """
    يجلب قائمة ملفات .ipk لمطوّر معيّن.

    Args:
        developer: اسم المجلد (مثل "Audi06_19")

    Returns:
        (ok: bool, files_or_error: list | str)
        كل ملف: {
            "name":         اسم الملف,
            "url":          رابط التنزيل الخام,
            "size":         الحجم بالبايت,
            "download_url": رابط مباشر
        }
    """
    api_url = "%s/contents/%s?ref=%s" % (REPO_API_BASE, developer,
                                          REPO_BRANCH)

    ok, data = _http_get(api_url, timeout=timeout, as_json=True)
    if not ok:
        return False, data

    if not isinstance(data, list):
        return False, "Unexpected response format"

    files = []
    for item in data:
        if not isinstance(item, dict):
            continue
        if item.get("type") != "file":
            continue

        name = item.get("name", "")
        if not name.lower().endswith(".ipk"):
            continue

        files.append({
            "name":         name,
            "url":          item.get("download_url", ""),
            "size":         item.get("size", 0),
            "download_url": item.get("download_url", ""),
        })

    return True, files


def get_all_developers():
    """
    يُعيد قائمة المطوّرين (مرتبة).

    Returns:
        list of dict: [{"id": "Audi06_19", "display": "Audi06_19"}, ...]
    """
    return list(DEVELOPERS)


# ═══════════════════════════════════════════════════════════════════
#  تحليل اسم ملف IPK
# ═══════════════════════════════════════════════════════════════════
def parse_ipk_filename(filename):
    """
    يحلّل اسم ملف IPK ويستخرج منه:
        - binary_name : اسم البناري (oscam, ncam, oscamicam)
        - version     : رقم النسخة (11966, 15.8)
        - revision    : رقم المراجعة (803) أو None
        - display     : اسم للعرض

    أمثلة:
        "oscam_11966-r803.ipk"            → oscam, 11966, 803
        "oscam-11966-r803.ipk"            → oscam, 11966, 803
        "ncam-15.8.ipk"                   → ncam, 15.8, None
        "oscamicam_11906.ipk"             → oscamicam, 11906, None
        "enigma2-plugin-softcams-oscam_11966-r803.ipk"
            → oscam, 11966, 803

    Returns:
        dict: {
            "binary_name": str,
            "version":     str,
            "revision":    int | None,
            "display":     str,    # نص قصير للعرض
            "family":      str,    # "oscam" أو "ncam"
        }
    """
    result = {
        "binary_name": "",
        "version":     "",
        "revision":    None,
        "display":     "",
        "family":      "",
    }

    if not filename:
        return result

    # أزل الامتداد
    name = filename
    if name.lower().endswith(".ipk"):
        name = name[:-4]

    # أزل البادئة "enigma2-plugin-softcams-"
    prefix = "enigma2-plugin-softcams-"
    if name.lower().startswith(prefix):
        name = name[len(prefix):]

    result["display"] = name

    # اكتشف العائلة
    name_low = name.lower()
    if "oscam" in name_low:
        result["family"] = "oscam"
    elif "ncam" in name_low:
        result["family"] = "ncam"

    # استخرج النسخة + المراجعة
    # الأنماط:
    #   name_11966-r803
    #   name-11966-r803
    #   name_15.8
    #   name-15.8

    # ① ابحث عن rNNN
    rev_match = re.search(r'[-_]r(\d{2,5})', name)
    if rev_match:
        try:
            result["revision"] = int(rev_match.group(1))
        except (ValueError, TypeError):
            pass

    # ② استخرج النسخة (الأرقام بعد آخر _ أو -)
    # سنأخذ الجزء الأخير الذي يبدأ برقم
    version = ""

    # أزل rNNN
    name_no_rev = re.sub(r'[-_]r\d{2,5}', '', name)

    # ابحث عن _NNNN أو -NNNN في النهاية
    m = re.search(r'[-_](\d+(?:\.\d+)*)\s*$', name_no_rev)
    if m:
        version = m.group(1)
    else:
        # ابحث عن أي رقم بعد آخر _
        parts = re.split(r'[-_]', name_no_rev)
        for p in reversed(parts):
            m = re.match(r'^(\d+(?:\.\d+)*)$', p)
            if m:
                version = m.group(1)
                break

    result["version"] = version

    # استخرج binary_name
    # من البداية، أزل النسخة
    binary_name = name
    if version:
        binary_name = binary_name.replace("_" + version, "")
        binary_name = binary_name.replace("-" + version, "")
    # أزل rNNN
    binary_name = re.sub(r'[-_]r\d{2,5}', '', binary_name)
    # أزل أي _ أو - في النهاية
    binary_name = binary_name.rstrip("-_")

    result["binary_name"] = binary_name.lower()

    return result


# ═══════════════════════════════════════════════════════════════════
#  اكتشاف البناريات المُثبَّتة
# ═══════════════════════════════════════════════════════════════════
def get_installed_binaries():
    """يُعيد dict بأسماء البناريات الفعلية في /usr/bin."""
    binaries = {}

    search_dirs = [
        "/usr/bin",
        "/usr/bin/cam",
        "/usr/softcams",
        "/usr/emu",
    ]

    for d in search_dirs:
        try:
            if not os.path.isdir(d):
                continue
            for entry in os.listdir(d):
                if entry.startswith("."):
                    continue
                full_path = os.path.join(d, entry)
                if not (os.path.isfile(full_path)
                        or os.path.islink(full_path)):
                    continue
                low = entry.lower()
                if not (low.startswith("oscam") or low.startswith("ncam")):
                    continue
                if low not in binaries:
                    binaries[low] = full_path
        except Exception as e:
            logger.log("EmuInstaller",
                       "listdir %s error: %s" % (d, e))

    logger.log("EmuInstaller",
               "Installed binaries: [%s]"
               % ", ".join(sorted(binaries.keys())))
    return binaries


def get_package_name_for_ipk(ipk_path):
    """
    يستخرج اسم الحزمة من ملف .ipk عبر opkg.

    Returns:
        str : اسم الحزمة (مثل "enigma2-plugin-softcams-oscam") أو ""
    """
    if not ipk_path or not os.path.exists(ipk_path):
        return ""

    try:
        rc, out, err = _run(
            "opkg info %s 2>/dev/null" % ipk_path, timeout=10)
        if rc == 0 and out:
            for line in out.split("\n"):
                if line.startswith("Package:"):
                    return line.split(":", 1)[1].strip()
    except Exception:
        pass

    return ""


def _run(cmd, timeout=30):
    """ينفّذ أمر shell ويُعيد (rc, stdout, stderr)."""
    p = None
    try:
        p = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        try:
            out, err = p.communicate(timeout=timeout)
        except TypeError:
            # Py2
            result = [b"", b""]

            def _target():
                try:
                    result[0], result[1] = p.communicate()
                except Exception:
                    pass

            t = threading.Thread(target=_target)
            t.setDaemon(True)
            t.start()
            t.join(timeout)
            if t.isAlive():
                try:
                    p.kill()
                except Exception:
                    pass
                return -1, "", "timeout"
            out, err = result

        if isinstance(out, bytes):
            out = out.decode("utf-8", "ignore")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "ignore")
        return p.returncode, out, err
    except Exception as e:
        if p:
            try:
                p.kill()
            except Exception:
                pass
        return -1, "", str(e)


# ═══════════════════════════════════════════════════════════════════
#  حالة المحاكي
# ═══════════════════════════════════════════════════════════════════
def _parse_version_and_revision(ver_string):
    """يُحلّل "11966-r803" إلى ("11966", 803)."""
    if not ver_string:
        return "", None

    s = str(ver_string).strip().lower()

    # rNNN
    revision = None
    rev_match = re.search(r'[-_]r(\d{2,5})', s)
    if rev_match:
        try:
            revision = int(rev_match.group(1))
        except (ValueError, TypeError):
            pass
        s = re.sub(r'[-_]r\d{2,5}', '', s)

    # الرقم الرئيسي
    version = ""
    m = re.search(r'(\d+(?:\.\d+)+)', s)
    if m:
        version = m.group(1)
    else:
        m = re.search(r'(\d+)', s)
        if m:
            version = m.group(1)

    return version, revision


def _compare_versions(local_ver, remote_ver):
    """يقارن نسختين."""
    local_v, local_r = _parse_version_and_revision(local_ver)
    remote_v, remote_r = _parse_version_and_revision(remote_ver)

    if local_v != remote_v:
        if not local_v or not remote_v:
            return "different"

        try:
            l_parts = [int(x) for x in local_v.split(".")]
            r_parts = [int(x) for x in remote_v.split(".")]

            max_len = max(len(l_parts), len(r_parts))
            l_parts += [0] * (max_len - len(l_parts))
            r_parts += [0] * (max_len - len(r_parts))

            if l_parts < r_parts:
                return "different"
            if l_parts > r_parts:
                return "local_newer"
        except (ValueError, TypeError):
            pass

        return "different"

    if local_r is not None and remote_r is not None:
        if local_r == remote_r:
            return "same"
        if remote_r > local_r:
            return "update"
        if remote_r < local_r:
            return "local_newer"

    if local_r is None and remote_r is None:
        return "same"

    if local_r is None and remote_r is not None:
        return "update"

    if local_r is not None and remote_r is None:
        return "local_newer"

    return "same"


def _read_local_version_for_binary(binary_name):
    """يقرأ النسخة المحلية من /tmp."""
    binary = (binary_name or "").lower()
    if not binary:
        return ""

    if "ncam" in binary:
        candidate_files = [
            "/tmp/.ncam/ncam.version",
            "/tmp/ncam.version",
        ]
    elif "oscam" in binary:
        candidate_files = [
            "/tmp/.oscam/oscam.version",
            "/tmp/oscam.version",
        ]
    else:
        return ""

    for path in candidate_files:
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r") as f:
                for line in f:
                    if line.startswith("Version:"):
                        ver = line.split('@')[0]
                        ver = ver.replace("Version:", "").strip()
                        return ver
        except Exception:
            continue

    return ""


def get_emulator_status(ipk_info, remote_version=None):
    """
    يُعيد حالة محاكي (من ملف IPK).

    Args:
        ipk_info      : dict من parse_ipk_filename()
        remote_version: للتوافق (غير مستخدم — النسخة من الاسم)

    Returns:
        str : "Installed" | "Update" | "-"
    """
    if not ipk_info:
        return STATUS_NONE

    binary_name = ipk_info.get("binary_name", "").lower()
    ipk_version = ipk_info.get("version", "")
    ipk_revision = ipk_info.get("revision")

    if not binary_name:
        return STATUS_NONE

    # ابحث عن البناري المُثبَّت
    installed = get_installed_binaries()

    matched = None
    for name, path in installed.items():
        if name.startswith(binary_name):
            matched = name
            break

    if not matched:
        return STATUS_NONE

    # اقرأ النسخة المحلية
    local_ver = _read_local_version_for_binary(binary_name)
    if not local_ver:
        # احتياطي: من اسم البناري
        local_v, local_r = _parse_version_and_revision(matched)
        local_ver = local_v
        if local_r is not None:
            local_ver += "-r%d" % local_r

    if not local_ver:
        return STATUS_INSTALLED

    # قارن
    cmp_result = _compare_versions(local_ver, ipk_version)
    if cmp_result == "same":
        return STATUS_INSTALLED
    if cmp_result == "update":
        return STATUS_UPDATE
    if cmp_result == "local_newer":
        return STATUS_INSTALLED

    return STATUS_NONE


# ═══════════════════════════════════════════════════════════════════
#  تثبيت IPK
# ═══════════════════════════════════════════════════════════════════
def install_ipk(ipk_url, ipk_name=None, on_line=None, timeout=240):
    """
    ينزّل ويُثبّت ملف .ipk.

    Args:
        ipk_url : رابط التنزيل
        ipk_name: اسم الملف (اختياري — يُستخرج من URL)
        on_line : callback(line)
        timeout : المهلة

    Returns:
        dict: {
            "ok": bool,
            "error": str,
            "output": str,
            "package_name": str,
        }
    """
    result = {
        "ok": False,
        "error": "",
        "output": "",
        "package_name": "",
    }

    if not ipk_url:
        result["error"] = "No URL"
        return result

    # استخرج اسم الملف
    if not ipk_name:
        ipk_name = ipk_url.rstrip("/").split("/")[-1]
        if not ipk_name.lower().endswith(".ipk"):
            ipk_name += ".ipk"

    # مسار مؤقت
    tmp_dir = "/tmp/.rm_install"
    try:
        if not os.path.isdir(tmp_dir):
            os.makedirs(tmp_dir)
    except Exception:
        tmp_dir = "/tmp"

    ipk_path = os.path.join(tmp_dir, ipk_name)

    # ─── ① التنزيل ───
    if on_line:
        try:
            on_line("=== Download IPK ===")
            on_line("URL: %s" % ipk_url)
            on_line("Dest: %s" % ipk_path)
            on_line("")
        except Exception:
            pass

    def _progress(current, total):
        if on_line:
            try:
                if total > 0:
                    pct = int((current * 100) / total)
                    on_line("Downloading... %d%% (%d/%d KB)"
                            % (pct, current // 1024, total // 1024))
                else:
                    on_line("Downloading... %d KB" % (current // 1024))
            except Exception:
                pass

    # احذف ملفاً قديماً
    try:
        if os.path.exists(ipk_path):
            os.remove(ipk_path)
    except Exception:
        pass

    ok, msg = _download_file(ipk_url, ipk_path,
                             timeout=60.0, on_progress=_progress)
    if not ok:
        result["error"] = "Download failed: %s" % msg
        return result

    if on_line:
        try:
            on_line("")
            on_line("Download OK: %s" % msg)
            on_line("")
        except Exception:
            pass

    # ─── ② التثبيت ───
    if on_line:
        try:
            on_line("=== Installing via opkg ===")
        except Exception:
            pass

    install_cmd = ("opkg install --force-reinstall --force-overwrite %s"
                   " 2>&1" % ipk_path)

    rc, output = _run_shell_stream(install_cmd, timeout=timeout,
                                   on_line=on_line)

    result["output"] = output

    if rc != 0:
        result["error"] = "opkg install failed (rc=%d)" % rc
        return result

    # ─── ③ احصل على اسم الحزمة ───
    pkg_name = get_package_name_for_ipk(ipk_path)
    if pkg_name:
        result["package_name"] = pkg_name
        if on_line:
            try:
                on_line("Package: %s" % pkg_name)
            except Exception:
                pass

    # ─── ④ احذف الملف المؤقت ───
    try:
        os.remove(ipk_path)
    except Exception:
        pass

    result["ok"] = True
    return result


def _run_shell_stream(cmd, timeout=240, on_line=None):
    """ينفّذ أمر shell ويقرأ المخرجات سطراً بسطر."""
    p = None
    output_lines = []

    try:
        p = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            close_fds=True)

        def _killer():
            try:
                if p.poll() is None:
                    p.kill()
            except Exception:
                pass

        killer = threading.Timer(timeout, _killer)
        killer.setDaemon(True)
        killer.start()

        try:
            while True:
                line = p.stdout.readline()
                if not line:
                    break
                if isinstance(line, bytes):
                    line = line.decode("utf-8", "ignore")
                line = line.rstrip("\r\n")
                if line:
                    output_lines.append(line)
                    if on_line:
                        try:
                            on_line(line)
                        except Exception:
                            pass
        except Exception as e:
            logger.log("EmuInstaller", "read error: %s" % e)

        try:
            p.wait()
        except Exception:
            pass

        try:
            killer.cancel()
        except Exception:
            pass

        rc = p.returncode if p.returncode is not None else -1
        return rc, "\n".join(output_lines)

    except Exception as e:
        if p:
            try:
                p.kill()
            except Exception:
                pass
        return -1, "Exception: %s" % e


def uninstall_ipk(ipk_info, on_line=None, timeout=120):
    """
    يُزيل حزمة IPK مُثبَّتة عبر opkg.

    Args:
        ipk_info : dict من parse_ipk_filename()
        on_line  : callback
        timeout  : المهلة

    Returns:
        dict: {
            "ok": bool,
            "error": str,
            "output": str,
        }
    """
    result = {
        "ok": False,
        "error": "",
        "output": "",
    }

    if not ipk_info:
        result["error"] = "No ipk info"
        return result

    binary_name = ipk_info.get("binary_name", "").lower()
    if not binary_name:
        result["error"] = "No binary name"
        return result

    # احصل على قائمة الحزم المُثبَّتة
    rc, output = _run_shell_stream(
        "opkg list-installed 2>/dev/null", timeout=30)
    if rc != 0:
        result["error"] = "Cannot list installed packages"
        result["output"] = output
        return result

    # ابحث عن الحزم المطابقة
    matched_packages = []
    for line in output.split("\n"):
        line = line.strip()
        if not line:
            continue
        # opkg format: "package-name - version"
        parts = line.split(" - ", 1)
        if not parts:
            continue
        pkg_name = parts[0].strip()
        pkg_low = pkg_name.lower()

        # هل يبدأ أو يحتوي على اسم البناري؟
        if binary_name in pkg_low and "softcam" in pkg_low:
            matched_packages.append(pkg_name)
        elif pkg_low.endswith("-" + binary_name):
            matched_packages.append(pkg_name)

    if not matched_packages:
        result["error"] = "No matching package found"
        return result

    if on_line:
        try:
            on_line("=== Uninstall via opkg ===")
            for pkg in matched_packages:
                on_line("Package: %s" % pkg)
            on_line("")
        except Exception:
            pass

    # احذف كل حزمة
    all_output = []
    success_count = 0

    for pkg in matched_packages:
        cmd = ("opkg remove --force-depends %s 2>&1" % pkg)
        rc, output = _run_shell_stream(cmd, timeout=timeout,
                                        on_line=on_line)
        all_output.append(output)
        if rc == 0:
            success_count += 1

    result["output"] = "\n".join(all_output)

    if success_count == 0:
        result["error"] = "All removals failed"
        return result

    result["ok"] = True
    return result


# ═══════════════════════════════════════════════════════════════════
#  إعادة تشغيل Enigma2
# ═══════════════════════════════════════════════════════════════════
def _schedule_restart_script(delay_seconds=2):
    """سكريبت خلفي: sleep N ; init 4 ; sleep 3 ; init 3"""
    script = "/tmp/.rm_restart_enigma.sh"

    content = (
        "#!/bin/sh\n"
        "sleep %d\n"
        "init 4\n"
        "sleep 3\n"
        "init 3\n"
    ) % delay_seconds

    try:
        with open(script, "w") as f:
            f.write(content)
        os.chmod(script, 0o755)

        cmd = "nohup setsid /bin/sh %s >/dev/null 2>&1 &" % script

        subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            close_fds=True)

        logger.log("EmuInstaller",
                   "Restart script scheduled (delay=%ds)"
                   % delay_seconds)
        return True, "scheduled"

    except Exception as e:
        logger.log("EmuInstaller",
                   "Cannot schedule restart script: %s" % e)
        return False, str(e)


def restart_enigma(delay_seconds=2):
    """يُعيد تشغيل Enigma2."""
    ok, msg = _schedule_restart_script(delay_seconds)
    if ok:
        return True, "scheduled"

    try:
        subprocess.Popen(
            "nohup killall -9 enigma2 >/dev/null 2>&1 &",
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True)
        return True, "killall"
    except Exception:
        pass

    try:
        from enigma import quitMainloop
        quitMainloop(3)
        return True, "quitMainloop"
    except Exception:
        pass

    return False, "all failed"


# ═══════════════════════════════════════════════════════════════════
#  Public API
# ═══════════════════════════════════════════════════════════════════
def get_installed_emulator():
    """يكتشف المحاكي المُثبَّت حالياً (id) — للتوافق."""
    installed = get_installed_binaries()
    if not installed:
        return ""

    # نُعيد أول اسم بناري
    return sorted(installed.keys())[0]


def get_installed_version():
    """يقرأ نسخة المحاكي المُثبَّت — للتوافق."""
    for family in ("ncam", "oscam"):
        ver = _read_local_version_for_binary(family)
        if ver:
            return ver
    return ""


def get_installed_family():
    """يكتشف العائلة."""
    if os.path.exists("/tmp/.ncam/ncam.version"):
        return "ncam"
    if os.path.exists("/tmp/.oscam/oscam.version"):
        return "oscam"

    try:
        entries = os.listdir("/usr/bin")
        has_oscam = any(e.lower().startswith("oscam") for e in entries)
        has_ncam  = any(e.lower().startswith("ncam")  for e in entries)
        if has_oscam:
            return "oscam"
        if has_ncam:
            return "ncam"
    except Exception:
        pass

    return ""


def debug_status():
    """دالة تشخيص."""
    installed = get_installed_binaries()
    info = {
        "installed_binaries": dict(installed),
        "local_versions": {},
        "developers": get_all_developers(),
    }
    for b in installed.keys():
        info["local_versions"][b] = _read_local_version_for_binary(b)
    return info