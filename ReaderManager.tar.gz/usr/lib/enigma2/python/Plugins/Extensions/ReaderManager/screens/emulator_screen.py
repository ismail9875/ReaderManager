# -*- coding: utf-8 -*-
"""
screens/emulator_screen.py — شاشة إدارة المحاكيات.

v5 (نهائي):
    - استيراد logger من ..utils (صحيح)
    - _get_script_hint / _get_binary_hint مضمّنة
    - تمرير cam_name + script_hint + binary_hint إلى APIs
    - منطق ذكي للزر الأزرق (restart vs switch)
    - حماية كاملة من الأخطاء
"""
from __future__ import absolute_import, print_function, unicode_literals

import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.MenuList import MenuList
from Tools.LoadPixmap import LoadPixmap
from enigma import eListboxPythonMultiContent, gFont
from enigma import RT_HALIGN_LEFT, RT_VALIGN_CENTER

from ..utils import logger
from ..utils.emu_manager import EmulatorManager
from ..utils.skin_loader import get_screen_skin


class EmulatorManagerScreen(Screen):
    screen_name = "EmulatorManager"


    IMAGES_SUBDIR = "images"
    FAMILY_IMAGES = {
        "oscam": "oscam_emu.png",
        "ncam":  "ncam_emu.png",
    }

    ROW_HEIGHT = 58
    PICON_X    = 12
    PICON_Y    = 7
    PICON_W    = 140
    PICON_H    = 44

    COL_FAMILY_X  = 160
    COL_FAMILY_W  = 260
    COL_VERSION_X = 440
    COL_VERSION_W = 380
    COL_STATE_X   = 830
    COL_STATE_W   = 350

    FONT_SIZE = 30
    SYNC_INTERVAL = 3.0

    def __init__(self, session, on_change_callback=None):
        # ⭐ اسنِ السكين قبل Screen.__init__
        skin_content = get_screen_skin(self.screen_name)
        if skin_content:
            self.skin = skin_content

        Screen.__init__(self, session)
        self.session = session
        self.on_change_callback = on_change_callback

        self["status"]      = Label("")
        self["key_red"]     = Button("Close")
        self["key_green"]   = Button("Start/Stop")
        self["key_yellow"]  = Button("Refresh")
        self["key_blue"]    = Button("Restart/Switch")

        # MenuList مع eListboxPythonMultiContent لدعم الصور
        self["list_emu"] = MenuList([], True, eListboxPythonMultiContent)
        self["list_emu"].l.setFont(0, gFont("Regular", self.FONT_SIZE))
        self["list_emu"].l.setItemHeight(self.ROW_HEIGHT)

        self.emulators = []
        self.current_index = 0
        self._syncing = False
        self._sync_timer = None
        self._pending_timers = []
        self._busy = False

        # cache الصور
        self._pixmap_cache = {}

        # مسار مجلد الصور: <plugin_root>/images
        self._images_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            self.IMAGES_SUBDIR)

        self.manager = EmulatorManager()

        try:
            self["list_emu"].onSelectionChanged.append(
                self._on_selection_changed)
        except Exception:
            pass

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions",
             "DirectionActions", "MenuActions"],
            {
                "ok":     self.toggle_selected,
                "cancel": self.close,
                "red":    self.close,
                "green":  self.toggle_selected,
                "yellow": self.refresh,
                "blue":   self.restart_selected,
                "up":     self.move_up,
                "down":   self.move_down,
            }, -1)

        self.onLayoutFinish.append(self._on_start)

    # ------------------------------------------------------------------
    def _on_start(self):
        self._preload_pixmaps()
        self.load_emulators()
        self._start_periodic_sync()

    # ------------------------------------------------------------------
    def _preload_pixmaps(self):
        """يحمّل الصور من ./images/ مرة واحدة."""
        try:
            logger.log("EmuManagerScreen",
                       "Loading family images from: %s" % self._images_dir)

            if not os.path.isdir(self._images_dir):
                logger.log("EmuManagerScreen",
                           "Images dir not found: %s" % self._images_dir)
                return

            for key, filename in self.FAMILY_IMAGES.items():
                path = os.path.join(self._images_dir, filename)

                if not os.path.isfile(path):
                    logger.log("EmuManagerScreen",
                               "Image not found: %s" % path)
                    self._pixmap_cache[key] = None
                    continue

                try:
                    pix = LoadPixmap(path)
                    self._pixmap_cache[key] = pix
                    logger.log("EmuManagerScreen",
                               "Loaded pixmap: %s" % path)
                except Exception as e:
                    logger.log("EmuManagerScreen",
                               "LoadPixmap error for %s: %s" % (path, e))
                    self._pixmap_cache[key] = None
        except Exception as e:
            logger.log("EmuManagerScreen",
                       "_preload_pixmaps error: %s" % e)

    def _get_family_pixmap(self, family):
        """يُرجع ePixmap للعائلة أو None."""
        family = (family or "").lower().strip()
        if "oscam" in family:
            return self._pixmap_cache.get("oscam")
        if "ncam" in family:
            return self._pixmap_cache.get("ncam")
        return None

    # ------------------------------------------------------------------
    def _fit_pixmap(self, pix, box_w, box_h):
        """يحسب الأبعاد المناسبة للصورة داخل box مع الحفاظ على النسبة."""
        try:
            sz = pix.size()
            pw, ph = sz.width(), sz.height()
        except Exception:
            return 0, 0, box_w, box_h

        if pw <= 0 or ph <= 0:
            return 0, 0, box_w, box_h

        ratio_pix = float(pw) / float(ph)
        ratio_box = float(box_w) / float(box_h)

        if ratio_pix > ratio_box:
            w = box_w
            h = int(box_w / ratio_pix)
        else:
            h = box_h
            w = int(box_h * ratio_pix)

        x_off = (box_w - w) // 2
        y_off = (box_h - h) // 2

        return x_off, y_off, w, h

    # ------------------------------------------------------------------
    def _build_row(self, emu):
        """يبني صف قائمة: [معرّف, صورة, Family, Version, State]."""
        pix = self._get_family_pixmap(emu.family)

        family_text  = (emu.family or "-").upper()
        version_text = emu.version or "-"
        state_text   = "RUNNING" if emu.running else "STOPPED"

        row = [emu]

        if pix is not None:
            x_off, y_off, w, h = self._fit_pixmap(
                pix, self.PICON_W, self.PICON_H)
            row.append((
                eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST,
                self.PICON_X + x_off,
                self.PICON_Y + y_off,
                w, h,
                pix,
            ))

        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            self.COL_FAMILY_X, 0,
            self.COL_FAMILY_W, self.ROW_HEIGHT,
            0,
            RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            family_text,
        ))

        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            self.COL_VERSION_X, 0,
            self.COL_VERSION_W, self.ROW_HEIGHT,
            0,
            RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            version_text,
        ))

        row.append((
            eListboxPythonMultiContent.TYPE_TEXT,
            self.COL_STATE_X, 0,
            self.COL_STATE_W, self.ROW_HEIGHT,
            0,
            RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            state_text,
        ))

        return row

    # ------------------------------------------------------------------
    def _sync_states(self):
        """يعيد فحص حالة كل محاكي من النظام."""
        try:
            old_states = [bool(e.running) for e in self.emulators]

            fresh = None
            try:
                fresh = self.manager.refresh()
            except Exception as e:
                logger.log("EmuManagerScreen", "refresh error: %s" % e)

            if fresh:
                fresh_map = {}
                for e in fresh:
                    key = (e.name or "", e.family or "", e.binary_path or "")
                    fresh_map[key] = e

                for emu in self.emulators:
                    key = (emu.name or "", emu.family or "",
                           emu.binary_path or "")
                    if key in fresh_map:
                        emu.running = fresh_map[key].running
                        emu.version = fresh_map[key].version or emu.version
                    else:
                        try:
                            emu.running = self.manager.is_running(emu)
                        except Exception:
                            pass
            else:
                for emu in self.emulators:
                    try:
                        emu.running = self.manager.is_running(emu)
                    except Exception:
                        pass

            new_states = [bool(e.running) for e in self.emulators]
            return old_states != new_states

        except Exception as e:
            logger.log("EmuManagerScreen", "_sync_states error: %s" % e)
            return False

    # ------------------------------------------------------------------
    def load_emulators(self):
        """يحمّل قائمة المحاكيات."""
        self["status"].setText("Scanning /usr/bin ...")
        try:
            self.emulators = self.manager.refresh()
        except Exception as e:
            logger.log("EmuManagerScreen", "discover error: %s" % e)
            self.emulators = []

        self.refresh_lists()

        if not self.emulators:
            self["status"].setText("No emulators found in /usr/bin")
        else:
            on, total = self.manager.get_running_count()
            self["status"].setText("%d/%d running" % (on, total))

    # ------------------------------------------------------------------
    def refresh_lists(self):
        """يبني الصفوف ويرسلها للـ MenuList."""
        rows = []
        for emu in self.emulators:
            rows.append(self._build_row(emu))

        self._syncing = True
        try:
            self["list_emu"].setList(rows)
        finally:
            self._syncing = False

        if self.emulators:
            idx = min(self.current_index, len(self.emulators) - 1)
            if idx < 0:
                idx = 0
            self.current_index = idx
            self._focus_current()

        on, total = self.manager.get_running_count()
        self["status"].setText("%d/%d running" % (on, total))

    # ------------------------------------------------------------------
    def _on_selection_changed(self):
        if self._syncing:
            return
        try:
            idx = self["list_emu"].l.getCurrentSelectionIndex()
        except Exception:
            try:
                idx = self["list_emu"].getSelectedIndex()
            except Exception:
                idx = None
        if idx is not None and idx >= 0 and idx != self.current_index:
            self.current_index = idx

    def move_up(self):
        if not self.emulators or self._syncing:
            return
        if self.current_index <= 0:
            self.current_index = len(self.emulators) - 1
        else:
            self.current_index -= 1
        self._focus_current()

    def move_down(self):
        if not self.emulators or self._syncing:
            return
        if self.current_index >= len(self.emulators) - 1:
            self.current_index = 0
        else:
            self.current_index += 1
        self._focus_current()

    def _focus_current(self):
        try:
            self["list_emu"].moveToIndex(self.current_index)
        except Exception:
            try:
                self["list_emu"].setCurrentIndex(self.current_index)
            except Exception:
                pass
        try:
            if len(self["list_emu"].onSelectionChanged) > 0:
                self["list_emu"].onSelectionChanged[0]()
        except Exception:
            pass

    # ------------------------------------------------------------------
    def _start_periodic_sync(self):
        """يبدأ مؤقت التحديث الدوري."""
        if self._sync_timer is not None:
            try:
                self._sync_timer.cancel()
            except Exception:
                pass
            self._sync_timer = None

        try:
            from twisted.internet import reactor
            self._sync_timer = reactor.callLater(
                self.SYNC_INTERVAL, self._periodic_sync)
        except Exception as e:
            logger.log("EmuManagerScreen", "timer start error: %s" % e)

    def _periodic_sync(self):
        self._sync_timer = None

        try:
            if not self.shown:
                return
        except Exception:
            pass

        try:
            if not self._busy:
                changed = self._sync_states()
                if changed:
                    self.refresh_lists()
                    logger.log("EmuManagerScreen",
                               "periodic sync: states changed, UI updated")
        except Exception as e:
            logger.log("EmuManagerScreen", "_periodic_sync error: %s" % e)

        self._start_periodic_sync()

    # ------------------------------------------------------------------
    def _schedule(self, delay, func, *args):
        """جدولة عملية مؤقتة بأمان."""
        try:
            from twisted.internet import reactor
            t = reactor.callLater(delay, func, *args)
            self._pending_timers.append(t)
            return t
        except Exception as e:
            logger.log("EmuManagerScreen", "_schedule error: %s" % e)
            try:
                func(*args)
            except Exception:
                pass
            return None

    # ==================================================================
    #  Green Button — Start/Stop
    # ==================================================================
    def toggle_selected(self):
        """Start أو Stop المحاكي المحدد."""
        if not self.emulators or self._busy:
            return

        emu = self.emulators[self.current_index]
        was_running = emu.running

        self._busy = True
        self["status"].setText(
            "%s %s..." % ("Stopping" if was_running else "Starting",
                          emu.name))

        logger.log("EmuManagerScreen",
                   "toggle_selected: name=%s was_running=%s"
                   % (emu.name, was_running))

        try:
            ok, msg = self.manager.toggle(emu)
        except Exception as e:
            logger.log("EmuManagerScreen", "toggle exception: %s" % e)
            ok, msg = False, "Exception: %s" % e

        if not ok:
            self._busy = False
            self.session.open(MessageBox, msg,
                              MessageBox.TYPE_ERROR, timeout=6)
            self._sync_states()
            self.refresh_lists()
            return

        self._schedule(0.8, self._after_toggle, msg)

    def _after_toggle(self, msg):
        try:
            self._busy = False
            self._sync_states()
            self.refresh_lists()
            self["status"].setText(msg)
            if self.on_change_callback:
                try:
                    self.on_change_callback()
                except Exception:
                    pass
        except Exception as e:
            logger.log("EmuManagerScreen", "_after_toggle error: %s" % e)

    # ==================================================================
    #  ⭐ Script/Binary Hints
    # ==================================================================
    def _get_script_hint(self, emu):
        """
        يُعيد مسار init script الصحيح للمحاكي.
        يحاول:
          1. emu.init_script (من EmuManager)
          2. emu.script_path
          3. البحث اليدوي في /etc/init.d/
        """
        script = (getattr(emu, "init_script", None)
                  or getattr(emu, "script_path", None))

        if script and os.path.isfile(script) \
                and os.access(script, os.X_OK):
            return script

        name = (getattr(emu, "name", "") or "").strip()
        family = (getattr(emu, "family", "") or "").strip().lower()

        candidates = []
        if name:
            candidates.extend([
                "/etc/init.d/softcam.%s" % name,
                "/etc/init.d/softcam_%s" % name,
            ])
        if family:
            candidates.extend([
                "/etc/init.d/softcam.%s" % family,
                "/etc/init.d/softcam_%s" % family,
                "/etc/init.d/%s" % family,
            ])

        candidates.append("/etc/init.d/softcam")

        for c in candidates:
            if os.path.isfile(c) and os.access(c, os.X_OK):
                logger.log("EmuManagerScreen",
                           "_get_script_hint: %s → %s" % (name, c))
                return c

        logger.log("EmuManagerScreen",
                   "_get_script_hint: no script for %s" % name)
        return None

    def _get_binary_hint(self, emu):
        """يُعيد مسار الـ binary الصحيح."""
        binary = getattr(emu, "binary_path", None)

        if binary and os.path.isfile(binary):
            return binary

        name = (getattr(emu, "name", "") or "").strip()
        if name:
            candidate = "/usr/bin/%s" % name
            if os.path.isfile(candidate):
                return candidate

        return None

    # ==================================================================
    #  Blue Button — Restart / Switch
    # ==================================================================
    def restart_selected(self):
        """
        الزر الأزرق:
          - نفس المحاكي النشط → restart
          - محاكي مختلف       → stop النشط + start المحدد
        """
        if not self.emulators or self._busy:
            return

        selected = self.emulators[self.current_index]

        active = self._find_active_emulator()

        selected_name = (selected.name or "").lower()
        active_name   = (active.name or "").lower() if active else None

        logger.log("EmuManagerScreen",
                   "restart_selected: selected=%s active=%s"
                   % (selected_name or "?", active_name or "none"))

        if active is None:
            self._start_emulator(selected)
            return

        if active_name == selected_name:
            self._restart_emulator(selected)
            return

        self._switch_emulator(active, selected)

    # ------------------------------------------------------------------
    def _find_active_emulator(self):
        """يُعيد المحاكي النشط حالياً (running=True) أو None."""
        for emu in self.emulators:
            if emu.running:
                return emu

        try:
            for emu in self.emulators:
                try:
                    if self.manager.is_running(emu):
                        emu.running = True
                        return emu
                except Exception:
                    pass
        except Exception:
            pass

        return None

    # ------------------------------------------------------------------
    def _get_api_for(self, emu):
        """
        يُعيد (module, tag) لوحدة الـ API المناسبة:
            - oscam → oscamapi
            - ncam  → ncamapi
        أو (None, "unknown").
        """
        family = (getattr(emu, "family", "") or "").lower()
        name   = (getattr(emu, "name", "") or "").lower()
        combined = family + " " + name

        try:
            if "oscam" in combined:
                from ..utils import oscamapi
                return oscamapi, "oscam"
            if "ncam" in combined:
                from ..utils import ncamapi
                return ncamapi, "ncam"
        except Exception as e:
            logger.log("EmuManagerScreen",
                       "_get_api_for import error: %s" % e)

        return None, "unknown"

    # ------------------------------------------------------------------
    def _get_api_instance(self, emu):
        """
        يُعيد instance جاهز من الـ API (singleton) أو None.
        يحاول configure_auto() إذا لم يكن مهيأ.
        """
        api_module, tag = self._get_api_for(emu)
        if api_module is None:
            return None, "unknown"

        try:
            api = api_module.get_default()
        except Exception:
            api = None

        if api is None:
            try:
                api = api_module.configure_auto()
                logger.log("EmuManagerScreen",
                           "Auto-configured %s API" % tag)
            except Exception as e:
                logger.log("EmuManagerScreen",
                           "auto-config %s failed: %s" % (tag, e))
                return None, tag

        return api, tag

    # ==================================================================
    #  Restart — نفس المحاكي
    # ==================================================================
    def _restart_emulator(self, emu):
        """نفس المحاكي — restart مباشر عبر API."""
        self._busy = True
        self["status"].setText("Restarting %s..." % emu.name)

        api, tag = self._get_api_instance(emu)
        script_hint = self._get_script_hint(emu)
        binary_hint = self._get_binary_hint(emu)

        logger.log("EmuManagerScreen",
                   "_restart_emulator: %s cam_name=%s "
                   "script_hint=%s binary_hint=%s"
                   % (tag, emu.name, script_hint or "-",
                      binary_hint or "-"))

        if api is None:
            # fallback: manager.restart
            logger.log("EmuManagerScreen",
                       "_restart_emulator: no API — using manager.restart")
            try:
                ok, msg = self.manager.restart(emu)
            except Exception as e:
                ok, msg = False, "Exception: %s" % e
            self._handle_restart_result(ok, msg, emu)
            return

        logger.log("EmuManagerScreen",
                   "_restart_emulator: calling %sApi.restart()" % tag)

        try:
            # ⭐ مرّر cam_name أيضاً
            try:
                ok, msg = api.restart(
                    force=True,
                    script_hint=script_hint,
                    binary_hint=binary_hint,
                    cam_name=emu.name)
            except TypeError:
                # API قديم بدون cam_name
                logger.log("EmuManagerScreen",
                           "%sApi.restart doesn't accept cam_name"
                           % tag)
                try:
                    ok, msg = api.restart(
                        force=True,
                        script_hint=script_hint,
                        binary_hint=binary_hint)
                except TypeError:
                    ok, msg = api.restart(force=True)
        except Exception as e:
            logger.log("EmuManagerScreen",
                       "%sApi.restart exception: %s" % (tag, e))
            ok, msg = False, "Exception: %s" % e

        self._handle_restart_result(ok, msg, emu)

    def _handle_restart_result(self, ok, msg, emu):
        """يعالج نتيجة restart ويعرضها."""
        logger.log("EmuManagerScreen",
                   "_handle_restart_result: ok=%s msg=%s" % (ok, msg))

        if not ok:
            self._busy = False
            self.session.open(MessageBox, msg,
                              MessageBox.TYPE_ERROR, timeout=8)
            self._sync_states()
            self.refresh_lists()
            return

        self._schedule(1.5, self._after_restart, msg)

    def _after_restart(self, msg):
        try:
            self._busy = False
            self._sync_states()
            self.refresh_lists()
            self["status"].setText(msg)
            if self.on_change_callback:
                try:
                    self.on_change_callback()
                except Exception:
                    pass
        except Exception as e:
            logger.log("EmuManagerScreen", "_after_restart error: %s" % e)

    # ==================================================================
    #  Switch — من محاكي إلى آخر
    # ==================================================================
    def _switch_emulator(self, active, selected):
        """محاكي مختلف — stop النشط ثم start المحدد عبر API."""
        self._busy = True
        self["status"].setText(
            "Switching %s → %s..." % (active.name, selected.name))

        logger.log("EmuManagerScreen",
                   "_switch_emulator: %s → %s"
                   % (active.name, selected.name))

        stop_ok, stop_msg = self._stop_via_api(active)

        self._schedule(0.8, self._do_start_selected,
                       selected, active, stop_ok, stop_msg)

    def _stop_via_api(self, emu):
        """يوقف emu عبر API أو manager كـ fallback."""
        api, tag = self._get_api_instance(emu)
        script_hint = self._get_script_hint(emu)

        if api is not None:
            try:
                logger.log("EmuManagerScreen",
                           "calling %sApi.stop(cam=%s, script=%s)"
                           % (tag, emu.name, script_hint or "-"))
                # ⭐ مرّر cam_name
                try:
                    return api.stop(
                        script_hint=script_hint,
                        cam_name=emu.name)
                except TypeError:
                    try:
                        return api.stop(script_hint=script_hint)
                    except TypeError:
                        return api.stop()
            except Exception as e:
                logger.log("EmuManagerScreen",
                           "%sApi.stop exception: %s" % (tag, e))

        # fallback: manager.stop
        try:
            logger.log("EmuManagerScreen",
                       "fallback manager.stop(%s)" % emu.name)
            return self.manager.stop(emu)
        except Exception as e:
            logger.log("EmuManagerScreen",
                       "manager.stop exception: %s" % e)
            return False, "stop exception: %s" % e

    def _do_start_selected(self, selected, active,
                           stop_ok, stop_msg):
        """يشغّل المحاكي المحدد بعد إيقاف النشط."""
        logger.log("EmuManagerScreen",
                   "_do_start_selected: starting %s" % selected.name)

        start_ok, start_msg = self._start_via_api(selected)

        logger.log("EmuManagerScreen",
                   "start %s: ok=%s msg=%s"
                   % (selected.name, start_ok, start_msg))

        self._schedule(1.2, self._after_switch,
                       selected, active,
                       stop_ok, stop_msg,
                       start_ok, start_msg)

    def _start_via_api(self, emu):
        """يشغّل emu عبر API أو manager كـ fallback."""
        api, tag = self._get_api_instance(emu)
        script_hint = self._get_script_hint(emu)
        binary_hint = self._get_binary_hint(emu)

        logger.log("EmuManagerScreen",
                   "_start_via_api: %s cam_name=%s script_hint=%s "
                   "binary_hint=%s"
                   % (tag, emu.name, script_hint or "-",
                      binary_hint or "-"))

        if api is not None:
            try:
                # ⭐ مرّر cam_name
                try:
                    return api.start(
                        script_hint=script_hint,
                        binary_hint=binary_hint,
                        cam_name=emu.name)
                except TypeError:
                    try:
                        return api.start(
                            script_hint=script_hint,
                            binary_hint=binary_hint)
                    except TypeError:
                        return api.start()
            except Exception as e:
                logger.log("EmuManagerScreen",
                           "%sApi.start exception: %s" % (tag, e))

        # fallback: manager.start
        try:
            logger.log("EmuManagerScreen",
                       "fallback manager.start(%s)" % emu.name)
            return self.manager.start(emu)
        except Exception as e:
            logger.log("EmuManagerScreen",
                       "manager.start exception: %s" % e)
            return False, "start exception: %s" % e

    def _after_switch(self, selected, active,
                      stop_ok, stop_msg,
                      start_ok, start_msg):
        """يُحدّث الحالة ويعرض النتيجة."""
        self._busy = False

        try:
            self._sync_states()
            self.refresh_lists()
        except Exception as e:
            logger.log("EmuManagerScreen",
                       "_after_switch refresh error: %s" % e)

        if start_ok:
            msg = "Switched: %s → %s" % (active.name, selected.name)
            self["status"].setText(msg)
            logger.log("EmuManagerScreen", msg)

            if not stop_ok:
                logger.log("EmuManagerScreen",
                           "Note: stop of %s reported failure: %s"
                           % (active.name, stop_msg))
        else:
            msg = ("Failed to switch to %s\n"
                   "Stop %s: %s\nStart %s: %s"
                   % (selected.name,
                      active.name, stop_msg,
                      selected.name, start_msg))
            self["status"].setText("Switch failed")
            logger.log("EmuManagerScreen", msg)
            self.session.open(MessageBox, msg,
                              MessageBox.TYPE_ERROR, timeout=8)

        if self.on_change_callback:
            try:
                self.on_change_callback()
            except Exception:
                pass

    # ==================================================================
    #  Start — لا يوجد نشط
    # ==================================================================
    def _start_emulator(self, emu):
        """لا يوجد نشط — فقط شغّل المحدد."""
        self._busy = True
        self["status"].setText("Starting %s..." % emu.name)

        logger.log("EmuManagerScreen",
                   "_start_emulator: %s" % emu.name)

        ok, msg = self._start_via_api(emu)

        logger.log("EmuManagerScreen",
                   "_start_emulator: ok=%s msg=%s" % (ok, msg))

        if not ok:
            self._busy = False
            self.session.open(MessageBox, msg,
                              MessageBox.TYPE_ERROR, timeout=6)
            self._sync_states()
            self.refresh_lists()
            return

        self._schedule(1.2, self._after_restart, msg)

    # ==================================================================
    #  Refresh
    # ==================================================================
    def refresh(self):
        """Refresh يدوي."""
        self.load_emulators()
        self._start_periodic_sync()

    # ==================================================================
    #  Close
    # ==================================================================
    def close(self):
        """إغلاق الشاشة + تنظيف المؤقتات."""
        if self._sync_timer is not None:
            try:
                self._sync_timer.cancel()
            except Exception:
                pass
            self._sync_timer = None

        for t in list(self._pending_timers):
            try:
                if t.active():
                    t.cancel()
            except Exception:
                pass
        self._pending_timers = []

        Screen.close(self)