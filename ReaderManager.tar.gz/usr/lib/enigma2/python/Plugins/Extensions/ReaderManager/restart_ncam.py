# -*- coding: utf-8 -*-
"""
restart_ncam.py — إعادة تشغيل NCam فقط.
متوافق مع Python 2.7 و Python 3.x — DreamOS / OpenSource

الاستخدام من Python:
    from . import restart_ncam
    ok, msg = restart_ncam.restart()

الاستخدام من SSH:
    python /path/to/restart_ncam.py
"""
from __future__ import absolute_import, print_function

import os
import subprocess
import time
import threading

# ─── توافق Py2/Py3 ───
try:
    _TimeoutExpired = subprocess.TimeoutExpired
except AttributeError:
    class _TimeoutExpired(Exception):
        pass


# ═══════════════════════════════════════════════════════════════════
#  إعدادات NCam
# ═══════════════════════════════════════════════════════════════════
CAM = "ncam"

CAM_SCRIPTS = [
    "/etc/init.d/softcam.ncam-*",
    "/etc/init.d/softcam.ncam",
    "/etc/init.d/softcam.NCam-*",
    "/etc/init.d/softcam.NCam",
    "/etc/init.d/softcam_ncam*",
    "/etc/init.d/ncam",
    "/etc/init.d/softcam",
    "/usr/script/ncam.sh",
    "/usr/camscript/Ncam_Oscam.sh",
]

CAM_PROCESSES = [
    "ncam", "ncam-svn", "ncam-relay", "ncam-master",
    "NCam", "ncam_emu", "ncam-streamrelay",
]

NCAM_CONFIGS = [
    "/etc/tuxbox/config/ncam.server",
    "/etc/tuxbox/config/ncam/ncam.server",
    "/usr/keys/ncam.server",
]

VERSION_FILES = [
    "/tmp/.ncam/ncam.version",
    "/tmp/ncam.version",
    "/var/tmp/ncam.version",
]

TAG = "[ncam]"
CACHE_KEY = "ncam"


# ═══════════════════════════════════════════════════════════════════
#  Logger
# ═══════════════════════════════════════════════════════════════════
try:
    from . import logger
    _HAS_LOGGER = True
except Exception:
    _HAS_LOGGER = False


def _log(msg):
    if _HAS_LOGGER:
        try:
            logger.log("RestartNCam", msg)
            return
        except Exception:
            pass
    try:
        print("%s %s" % (TAG, msg))
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════
#  Helpers — متوافق مع Py2 و Py3
# ═══════════════════════════════════════════════════════════════════
def _run(cmd, timeout=15):
    """ينفّذ أمر shell ويُعيد (rc, stdout, stderr)."""
    p = None
    try:
        p = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            # Py3.3+: communicate يدعم timeout
            out, err = p.communicate(timeout=timeout)
        except TypeError:
            # Py2: لا يدعم timeout
            result = [b"", b""]

            def _target():
                try:
                    result[0], result[1] = p.communicate()
                except Exception:
                    pass

            t = threading.Thread(target=_target)
            t.setDaemon(True)
            t.start()
            t.join(timeout)
            if t.isAlive():
                try:
                    p.kill()
                except Exception:
                    pass
                return -1, "", "timeout"
            out, err = result

        if isinstance(out, bytes):
            out = out.decode("utf-8", "ignore")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "ignore")
        return p.returncode, out, err
    except _TimeoutExpired:
        if p:
            try:
                p.kill()
            except Exception:
                pass
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)


# ═══════════════════════════════════════════════════════════════════
#  PID
# ═══════════════════════════════════════════════════════════════════
def _get_pid_proc():
    try:
        for pid_dir in os.listdir("/proc"):
            if not pid_dir.isdigit():
                continue
            try:
                with open("/proc/%s/comm" % pid_dir, "r") as f:
                    comm = f.read().strip()

                cmdline = ""
                try:
                    with open("/proc/%s/cmdline" % pid_dir, "rb") as f:
                        cmdline = f.read().decode("utf-8", "ignore") \
                            .replace("\0", " ").strip()
                except Exception:
                    pass

                for name in CAM_PROCESSES:
                    if (name.lower() in comm.lower()
                            or name.lower() in cmdline.lower()):
                        return int(pid_dir), cmdline or comm
            except (IOError, OSError):
                continue
    except Exception:
        pass
    return None, ""


def _get_pid_pidof():
    for name in CAM_PROCESSES:
        rc, out, _ = _run("pidof %s 2>/dev/null" % name, timeout=5)
        if rc == 0 and out.strip():
            try:
                pid = int(out.strip().split()[0])
                try:
                    with open("/proc/%d/cmdline" % pid, "rb") as f:
                        cmdline = f.read().decode("utf-8", "ignore") \
                            .replace("\0", " ").strip()
                except Exception:
                    cmdline = name
                return pid, cmdline
            except Exception:
                pass
    return None, ""


def get_pid():
    pid, _ = _get_pid_proc()
    if pid:
        return pid
    pid, _ = _get_pid_pidof()
    return pid


def is_running():
    pid, cmdline = _get_pid_proc()
    if pid:
        return True, "%d (%s)" % (pid, cmdline)
    pid, cmdline = _get_pid_pidof()
    if pid:
        return True, "%d (%s)" % (pid, cmdline)
    return False, ""


def is_active():
    if is_running()[0]:
        return True
    for path in VERSION_FILES:
        if os.path.exists(path):
            return True
    return False


# ═══════════════════════════════════════════════════════════════════
#  البحث عن السكريبتات
# ═══════════════════════════════════════════════════════════════════
def _expand_scripts():
    import glob as globmod

    found = []
    seen = set()

    for pattern in CAM_SCRIPTS:
        if "*" in pattern or "?" in pattern:
            try:
                matches = sorted(globmod.glob(pattern), reverse=True)
            except Exception:
                matches = []
            for path in matches:
                if path in seen:
                    continue
                seen.add(path)
                if os.path.isfile(path) and os.access(path, os.X_OK):
                    found.append(path)
        else:
            if pattern in seen:
                continue
            seen.add(pattern)
            if os.path.isfile(pattern) and os.access(pattern, os.X_OK):
                found.append(pattern)

    return found


def find_script():
    scripts = _expand_scripts()
    return scripts[0] if scripts else None


def find_all_scripts():
    return _expand_scripts()


# ═══════════════════════════════════════════════════════════════════
#  cache
# ═══════════════════════════════════════════════════════════════════
def _cache_path():
    try:
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
        cache_dir = os.path.join(plugin_dir, "cache")
        if not os.path.isdir(cache_dir):
            os.makedirs(cache_dir)
        return os.path.join(cache_dir, "restart_methods.json")
    except Exception:
        return "/tmp/.cam_restart_method.json"


def _load_cache():
    try:
        import json
        path = _cache_path()
        if not os.path.exists(path):
            return {}
        with open(path, "r") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_cache(cache):
    try:
        import json
        path = _cache_path()
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(cache, f, indent=2, sort_keys=True)
        os.rename(tmp, path)
        return True
    except Exception as e:
        _log("Cannot save cache: %s" % e)
        return False


def get_recorded_method():
    cache = _load_cache()
    entry = cache.get(CACHE_KEY, {})
    return entry.get("method") if entry else None


def set_recorded_method(method_id, script=None):
    cache = _load_cache()
    cache[CACHE_KEY] = {
        "method": method_id,
        "script": script,
        "recorded_at": time.time(),
    }
    _save_cache(cache)


def clear_recorded_method():
    cache = _load_cache()
    if CACHE_KEY in cache:
        del cache[CACHE_KEY]
        _save_cache(cache)
        _log("Cleared recorded method")


# ═══════════════════════════════════════════════════════════════════
#  طرق إعادة التشغيل
# ═══════════════════════════════════════════════════════════════════
def _try_restart(script):
    rc, out, err = _run("%s restart" % script, timeout=20)
    if rc == 0:
        return True, "restart rc=0"
    return False, "restart rc=%d" % rc


def _try_stop_start(script, wait=1):
    _run("%s stop" % script, timeout=15)
    time.sleep(wait)
    rc, out, err = _run("%s start" % script, timeout=15)
    if rc == 0:
        return True, "stop+start rc=0"
    return False, "stop+start rc=%d" % rc


def _try_killall_start(script, wait=1):
    for proc in CAM_PROCESSES:
        _run("killall -9 %s 2>/dev/null" % proc, timeout=5)
    time.sleep(wait)
    rc, out, err = _run("%s start" % script, timeout=15)
    if rc == 0:
        return True, "killall+start rc=0"
    return False, "killall+start rc=%d" % rc


# ═══════════════════════════════════════════════════════════════════
#  التحقق من تغيّر PID
# ═══════════════════════════════════════════════════════════════════
def _verify(old_pid, wait=2):
    time.sleep(wait)

    running, pid_info = is_running()
    if not running:
        return False, None, "no process after restart"

    try:
        new_pid = int(str(pid_info).split()[0])
    except Exception:
        new_pid = None

    if old_pid is not None and new_pid == old_pid:
        return False, new_pid, "PID unchanged (%s)" % old_pid

    return True, new_pid, "PID %s -> %s" % (old_pid, new_pid)


# ═══════════════════════════════════════════════════════════════════
#  Public API
# ═══════════════════════════════════════════════════════════════════
def restart(wait_seconds=2, force=False):
    """
    يعيد تشغيل NCam.

    Returns:
        (ok: bool, msg: str)
    """
    _log("=" * 50)
    _log("Restarting NCAM ...")

    if not is_active():
        _log("NCam is not active — nothing to restart")
        return False, "NCam is not active"

    old_pid = get_pid()
    _log("PID before: %s" % (old_pid or "none"))

    scripts = find_all_scripts()
    if not scripts:
        _log("No control script found")
        return False, "No control script found for NCAM"

    _log("Available scripts:")
    for s in scripts:
        _log("  %s" % s)

    # ① الطريقة المسجّلة
    if not force:
        recorded = get_recorded_method()
        if recorded:
            parts = recorded.split(":", 1)
            rec_script = parts[0]
            rec_method = parts[1] if len(parts) > 1 else "restart"

            _log("Trying recorded: %s (%s)" % (rec_script, rec_method))

            if os.path.isfile(rec_script) \
                    and os.access(rec_script, os.X_OK):
                if rec_method == "restart":
                    ok, msg = _try_restart(rec_script)
                elif rec_method == "stop_start":
                    ok, msg = _try_stop_start(rec_script, wait_seconds)
                elif rec_method == "killall_start":
                    ok, msg = _try_killall_start(rec_script, wait_seconds)
                else:
                    ok, msg = False, "unknown method"

                if ok:
                    verified, new_pid, vmsg = _verify(
                        old_pid, wait_seconds)
                    if verified:
                        _log("OK Recorded worked: %s" % vmsg)
                        return True, "NCAM restarted via recorded (%s)" % vmsg
                    else:
                        _log("FAIL Recorded returned OK but %s" % vmsg)
                else:
                    _log("Recorded failed: %s" % msg)
            else:
                _log("Recorded script missing: %s" % rec_script)

            clear_recorded_method()
            old_pid = get_pid()

    # ② جرّب الكل
    _log("Trying all combinations...")

    tried = []

    for script in scripts:
        for method_name, method_fn, needs_wait in [
            ("restart",       _try_restart,       False),
            ("stop_start",    _try_stop_start,    True),
            ("killall_start", _try_killall_start, True),
        ]:
            _log("-> [%s] %s" % (method_name, script))

            pid_before = get_pid()

            try:
                if needs_wait:
                    ok, msg = method_fn(script, wait_seconds)
                else:
                    ok, msg = method_fn(script)
            except Exception as e:
                ok, msg = False, "exception: %s" % e

            tried.append((script, method_name, ok))

            if not ok:
                _log("  FAIL %s" % msg)
                continue

            verified, new_pid, vmsg = _verify(pid_before, wait_seconds)

            if verified:
                _log("  OK %s - %s" % (msg, vmsg))
                set_recorded_method(
                    "%s:%s" % (script, method_name),
                    script=script)
                return True, "NCAM restarted via %s on %s (%s)" % (
                    method_name, script, vmsg)
            else:
                _log("  FAIL %s but %s" % (msg, vmsg))

    summary = "; ".join(
        "%s:%s=%s" % (os.path.basename(s), m, "OK" if ok else "FAIL")
        for s, m, ok in tried
    )
    _log("All methods failed: %s" % summary)
    return False, "All restart methods failed for NCAM"


def restart_silent():
    try:
        return restart()
    except Exception:
        return False, "exception"


def get_status():
    running, pid = is_running()
    recorded = get_recorded_method() or "-"
    if running:
        return "NCAM: Running (PID %s) [method: %s]" % (pid, recorded)
    return "NCAM: Stopped [method: %s]" % recorded


# ═══════════════════════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════════════════════
def _main():
    import sys

    if len(sys.argv) > 1:
        if sys.argv[1] == "status":
            print(get_status())
            sys.exit(0)
        elif sys.argv[1] == "force":
            ok, msg = restart(force=True)
            print(msg)
            sys.exit(0 if ok else 2)
        elif sys.argv[1] == "reset":
            clear_recorded_method()
            print("Cache cleared")
            sys.exit(0)

    ok, msg = restart()
    print(msg)
    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    _main()