# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals

import os
import subprocess
import threading

# ─── توافق Py2/Py3 ───
try:
    from io import open
except ImportError:
    pass

try:
    _TimeoutExpired = subprocess.TimeoutExpired
except AttributeError:
    class _TimeoutExpired(Exception):
        pass

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Button import Button
from Components.Pixmap import Pixmap
from Components.ScrollLabel import ScrollLabel
from Components.config import (
    config, ConfigSubsection, ConfigYesNo, ConfigSelection,
    ConfigText, ConfigInteger, ConfigPassword, getConfigListEntry
)
from Components.ConfigList import ConfigListScreen
from Tools.LoadPixmap import LoadPixmap

from .reader_parser import ReaderParser
from .test_queue import get_queue
from . import oscamapi
from . import ncamapi
from . import restart_oscam
from . import restart_ncam
from . import paths
from . import logger
from .emu_manager import EmulatorManager


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/OscamReaderManager"

_bootstrap = paths.bootstrap()
OSCAM_FILE = _bootstrap["oscam_file"]
NCAM_FILE  = _bootstrap["ncam_file"]


# =====================================================================
# Settings
# =====================================================================
config.plugins.OscamReaderManager = ConfigSubsection()
config.plugins.OscamReaderManager.auto_restart = ConfigYesNo(default=True)
config.plugins.OscamReaderManager.restart_delay = ConfigSelection(
    default="3",
    choices=[("0", "Immediate"), ("1", "1 second"), ("3", "3 seconds"),
             ("5", "5 seconds"), ("10", "10 seconds")])
config.plugins.OscamReaderManager.confirm_restart = ConfigYesNo(default=False)
config.plugins.OscamReaderManager.poll_interval = ConfigInteger(
    default=10, limits=(3, 120))
config.plugins.OscamReaderManager.sort_mode = ConfigSelection(
    default="alpha",
    choices=[
        ("alpha", "Alphabetical (A-Z)"),
        ("file",  "Original file order"),
    ])

config.plugins.OscamReaderManager.default_editor_mode = ConfigSelection(
    default="simple",
    choices=[
        ("simple",   "Simple (Basic fields)"),
        ("advanced", "Advanced (All fields)"),
    ])

# OSCam
config.plugins.OscamReaderManager.oscam_enabled = ConfigYesNo(default=True)
config.plugins.OscamReaderManager.oscam_autoconf = ConfigYesNo(default=True)
config.plugins.OscamReaderManager.oscam_url = ConfigText(
    default="http://127.0.0.1:8888", fixed_size=False)
config.plugins.OscamReaderManager.oscam_user = ConfigText(
    default="root", fixed_size=False)
config.plugins.OscamReaderManager.oscam_pass = ConfigPassword(
    default="", fixed_size=False)
config.plugins.OscamReaderManager.oscam_timeout = ConfigInteger(
    default=5, limits=(1, 30))

# NCam
config.plugins.OscamReaderManager.ncam_enabled = ConfigYesNo(default=True)
config.plugins.OscamReaderManager.ncam_autoconf = ConfigYesNo(default=True)
config.plugins.OscamReaderManager.ncam_url = ConfigText(
    default="http://127.0.0.1:8181", fixed_size=False)
config.plugins.OscamReaderManager.ncam_user = ConfigText(
    default="root", fixed_size=False)
config.plugins.OscamReaderManager.ncam_pass = ConfigPassword(
    default="", fixed_size=False)
config.plugins.OscamReaderManager.ncam_timeout = ConfigInteger(
    default=5, limits=(1, 30))

# CAID temp bridge
config.plugins.OscamReaderManager.temp_caid = ConfigText(
    default="", fixed_size=False)


# =====================================================================
# Helper
# =====================================================================
HOST_MASK = "*****"


def display_host(host):
    if not host or host == "-":
        return host
    return HOST_MASK


def _validate_url(url):
    try:
        try:
            from urllib.parse import urlparse
        except ImportError:
            from urlparse import urlparse
        p = urlparse(url)
        if p.scheme not in ("http", "https"):
            return False, "Only http/https allowed"
        if not p.hostname:
            return False, "Missing hostname"
        return True, ""
    except Exception as e:
        return False, str(e)


# =====================================================================
# Active SoftCam detection
# =====================================================================
def detect_active_softcam():
    version_files = [
        ("/tmp/.ncam/ncam.version",  "NCam"),
        ("/tmp/.oscam/oscam.version", "OSCam"),
    ]

    for path, default_name in version_files:
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r") as f:
                for line in f:
                    if line.startswith("Version:"):
                        ver = line.split('@')[0]
                        ver = ver.replace("Version:", "").strip()
                        return {
                            "name": default_name,
                            "version": ver,
                            "path": path,
                        }
        except Exception:
            pass

    script = "/etc/init.d/softcam"
    if os.path.exists(script):
        try:
            with open(script, "r") as f:
                for line in f:
                    if line.startswith("CAMNAME="):
                        try:
                            name = line.split('"')[1].strip()
                        except Exception:
                            name = line.split("=", 1)[1].strip()
                        if name:
                            return {
                                "name": name,
                                "version": "",
                                "path": script,
                            }
        except Exception:
            pass

    if os.path.exists("/tmp/.ncam/ncam.version"):
        return {"name": "NCam", "version": "",
                "path": "/tmp/.ncam/ncam.version"}
    if os.path.exists("/tmp/.oscam/oscam.version"):
        return {"name": "OSCam", "version": "",
                "path": "/tmp/.oscam/oscam.version"}

    return None


def _is_oscam_active(info):
    if not info:
        return False
    name = (info.get("name") or "").lower()
    return ("oscam" in name) or ("ncam" in name and "oscam" in name)


def _is_ncam_active(info):
    if not info:
        return False
    name = (info.get("name") or "").lower()
    return ("ncam" in name) and ("oscam" not in name)


# =====================================================================
# Helper: restart only the active softcam
# =====================================================================
def _restart_active_softcam():
    try:
        active = detect_active_softcam()
        if not active:
            logger.log("ReaderManager",
                       "No active SoftCam detected - skipping restart")
            return False, "No active SoftCam"

        name = (active.get("name") or "").lower()
        ver = active.get("version") or "?"

        logger.log("ReaderManager",
                   "Active SoftCam: %s v%s -> restarting" % (name, ver))

        if "ncam" in name and "oscam" not in name:
            return restart_ncam.restart_silent()

        if "oscam" in name:
            return restart_oscam.restart_silent()

        return False, "Unknown active SoftCam: %s" % name
    except Exception as e:
        logger.log("ReaderManager",
                   "restart_active_softcam error: %s" % e)
        return False, "exception: %s" % e


def _get_status_for_active():
    try:
        active = detect_active_softcam()
        if active:
            name = (active.get("name") or "").lower()
            if "ncam" in name and "oscam" not in name:
                return restart_ncam.get_status()
            if "oscam" in name:
                return restart_oscam.get_status()

        return restarter.get_status()
    except Exception:
        return "status: unknown"


def _get_status_for_file(current_file=None):
    return _get_status_for_active()


# =====================================================================
# BaseSetupScreen
# =====================================================================
class BaseSetupScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="BaseSetupScreen" position="center,center" size="1280,720" title="Settings" flags="wfNoBorder" backgroundColor="#0A1428">

        <eLabel position="0,0" size="1280,4" backgroundColor="#1E90FF"/>
        <eLabel position="0,4" size="1280,2" backgroundColor="#22D3EE"/>
        <eLabel position="0,6" size="1280,1" backgroundColor="#A855F7"/>

        <eLabel position="30,14" size="1220,72" backgroundColor="#0E1E3C" cornerRadius="18" zPosition="-1"/>
        <eLabel position="30,14" size="1220,3"  backgroundColor="#1E90FF" cornerRadius="18"/>
        
        <eLabel position="55,24" size="900,58" text="Settings" font="Regular;42" foregroundColor="#EAF2FF" backgroundColor="#0A1428" halign="left" valign="center" transparent="1"/>

        <eLabel position="30,94" size="1220,46" backgroundColor="#132B54" cornerRadius="10" zPosition="-1"/>
        <widget name="section_title" position="50,94" size="1180,46" font="Regular;22" foregroundColor="#22D3EE" halign="left" valign="center" backgroundColor="#0A1B2C" transparent="1" />

        <eLabel position="30,146" size="1220,466" backgroundColor="#0E1E3C" cornerRadius="12" zPosition="-1"/>
        <widget name="config" position="50,156" size="1180,446" scrollbarMode="showOnDemand" itemHeight="50" font="Regular_bold;45" halign="center" valign="center" backgroundColor="#0A1B2C" />

        <widget name="key_red"    position="200,672" size="240,42" font="Regular;30" backgroundColor="#3A0A18" foregroundColor="#FFB3C1" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_green"  position="840,672" size="240,42" font="Regular;30" backgroundColor="#0A3A18" foregroundColor="#B3FFC9" halign="center" valign="center" transparent="0" cornerRadius="21"/>
    </screen>
    """

    def __init__(self, session, title, subtitle, config_list,
                 yellow_label="", blue_label=""):
        Screen.__init__(self, session)
        self.session = session
        self._config_list = config_list or []

        self["section_title"] = Label(title)
        self["status"]        = Label(subtitle or _get_status_for_active())
        self["key_red"]       = Button("Cancel")
        self["key_green"]     = Button("Save")

        ConfigListScreen.__init__(self, self._config_list, session=session)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "cancel": self.cancel,
                "red":    self.cancel,
                "green":  self.save,
                "ok":     self.save,
                "yellow": self.yellow_action,
                "blue":   self.blue_action,
            }, -1)

    def yellow_action(self):
        pass

    def blue_action(self):
        pass

    def save(self):
        errors = []
        try:
            for x in self["config"].list:
                x[1].save()
            config.plugins.OscamReaderManager.save()
        except Exception as e:
            errors.append(str(e))
            logger.log("Setup", "Save error: %s" % e)

        if errors:
            self.session.open(MessageBox,
                "Save failed:\n%s" % "\n".join(errors),
                MessageBox.TYPE_ERROR, timeout=5)
        else:
            self.close(True)

    def cancel(self):
        try:
            for x in self["config"].list:
                x[1].cancel()
        except Exception:
            pass
        self.close(False)


# =====================================================================
# General Settings
# =====================================================================
class GeneralSettings(BaseSetupScreen):
    def __init__(self, session):
        lst = [
            getConfigListEntry("Poll Interval (sec)",
                config.plugins.OscamReaderManager.poll_interval),
            getConfigListEntry("Sort readers",
                config.plugins.OscamReaderManager.sort_mode),

            getConfigListEntry("Editor Mode",
                config.plugins.OscamReaderManager.default_editor_mode),

            getConfigListEntry("Auto restart after changes",
                config.plugins.OscamReaderManager.auto_restart),
            getConfigListEntry("Restart delay",
                config.plugins.OscamReaderManager.restart_delay),
            getConfigListEntry("Confirm before restart",
                config.plugins.OscamReaderManager.confirm_restart),
        ]
        BaseSetupScreen.__init__(self, session,
            title="General Settings",
            subtitle="Reader Manager - General",
            config_list=lst)


# =====================================================================
# OSCam WebIF Settings
# =====================================================================
class OscamSettings(BaseSetupScreen):
    def __init__(self, session):
        lst = [
            getConfigListEntry("Enable OSCam WebIF",
                config.plugins.OscamReaderManager.oscam_enabled),
            getConfigListEntry("Auto-detect (oscam.version)",
                config.plugins.OscamReaderManager.oscam_autoconf),
            getConfigListEntry("WebIF URL",
                config.plugins.OscamReaderManager.oscam_url),
            getConfigListEntry("Username",
                config.plugins.OscamReaderManager.oscam_user),
            getConfigListEntry("Password",
                config.plugins.OscamReaderManager.oscam_pass),
            getConfigListEntry("Timeout (sec)",
                config.plugins.OscamReaderManager.oscam_timeout),
        ]
        BaseSetupScreen.__init__(self, session,
            title="OSCam WebIF Settings",
            subtitle="Reader Manager - OSCam",
            config_list=lst,
            yellow_label="Test OSCam")

    def yellow_action(self):
        url = config.plugins.OscamReaderManager.oscam_url.value
        user = config.plugins.OscamReaderManager.oscam_user.value
        pwd = config.plugins.OscamReaderManager.oscam_pass.value
        try:
            timeout = float(
                config.plugins.OscamReaderManager.oscam_timeout.value)
        except (TypeError, ValueError):
            timeout = 5.0

        ok, err = _validate_url(url)
        if not ok:
            self.session.open(MessageBox,
                "Invalid URL: %s" % err,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        self["status"].setText("Testing OSCam...")
        lines = ["=== OSCam WebIF Test ===", ""]
        try:
            api = oscamapi.OSCamAPI(url, user, pwd, timeout=timeout)
            readers = api.get_reader_status()
            if readers:
                method = api.get_last_method() or "?"
                lines.append("OK - %d reader(s) via %s"
                             % (len(readers), method))
                lines.append("")
                for r in readers[:10]:
                    lines.append("* %s -> %s [%d cards]"
                                 % (r.label, r.status, r.card_count))
                self["status"].setText(
                    "OSCam OK: %d readers" % len(readers))
            else:
                err_msg = api.get_last_error()
                lines.append("EMPTY response")
                lines.append(err_msg or "no readers found")
                self["status"].setText("OSCam failed")
        except Exception as e:
            lines.append("FAILED: %s" % e)
            self["status"].setText("OSCam failed")

        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=15)


# =====================================================================
# NCam WebIF Settings
# =====================================================================
class NcamSettings(BaseSetupScreen):
    def __init__(self, session):
        lst = [
            getConfigListEntry("Enable NCam WebIF",
                config.plugins.OscamReaderManager.ncam_enabled),
            getConfigListEntry("Auto-detect (ncam.version)",
                config.plugins.OscamReaderManager.ncam_autoconf),
            getConfigListEntry("WebIF URL",
                config.plugins.OscamReaderManager.ncam_url),
            getConfigListEntry("Username",
                config.plugins.OscamReaderManager.ncam_user),
            getConfigListEntry("Password",
                config.plugins.OscamReaderManager.ncam_pass),
            getConfigListEntry("Timeout (sec)",
                config.plugins.OscamReaderManager.ncam_timeout),
        ]
        BaseSetupScreen.__init__(self, session,
            title="NCam WebIF Settings",
            subtitle="Reader Manager - NCam",
            config_list=lst,
            yellow_label="Test NCam")

    def yellow_action(self):
        url = config.plugins.OscamReaderManager.ncam_url.value
        user = config.plugins.OscamReaderManager.ncam_user.value
        pwd = config.plugins.OscamReaderManager.ncam_pass.value
        try:
            timeout = float(
                config.plugins.OscamReaderManager.ncam_timeout.value)
        except (TypeError, ValueError):
            timeout = 5.0

        ok, err = _validate_url(url)
        if not ok:
            self.session.open(MessageBox,
                "Invalid URL: %s" % err,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        self["status"].setText("Testing NCam...")
        lines = ["=== NCam WebIF Test ===", ""]
        try:
            api = ncamapi.NCamAPI(url, user, pwd, timeout=timeout)
            readers = api.get_reader_status(fetch_cards=True)
            if readers:
                method = api.get_last_method() or "?"
                lines.append("OK - %d reader(s) via %s"
                             % (len(readers), method))
                lines.append("")
                for r in readers[:10]:
                    lines.append("* %s -> %s [%d cards]"
                                 % (r.label, r.status, r.card_count))
                self["status"].setText(
                    "NCam OK: %d readers" % len(readers))
            else:
                err_msg = api.get_last_error()
                lines.append("EMPTY response")
                lines.append(err_msg or "no readers found")
                self["status"].setText("NCam failed")
        except Exception as e:
            lines.append("FAILED: %s" % e)
            self["status"].setText("NCam failed")

        self.session.open(MessageBox, "\n".join(lines),
                          MessageBox.TYPE_INFO, timeout=15)


# =====================================================================
# Emulator Manager Screen
# =====================================================================
class EmulatorManagerScreen(Screen):
    skin = """
    <screen name="EmulatorManagerScreen" position="center,center" size="1280,720" title="Emulator Manager" flags="wfNoBorder" backgroundColor="#0A1428">

        <eLabel position="0,0" size="1280,4" backgroundColor="#1E90FF"/>
        <eLabel position="0,4" size="1280,2" backgroundColor="#22D3EE"/>
        <eLabel position="0,6" size="1280,1" backgroundColor="#A855F7"/>

        <eLabel position="30,14" size="1220,72" backgroundColor="#0E1E3C" cornerRadius="18" zPosition="-1"/>
        <eLabel position="30,14" size="1220,3"  backgroundColor="#1E90FF" cornerRadius="18"/>
        <eLabel position="55,24" size="600,42" text="Emulator Manager" font="Regular;34" foregroundColor="#EAF2FF" halign="left" valign="center" transparent="1"/>

        <widget name="status" position="700,24" size="530,42" font="Regular;18" foregroundColor="#22D3EE" halign="right" valign="center" transparent="1"/>

        <eLabel position="30,94" size="1220,46" backgroundColor="#132B54" cornerRadius="10" zPosition="-1"/>
        <eLabel position="50,94"   size="350,46" text="Name"        font="Regular;24" foregroundColor="#22D3EE" halign="left" valign="center" transparent="1"/>
        <eLabel position="420,94"  size="180,46" text="Family"      font="Regular;24" foregroundColor="#22D3EE" halign="center" valign="center" transparent="1"/>
        <eLabel position="610,94"  size="200,46" text="Version"     font="Regular;24" foregroundColor="#22DD66" halign="center" valign="center" transparent="1"/>
        <eLabel position="820,94"  size="200,46" text="Init Script" font="Regular;24" foregroundColor="#A855F7" halign="center" valign="center" transparent="1"/>
        <eLabel position="1030,94" size="200,46" text="State"       font="Regular;24" foregroundColor="#22D3EE" halign="center" valign="center" transparent="1"/>

        <eLabel position="30,140" size="1220,1" backgroundColor="#1E90FF"/>

        <widget name="list_name"   halign="left"   valign="center" position="50,148"   size="350,466" font="Regular;28" itemHeight="52" foregroundColor="#EAF2FF" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1" scrollbarMode="showOnDemand"/>
        <widget name="list_family" halign="center" valign="center" position="420,148"  size="180,466" font="Regular;26" itemHeight="52" foregroundColor="#7EC8FF" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_ver"    halign="center" valign="center" position="610,148"  size="200,466" font="Regular;26" itemHeight="52" foregroundColor="#22DD66" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_script" halign="center" valign="center" position="820,148"  size="200,466" font="Regular;22" itemHeight="52" foregroundColor="#A855F7" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_state"  halign="center" valign="center" position="1030,148" size="200,466" font="Regular;26" itemHeight="52" foregroundColor="#22DD66" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>

        <widget name="key_red"    position="130,672" size="240,42" font="Regular;22" backgroundColor="#3A0A18" foregroundColor="#FFB3C1" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_green"  position="380,672" size="240,42" font="Regular;22" backgroundColor="#0A3A18" foregroundColor="#B3FFC9" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_yellow" position="640,672" size="240,42" font="Regular;22" backgroundColor="#3A2E0A" foregroundColor="#FFE9A3" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_blue"   position="900,672" size="240,42" font="Regular;22" backgroundColor="#0A1F3A" foregroundColor="#A3D4FF" halign="center" valign="center" transparent="0" cornerRadius="21"/>
    </screen>
    """

    def __init__(self, session, on_change_callback=None):
        Screen.__init__(self, session)
        self.session = session
        self.on_change_callback = on_change_callback

        self["status"]      = Label("")
        self["key_red"]     = Button("Close")
        self["key_green"]   = Button("Start/Stop")
        self["key_yellow"]  = Button("Refresh")
        self["key_blue"]    = Button("Restart")

        self["list_name"]   = MenuList([])
        self["list_family"] = MenuList([])
        self["list_ver"]    = MenuList([])
        self["list_script"] = MenuList([])
        self["list_state"]  = MenuList([])

        self.emulators = []
        self.current_index = 0
        self._syncing = False

        self.manager = EmulatorManager()

        for name in ("list_name", "list_family", "list_ver",
                     "list_script", "list_state"):
            self[name].onSelectionChanged.append(self._sync_lists)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions",
             "DirectionActions", "MenuActions"],
            {
                "ok":     self.toggle_selected,
                "cancel": self.close,
                "red":    self.close,
                "green":  self.toggle_selected,
                "yellow": self.refresh,
                "blue":   self.restart_selected,
                "up":     self.move_up,
                "down":   self.move_down,
            }, -1)

        self.onLayoutFinish.append(self.load_emulators)

    # ------------------------------------------------------------------
    def load_emulators(self):
        self["status"].setText("Scanning /usr/bin ...")
        try:
            self.emulators = self.manager.refresh()
        except Exception as e:
            logger.log("EmuManagerScreen", "discover error: %s" % e)
            self.emulators = []

        self.refresh_lists()

        if not self.emulators:
            self["status"].setText("No emulators found in /usr/bin")
        else:
            on, total = self.manager.get_running_count()
            self["status"].setText("%d/%d running" % (on, total))

    def refresh_lists(self):
        names, families, versions, scripts, states = [], [], [], [], []

        for e in self.emulators:
            names.append(e.name or "-")
            families.append((e.family or "-").upper())
            versions.append(e.version or "-")

            if e.init_script:
                scripts.append(os.path.basename(e.init_script)[:24])
            else:
                scripts.append("(none)")

            states.append("RUNNING" if e.running else "STOPPED")

        self._syncing = True
        try:
            self["list_name"].setList(names)
            self["list_family"].setList(families)
            self["list_ver"].setList(versions)
            self["list_script"].setList(scripts)
            self["list_state"].setList(states)
        finally:
            self._syncing = False

        if self.emulators:
            idx = min(self.current_index, len(self.emulators) - 1)
            if idx < 0:
                idx = 0
            self.current_index = idx
            self.set_index(idx, force=True)

        on, total = self.manager.get_running_count()
        self["status"].setText("%d/%d running" % (on, total))

    def set_index(self, idx, force=False):
        if self._syncing or not self.emulators:
            return
        idx = max(0, min(idx, len(self.emulators) - 1))
        if not force and idx == self.current_index:
            return
        self._syncing = True
        try:
            self.current_index = idx
            for name in ("list_name", "list_family", "list_ver",
                         "list_script", "list_state"):
                widget = self[name]
                try:
                    if hasattr(widget, "setCurrentIndex"):
                        widget.setCurrentIndex(idx)
                    elif hasattr(widget, "moveToIndex"):
                        widget.moveToIndex(idx)
                    elif (hasattr(widget, "instance")
                          and widget.instance is not None):
                        widget.instance.moveToIndex(idx)
                except Exception:
                    pass
        finally:
            self._syncing = False

    def _sync_lists(self):
        if self._syncing:
            return
        for name in ("list_name", "list_family", "list_ver",
                     "list_script", "list_state"):
            try:
                widget = self[name]
                idx = None
                if hasattr(widget, "getSelectedIndex"):
                    idx = widget.getSelectedIndex()
                elif hasattr(widget, "getCurrentIndex"):
                    idx = widget.getCurrentIndex()
                elif (hasattr(widget, "instance")
                      and widget.instance is not None):
                    idx = widget.instance.getCurrentIndex()
            except Exception:
                continue
            if idx is not None and idx >= 0 and idx != self.current_index:
                self.set_index(idx)
                break

    def move_up(self):
        if not self.emulators or self._syncing:
            return
        if self.current_index <= 0:
            self.set_index(len(self.emulators) - 1)
        else:
            self.set_index(self.current_index - 1)

    def move_down(self):
        if not self.emulators or self._syncing:
            return
        if self.current_index >= len(self.emulators) - 1:
            self.set_index(0)
        else:
            self.set_index(self.current_index + 1)

    # ------------------------------------------------------------------
    #  Start / Stop — لمحاكٍ واحد فقط
    # ------------------------------------------------------------------
    def toggle_selected(self):
        if not self.emulators:
            return

        emu = self.emulators[self.current_index]

        self["status"].setText(
            "%s %s..." % ("Stopping" if emu.running else "Starting",
                          emu.name))

        ok, msg = self.manager.toggle(emu)

        if not ok:
            self.session.open(MessageBox, msg,
                              MessageBox.TYPE_ERROR, timeout=6)
            self.refresh_lists()
            return

        self.refresh_lists()
        self["status"].setText(msg)

        if self.on_change_callback:
            try:
                self.on_change_callback()
            except Exception:
                pass

    # ------------------------------------------------------------------
    #  Restart — لمحاكٍ واحد فقط
    # ------------------------------------------------------------------
    def restart_selected(self):
        if not self.emulators:
            return

        emu = self.emulators[self.current_index]

        self["status"].setText("Restarting %s..." % emu.name)

        ok, msg = self.manager.restart(emu)

        if not ok:
            self.session.open(MessageBox, msg,
                              MessageBox.TYPE_ERROR, timeout=6)
            self.refresh_lists()
            return

        self.refresh_lists()
        self["status"].setText(msg)

        if self.on_change_callback:
            try:
                self.on_change_callback()
            except Exception:
                pass

    # ------------------------------------------------------------------
    #  Refresh — لا يطبّق أي أمر
    # ------------------------------------------------------------------
    def refresh(self):
        self.load_emulators()


# =====================================================================
# SettingsMenu
# =====================================================================
class SettingsMenu(Screen):
    skin = """
    <screen name="SettingsMenu" position="center,center" size="1280,720" title="Settings" flags="wfNoBorder" backgroundColor="#0A1428">

        <eLabel position="0,0" size="1280,4" backgroundColor="#1E90FF"/>
        <eLabel position="0,4" size="1280,2" backgroundColor="#22D3EE"/>
        <eLabel position="0,6" size="1280,1" backgroundColor="#A855F7"/>

        <eLabel position="30,14" size="1220,72" backgroundColor="#0E1E3C" cornerRadius="18" zPosition="-1"/>
        <eLabel position="30,14" size="1220,3"  backgroundColor="#1E90FF" cornerRadius="18"/>
        <eLabel position="55,24" size="900,58" text="Settings" font="Regular;45" foregroundColor="#EAF2FF" transparent="1" halign="center" valign="center"/>

        <eLabel position="30,146" size="1220,466" backgroundColor="#0E1E3C" cornerRadius="12" zPosition="-1"/>
        <widget name="menu" valign="center" halign="center" position="50,156" size="1180,446" font="Regular_bold;55" itemHeight="70" scrollbarMode="showOnDemand" foregroundColor="#EAF2FF" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="0"/>

        <widget name="key_red"    position="200,672" size="240,42" font="Regular;30" backgroundColor="#3A0A18" foregroundColor="#FFB3C1" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_green"  position="840,672" size="240,42" font="Regular;30" backgroundColor="#0A3A18" foregroundColor="#B3FFC9" halign="center" valign="center" transparent="0" cornerRadius="21"/>
    </screen>
    """

    def __init__(self, session, on_emu_change=None):
        Screen.__init__(self, session)
        self.session = session
        self._on_emu_change = on_emu_change

        self["status"]     = Label(
            "Choose a category - Up/Down - OK to open")
        self["key_red"]    = Button("Close")
        self["key_green"]  = Button("Open")

        menu_items = [
            ("General Settings",     "general"),
            ("OSCam WebIF Settings", "oscam"),
            ("NCam WebIF Settings",  "ncam"),
            ("Emulator Manager",     "emulators"),
        ]
        self["menu"] = MenuList([item[0] for item in menu_items])
        self._menu_items = menu_items

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "ok":     self.open_selected,
                "green":  self.open_selected,
                "cancel": self.close,
                "red":    self.close,
            }, -1)

    def open_selected(self):
        idx = self["menu"].getSelectedIndex()
        if idx < 0 or idx >= len(self._menu_items):
            return

        label, key = self._menu_items[idx]

        try:
            if key == "general":
                self.session.open(GeneralSettings)
            elif key == "oscam":
                self.session.open(OscamSettings)
            elif key == "ncam":
                self.session.open(NcamSettings)
            elif key == "emulators":
                self.session.openWithCallback(
                    self._after_emulators,
                    EmulatorManagerScreen,
                    self._on_emu_change)
        except Exception as e:
            logger.log("SettingsMenu", "Open error: %s" % e)

    def _after_emulators(self, *args, **kwargs):
        if self._on_emu_change:
            try:
                self._on_emu_change()
            except Exception as e:
                logger.log("SettingsMenu",
                           "emu change callback error: %s" % e)


# =====================================================================
# LogViewer
# =====================================================================
class LogViewer(Screen):
    skin = """
    <screen name="LogViewer" position="center,center" size="1280,720" title="ReaderManager Log" flags="wfNoBorder" backgroundColor="#0A1428">

        <eLabel position="0,0" size="1280,4" backgroundColor="#1E90FF"/>
        <eLabel position="0,4" size="1280,2" backgroundColor="#22D3EE"/>
        <eLabel position="0,6" size="1280,1" backgroundColor="#A855F7"/>

        <eLabel position="30,14" size="1220,72" backgroundColor="#0E1E3C" cornerRadius="18" zPosition="-1"/>
        <eLabel position="30,14" size="1220,3"  backgroundColor="#1E90FF" cornerRadius="18"/>
        <eLabel position="55,24" size="900,42" text="Debug Log" font="Regular;34" foregroundColor="#EAF2FF" halign="left" valign="center"/>
        <widget name="log_status" position="700,24" size="530,42" font="Regular;15" foregroundColor="#22D3EE" halign="right" valign="center"/>

        <eLabel position="30,94" size="1220,518" backgroundColor="#0E1E3C" cornerRadius="12" zPosition="-1"/>
        <widget name="content" position="50,108" size="1180,490" noWrap="0"  font="Regular;35" foregroundColor="#EAF2FF" transparent="0" scrollbarMode="showOnDemand"/>

        <eLabel position="30,622" size="1220,38" backgroundColor="#0E1E3C" cornerRadius="10" zPosition="-1"/>
        <eLabel position="30,622" size="4,38" backgroundColor="#1E90FF" cornerRadius="10"/>

        <widget name="key_red"    position="130,672" size="240,42" font="Regular;24" backgroundColor="#3A0A18" foregroundColor="#FFB3C1" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_green"  position="380,672" size="240,42" font="Regular;24" backgroundColor="#0A3A18" foregroundColor="#B3FFC9" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_yellow" position="640,672" size="240,42" font="Regular;24" backgroundColor="#3A2E0A" foregroundColor="#FFE9A3" halign="center" valign="center" transparent="0" cornerRadius="21"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self["status"]     = Label(logger.get_log_path())
        self["log_status"] = Label("")
        self["content"]    = ScrollLabel("")
        self["key_red"]    = Button("Close")
        self["key_green"]  = Button("Refresh")
        self["key_yellow"] = Button("Clear")
        self["key_blue"]   = Button("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.close, "cancel": self.close, "red": self.close,
                "green":  self.refresh, "yellow": self.clear_log,
                "up":     self.scroll_up, "down": self.scroll_down,
                "left":   self.page_up,   "right": self.page_down,
            }, -1)

        self.onLayoutFinish.append(self.refresh)

    def _call_scroll(self, names):
        w = self["content"]
        for name in names:
            if hasattr(w, name):
                try:
                    getattr(w, name)()
                    return
                except Exception:
                    pass

    def scroll_up(self):   self._call_scroll(["up", "moveUp"])
    def scroll_down(self): self._call_scroll(["down", "moveDown"])
    def page_up(self):     self._call_scroll(["pageUp", "movePageUp"])
    def page_down(self):   self._call_scroll(["pageDown", "movePageDown"])

    def refresh(self):
        try:
            with open(logger.get_log_path(), "r") as f:
                data = f.read()
        except Exception as e:
            data = "Cannot read log: %s" % e
        lines = data.splitlines()
        if len(lines) > 300:
            lines = lines[-300:]
        self["content"].setText("\n".join(lines))
        self["status"].setText(logger.get_log_path())
        self["log_status"].setText("%d lines" % len(lines))

    def clear_log(self):
        try:
            logger.clear()
        except Exception as e:
            logger.log("LogViewer", "Clear error: %s" % e)
        self.refresh()


# =====================================================================
# ReaderManager
# =====================================================================
class ReaderManager(Screen):
    skin = """
    <screen name="ReaderManager" position="center,center" size="1280,720" title="Reader Manager" flags="wfNoBorder" backgroundColor="#0A1428" cornerRadius="20" >

        <eLabel position="0,0" size="1280,4" backgroundColor="#1E90FF"/>
        <eLabel position="0,4" size="1280,2" backgroundColor="#22D3EE"/>
        <eLabel position="0,6" size="1280,1" backgroundColor="#A855F7"/>

        <eLabel position="30,14" size="1220,72" backgroundColor="#0E1E3C" cornerRadius="18" zPosition="-1"/>
        <eLabel position="30,14" size="1220,3"  backgroundColor="#1E90FF" cornerRadius="18"/>
        <eLabel position="55,24" size="600,42" transparent="1" text="Reader Manager" font="Regular;34" foregroundColor="#EAF2FF" halign="left" valign="center"/>

        <eLabel position="1000,26" size="230,48" backgroundColor="#132B54" cornerRadius="14" zPosition="-1"/>
        <widget name="file_badge" position="1010,30" size="210,40" zPosition="1" alphatest="blend" scale="1" />

        <eLabel position="30,94" size="1220,46" backgroundColor="#132B54" cornerRadius="10" zPosition="-1"/>

        <eLabel position="50,94"   size="180,46" text="Label"    font="Regular;24" foregroundColor="#22D3EE" halign="left" valign="center" transparent="1"/>
        <eLabel position="240,94"  size="200,46" text="Host"     font="Regular;24" foregroundColor="#22D3EE" halign="left" valign="center" transparent="1"/>
        <eLabel position="450,94"  size="150,46"  text="Port"     font="Regular;24" foregroundColor="#22D3EE" halign="center" valign="center" transparent="1"/>
        <eLabel position="600,94"  size="150,46"  text="ON/OFF"   font="Regular;24" foregroundColor="#22D3EE" halign="center" valign="center" transparent="1"/>
        <eLabel position="750,94"  size="150,46" text="Protocol" font="Regular;24" foregroundColor="#22D3EE" halign="center" valign="center" transparent="1"/>
        <eLabel position="900,94"  size="150,46"  text="Cards"    font="Regular;24" foregroundColor="#22DD66" halign="center" valign="center" transparent="1"/>
        <eLabel position="1050,94" size="200,46" text="Status"   font="Regular;24" foregroundColor="#22D3EE" halign="center" valign="center" transparent="1"/>

        <eLabel position="30,140" size="1220,1" backgroundColor="#1E90FF"/>

        <widget name="list_label"  halign="left"   valign="center" position="50,148"   size="180,466" font="Regular;32" itemHeight="48" foregroundColor="#EAF2FF" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1" scrollbarMode="showOnDemand"/>
        <widget name="list_host"   halign="left"   valign="center" position="240,148"  size="200,466" font="Regular;26" itemHeight="48" foregroundColor="#EAF2FF" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_port"   halign="center" valign="center" position="450,148"  size="150,466"  font="Regular;26" itemHeight="48" foregroundColor="#7EC8FF" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_state"  halign="center" valign="center" position="600,148"  size="150,466"  font="Regular;26" itemHeight="48" foregroundColor="#22DD66" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_file"   halign="center" valign="center" position="750,148"  size="150,466" font="Regular;26" itemHeight="48" foregroundColor="#A855F7" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_cards"  halign="center" valign="center" position="900,148"  size="150,466"  font="Regular;26" itemHeight="48" foregroundColor="#22DD66" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>
        <widget name="list_status" halign="center" valign="center" position="1050,148" size="200,466" font="Regular;26" itemHeight="48" foregroundColor="#FFC93C" backgroundColor="#0F2044" backgroundColorSelected="#1E90FF" foregroundColorSelected="#FFFFFF" transparent="1"/>

        <widget name="key_red"    position="130,672" size="240,42" font="Regular;24" backgroundColor="#3A0A18" foregroundColor="#FFB3C1" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_green"  position="380,672" size="240,42" font="Regular;24" backgroundColor="#0A3A18" foregroundColor="#B3FFC9" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_yellow" position="640,672" size="240,42" font="Regular;24" backgroundColor="#3A2E0A" foregroundColor="#FFE9A3" halign="center" valign="center" transparent="0" cornerRadius="21"/>
        <widget name="key_blue"   position="900,672" size="240,42" font="Regular;24" backgroundColor="#0A1F3A" foregroundColor="#A3D4FF" halign="center" valign="center" transparent="0" cornerRadius="21"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self["status"]      = Label("Ready")
        self["active_file"] = Label("")
        self["file_badge"]  = Pixmap()
        self["key_red"]     = Button("Exit")
        self["key_green"]   = Button("Add")
        self["key_yellow"]  = Button("Delete")
        self["key_blue"]    = Button("Edit")

        self["list_label"]  = MenuList([])
        self["list_host"]   = MenuList([])
        self["list_port"]   = MenuList([])
        self["list_state"]  = MenuList([])
        self["list_file"]   = MenuList([])
        self["list_cards"]  = MenuList([])
        self["list_status"] = MenuList([])

        self.readers = []
        self.current_index = 0
        self.current_file = OSCAM_FILE
        self._syncing = False

        self.oscam_details = {}
        self.ncam_details = {}
        self.status_cache = {}

        try:
            from threading import Lock as _Lock
            self._data_lock = _Lock()
        except Exception:
            self._data_lock = None

        self._refresh_timer = None
        self._oscam_poll_timer = None
        self._ncam_poll_timer = None
        self._refresh_scheduled_timer = None
        self._editor_timer = None
        self._restart_timer = None

        self._closing = False

        self._active_softcam = detect_active_softcam()

        self._queue = get_queue(test_timeout=5)
        self._queue.add_listener(self._on_queue_result)

        self._oscam_client = None
        self._ncam_client = None

        self._setup_clients()

        for name in ("list_label", "list_host", "list_port", "list_state",
                     "list_file", "list_cards", "list_status"):
            self[name].onSelectionChanged.append(self.sync_lists)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions",
             "MenuActions", "InfobarActions", "EPGSelectActions"],
            {
                "ok":            self.toggleState,
                "cancel":        self.close,
                "red":           self.close,
                "green":         self.addReader,
                "yellow":        self.deleteReader,
                "blue":          self.editReader,
                "menu":          self.openSettingsMenu,
                "info":          self.viewReader,
                "infobar":       self.viewReader,
                "epg":           self.openLog,
                "showEventInfo": self.openLog,
                "text":          self.openLog,
                "up":            self.moveUp,
                "down":          self.moveDown,
                "left":          self.switchToOscam,
                "right":         self.switchToNcam,
            }, -1)

        self.onLayoutFinish.append(self._on_start)

    # ------------------------------------------------------------------
    #  File badge
    # ------------------------------------------------------------------
    def _update_file_badge(self):
        try:
            plugin_dir = os.path.dirname(os.path.abspath(__file__))
            images_dir = os.path.join(plugin_dir, "images")

            if self.current_file == NCAM_FILE:
                img_name = "ncam.png"
            else:
                img_name = "oscam.png"

            img_path = os.path.join(images_dir, img_name)

            if os.path.isfile(img_path):
                pix = LoadPixmap(img_path)
                if pix:
                    self["file_badge"].instance.setPixmap(pix)
                    return
                else:
                    logger.log("ReaderManager",
                               "Cannot load pixmap: %s" % img_path)
            else:
                logger.log("ReaderManager",
                           "Image not found: %s" % img_path)

            try:
                self["file_badge"].instance.setPixmap(None)
            except Exception:
                pass

        except Exception as e:
            logger.log("ReaderManager",
                       "_update_file_badge error: %s" % e)

    # ------------------------------------------------------------------
    #  Client setup
    # ------------------------------------------------------------------
    def _setup_clients(self):
        self._oscam_client = None
        self._ncam_client = None

        active = self._active_softcam
        if active:
            name = active.get("name") or "?"
            ver = active.get("version") or "?"
            logger.log("ReaderManager",
                       "Active SoftCam: %s (version=%s)" % (name, ver))
        else:
            logger.log("ReaderManager", "No active SoftCam detected")

        if config.plugins.OscamReaderManager.oscam_enabled.value:
            if _is_oscam_active(active) or active is None:
                self._setup_oscam_client()
            else:
                logger.log("OSCamAPI", "Not active - skip setup")

        if config.plugins.OscamReaderManager.ncam_enabled.value:
            if _is_ncam_active(active):
                self._setup_ncam_client()
            else:
                logger.log("NCamAPI", "Not active - skip setup")

    def _setup_oscam_client(self):
        try:
            if config.plugins.OscamReaderManager.oscam_autoconf.value:
                try:
                    if hasattr(oscamapi, "configure_auto"):
                        self._oscam_client = oscamapi.configure_auto()
                        return
                except Exception as e:
                    logger.log("OSCamAPI", "Auto failed: %s" % e)

            url = config.plugins.OscamReaderManager.oscam_url.value
            user = config.plugins.OscamReaderManager.oscam_user.value
            pwd = config.plugins.OscamReaderManager.oscam_pass.value
            try:
                timeout = float(
                    config.plugins.OscamReaderManager.oscam_timeout.value)
            except (TypeError, ValueError):
                timeout = 5.0
            self._oscam_client = oscamapi.OSCamAPI(url, user, pwd,
                                                    timeout=timeout)
        except Exception as e:
            logger.log("OSCamAPI", "Setup failed: %s" % e)
            self._oscam_client = None

    def _setup_ncam_client(self):
        try:
            if config.plugins.OscamReaderManager.ncam_autoconf.value:
                try:
                    if hasattr(ncamapi, "configure_auto"):
                        self._ncam_client = ncamapi.configure_auto()
                        return
                except Exception as e:
                    logger.log("NCamAPI", "Auto failed: %s" % e)

            url = config.plugins.OscamReaderManager.ncam_url.value
            user = config.plugins.OscamReaderManager.ncam_user.value
            pwd = config.plugins.OscamReaderManager.ncam_pass.value
            try:
                timeout = float(
                    config.plugins.OscamReaderManager.ncam_timeout.value)
            except (TypeError, ValueError):
                timeout = 5.0
            self._ncam_client = ncamapi.NCamAPI(url, user, pwd,
                                                 timeout=timeout)
        except Exception as e:
            logger.log("NCamAPI", "Setup failed: %s" % e)
            self._ncam_client = None

    def _get_active_client(self):
        if self.current_file == NCAM_FILE:
            return self._ncam_client, "NCamAPI"
        return self._oscam_client, "OSCamAPI"

    def _get_active_details(self):
        if self.current_file == NCAM_FILE:
            return self.ncam_details
        return self.oscam_details

    # ------------------------------------------------------------------
    #  Sorting
    # ------------------------------------------------------------------
    def _sort_readers(self, readers):
        try:
            mode = config.plugins.OscamReaderManager.sort_mode.value
        except Exception:
            mode = "alpha"

        if mode != "alpha":
            return list(readers)

        def sort_key(r):
            label = (getattr(r, "label", "") or "").strip().lower()
            return (label == "", label)

        try:
            return sorted(readers, key=sort_key)
        except Exception:
            return list(readers)

    # ------------------------------------------------------------------
    #  Selection
    # ------------------------------------------------------------------
    def _current_label(self):
        if not self.readers:
            return None
        try:
            r = self.readers[self.current_index]
            return getattr(r, "label", None)
        except Exception:
            return None

    def _find_index_by_label(self, label):
        if not label:
            return -1
        for i, r in enumerate(self.readers):
            if (getattr(r, "label", "") or "") == label:
                return i
        return -1

    def _restore_selection(self, label):
        if not label:
            return
        idx = self._find_index_by_label(label)
        if idx >= 0:
            self.current_index = idx

    # ------------------------------------------------------------------
    #  Lifecycle
    # ------------------------------------------------------------------
    def _on_start(self):
        self.loadReaders()
        self._start_polling()

    def _start_polling(self):
        try:
            from enigma import eTimer
            try:
                interval = int(
                    config.plugins.OscamReaderManager.poll_interval.value
                ) * 1000
            except (TypeError, ValueError):
                interval = 10000

            for attr in ("_oscam_poll_timer", "_ncam_poll_timer"):
                timer = getattr(self, attr, None)
                if timer:
                    try:
                        timer.stop()
                    except Exception:
                        pass
                setattr(self, attr, None)

            self._active_softcam = detect_active_softcam()
            active = self._active_softcam

            if not active:
                logger.log("ReaderManager",
                           "No active SoftCam - polling skipped")
                return

            logger.log("ReaderManager",
                       "Polling for %s" % active.get("name", "?"))

            if _is_ncam_active(active):
                if self._ncam_client:
                    self._ncam_poll_timer = eTimer()
                    self._ncam_poll_timer.callback.append(self._poll_ncam)
                    self._ncam_poll_timer.start(interval, False)
                    self._poll_ncam()
                else:
                    logger.log("NCamAPI",
                               "NCam active but client missing")
            elif _is_oscam_active(active):
                if self._oscam_client:
                    self._oscam_poll_timer = eTimer()
                    self._oscam_poll_timer.callback.append(self._poll_oscam)
                    self._oscam_poll_timer.start(interval, False)
                    self._poll_oscam()
                else:
                    logger.log("OSCamAPI",
                               "OSCam active but client missing")
            else:
                if self.current_file == NCAM_FILE and self._ncam_client:
                    self._ncam_poll_timer = eTimer()
                    self._ncam_poll_timer.callback.append(self._poll_ncam)
                    self._ncam_poll_timer.start(interval, False)
                    self._poll_ncam()
                elif self.current_file == OSCAM_FILE \
                        and self._oscam_client:
                    self._oscam_poll_timer = eTimer()
                    self._oscam_poll_timer.callback.append(
                        self._poll_oscam)
                    self._oscam_poll_timer.start(interval, False)
                    self._poll_oscam()
        except Exception as e:
            logger.log("ReaderManager", "Timer failed: %s" % e)

    # ------------------------------------------------------------------
    #  Polling
    # ------------------------------------------------------------------
    def _poll_oscam(self):
        if self._closing or not self._oscam_client:
            return
        try:
            t = threading.Thread(target=self._oscam_worker)
            t.setDaemon(True)
            t.start()
        except Exception as e:
            logger.log("OSCamAPI", "Thread spawn failed: %s" % e)

    def _oscam_worker(self):
        if self._closing:
            return
        try:
            readers = self._oscam_client.get_reader_status()
            details = {r.label: r for r in readers}
            with self._data_lock:
                self.oscam_details = details

            connected = sum(1 for r in readers if r.is_connected)
            method = self._oscam_client.get_last_method() or "?"
            logger.log("OSCamAPI", "Poll OK: %d/%d (via %s)"
                       % (connected, len(readers), method))
            self._schedule_ui_refresh()
        except Exception as e:
            logger.log("OSCamAPI", "Poll error: %s" % e)

    def _poll_ncam(self):
        if self._closing or not self._ncam_client:
            return
        try:
            t = threading.Thread(target=self._ncam_worker)
            t.setDaemon(True)
            t.start()
        except Exception as e:
            logger.log("NCamAPI", "Thread spawn failed: %s" % e)

    def _ncam_worker(self):
        if self._closing:
            return
        try:
            readers = self._ncam_client.get_reader_status(
                fetch_cards=True)
            details = {r.label: r for r in readers}
            with self._data_lock:
                self.ncam_details = details

            connected = sum(1 for r in readers if r.is_connected)
            method = self._ncam_client.get_last_method() or "?"
            logger.log("NCamAPI", "Poll OK: %d/%d (via %s)"
                       % (connected, len(readers), method))
            self._schedule_ui_refresh()
        except Exception as e:
            logger.log("NCamAPI", "Poll error: %s" % e)

    # ------------------------------------------------------------------
    #  UI refresh
    # ------------------------------------------------------------------
    def _schedule_ui_refresh(self):
        if self._closing:
            return
        try:
            from enigma import eTimer
            t = eTimer()
            t.callback.append(self._apply_api_update)
            t.start(10, True)
            self._refresh_timer = t
        except Exception:
            pass

    def _apply_api_update(self):
        if self._closing:
            return
        try:
            self.refreshLists()
            self._update_status_bar()
        except Exception as e:
            logger.log("ReaderManager", "Apply update error: %s" % e)

    def _update_status_bar(self):
        try:
            if self.current_file == NCAM_FILE:
                with self._data_lock:
                    details = dict(self.ncam_details)
                api_name = "NCam"
                client = self._ncam_client
            else:
                with self._data_lock:
                    details = dict(self.oscam_details)
                api_name = "OSCam"
                client = self._oscam_client

            n = len(details)
            method = (client.get_last_method() if client else "?") or "?"
            err = client.get_last_error() if client else ""

            active_name = ""
            if self._active_softcam:
                active_name = self._active_softcam.get("name") or ""

            status = _get_status_for_active()

            if err and n == 0:
                self["status"].setText(
                    "%s: error | %s" % (api_name, err))
            else:
                self["status"].setText(
                    "%s WebIF: %d reader(s) via %s | %s | Active: %s"
                    % (api_name, n, method, status, active_name or "-"))
        except Exception:
            pass

    def _schedule_oscam_refresh(self, delay_ms=1500,
                                 immediate_first=False):
        if self._closing:
            return
        try:
            from enigma import eTimer
            if self._refresh_scheduled_timer is not None:
                try:
                    self._refresh_scheduled_timer.stop()
                except Exception:
                    pass
                self._refresh_scheduled_timer = None

            poller = (self._poll_ncam
                      if self.current_file == NCAM_FILE
                      else self._poll_oscam)

            if immediate_first:
                poller()

            t = eTimer()
            t.callback.append(poller)
            t.start(delay_ms, True)
            self._refresh_scheduled_timer = t
        except Exception as e:
            logger.log("ReaderManager", "Schedule error: %s" % e)

    def _on_queue_result(self, reader, result):
        if self._closing:
            return
        try:
            label = getattr(reader, "label", "") or "?"
            active = self._get_active_details()
            if label in active:
                return

            if not getattr(reader, "enabled", True):
                new_val = "-"
            else:
                ok = bool(result and result.get("ok"))
                new_val = "Connected" if ok else "Disconnected"

            with self._data_lock:
                self.status_cache[label] = new_val
            self._schedule_ui_refresh()
        except Exception as e:
            logger.log("ReaderManager", "Queue result error: %s" % e)

    # ------------------------------------------------------------------
    #  File helpers
    # ------------------------------------------------------------------
    def _file_tag(self, path):
        if path == OSCAM_FILE:
            return "OSCAM"
        if path == NCAM_FILE:
            return "NCAM"
        return "UNKNOWN"

    def _file_exists(self, path):
        return path and os.path.exists(path)

    def _reload_active(self, new_file, label):
        if not self._file_exists(new_file):
            self.session.open(MessageBox,
                "%s file not found:\n%s" % (label, new_file),
                MessageBox.TYPE_ERROR, timeout=4)
            return
        if new_file == self.current_file:
            self["status"].setText("Already on %s" % label)
            return

        self.current_file = new_file
        self.current_index = 0
        self["status"].setText("Loading %s readers..." % label)

        self._update_file_badge()

        self.loadReaders()
        self["status"].setText("Showing %d reader(s) from %s"
                               % (len(self.readers), label))

        self._start_polling()
        self._schedule_oscam_refresh(delay_ms=1000,
                                      immediate_first=True)

    def switchToOscam(self):
        self._reload_active(OSCAM_FILE, "OSCAM")

    def switchToNcam(self):
        self._reload_active(NCAM_FILE, "NCAM")

    # ------------------------------------------------------------------
    #  Auto restart
    # ------------------------------------------------------------------
    def auto_restart_cam(self, action_text=""):
        if not config.plugins.OscamReaderManager.auto_restart.value:
            self._schedule_oscam_refresh(delay_ms=2000,
                                          immediate_first=True)
            return

        try:
            delay = int(
                config.plugins.OscamReaderManager.restart_delay.value)
        except (TypeError, ValueError):
            delay = 3

        if config.plugins.OscamReaderManager.confirm_restart.value:
            self.session.openWithCallback(
                lambda ans: self._do_restart(ans, delay, action_text),
                MessageBox, "%s. Restart softcam now?" % action_text,
                MessageBox.TYPE_YESNO)
        else:
            self._do_restart(True, delay, action_text)

    def _do_restart(self, answer, delay, action_text):
        if not answer:
            self._schedule_oscam_refresh(delay_ms=1500,
                                          immediate_first=True)
            return
        if delay > 0:
            self["status"].setText("Waiting %d seconds..." % delay)
            try:
                from enigma import eTimer
                self._restart_timer = eTimer()
                self._restart_timer.callback.append(
                    lambda: self._execute_restart(action_text))
                self._restart_timer.start(delay * 1000, True)
            except Exception as e:
                logger.log("ReaderManager",
                           "Restart timer error: %s" % e)
                self._schedule_oscam_refresh(delay_ms=1000,
                                              immediate_first=True)
        else:
            self._execute_restart(action_text)

    def _execute_restart(self, action_text):
        if self._closing:
            return
        try:
            ok, msg = _restart_active_softcam()

            self["status"].setText("%s | %s - refreshing..."
                                   % (action_text, msg))
            self._schedule_oscam_refresh(delay_ms=5000,
                                          immediate_first=False)
        except Exception as e:
            self["status"].setText("Restart error: %s" % str(e))
            self._schedule_oscam_refresh(delay_ms=2000,
                                          immediate_first=True)

    def _restart_directly(self, action_text=""):
        logger.log("ReaderManager",
                   "_restart_directly: action=%r closing=%s"
                   % (action_text, self._closing))

        if self._closing:
            return

        try:
            ok, msg = _restart_active_softcam()
            logger.log("ReaderManager",
                       "_restart_directly: result ok=%s msg=%r"
                       % (ok, msg))

            self["status"].setText("%s | %s - refreshing..."
                                   % (action_text, msg))

            self._schedule_oscam_refresh(delay_ms=5000,
                                          immediate_first=False)
        except Exception as e:
            logger.log("ReaderManager",
                       "_restart_directly error: %s" % e)
            self["status"].setText("Restart error: %s" % str(e))
            self._schedule_oscam_refresh(delay_ms=2000,
                                          immediate_first=True)

    # ------------------------------------------------------------------
    #  Load readers
    # ------------------------------------------------------------------
    def loadReaders(self):
        raw_readers = []
        tag = self._file_tag(self.current_file)
        self["active_file"].setText("Active file: %s" % tag)

        self._update_file_badge()

        if not self._file_exists(self.current_file):
            self.readers = []
            self.refreshLists()
            self["status"].setText("%s file not found | %s"
                                   % (tag, _get_status_for_active()))
            return

        parser = ReaderParser()
        try:
            for r in parser.parse_file(self.current_file):
                r.source_file = self.current_file
                r.source_tag  = tag
                raw_readers.append(r)
        except Exception as e:
            logger.log("ReaderManager",
                       "parse error %s: %s" % (self.current_file, e))

        self.readers = self._sort_readers(raw_readers)

        self.refreshLists()
        self["status"].setText("%d reader(s) from %s | %s"
                               % (len(self.readers), tag,
                                  _get_status_for_active()))

        active_client = (self._ncam_client
                         if self.current_file == NCAM_FILE
                         else self._oscam_client)
        readers_on = [r for r in self.readers
                      if getattr(r, "enabled", True)]
        if readers_on and not active_client:
            self._queue.enqueue_many(readers_on, priority=5,
                                      reason="startup")

    # ------------------------------------------------------------------
    #  Refresh lists
    # ------------------------------------------------------------------
    def refreshLists(self):
        labels, hosts, ports, states, files, cards, statuses = (
            [], [], [], [], [], [], [])

        active = self._get_active_details()
        with self._data_lock:
            active_copy = dict(active)
            cache_copy = dict(self.status_cache)

        for r in self.readers:
            labels.append(r.label or "-")
            dev = r.device or ""
            if "," in dev:
                h, p = dev.split(",", 1)
            else:
                h, p = dev, "-"
            hosts.append(display_host(h) if h else "-")
            ports.append(p or "-")
            states.append("ON" if r.enabled else "OFF")
            files.append(r.protocol or "-")

            if not r.enabled:
                cards.append("-")
                statuses.append("-")
                continue

            info = active_copy.get(r.label)
            if info is not None:
                cards.append(info.display_cards)
                statuses.append(info.display_status)
            else:
                cards.append("?")
                statuses.append(cache_copy.get(r.label, "?"))

        self._syncing = True
        try:
            self["list_label"].setList(labels)
            self["list_host"].setList(hosts)
            self["list_port"].setList(ports)
            self["list_state"].setList(states)
            self["list_file"].setList(files)
            self["list_cards"].setList(cards)
            self["list_status"].setList(statuses)
        finally:
            self._syncing = False

        if self.readers:
            idx = min(self.current_index, len(self.readers) - 1)
            if idx < 0:
                idx = 0
            self.current_index = idx
            self.setIndex(idx, force=True)

    def setIndex(self, idx, force=False):
        if self._syncing or not self.readers:
            return
        idx = max(0, min(idx, len(self.readers) - 1))
        if not force and idx == self.current_index:
            return
        self._syncing = True
        try:
            self.current_index = idx
            for name in ("list_label", "list_host", "list_port",
                         "list_state", "list_file", "list_cards",
                         "list_status"):
                widget = self[name]
                try:
                    if hasattr(widget, "setCurrentIndex"):
                        widget.setCurrentIndex(idx)
                    elif hasattr(widget, "moveToIndex"):
                        widget.moveToIndex(idx)
                    elif (hasattr(widget, "instance")
                          and widget.instance is not None):
                        widget.instance.moveToIndex(idx)
                except Exception:
                    pass
        finally:
            self._syncing = False

    def sync_lists(self):
        if self._syncing:
            return
        for name in ("list_label", "list_host", "list_port",
                     "list_state", "list_file", "list_cards",
                     "list_status"):
            try:
                widget = self[name]
                idx = None
                if hasattr(widget, "getSelectedIndex"):
                    idx = widget.getSelectedIndex()
                elif hasattr(widget, "getCurrentIndex"):
                    idx = widget.getCurrentIndex()
                elif (hasattr(widget, "instance")
                      and widget.instance is not None):
                    idx = widget.instance.getCurrentIndex()
            except Exception:
                continue
            if idx is not None and idx >= 0 and idx != self.current_index:
                self.setIndex(idx)
                break

    def moveUp(self):
        if self.readers and not self._syncing:
            if self.current_index <= 0:
                self.setIndex(len(self.readers) - 1)
            else:
                self.setIndex(self.current_index - 1)

    def moveDown(self):
        if self.readers and not self._syncing:
            if self.current_index >= len(self.readers) - 1:
                self.setIndex(0)
            else:
                self.setIndex(self.current_index + 1)

    # ------------------------------------------------------------------
    #  Settings Menu
    # ------------------------------------------------------------------
    def openSettingsMenu(self):
        self.session.openWithCallback(
            self._after_settings_menu,
            SettingsMenu,
            self._on_emulator_changed)

    def _after_settings_menu(self, *args):
        if self._closing:
            return
        try:
            keep_label = self._current_label()

            self._active_softcam = detect_active_softcam()
            self._setup_clients()
            self._start_polling()

            self.loadReaders()
            self._restore_selection(keep_label)

            self.refreshLists()
            self._schedule_oscam_refresh(delay_ms=500,
                                          immediate_first=True)
        except Exception as e:
            logger.log("ReaderManager", "Reconfigure error: %s" % e)

    def _on_emulator_changed(self):
        if self._closing:
            return
        try:
            logger.log("ReaderManager",
                       "Emulator state changed - reloading readers")
            self._active_softcam = detect_active_softcam()
            self._setup_clients()
            self._start_polling()
            self.loadReaders()
        except Exception as e:
            logger.log("ReaderManager",
                       "emu change reload error: %s" % e)

    # ------------------------------------------------------------------
    #  LogViewer
    # ------------------------------------------------------------------
    def openLog(self):
        try:
            self.session.open(LogViewer)
        except Exception as e:
            logger.log("ReaderManager", "openLog failed: %s" % e)

    # ------------------------------------------------------------------
    #  View Reader
    # ------------------------------------------------------------------
    def viewReader(self):
        if not self.readers:
            self["status"].setText("No reader to display")
            return

        try:
            from .reader_view import ReaderView
        except Exception as e:
            self.session.open(MessageBox,
                "Failed to load reader view: %s" % str(e),
                MessageBox.TYPE_ERROR, timeout=5)
            return

        r = self.readers[self.current_index]
        label = getattr(r, "label", "") or ""

        api_status = None
        try:
            active = self._get_active_details()
            with self._data_lock:
                api_status = active.get(label)
        except Exception as e:
            logger.log("ReaderManager",
                       "viewReader api lookup failed: %s" % e)

        try:
            self.session.openWithCallback(
                self._after_view,
                ReaderView,
                r,
                self._on_reader_changed,
                api_status)
        except Exception as e:
            self.session.open(MessageBox,
                "ReaderView error: %s" % str(e),
                MessageBox.TYPE_ERROR, timeout=5)

    def _after_view(self, *args, **kwargs):
        self.loadReaders()
        self._schedule_oscam_refresh(delay_ms=2000,
                                      immediate_first=True)

    def _on_status_update(self, label, status, auth=None):
        if label and status:
            active = self._get_active_details()
            if label not in active:
                with self._data_lock:
                    self.status_cache[label] = status
            self.refreshLists()

    def _on_reader_changed(self, reader):
        if reader is None:
            try:
                del self.readers[self.current_index]
            except Exception:
                pass
            self.readers = self._sort_readers(self.readers)
            if self.current_index >= len(self.readers):
                self.current_index = max(0, len(self.readers) - 1)
            self.refreshLists()
            self["status"].setText("Reader deleted - refreshing...")
            self.auto_restart_cam("Reader deleted")
        else:
            old_label = None
            try:
                old_label = self.readers[self.current_index].label
            except Exception:
                pass
            try:
                self.readers[self.current_index] = reader
            except Exception:
                pass
            self.readers = self._sort_readers(self.readers)
            new_label = getattr(reader, "label", None) or old_label
            self._restore_selection(new_label)
            self.refreshLists()

            active_client = (self._ncam_client
                             if self.current_file == NCAM_FILE
                             else self._oscam_client)
            if getattr(reader, "enabled", True):
                if not active_client:
                    self._queue.enqueue(reader, priority=2,
                                        reason="edit")
                self["status"].setText(
                    "%s -> ON - refreshing..." % reader.label)
            else:
                with self._data_lock:
                    self.status_cache.pop(reader.label, None)
                self._queue.remove(reader.label)
                self["status"].setText("%s -> OFF" % reader.label)

            self.auto_restart_cam(
                "Reader %s updated" % reader.label)

    # ------------------------------------------------------------------
    #  Editor result verification
    # ------------------------------------------------------------------
    def _verify_reader_in_file(self, reader):
        try:
            if not self._file_exists(reader.source_file):
                logger.log("ReaderManager",
                    "verify: file missing %s" % reader.source_file)
                return False
            labels = {r.label for r in
                      ReaderParser().parse_file(reader.source_file)}
            if (reader.label or "") not in labels:
                logger.log("ReaderManager",
                    "verify: label '%s' not found in %s"
                    % (reader.label, reader.source_file))
                return False
            return True
        except Exception as e:
            logger.log("ReaderManager", "verify error: %s" % e)
            return False

    # ------------------------------------------------------------------
    #  Unified editor result handler
    # ------------------------------------------------------------------
    def _handle_editor_result(self, reader, is_edit):
        if not reader:
            return

        if not self._verify_reader_in_file(reader):
            self.session.open(
                MessageBox,
                "Save verification failed:\n"
                "Reader '%s' was not found in:\n%s"
                % (getattr(reader, "label", "?"), reader.source_file),
                MessageBox.TYPE_ERROR, timeout=6)
            return

        try:
            on_disk = ReaderParser().parse_file(reader.source_file)
            for r in on_disk:
                if r.label == reader.label:
                    r.source_file = reader.source_file
                    r.source_tag = self._file_tag(self.current_file)
                    reader = r
                    break
        except Exception as e:
            logger.log("ReaderManager", "re-read failed: %s" % e)

        if reader.source_file != self.current_file:
            reader.source_file = self.current_file
            reader.source_tag = self._file_tag(self.current_file)

        if is_edit:
            try:
                self.readers[self.current_index] = reader
            except Exception:
                self.readers.append(reader)
        else:
            self.readers.append(reader)

        self.readers = self._sort_readers(self.readers)
        idx = self._find_index_by_label(getattr(reader, "label", ""))
        if idx >= 0:
            self.current_index = idx
        self.refreshLists()

        active_client = (self._ncam_client
                         if self.current_file == NCAM_FILE
                         else self._oscam_client)
        action_word = "Updated" if is_edit else "Added"

        if getattr(reader, "enabled", True):
            if not active_client:
                self._queue.enqueue(
                    reader, priority=2,
                    reason="edit" if is_edit else "add")
            self["status"].setText(
                "%s: %s - refreshing..." % (action_word, reader.label))
        else:
            with self._data_lock:
                self.status_cache.pop(reader.label, None)
            self._queue.remove(reader.label)
            self["status"].setText(
                "%s: %s (OFF)" % (action_word, reader.label))

        self.auto_restart_cam(
            "Reader %s %s"
            % (reader.label, "updated" if is_edit else "added"))

    # ------------------------------------------------------------------
    #  Add / Edit / Delete / Toggle
    # ------------------------------------------------------------------
    def addReader(self):
        if not self._file_exists(self.current_file):
            self.session.open(
                MessageBox,
                "Cannot add: file not found:\n%s" % self.current_file,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        try:
            from .reader_dialog import ReaderEditor
        except Exception as e:
            self.session.open(MessageBox,
                "Cannot load editor: %s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        api_module = None
        if self.current_file == NCAM_FILE:
            api_module = ncamapi
        else:
            api_module = oscamapi

        self.session.openWithCallback(
            self._on_editor_done_add,
            ReaderEditor, None, self.current_file, api_module)

    def editReader(self):
        if not self.readers:
            self["status"].setText("No reader to edit")
            return

        try:
            r = self.readers[self.current_index]
        except Exception:
            self["status"].setText("Invalid selection")
            return

        if not self._file_exists(r.source_file):
            self.session.open(
                MessageBox,
                "Cannot edit: file not found:\n%s" % r.source_file,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        try:
            from .reader_dialog import ReaderEditor
        except Exception as e:
            self.session.open(MessageBox,
                "Cannot load editor: %s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        api_module = None
        if "ncam" in (r.source_file or "").lower():
            api_module = ncamapi
        else:
            api_module = oscamapi

        self.session.openWithCallback(
            self._on_editor_done_edit,
            ReaderEditor, r, r.source_file, api_module)

    def _on_editor_done_add(self, reader):
        self._handle_editor_result(reader, is_edit=False)

    def _on_editor_done_edit(self, reader):
        self._handle_editor_result(reader, is_edit=True)

    def deleteReader(self):
        if not self.readers:
            return
        r = self.readers[self.current_index]
        label = r.label
        self.session.openWithCallback(
            lambda ans: self._on_delete_confirm(ans, label),
            MessageBox,
            "Delete reader: %s ?" % label, MessageBox.TYPE_YESNO)

    def _on_delete_confirm(self, answer, label):
        if not answer:
            return
        target = None
        for i, r in enumerate(self.readers):
            if (r.label or "") == (label or ""):
                target = i
                break
        if target is None:
            self["status"].setText(
                "Reader not found (already removed?)")
            return

        r = self.readers[target]
        try:
            ReaderParser().remove_from_file(r)
        except Exception as e:
            logger.log("ReaderManager", "remove error: %s" % e)
            self.session.open(MessageBox,
                "Delete failed: %s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        with self._data_lock:
            self.status_cache.pop(label, None)
        self.oscam_details.pop(label, None)
        self.ncam_details.pop(label, None)
        self._queue.remove(label)

        try:
            del self.readers[target]
        except Exception:
            pass

        self.readers = self._sort_readers(self.readers)
        if self.current_index >= len(self.readers):
            self.current_index = max(0, len(self.readers) - 1)
        self.refreshLists()
        self["status"].setText("Deleted %s - refreshing..." % label)
        self.auto_restart_cam("Reader %s deleted" % label)

    # ------------------------------------------------------------------
    #  Toggle ON/OFF + Restart directly
    # ------------------------------------------------------------------
    def toggleState(self):
        if not self.readers:
            logger.log("ReaderManager", "toggle: no readers")
            return

        r = self.readers[self.current_index]
        old_enabled = r.enabled
        new_enabled = not old_enabled

        logger.log("ReaderManager",
                   "toggle: label=%r old=%s new=%s file=%s"
                   % (r.label, old_enabled, new_enabled, r.source_file))

        r.enabled = new_enabled

        try:
            ReaderParser().write_single(r, r.source_file)
            logger.log("ReaderManager",
                       "toggle: write_single OK for %r" % r.label)
        except Exception as e:
            r.enabled = old_enabled
            self.refreshLists()
            logger.log("ReaderManager", "toggle: write error: %s" % e)
            self.session.open(MessageBox,
                "Failed to change state:\n%s" % e,
                MessageBox.TYPE_ERROR, timeout=5)
            return

        if not r.enabled:
            with self._data_lock:
                self.status_cache.pop(r.label, None)
            self._queue.remove(r.label)

        self.refreshLists()
        state = "ON" if r.enabled else "OFF"
        self["status"].setText(
            "%s -> %s - restarting softcam..." % (r.label, state))

        active_client = (self._ncam_client
                         if self.current_file == NCAM_FILE
                         else self._oscam_client)
        if r.enabled and not active_client:
            self._queue.enqueue(r, priority=2, reason="edit")

        self._restart_directly("Reader %s set to %s" % (r.label, state))

    # ------------------------------------------------------------------
    #  Cleanup
    # ------------------------------------------------------------------
    def close(self):
        self._closing = True

        for attr in ("_oscam_poll_timer", "_ncam_poll_timer",
                     "_refresh_scheduled_timer", "_refresh_timer",
                     "_editor_timer", "_restart_timer"):
            timer = getattr(self, attr, None)
            if timer:
                try:
                    timer.stop()
                except Exception:
                    pass
                setattr(self, attr, None)

        try:
            self._queue.remove_listener(self._on_queue_result)
        except Exception:
            pass

        for name in ("list_label", "list_host", "list_port",
                     "list_state", "list_file", "list_cards",
                     "list_status"):
            try:
                self[name].onSelectionChanged.remove(self.sync_lists)
            except Exception:
                pass

        logger.log("ReaderManager", "Screen closed")
        Screen.close(self)


# =====================================================================
# Entry points
# =====================================================================
def main(session, **kwargs):
    session.open(ReaderManager)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Readers Manager",
            description="Manage Oscam & NCam readers via WebIF",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main),
        PluginDescriptor(
            name="Readers Manager Settings",
            description="Configure OSCam & NCam WebIF",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon="plugin.png",
            fnc=lambda session, **kw: session.open(SettingsMenu)),
    ]